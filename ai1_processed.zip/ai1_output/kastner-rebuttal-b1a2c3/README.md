# Kastner's Rebuttal: SOA Was One of Many Technologies

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner (rebuttal input); AI synthesis |
| Date | 2026-01-01 |
| Type | ai-response |
| Domain | Enterprise Software Architecture |
| License | CC-BY-4.0 |

## Abstract

A five-point AI-synthesized rebuttal correcting an overly SOA-centric framing of Peter S. Kastner's career. The document argues Kastner was a long-running technology translator across multiple eras—OLTP, databases, PCs, client-server, data warehousing, and SOA—rather than primarily 'the SOA guy.' It also contextualizes his cloud and open-source commentary within the actual enterprise buyer reality of the early 2000s, and highlights Aberdeen's free research distribution model that drove Alexa top-10 status in 1997.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 8 |
| observations.csv | 17 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (rebuttal input); AI synthesis (2026). Kastner's Rebuttal: SOA Was One of Many Technologies.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

ai-dialog, document-review
