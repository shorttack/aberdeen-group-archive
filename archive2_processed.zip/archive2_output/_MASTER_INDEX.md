# Kastner Video Transcript Archive — Master Index

> **Archive-2** | Archival Ingest Skill v16 | Processed 2026-04-09
> Peter S. Kastner video appearances: commercials, presentations, and TV programs

## Summary Statistics

| Metric | Count |
|--------|-------|
| Studies | 10 |
| Date range | 1988–2001 |
| Unique entities | 67 |
| Unique technologies | 81 |
| Total observations | 275 |

## Observation Types

- **expert-opinion**: 120
- **technology-assessment**: 51
- **market-data**: 33
- **actual-outcome**: 27
- **viability-prediction**: 22
- **personal-recollection**: 9
- **benchmark-result**: 7
- **strategy-classification**: 6

## Studies (Chronological)

| Title | Year | Importance | Relevance | Prescience | Entities | Technologies | Observations |
|-------|------|-----------|-----------|-----------|---------|-------------|-------------|
| [DEC Blue Monday Telecast: Transaction Processing Competitive Training (August 1, 1988)](transcript-dec-blue-monday-8-1-1988-dect-a89117/README.md) | 1988 | high | high | high | 14 | 20 | 45 |
| [Ingres Windows 4GL — Analyst and Customer Panel (May 1990)](transcript-ingres-windows-4gl-(may-1990)-a92e41/README.md) | 1990 | high | high | high | 3 | 8 | 27 |
| [Informix Competitive Update: RDBMS Market Analysis — February 17, 1994](transcript-informix-competitive-update-2-368bc6/README.md) | 1994 | high | high | high | 14 | 17 | 40 |
| [CNBC Technology Edge: IBM, DEC, and HP in Transition (August 6, 1994)](transcript-cnbc-8-6-1994-technology-edge-df458b/README.md) | 1994 | high | high | high | 17 | 10 | 30 |
| [Informix Universal Server Launch Event — December 1996](transcript-informix-universal-server-lau-6e0828/README.md) | 1996 | high | high | medium | 30 | 21 | 50 |
| [Crossroads Integration Middleware — Analyst Interview (June 1997)](transcript-crossroads-(6-1997)-eee416/README.md) | 1997 | medium | high | medium | 3 | 3 | 20 |
| [Crossroads Product Launch Event — Analyst Panel (June 1997)](transcript-crossroads-launch-(june1997)-461bde/README.md) | 1997 | high | high | high | 3 | 4 | 20 |
| [Crossroads Integration Middleware — Commercial Spot 1 (1997)](transcript-crossroads-ad-1-1997-a8c602/README.md) | 1997 | medium | high | medium | 6 | 2 | 15 |
| [Crossroads Integration Middleware — Commercial Spot 2 (1997)](transcript-crossroads-ad-2-f2b853/README.md) | 1997 | medium | high | medium | 3 | 2 | 12 |
| [MSNBC News Segment: AOL Modem Shortage and Service Crisis (2001)](transcript-msnbc-on-aol-modem-shortage-(-e1b733/README.md) | 2001 | medium | high | high | 8 | 4 | 16 |

## Collection Notes

- **Crossroads cluster**: Three transcripts cover overlapping Crossroads Integration Middleware events (June 1997); `crossroads-(6-1997)-eee416` and `crossroads-launch-(june1997)-461bde` are near-duplicate cuts of the same event.
- **DEC Blue Monday (1988)**: Kastner appeared as an internal DEC presenter/analyst, not yet at Aberdeen Group. This predates his Aberdeen co-founding.
- **Format mix**: 4 Crossroads commercial/launch spots, 3 TV news/panel appearances (CNBC, MSNBC), 3 vendor briefings (Informix ×2, Ingres).
- All `[DEFERRED]` entity and technology fields have been resolved via web verification (Phase 3).

## Repository

`github.com/shorttack/aberdeen-group-archive`

## License

CC-BY-4.0 — Peter S. Kastner
