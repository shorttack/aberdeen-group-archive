# CNBC Technology Edge: IBM, DEC, and HP in Transition (August 6, 1994)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1994-08-06 |
| Type | transcript |
| Domain | enterprise-hardware-market |
| License | CC-BY-4.0 |

## Abstract

Panel discussion on CNBC Technology Edge examining the strategic challenges facing IBM, Digital Equipment Corporation (DEC), and Hewlett-Packard as they transition from proprietary systems to open/client-server architectures. Panelists include Peter Kastner (Aberdeen Group), Stephen Roach (Morgan Stanley), George Tabak (Ingersoll Rand), and Pat Sochi (Teleport Communications Group). The discussion covers customer needs, open systems transition, DEC's viability concerns, Alpha/PowerPC/HP-Intel chip strategies, and the potential for further industry consolidation.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 17 |
| technologies.csv | 10 |
| observations.csv | 30 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1994). CNBC Technology Edge: IBM, DEC, and HP in Transition (August 6, 1994).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
