# CNBC Technology Edge: IBM, DEC, and HP in Transition (August 6, 1994)

> Archived from: transcript-cnbc-8-6-1994-technology-edge-df458b.txt
> Original publication date: 1994-08-06
> Author: Peter S. Kastner

---

## Original Document Text



CNBC 8_6_1994

⏰Sat, 11/16 13:19PM · 29mins

AI Notes

 
 Summary
 This episode of Technology Edge, hosted by Bruce Francis, focuses on the challenges faced by computer giants IBM, Digital Equipment Corporation (DEC), and Hewlett Packard (HP) as they adapt to changing market conditions. The discussion highlights how these companies are transitioning from proprietary systems to open systems and struggling to meet evolving customer needs. George Tabak from Ingersoll Rand, Stephen Roach from Morgan Stanley, Pat Sochi from Teleport Communications Group (TCG), and Peter Kastner from Aberdeen Group provide insights as industry experts and customers. They emphasize the importance of companies listening to customer needs, providing integrated solutions, and adapting to the shift towards client-server architecture. The experts give mixed reviews of the companies' progress, with HP generally seen as the most successful in transitioning, IBM showing signs of recovery, and DEC facing significant challenges. The discussion also touches on the future of these companies, the potential for further industry consolidation, and the changing role of technology in business productivity.
 Chapters
00:00:52 Introduction to the challenges faced by computer giants
 Bruce Francis introduces the topic, comparing the situation of IBM, Digital, and Hewlett Packard to dinosaurs facing extinction. He notes that these companies are being forced to reinvent themselves and adjust to changing times.
00:01:25 Shift from mainframe to client-server architecture
 The host explains the transition from mainframe dominance to client-server architecture, highlighting the increased pace of technological change and product introductions.
00:02:04 Evaluation of companies' transition efforts
 Experts assess the progress of HP, IBM, and DEC in transitioning their businesses. HP is seen as the most successful, IBM shows signs of recovery, while DEC faces significant challenges.
00:03:59 Introduction of expert panel
 Bruce Francis introduces the panel of experts: George Tabak from Ingersoll Rand, Stephen Roach from Morgan Stanley, Pat Sochi from TCG, and Peter Kastner from Aberdeen Group.
00:08:41 Discussion on customer needs and vendor responsiveness
 The panel discusses the importance of vendors listening to customer needs. Pat Sochi emphasizes that technology must help businesses complete their mission faster, better, and cheaper than competitors.
00:11:30 Changes in information technology marketplace
 Stephen Roach explains the shift in the user community, with businesses now focusing on measurable productivity paybacks from technology investments due to deregulation and globalization.
00:13:48 Transition to open systems
 The panel discusses the move from proprietary to open systems, evaluating the progress of IBM, HP, and DEC in this transition. HP is noted as being ahead due to their early commitment to open systems.
00:17:15 Concerns about Digital Equipment Corporation
 The experts express significant concerns about DEC's future, citing confused messaging, late entry into open systems, and internal turmoil.
00:20:49 Future of productivity and information technology
 Stephen Roach discusses the next phase of productivity push, emphasizing the transition from downsizing to rebuilding and laying out technology platforms for the 21st century.
00:23:15 Technological advancements and partnerships
 The panel discusses new computing platforms (Alpha, PowerPC, Intel-HP collaboration) and the increasing importance of partnerships between hardware and software vendors.
00:25:51 Conclusion and future outlook
 The discussion concludes with considerations about the future of IBM, DEC, and HP, potential industry consolidation, and the evolving role of technology in business strategies.
 Action Items
00:23:48 George Tabak suggested that vendors should partner with third-party providers to deliver integrated solutions rather than just commodities.
00:11:03 Pat Sochi emphasized that hardware vendors need to demonstrate how their technology can help businesses complete their mission faster, better, and cheaper than competitors.
00:12:12 Stephen Roach advised that computer companies need to appreciate the fundamental change in user community needs, focusing on measurable productivity paybacks.
00:18:30 Peter Kastner recommended that Digital Equipment Corporation needs to re-satisfy their installed VAX base to remain competitive.
00:27:08 Bruce Francis suggested that customers need to be careful about the choices they make and not just listen to the last salesman, as these decisions could affect their jobs.
 

Transcript

 00:29
Technology Edge is brought to you by Sequent Computer Systems. 

 00:32
SEQUENT, our business is your success. 

 00:52
Welcome to this edition of Technology Edge. I'm Bruce Francis. In the movie Jurassic Park, giant dinosaurs thought to be permanently extinct came back to life through genetic engineering. Well, reengineering of a different sort has been happening to several giant computer companies forced to reinvent themselves and adjust to changing times, or risk extinction. 

 01:14
Took 300 million years for dinosaurs to become extinct after they were obsolete. So these guys are dinosaurs, but they're dinosaurs that still have the opportunity, perhaps, of a metamorphosis. They can now turn into something else. 

 01:25
Back in the good old days, IBM, Digital, and Hewlett Packard were all clear leaders in the nascent information technology field. But the days when the mainframe dominated corporate America seemed like prehistoric times. 

 01:38
Today, cutting edge means client server. Big thing about that point in time is I would say that technology wasn't changing at the rate that you see it changing today. Product introduction was not every six months. 

 01:50
Product introduction was measured in years, and people were willing to wait. No one is willing to wait anymore, and that's left behemoth Hewlett Packard, IBM, and Digital equipment struggling to reinvent themselves and their products in order to compete. 

 02:04
Experts agree that so far Hewlett Packard has been the most successful in the transition. 

 02:09
Hewitt was in a position where they could make earlier changes, and they've benefited tremendously from it. They probably are the single biggest beneficiary of all the changes that are going on in the computer world. 

 02:21
They seem in terms of their products, to clearly understand they need shorter product development cycle times, lowering a lot of their internal costs, and they seem to be able to make moves like that. 

 02:31
Not so long ago, things at IBM looked so bleak, analysts began to call the legendary computer giant Big Black and Blue. Now, with recently announced solid quarterly earnings, the company appears to be on the road to recovery. 

 02:45
I think IBM is certainly further along in its transitions and has a good solid low end foundation to rest on, not to mention that it is and has been kind of the corporate factor through all the years. 

 03:01
You can't throw that away and customers aren't throwing that away. I think I'm pretty optimistic about that. 

 03:07
But at Digital, it's a different story. DEC hasn't been able to instill the same level of confidence. The company recently announced a major restructuring in hopes of resuscitating a bleeding balance sheet. 

 03:18
has been probably going through wrenching changes for some time now. They were late to really appreciate and then implement many of the changes and the result is they're still not, they still haven't hit what you could call ground zero. 

 03:34
All three companies still retain large customer bases and are confident they will be able to meet the challenges of the future. But experts say that future won't look anything like the glory days of the past. 

 03:45
So I don't know if any of these guys will ever revisit that again with the global competition and the other issues that they're facing. So success may be that they're still in business. Success may be that they're occupying a significant market share and they're viewed as a leader. 

 03:59
But success will never be that they're the only game in town. With more on these companies, their relationships with customers, and their efforts at transitioning, this week's panel of experts. George Tabak, director of corporate information systems for Ingersoll Rand, machinery and equipment company spends about $70 million a year on technology. 

 04:19
Ingersoll Rand buys from all three, IBM, Hewlett Packard, and Digital. Tabak gives them mixed reviews and advises companies not to put all their eggs in one basket. From our bureau in New York today, Stephen Roach, a principal at Morgan Stanley, where he assesses the impact of information technology on the productivity of American companies. 

 04:38
Also back here in the studio, Pat Sochi, vice president of management information systems for Teleport Communications Group, or TCG, a local telephone company that serves 20 markets across the company, caress the country that is, TCG is customer of both Digital and Hewlett Packard. 

 04:54
Well, he believes that both ought to pay more attention to customer needs. And Peter Kastner, vice president of Aberdeen Group. Kastner currently consults all three vendors. He's cynical though about Digital's chances, questions some of IBM's strategies for the future and gives Hewlett Packard the highest score in terms of being visionary. 

 05:14
We should mention today that IBM, Digital Equipment Corporation, and Hewlett Packard were all invited to join this discussion and respond to customer concerns, but they declined that invitation. That discussion is next, don't go away. 

 05:26
["The Future of Technology Edge"] Technology Edge is brought to you by Sequin Computer Systems. As the world leader in high-end open systems, we help you plan and manage your safe passage to open computing, because at Sequin, our business is your success. 

 06:10
The trip to open computing demands an experienced guide. Sequent computer systems. We start with a plan that aligns business goals and information systems. We identify a process for step-by-step implementation. 

 06:24
And we make a commitment to your certain success. For planning, process, and commitment for safe passage to open systems, call 1-800-237-8733. 

 06:41
Fellow travelers, life's a journey. Our friends and colleagues, lovers and loved ones, is it all part of a bigger picture? 

 06:51
connects us to each other. 

 06:53
Well, mobile ink? Only cellular service that has mobile ink makes it easy to connect with everyone, no matter where you are. 

 07:00
on that cosmic interstate, even if you don't know where you are. 

 07:05
Make sure your local cellular service has mobile link. Call 800-995-4000. 

 07:10
You will receive cash. Yes, cash. 

 07:14
cash for Pot-Tech Philippe, cash for Cartier. Heritage estate buyers will pay for it. 

 07:19
You cash for these men's wrist watches or the others I will list heritage is on a national search for watches We will help you with cash if you 

 07:27
own a Vacheron, Universal Geneve, Breitling, also Audemars, Movado, and the Kultra. Your watch can be worth thousands of dollars if it's a chronograph, moon phase, or repeater. This is an opportunity for you to receive cash for a watch that's gathering dust in 

 07:44
the drawer heritage estate buyers will pay you cash for the fine men's wrist watches we listed working or not if you don't call now you're losing money write down our number we're ready to pay top dollars now time means money call heritage 

 07:58
Call 1-800-851-1400 for cash or to trade up to a fine brand name watch. We will buy your watch working or not. Call 1-800-851-1400 for cash or trade now. 

 08:15
This is CNBC. 

 08:27
Welcome back. We've been looking at computer giants, IBM, Hewlett Packard, and digital. They are vendors in transition, but can these former titans adjust their business strategies quickly enough to compete in a rapidly changing technology landscape? 

 08:41
And what we're talking about here, a big common thread, has got to be listening to customers and identifying customers' needs. Is that a fair point to start, that these companies along the way stopped listening to or never did listen to what their customers needed? 

 09:01
I agree. I think basically what happens is they were so caught up within their own internal organizations and they felt that they had so much of the market share that they had all of the answers and they were not paying attention. 

 09:15
The market was moving quickly and they were not really coming up with the solutions that the people were asking for. We constantly talked to them about changes in some of the competition and the way they were marketing their product, the products themselves, and it was basically they would come back and they'd attempt to listen to you. 

 09:36
They'd basically give you the sales pitch that yes, we are trying to listen to you and we are trying to change, but in reality this is the only solution in town. The fastest growing part of IBM, Hewlett-Packard and Digital is their service business. 

 09:54
The margins are lower, but the reason for it is because customers really have so many different technologies they're trying to glue together today, the LANs, the client software, the databases, the downsizing, that they really need help in doing it. 

 10:08
That's why services are so important and the ball's been dropped on more than one occasion there. Is it fair to say that for a long time customers didn't need to be listened to as much as they do today? 

 10:20
And does that have to do with the changing way that businesses use computers? Yeah, I think the technology is more firmly implanted now in just about every industry that there is. And ever since the stock market crashed in 87, every company, every industry that I know of is much more profit-oriented, contained costs, lower expenses, and the only way to do that is through technology. 

 10:44
So when they come up with a new platform, a new computer, what I say is that's only a commodity to me. Show me how that's going to help me do my job and help us complete our mission of customer satisfaction to our customers faster, better, cheaper than our competition. 

 11:03
I'm in the communications industry and we believe that to be a commodity industry. The only differentiator is customer service and they've got to show us how they can help, how their technology can help us accomplish that mission. 

 11:15
Steve, I know this is an area that you've written about extensively. What changed in the marketplace for information technology and how businesses use computers? I think Bruce, there's been a real upheaval in the user community. 

 11:30
Gone are the days of open-ended technology acquisition that was evident throughout the 1970s, well into the 1980s. Our service sector, the banks, the telecommunications, the airlines, the retailers who used to buy each and every twist and turn of the product cycle are now facing their own competitive upheaval. 

 11:53
And they have now had to slow down their acquisition of technology, dedicating computers and communications equipment to measurable productivity paybacks. Because of deregulation, because of globalization, they cannot afford to be reckless in their technology acquisition programs. 

 12:12
That has been a fundamental change that I believe the computer industry has failed to appreciate focusing as they've always done on things like product cycles, faster chips, smaller machines, and all the things they've been enamored with over most of their long history. 

 12:27
So information technology is really being held to a higher standard and ones that I guess the vendors really did not appreciate in time. I believe that's true. And as long as the user community remains in such an intense state of upheaval, the technology vendor who fails to appreciate that will quickly become a member of Jurassic Park. 

 12:48
What responsibility do the customers have right now, customers of these companies, to better communicate that urgency of these computers are embedded in my business process, you've got to change and meet my needs. 

 13:03
What can customers do? Well, it's a two-way street. The companies certainly need to articulate what their business strategies are and ask the question, how can your technology help me to meet those business goals? 

 13:16
But then the computer companies have to respond on a case-by-case basis more and more. One thing that's been lost is the fact that many buyers have told us that they want to cut down the number of relationships they have, fewer but better and stronger partnerships. 

 13:32
Interesting now now one one part of that of there's been a lot of cry for customers for open systems less proprietary system Certainly IBM and and deck and and HP also fall in this category of vendors going from Proprietary to open systems, but let's talk some specifics. 

 13:48
How how is IBM capturing that that trend right now in the open system? So me yes, well, they're moving in with their RS 6000. That seems to be a fairly good Solution that they've come up with quickly. 

 14:01
I think I think they they really saw a Lot of competition with the Hewlett Packard where Hewlett Packard actually made the commitment to open systems probably before any of the other two and They had to catch up quickly Initially the the box was was not one that could really meet the demand of True applications, and they've I think they've reacted extremely well in that particular instance Hewlett Packard Well Hewlett Packard got started almost 10 years ago And they today have enormous experience years of experience on using the same risk silicon for both their proprietary HP 3000 machines which would compete with the AS 400 and Digitals Vax VMS They've also have the HP 9000 on the UNIX side Digitals just doing this now with their alpha products and IBM will next year slide in a risk chip underneath their AS 400 and Goose the speed of that up as well So we're seeing tremendous changes But one of the reasons HP is ahead in our opinion is because they've been doing it for almost 10 years now and have Learned from what the market wants deck is probably the slowest to learn in this category. 

 15:14
Would you agree with that? Yeah, they Were very slow in moving away from their proprietary VMS operating system, and they introduced the alpha much too soon Again going back to what I said earlier They introduced the platform the platform is meaningless to me unless I have software to run on it, and it's going to help my industry There are simply not a lot of applications running on alpha today and those that are not making use of the 64-bit architecture So they're still in transition. 

 15:45
They introduced the product much too soon They don't have the the products running on third party products running on the alphas yet And so they've sent a very confused message that coupled with their shift from Ultrix which was their past Entry into the open systems arena now does it have would have to be a complete migration from Ultrix to OSF Causing me just as much work turmoil its Expense and cost of human resources that it now so that I would now say well if I have to make that jump Just as well look at Sun HP and IBM because the cost is the same thought on that but it's not just technology What really concerns me about digital's direction is they've recently said they're going to focus on Selling more through channels which means indirectly to major companies and that they're going to focus on a thousand companies around the world That means that many more companies will have to call 1-800 digital They won't get the support that we were talking about earlier that companies think they need to to partner with our concern basically is the fact that We really need integrators to help us tie all of these solutions together and from what I understand They've got all segments of their business up for sale at this point in time and that's those businesses Their systems integration is one of their key jewels Golden eggs and it becomes difficult for us to really focus in on how how when vendors are in this kind of transition How big a concern is that for a buyer? 

 17:15
I don't I want to stay away from company X because I'm concerned about financial problems I'm concerned they have their eye off the ball I'm not confident that that the company is going to take me in the direction I should go I can tell you with three years ago digital and IBM were our two key solutions And we would we would have preferred to stay in it in that direction What basically what was happening is as mentioned earlier? 

 17:39
I mean digital basically committed to the open systems every time we sat down and talked about open systems We were getting confused messages between a VMS and the other various Operating systems that they had and the 64-bit architecture Too late too late For for in digital's case to move to open systems and they just let that that window go Well their business on the VAX VMS side is declining at a 20 to 40 percent rate. 

 18:14
And yet the company's now got almost 40 percent of their sales out of PCs. I mean the company is literally tearing itself apart internally and therefore our question is not whether they're going to pull out as Wall Street thinks they are but I'm bracing for the crash. 

 18:30
Would you tell customers not to buy a deck right now? Well, digital's install base will be there for a long time but I don't think the company understands how important it is to re-satisfy their installed VAX base. 

 18:44
Alright, we've lost more talk about it. We're going to take a short break right now. We'll continue our discussion in just a moment and go away. Technology Edge is brought to you by Sequent Computer Systems. 

 19:07
As the world leader in high-end open systems, we help you plan and manage your safe passage to open computing because at Sequent, our business. 

 19:15
This is your success. 

 19:30
Early Saturday morning, one can observe a little-known ritual. It's a gathering of like-minded souls awaiting the arrival of their financial advisor. One who foretold the rallying bonds, saw money being invested overseas before it left our shores, and who thousands turned to for advice on mutual funds. 

 19:53
But most remarkable is the fee this advisor charges. Three dollars an issue. To get this advisor to visit your home, subscribe to Barron's. It's easier to use and you'll receive this Barron's investment guide free. 

 20:08
This $13.95 value offers insights on stocks, global investing, and mutual funds. Everything you need to know to turn money into wealth. Get 13 weeks of Barron's and the investment guide all for only $34. 

 20:20
Call now toll-free in the continental U.S. 800-851-1400. That's 800-851-1400. 

 20:36
Welcome back. We've been taking a look at IBM Hewlett Packard in digital and their efforts to reposition themselves in a changing business environment. And going forward, we've been talking in our previous segment about how businesses use computers. 

 20:49
Steve Roach in New York, I was wondering how, what do you think the next phase of this push for productivity and quantifiable results from information technology, where is it going to take this area now? 

 21:02
Well, I think what we're seeing is a real transition now, Bruce, between the stage when the user community is downsizing and shedding a lot of inefficiencies in terms of workers as well as redundant processing facilities, and now looking beyond restructuring towards rebuilding and really laying out the technology platform and the efficiency and competitive platform for the 21st century. 

 21:32
And I think this is the exciting stage that the computer industry can really be an active player on. I think a lot of companies are running scared that all we're going to do now is cut, cut, cut. Of course, if that's what we do, that's tantamount to competitive suicide. 

 21:48
And I think we're now at the point, though, where our companies are starting to rehire, to look to the future, and reconfigurations of back offices, sales functions, and managerial functions will now have an increasingly larger technological content to them. 

 22:04
I think that's a very exciting opportunity for the computer company that is going to be the survivor in the 21st century. Nevertheless, there are going to be major pressures on this industry. Do you think there's more shakeout ahead based on the basic economics that are operating here? 

 22:21
I mean, the commoditization in certain parts of the business at the same time when you have very high R&D costs? Absolutely. I think consolidation is not just a buzzword, but it's a trend that's going to be with us for years, if not decades, to come. 

 22:37
And I think complacency has been a real historical problem in the computer industry, especially for large companies like IBM and DEC, who have had such an enormous franchise historically. They've learned, I think, very painfully that complacency is not going to fly in this new competitive era. 

 22:58
The competition isn't going to change. And as they are getting their act together, hopefully they will be players in this new competitive environment. Well, one major challenge to the complacency by all three of them, they've all staked out new areas for new computing platforms. 

 23:15
Alpha, a DEC with the Alpha chip, IBM with a PowerPC chip, and now Intel and Hewlett-Packard are going to be working together on their next generation. Where is the technology going to take these vendors? 

 23:29
Are they staking out firm ground for their futures? Well, I think the strategy is changing. Years ago, when I would have status meetings with my hardware vendor, it was my hardware vendor alone. Now my hardware vendor comes with a third party vendor together as a solution. 

 23:48
And ongoing statuses take place together because they realize together they will survive in my environment. Separately, they're irrelevant to me. The software without the hardware, the hardware without the software makes no sense. 

 24:00
So I see them having to partner with a lot of third parties, shed a lot of their own internal research and development, and leave that to specialized third parties to handle that in a cost-effective way, and then partner with those third parties to develop solutions rather than delivering the commodity. 

 24:18
I hear less interest with buyers like yourself about chips and platforms. I want business solutions. Even with these technological changes, have the companies got that message? Well, there's investment protection, too. 

 24:34
One of the reasons why mainframes will be around for a long, long time is because of all that software. As you commented, I think the HP Intel Alliance to build the future chips after the year 2000 says a lot to HP customers and also to Intel customers as to where all this is going. 

 24:52
So buying machines and setting applications in place today, you'll know they'll be around for a while. I also think for small providers like digital, says, wow, how am I going to get the economics of scale here to be a player to keep up? 

 25:07
That's tough. I think with this new object orientation and the way they build in the database updates and things of that nature, where the hardware vendors are trying to partner with a software vendor and come out with a solution that'll allow the applications to run faster is getting to be a big piece of the market as well with Apple, IBM, Motorola, and the OLE and different object-oriented updating and embedded technology. 

 25:37
I think that's going to play a significant role. It's hard to imagine a world without a deck, an IBM, or an HP, although 10 years ago, it had been hard to imagine a world dominated by Microsoft and Intel the way it is today. 

 25:51
Is it possible that one of the three companies we're talking about or more will not be around in a few years? Do you remember RCA? Do you remember Honeywell? Do you remember what happened to Wang? I mean, this is not all written in rock. 

 26:03
You don't get to stay around forever unless, as they say, you evolve the whole Jurassic Park theme. I could easily see, for example, we saw NCR being purchased by AT&T. I could see digital selling way below book value as it is today being picked up by some cash-rich company, perhaps an RBAC, and partnering with them for technology. 

 26:25
Another interesting difference I see in my relationship with the vendors is one hardware vendor was giving me an overall view of their technology. And they had there some people from Intel, which represented the chip manufacturer they were using. 

 26:40
And the underlying message was very subtle that if you go with us, you're not taking much of a risk because the same chips and the same processors are being used by other vendors as well. Though they still wanted all the business, they wanted to let me know that it was leverageable and it wasn't as big a risk. 

 26:57
And we could move the software over to another vendor if we weren't satisfied. If you're going to ask our final word, are customers going to get squeezed in this transition? Are they the ones who are going to lose as these vendors are finding their new models? 

 27:08
Customers have to be very careful about the choices that they make and not just listen to the last salesman in because you could be betting your job with the choices that you make. That's good advice for all of us. 

 27:19
That does it for this edition of Technology Edge. I want to thank all of our guests, George Tabak, Director of Corporate Information Systems for Ingersoll RAN. From our Bureau in New York, Stephen Roach, a Principal at Morgan Stanley. 

 27:31
Pat Sochi, Vice President of Management Information Systems for Teleport Communications Group, or TCG. And Peter Kastner, Vice President at Aberdeen Group. Once again, here at Technology Edge, we regret that IBM, Digital and Hewlett Packard all declined the opportunity to join this discussion. 

 27:46
Next week, as technology increasingly takes center stage in key business strategies, the CIO's role is expanding as well. As the point person on technology, the CIO must now also be capable of leading and inspiring change. 

 28:01
We'll take a look at the changing role of the CIO next week. For now, I'm Bruce Francis. Thanks for joining us. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-cnbc-8-6-1994-technology-edge-df458b |
| title | CNBC Technology Edge: IBM, DEC, and HP in Transition (August 6, 1994) |
| author | Peter S. Kastner |
| date | 1994-08-06 |
| type | transcript |
| subject_domain | enterprise-hardware-market |
| methodology | oral-history |
| source_file | transcript-cnbc-8-6-1994-technology-edge-df458b.txt |
| license | CC-BY-4.0 |

### Abstract

Panel discussion on CNBC Technology Edge examining the strategic challenges facing IBM, Digital Equipment Corporation (DEC), and Hewlett-Packard as they transition from proprietary systems to open/client-server architectures. Panelists include Peter Kastner (Aberdeen Group), Stephen Roach (Morgan Stanley), George Tabak (Ingersoll Rand), and Pat Sochi (Teleport Communications Group). The discussion covers customer needs, open systems transition, DEC's viability concerns, Alpha/PowerPC/HP-Intel chip strategies, and the potential for further industry consolidation.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Captures expert and customer sentiment at a pivotal transition point for three dominant enterprise vendors; Kastner's DEC skepticism proved prescient as DEC was acquired by Compaq in 1998. |
| **Relevance** | high | Kastner is a primary panelist providing authoritative analysis of IBM, DEC, and HP competitive positioning, directly reflecting his Aberdeen Group research. |
| **Prescience** | high | Kastner's warnings about DEC's confused messaging and decline proved accurate; his assessment of HP as most adaptable and IBM recovering were borne out over the following years. |

### Prescience Detail


**Prediction 1:** DEC acquisition prediction
- **Claimed:** Could easily see Digital selling way below book value; picked up by some cash-rich company, perhaps an RBOC, and partnering with them for technology
- **Year:** 1994
- **Confidence at time:** medium

**Actual Outcome 1:** DEC acquisition outcome
- **Result:** DEC was acquired by Compaq in 1998 for $9.6 billion—the largest tech acquisition to that date. DEC did not survive as an independent company; Compaq was subsequently acquired by HP in 2002.
- **Confidence:** verified
- **Notes:** Wikipedia: Digital Equipment Corporation; Britannica Money; LinkedIn posts confirming Jan 1998 acquisition date


### Entities Referenced (17)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Bruce Francis | person | defunct |  |
| Stephen Roach | person | active |  |
| George Tabak | person | active |  |
| Pat Sochi | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Morgan Stanley | firm | public |  |
| Ingersoll Rand | company | spun-off | Trane Technologies / Ingersoll Rand Inc. |
| Teleport Communications Group (TCG) | company | acquired | AT&T |
| Digital Equipment Corporation (DEC) | company | acquired | Hewlett Packard Enterprise |
| IBM (International Business Machines) | company | public |  |
| Hewlett-Packard (HP) | company | spun-off | HP Inc. / Hewlett Packard Enterprise |
| Sequent Computer Systems | company | acquired | IBM |
| Intel | company | public |  |
| Microsoft | company | public |  |
| NCR Corporation | company | spun-off | NCR Voyix / NCR Atleos |
| AT&T | company | public |  |

### Technologies Referenced (10)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| DEC Alpha (AXP) | hardware | Digital Equipment Corporation | emerging | obsolete |
| VAX/VMS | platform | Digital Equipment Corporation | declining | legacy |
| IBM RS/6000 | hardware | IBM | growth | evolved |
| PowerPC | hardware | IBM/Apple/Motorola | emerging | evolved |
| HP PA-RISC | hardware | Hewlett-Packard | mature | obsolete |
| HP-Intel IA-64 (Next Generation) | hardware | HP/Intel | emerging | obsolete |
| Client-Server Architecture | framework |  | growth | evolved |
| Open Systems / UNIX | platform |  | growth | evolved |
| IBM AS/400 | hardware | IBM | mature | legacy |
| Object-Oriented Technology | framework |  | emerging | standard |

### Observation Summary

- Total observations: 30
- By type: expert-opinion: 24, market-data: 2, actual-outcome: 2, viability-prediction: 1, personal-recollection: 1
