# Crossroads Integration Middleware — Analyst Interview (June 1997)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1997-06-01 |
| Type | transcript |
| Domain | enterprise application integration |
| License | CC-BY-4.0 |

## Abstract

A ~4-minute analyst interview segment featuring Peter Kastner of Aberdeen Group discussing enterprise application integration challenges and validating the Crossroads solution. Content closely parallels the Crossroads launch video (transcript-crossroads-launch-(june1997)-461bde) with some speaker attribution differences. Kastner covers the same core market data: no US company fully integrated, $1–5M per-application integration costs, $50–$100B US in-house programmer spend, and Crossroads' industry-of-collaborations approach. This version ends with Kastner's 'Promised Land' statement without the trailing question visible in the launch video.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 3 |
| observations.csv | 20 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1997). Crossroads Integration Middleware — Analyst Interview (June 1997).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
