# Crossroads Integration Middleware — Analyst Interview (June 1997)

> Archived from: /home/user/workspace/archive2_raw/transcript-crossroads-(6-1997)-eee416.txt
> Original publication date: 1997-06-01
> Author: Peter S. Kastner

---

## Original Document Text



crossroads (6:1997)

⏰Sat, 11/16 15:37PM · 4mins

AI Notes

 
 Summary
 The meeting transcript discusses the challenges and potential solutions in integrating diverse software applications within organizations. Speaker0 highlights the reality of businesses using various application providers, operating systems, and hardware. Speaker1 emphasizes that no single software company can cater to all business needs, leading to companies purchasing packages that best fit their models. Speaker2 points out the downside of this approach: customers must integrate these disparate systems themselves, which is often a costly and time-consuming process. Speaker1 mentions that no U.S. company has fully integrated its front and back office applications, with integration costs often reaching millions of dollars. Speaker2 notes that U.S. companies spend between $50 and $100 billion on in-house programmers for integration. The speakers discuss the difficulties and expenses associated with custom programming and maintenance. Speaker0 suggests that a technology capable of cost-effectively integrating these disparate systems would be compelling. Speaker1 introduces Crossroads as a potential solution, describing it as a 'great idea' after following their technology and market response. Speaker0 and Speaker1 explain that Crossroads is attempting to solve the entire integration problem by building an industry of collaborations, enabling plug-and-play functionality for various applications. Speaker2 emphasizes that Crossroads allows for the creation of industry-specific and company-specific solutions in a multi-vendor way, working together as if built by a single vendor. The speakers conclude by highlighting the uniqueness of Crossroads' approach and its potential to simplify and accelerate the integration of best-of-breed applications.
 Chapters
00:00:07 The reality of diverse software ecosystems
 Speaker0 and Speaker1 discuss the reality of businesses using various application providers, operating systems, and hardware. They emphasize that no single software company can cater to all business needs, leading companies to purchase packages that best fit their specific models.
00:00:40 Challenges of integrating disparate systems
 Speaker2 and Speaker1 highlight the difficulties customers face in integrating best-of-breed applications. They mention that no U.S. company has fully integrated its front and back office applications, with integration costs often reaching one to five million dollars. Speaker2 notes that U.S. companies spend between $50 and $100 billion on in-house programmers for integration.
00:01:25 The burden of custom programming
 Speaker2 and Speaker1 discuss the challenges of custom programming for integration. They emphasize the enormous expense and ongoing maintenance requirements, with Speaker1 stating that the current situation is 'breaking' and causing 'real difficulty'.
00:02:01 Introduction of Crossroads as a potential solution
 Speaker1 introduces Crossroads as a promising solution to the integration problem. Speaker0 and Speaker1 explain that Crossroads is attempting to solve the entire integration issue by building an industry of collaborations, enabling plug-and-play functionality for various applications.
00:02:58 Advantages of the Crossroads approach
 Speaker2 emphasizes that Crossroads allows for the creation of industry-specific and company-specific solutions in a multi-vendor way, working together as if built by a single vendor. Speaker1 notes the uniqueness of Crossroads' approach, while Speaker2 highlights its potential to simplify and accelerate the integration of best-of-breed applications.
 Action Items
00:01:45 Speaker0 mentioned exploring technologies that can cost-effectively integrate disparate systems.
00:02:01 Speaker1 suggested following up on Crossroads' technology and market response.
00:03:16 Speaker2 proposed considering Crossroads as a solution for simplifying and accelerating the integration of best-of-breed applications.

Transcript

Speaker 1 
The real world is that there are a lot of good application database providers, a lot of good hardware providers, a lot of good operating system providers, and people are going to choose products and services that they feel they need to do their jobs best. 

Peter Kastner 
No software company can create all the nuances of all the ways to build software so people have bought the packages that best fit their particular business models. 

Speaker 3 
The downside of buying a best-of-breed set of applications is the customer is the one who has to tie them all together. And that is usually an enormous task that takes a long time. 

Peter Kastner 
There isn't a single company in the United States today that has integrated its front office and back office applications completely. It's not atypical to have a company spend seven figures, one to five million dollars to glue individual applications to other applications within the organization. 

Speaker 3 
They're spending on in-house programmers anywhere between $50 and $100 billion just in the U.S. alone. We've heard of several large projects that have been in the implementation phase for well over a year, and companies are having second thoughts about whether they made the right decision. 

Speaker 3 
They're trying to be software developers, but they don't want to be. 

Peter Kastner 
It's all breaking. And we're in real difficulty now in trying to glue all this together. Requires lots of custom programming at enormous expense. And as soon as you do that programming, you gotta maintain it for the whole life of the system. 

Speaker 1 
If you could come along with a technology that would help marry these disparate systems in a cost-effective way, that would be a very compelling story. 

Peter Kastner 
When we first met with Crossroads a year ago, when they were not much bigger than three people in a phone booth, we heard the story and said, wow, this is too good to be true. But we followed the company and followed their technology and talked to the marketplace and the answer is a resounding, this is a great idea. 

Speaker 1 
is really attempting to solve the entire problem. That's what makes the crossroad solution intriguing. 

Peter Kastner 
Crossroads is going out and building a whole industry of collaborations so that the applications that people buy will automatically be enabled because it's basically plug and play. 

Speaker 1 
Companies in the past have had to choose between purchasing a single application suite across all of their business functions and integrating best of breed applications. What Crossroads provides is a way that companies can have the best of both worlds. 

Speaker 3 
So now for the first time, we can build industry-specific and company-specific solutions in a multi-vendor way that work together as though they were built by a single vendor. 

Speaker 1 
In the past, that choice just didn't exist. 

Peter Kastner 
There is no other company doing exactly what Crossroads is doing. 

Speaker 3 
If you don't use the Crossroads solution you're looking at a huge investment to get your best of breed applications working together and with it it's going to be much simpler faster and easier for you. 

Peter Kastner 
If it works, it's marvelous. We're entering the Promised Land. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-crossroads-(6-1997)-eee416 |
| title | Crossroads Integration Middleware — Analyst Interview (June 1997) |
| author | Peter S. Kastner |
| date | 1997-06-01 |
| type | transcript |
| subject_domain | enterprise application integration |
| methodology | oral-history |
| source_file | /home/user/workspace/archive2_raw/transcript-crossroads-(6-1997)-eee416.txt |
| license | CC-BY-4.0 |

### Abstract

A ~4-minute analyst interview segment featuring Peter Kastner of Aberdeen Group discussing enterprise application integration challenges and validating the Crossroads solution. Content closely parallels the Crossroads launch video (transcript-crossroads-launch-(june1997)-461bde) with some speaker attribution differences. Kastner covers the same core market data: no US company fully integrated, $1–5M per-application integration costs, $50–$100B US in-house programmer spend, and Crossroads' industry-of-collaborations approach. This version ends with Kastner's 'Promised Land' statement without the trailing question visible in the launch video.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | medium | Appears to be a variant cut of the same June 1997 event as the launch video; some speaker attributions differ (content attributed to Speaker 3 vs. Peter Kastner). Valuable as a cross-reference for validating quotes and speaker identification. |
| **Relevance** | high | Reinforces Kastner's consistent messaging on EAI market sizing and Crossroads endorsement; slight differences in speaker attribution offer insight into how the commercial was assembled. |
| **Prescience** | medium | Same core claims as the launch video; see prescience rationale for transcript-crossroads-launch-(june1997)-461bde. The 'Promised Land' framing aged poorly given Crossroads' eventual trajectory. |

### Prescience Detail


**Prediction 1:** optimistic-forecast
- **Claimed:** If it works, it's marvelous. We're entering the Promised Land.
- **Year:** 1997
- **Confidence at time:** medium

**Actual Outcome 1:** competitive-uniqueness-actual
- **Result:** Crossroads integration middleware did not achieve long-term competitive uniqueness. The EAI middleware market became dominated by larger players (IBM MQ, Tibco, webMethods, BEA). Crossroads as a standalone product did not survive.
- **Confidence:** medium
- **Notes:** No evidence of Crossroads surviving as a major commercial product beyond late 1990s; EAI market consolidated into larger platforms


### Entities Referenced (3)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Crossroads | company | defunct |  |

### Technologies Referenced (3)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Crossroads Integration Middleware | middleware | Crossroads | launch | obsolete |
| Enterprise Application Integration (EAI) | middleware | generic | emerging | evolved |
| Best-of-Breed Enterprise Applications | application | multiple | mainstream | legacy |

### Observation Summary

- Total observations: 20
- By type: expert-opinion: 9, technology-assessment: 4, market-data: 3, actual-outcome: 2, personal-recollection: 1, viability-prediction: 1
