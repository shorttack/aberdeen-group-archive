# Crossroads Integration Middleware — Commercial Spot 1 (1997)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1997-11-16 |
| Type | transcript |
| Domain | enterprise application integration |
| License | CC-BY-4.0 |

## Abstract

A ~2-minute commercial advertisement in which Peter Kastner of Aberdeen Group advocates for Crossroads integration middleware. Kastner frames enterprise application integration as a 'buy versus make' decision, cites integration costs of $1.5–$4 million for two major applications, and claims Crossroads can reduce 5–7-year maintenance costs by 40–90%. A Crossroads representative adds that long-term savings and faster adoption of new business processes provide competitive advantage.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 6 |
| technologies.csv | 2 |
| observations.csv | 15 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1997). Crossroads Integration Middleware — Commercial Spot 1 (1997).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
