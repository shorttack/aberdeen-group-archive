# Crossroads Integration Middleware — Commercial Spot 2 (1997)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1997-11-16 |
| Type | transcript |
| Domain | enterprise application integration |
| License | CC-BY-4.0 |

## Abstract

A ~1-minute commercial advertisement for Crossroads integration middleware. Peter Kastner declares that 'getting ahead has been almost impossible' and that 'no other company is doing exactly what Crossroads is doing.' Other speakers frame modern business complexity and rising customer demands for integrated functionality as the pain point. Crossroads is positioned as a unique, plug-and-play packaged solution for enterprise application integration, described as 'process wear for enterprise applications.'

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 2 |
| observations.csv | 12 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1997). Crossroads Integration Middleware — Commercial Spot 2 (1997).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
