# Crossroads Product Launch Event — Analyst Panel (June 1997)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1997-06-01 |
| Type | transcript |
| Domain | enterprise application integration |
| License | CC-BY-4.0 |

## Abstract

A ~4-minute product launch video for Crossroads integration middleware (June 1997), featuring Peter Kastner of Aberdeen Group alongside Crossroads representatives. Kastner describes the enterprise integration pain: no US company has fully integrated front and back office applications, typical glue-code projects cost $1–5 million and take over a year, and US companies spend $50–100 billion on in-house integration programmers. Kastner recounts Aberdeen's initial skepticism when Crossroads was 'three people in a phone booth' but confirms validation after following the company. The launch video positions Crossroads as the first plug-and-play, industry-of-collaborations approach to solving the entire EAI problem.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 4 |
| observations.csv | 20 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1997). Crossroads Product Launch Event — Analyst Panel (June 1997).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
