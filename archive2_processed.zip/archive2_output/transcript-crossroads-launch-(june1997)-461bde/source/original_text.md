# Crossroads Product Launch Event — Analyst Panel (June 1997)

> Archived from: /home/user/workspace/archive2_raw/transcript-crossroads-launch-(june1997)-461bde.txt
> Original publication date: 1997-06-01
> Author: Peter S. Kastner

---

## Original Document Text



Crossroads launch (6:1997)

⏰Sat, 11/16 15:37PM · 4mins

AI Notes

 
 Summary
 The meeting transcript discusses the challenges of integrating diverse software applications within organizations. Speaker1 and Speaker2 highlight the difficulties companies face in connecting their front and back office systems, often spending millions of dollars and extensive time on integration efforts. Speaker0 introduces the concept of a technology that could efficiently merge these disparate systems, which is revealed to be Crossroads' solution. Speaker1 expresses initial skepticism about Crossroads but confirms its potential after market validation. The speakers emphasize that Crossroads' approach is unique in attempting to solve the entire integration problem by building an industry of collaborations, enabling plug-and-play functionality between applications. This solution allows companies to benefit from both integrated systems and best-of-breed applications. The transcript concludes with Speaker0 posing a question about the biggest problem in enterprise computing today.
 Chapters
00:00:07 The challenge of integrating diverse software applications
 Speaker0 and Speaker1 discuss the reality of diverse application providers in the market. Companies choose products that best fit their needs, but this leads to integration challenges. Speaker1 mentions that no U.S. company has fully integrated its front and back office applications.
00:00:55 The high cost of application integration
 Speaker1 reveals that companies typically spend between $1-5 million to integrate individual applications. Speaker2 adds that U.S. companies spend $50-100 billion on in-house programmers for integration. Some large projects have been in implementation for over a year, causing companies to reconsider their decisions.
00:01:44 The need for a cost-effective integration solution
 Speaker0 suggests that a technology capable of marrying disparate systems cost-effectively would be compelling. Speaker1 introduces Crossroads as a potential solution, initially met with skepticism but later validated by the market.
00:02:28 Crossroads' unique approach to integration
 Speaker1 explains that Crossroads is building an industry of collaborations, enabling plug-and-play functionality between applications. Speaker0 and Speaker2 emphasize that this approach allows companies to have the best of both worlds: integrated systems and best-of-breed applications.
00:03:10 The potential impact of Crossroads' solution
 Speaker1 states that no other company is doing exactly what Crossroads is doing. Speaker0 contrasts the simplicity of Crossroads' solution with the huge investment required for traditional integration methods. Speaker1 expresses optimism about the potential of the solution.
 Action Items
00:01:44 Speaker0 mentioned exploring technologies that can marry disparate systems cost-effectively.
00:02:00 Speaker1 suggested following up on Crossroads' technology and market validation.
00:02:57 Speaker2 proposed building industry-specific and company-specific solutions in a multi-vendor way.
00:03:18 Speaker0 recommended considering Crossroads' solution for simpler, faster, and easier integration of best-of-breed applications.

Transcript

Speaker 1 
The real world is that there are a lot of good application database providers, a lot of good hardware providers, a lot of good operating system providers, and people are going to choose products and services that they feel they need to do their jobs best. 

Peter Kastner 
No software company can create all the nuances of all the ways to build software so people have bought the packages that best fit their particular business models. The downside of buying a best-of-breed set of applications is the customer is the one who has to tie them all together, and that is usually an enormous task that takes a long time. 

Peter Kastner 
There isn't a set. 

Speaker 1 
single company in the United States today that is 

Speaker 3 
integrated its front office and back office applications completely. 

Peter Kastner 
It's not atypical to have a company spend seven figures, one to five million dollars to glue individual applications to other applications within the organization. 

Speaker 3 
They're spending on in-house programmers anywhere between $50 and $100 billion just in the U.S. alone. We've heard of several large projects that have been in the implementation phase for well over a year, and companies are having second thoughts about whether they made the right decision. 

Speaker 3 
They're trying to be software developers, but they don't want to be. 

Peter Kastner 
It's all breaking, and we're in real difficulty now in trying to glue all this together. Requires lots of custom programming at enormous expense, and as soon as you do that programming, you got to maintain it for the whole life of the system. 

Speaker 1 
If you could come along with a technology that would help marry these disparate systems in a cost-effective way, that would be a very compelling story. 

Peter Kastner 
When we first met with Crossroads a year ago, when they were not much bigger than three people in a phone booth, we heard the story and said, wow, this is too good to be true. But we followed the company and followed their technology and talked to the marketplace and the answer is a resounding, this is a great idea. 

Peter Kastner 
The new twist is 

Speaker 1 
It's really attempting to solve the entire problem. That's what makes the crossroad solution intriguing. 

Peter Kastner 
Crossroads is going out and building a whole industry of collaborations so that the applications that people buy will automatically be enabled because it's basically plug and play. 

Speaker 1 
Companies in the past have had to choose between purchasing a single application suite across all of their business functions and integrating best of breed applications. What Crossroads provides is a way that companies can have the best of both worlds. 

Speaker 3 
So now for the first time, we can build industry-specific and company-specific solutions in a multi-vendor way that work together as though they were built by a single vendor. 

Speaker 1 
In the past, that choice just didn't exist. 

Peter Kastner 
There is no other company doing exactly what Crossroads is doing. If you don't use the Crossroads solution, you're looking at... 

Speaker 1 
a huge investment to get your best of breed applications working together and with it it's going to be much simpler faster and easier for you. 

Peter Kastner 
If it works, it's marvelous. We're entering the Promised Land. 

Speaker 1 
Okay, what is the biggest problem with enterprise computing today? 

Peter Kastner 
Well, what we realized when we talked to a lot of 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-crossroads-launch-(june1997)-461bde |
| title | Crossroads Product Launch Event — Analyst Panel (June 1997) |
| author | Peter S. Kastner |
| date | 1997-06-01 |
| type | transcript |
| subject_domain | enterprise application integration |
| methodology | oral-history |
| source_file | /home/user/workspace/archive2_raw/transcript-crossroads-launch-(june1997)-461bde.txt |
| license | CC-BY-4.0 |

### Abstract

A ~4-minute product launch video for Crossroads integration middleware (June 1997), featuring Peter Kastner of Aberdeen Group alongside Crossroads representatives. Kastner describes the enterprise integration pain: no US company has fully integrated front and back office applications, typical glue-code projects cost $1–5 million and take over a year, and US companies spend $50–100 billion on in-house integration programmers. Kastner recounts Aberdeen's initial skepticism when Crossroads was 'three people in a phone booth' but confirms validation after following the company. The launch video positions Crossroads as the first plug-and-play, industry-of-collaborations approach to solving the entire EAI problem.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Richest of the three Crossroads videos; includes Aberdeen-sourced market sizing ($50–$100B US spend), Kastner's personal validation narrative, and detailed characterization of the EAI problem landscape in mid-1997. |
| **Relevance** | high | Directly documents Kastner's analyst assessment of Crossroads at launch, his firm's market data on integration costs, and his first-person account of evaluating Crossroads from pre-launch through market validation. |
| **Prescience** | high | The core thesis — that enterprise integration would remain costly and problematic without packaged middleware — proved accurate; the EAI market grew substantially. Kastner's framing anticipated the eventual dominance of integration platform vendors, though Crossroads specifically did not capture that market. |

### Prescience Detail


**Prediction 1:** optimistic-forecast
- **Claimed:** If it works, it's marvelous. We're entering the Promised Land.
- **Year:** 1997
- **Confidence at time:** medium

**Actual Outcome 1:** competitive-uniqueness-actual
- **Result:** Crossroads did not establish lasting competitive uniqueness in the integration middleware market, which consolidated around much larger enterprise vendors.
- **Confidence:** medium
- **Notes:** No evidence of Crossroads achieving market leadership or distinctive competitive position in the EAI space


### Entities Referenced (3)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Crossroads | company | defunct |  |

### Technologies Referenced (4)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Crossroads Integration Middleware | middleware | Crossroads | launch | obsolete |
| Enterprise Application Integration (EAI) | middleware | generic | emerging | evolved |
| Best-of-Breed Enterprise Applications | application | multiple | mainstream | legacy |
| Single-Vendor Application Suite | application | multiple | mainstream | evolved |

### Observation Summary

- Total observations: 20
- By type: expert-opinion: 7, technology-assessment: 6, market-data: 3, actual-outcome: 2, personal-recollection: 1, viability-prediction: 1
