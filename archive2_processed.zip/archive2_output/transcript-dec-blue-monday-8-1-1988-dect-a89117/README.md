# DEC Blue Monday Telecast: Transaction Processing Competitive Training (August 1, 1988)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1988-08-01 |
| Type | transcript |
| Domain | OLTP |
| License | CC-BY-4.0 |

## Abstract

Internal DEC sales training telecast (Blue Monday series) focused on positioning DEC's transaction processing (TP) products against IBM. Host Rod Sutherland is joined by Peter Kastner (DEC marketing executive, corporate systems group), Rick Case (competitive support), and Gary Hoppe (former IBM, now DEC competitive sales). The session covers the $21 billion TP market, DEC's less-than-5% market share with projections to triple, IBM vs DEC TP product comparison (ACMS/DEC-INTAC vs CICS/IMS DC), the debit-credit benchmark vs IBM's proprietary RAMP-C benchmark, five strategic TP sales areas, and selling tactics by customer level. Kastner was serving as a DEC internal marketing executive at this time (not yet at Aberdeen Group).

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 14 |
| technologies.csv | 20 |
| observations.csv | 45 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1988). DEC Blue Monday Telecast: Transaction Processing Competitive Training (August 1, 1988).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
