# DEC Blue Monday Telecast: Transaction Processing Competitive Training (August 1, 1988)

> Archived from: transcript-dec-blue-monday-8-1-1988-dect-a89117.txt
> Original publication date: 1988-08-01
> Author: Peter S. Kastner

---

## Original Document Text



DEC Blue Monday 8_1_1988

⏰Sat, 11/16 11:54AM · 61mins

AI Notes

 
 Summary
 This meeting transcript covers a Blue Monday telecast focused on transaction processing (TP) and Digital Equipment Corporation's (DEC) competitive position against IBM in this market. Rod Sutherland hosts the program with guests Rick Case, Peter Kastner, and Gary Hoppe. The discussion begins with an overview of the TP market, estimated at $21 billion annually, growing twice as fast as the overall computer market. Peter Kastner mentions that DEC currently has less than 5% market share but is projected to triple its size in TP over the next few years. The guests discuss the opportunities in TP across various industries and the benefits for customers, DEC, and sales representatives. Rick Case explains how to identify TP opportunities and distinguish between time-sharing and DEC TP environments. Gary Hoppe compares DEC's TP products (ACMS and DEC-INTAC) with IBM's offerings (CICS, IMS DC, and TPF). Peter Kastner outlines five strategic areas for TP: offloading existing mainframes, developing new software for mainframes, distributing applications, interoperability, and new applications. The discussion also covers selling tactics, performance benchmarks (debit-credit vs. RAMP-C), and how to position DEC against IBM in TP sales situations. The telecast concludes with a Q&A session addressing topics such as the debit-credit benchmark, case tools, and AS/400 performance estimates.
 Chapters
00:00:31 Introduction to Blue Monday and Transaction Processing
 Rod Sutherland introduces the Blue Monday telecast, focusing on transaction processing. He explains that Digital recently announced TP products to strengthen their position in this arena. The telecast aims to discuss how to compete with IBM in the TP environment.
00:03:33 Overview of the Transaction Processing Market
 Peter Kastner provides background on the TP market, stating it's worth $21 billion annually and growing twice as fast as the overall computer market. He mentions that Digital has less than 5% market share but is projected to triple its size in TP over the next few years.
00:04:56 Opportunities and Benefits of Transaction Processing
 Peter Kastner discusses the opportunities for TP across various industries, including banking, retail, manufacturing, healthcare, government, and education. He outlines the benefits for customers (increased productivity), Digital (business growth), and sales representatives (big ticket items and expansion opportunities).
00:07:13 Identifying Transaction Processing Opportunities
 Rick Case explains how to identify TP opportunities, distinguishing between time-sharing and DEC TP environments. He emphasizes that Digital can provide a mixed environment where some applications are under time-sharing and others under TP, which is unique among competitors.
00:09:52 Comparison of DEC and IBM TP Products
 Gary Hoppe compares DEC's TP products (ACMS and DEC-INTAC) with IBM's offerings (CICS, IMS DC, and TPF). He provides details on the number of licenses installed and the performance capabilities of each product.
00:12:26 Strategic Areas for Transaction Processing
 Peter Kastner identifies five strategic areas for TP: offloading existing mainframes, developing new software for mainframes, distributing applications, interoperability, and new applications. He explains the opportunities and advantages in each area.
00:14:48 Selling Tactics and Messaging for Different Audience Levels
 Peter Kastner discusses the messages that sales representatives should deliver to different levels of the customer organization (end-users, MIS department, and executives) regarding transaction processing solutions.
00:30:00 Performance Benchmarks and Positioning Against IBM
 Rick Case and Peter Kastner explain the debit-credit benchmark used to compare DEC and IBM systems. They discuss how to use this information in sales situations and how to position DEC's performance advantages against IBM.
00:49:49 Q&A Session and Closing Remarks
 The telecast concludes with a Q&A session addressing topics such as the debit-credit benchmark, case tools, and AS/400 performance estimates. The hosts provide final summaries and key takeaways for the sales force.
 Action Items
00:00:42 Sales representatives should use the Blue Monday evaluation form to provide feedback on the training.
00:01:05 Sales representatives should prepare questions during the telecast for the Q&A segment.
00:01:17 Sales representatives should call DTN2494800 or area code 6172764800 to ask questions during the Q&A segment.
00:57:29 Sales representatives should properly position IBM and Digital systems when comparing performance to showcase Digital's three-fold price performance advantage.
00:57:48 Sales representatives should aggressively look for new applications and business opportunities to fuel Digital's expansion in the TP market.
00:57:48 Sales representatives should use the interoperability story to show how customers can gradually switch to the VAX environment.
00:55:59 Sales representatives should contact the competitive hotline (296-4748 or 508-480-4748) for additional resources on transaction processing.
00:56:17 Sales representatives should provide feedback on the program through the all-in-one account (Risa Blondin at OGO) or VAX mail (CSTVAX::Blue Monday).
00:56:50 Sales representatives should fill out the Blue Monday evaluation forms before leaving.
 

Transcript

Rod Sutherland 00:31
Well, good evening and welcome to Blue Monday. I'm Rod Sutherland. Blue Monday is a series of monthly IBM competitive sales training telecasts designed to help you, the Digital sales team, compete more effectively with IBM. 

Rod Sutherland 00:42
To help us to determine a Blue Mondays meeting your training needs, we'd like you to fill out the Blue Monday evaluation form you have in front of you. A question and answer period with my guests will follow the discussion this evening. 

Rod Sutherland 00:53
And I encourage you to take advantage of the opportunity to talk with my guests on these telecasts. They're the experts. They can help you by providing you with information for your accounts and any activities in your accounts. 

Rod Sutherland 01:05
The Q&A segment of the program belongs to you, our audience. Now to make sure we get to as many of your questions as time allows, write down your questions during the telecast and be prepared immediately following the discussion tonight to call in with them. 

Rod Sutherland 01:17
We have several phone lines available to take your call, so there's no need to wait until the previous caller hangs up. The number to call with your questions is DTN2494800 or area code 6172764800. Tonight, we'll be discussing transaction processing. 

Rod Sutherland 01:35
Two weeks ago, Digital announced a set of transaction processing products designed to help strengthen our position in the transaction processing arena. If you saw the July 14th DVN telecast, you're familiar with the DECTP, Products and Services Digital can offer to its customers. 

Rod Sutherland 01:51
Tonight's telecast is focused not on features and benefits of the products versus IBM, but rather it will focus on how to compete with IBM in the transaction processing environment. We'll begin with a short introduction to the transaction processing market and then focus on identifying transaction processing opportunities, where to sell transaction processing solutions, the messages the sales rep should deliver to each level of the customer organization, 

Rod Sutherland 02:20
a Digital versus IBM strengths and weaknesses role play, performance issues, and finally, my guests will close with some specific selling tactics you should use when faced with a sales opportunity in the transaction processing environment. 

Rod Sutherland 02:34
My guests tonight are Rick Case, manager of competitive support organizations in the US sales support. Rick has been with Digital for 14 years. In addition to spending four years as an IBM competitive analyst in office marketing, Rick spent several years in field sales management. 

Rod Sutherland 02:52
Peter Kastner, Peter is a marketing executive in the corporate systems group. He's chairman of the DECTP task force on performance and competition. Peter joined Digital last year from Stratus, where he was responsible for marketing development and sales support. 

Rod Sutherland 03:08
And Gary Hoppe, Gary joined Digital two years ago from Applied Expert Systems, where he was vice president of sales. Prior to that, he spent almost 20 years in IBM in various sales and sales management positions, including Northeast regional sales manager. 

Rod Sutherland 03:23
Gary's currently manager of competitive sales consultants in the competitive support organization. Gentlemen, thanks for joining us here on Blue Monday tonight. Good to be here. Thank you very much. And let's get right into it. 

Rod Sutherland 03:33
Peter, if you could, could you give our audience some background on transaction processing, the environment, and how transaction processing fits and Digital fits into it? Sure, glad to. The market size is around $21 billion a year, and that is roughly twice the size of Digital. 

Peter Kastner 03:51
So it's a very large market. It's being driven by the fact that applications are moving from batch to a more online environment. This transition is due to competition, to cost pressures, to lower labor costs, just-in-time manufacturing, all those other things. 

Peter Kastner 04:04
And that ends up to the fact that it's growing at more than twice the speed of the whole computer market. So it's very attractive for Digital. Digital itself has less than a 5% market share. Now, the bad news of that is that up till now, we've been perceived as being not a major player in the TP market. 

Peter Kastner 04:22
But at a billion dollars in sales in transaction processing in the last year, we're worried about the size of tandem, which is perceived as being one of the leaders in transaction processing. The good news is that everyone projects the Digital, will grow to more than triple its size in transaction processing in the next several years. 

Peter Kastner 04:40
No, it certainly is good news. That kind of growth. Is there any set of customers that need transaction processing, or do all customers need transaction processing? I think that the real answer is that all customers need transaction processing in some part of their business. 

Peter Kastner 04:56
Examples being bank ATM systems where you can get your money out of the machine quickly instead of waiting for a teller. Retail point of sale is growing faster than any other form of transaction processing. 

Peter Kastner 05:07
Manufacturing has been called a sea of transactions as you look at the shop floor and the need for machines to get at the information and move it around. All other businesses, healthcare for example and hospital systems, government of course is a huge TP user and last just take the education market where things like student records systems are now online and run in a transaction processing environment. 

Rod Sutherland 05:30
So it's nearly everywhere. Well where do you see the opportunities and the benefits of transaction processing for the customer, for Digital company and for Digital sales reps at large, our audience here tonight? 

Peter Kastner 05:43
Well all those three benefit and I think that's important to understand. Customers ultimately become more productive. Information is being used as a competitive weapon, after all time is money. So we've got to do decision making faster and in a more timely fashion. 

Peter Kastner 05:58
This leads the customers to bottom line issues. They've got lower overhead, lower people cost, better factor utilization, etc. For Digital it's going to grow our business. It's really important. As John Logan of the Aberdeen Group was quoted as saying, Digital may well become the vendor of choice for TP in the 1990s. 

Peter Kastner 06:15
That shows you how independent people are important. They think it is for us. I think I like that man. Yeah, it rounds out our every purpose capabilities. And so the TP business is going to help Digital grow faster than the industry. 

Rod Sutherland 06:27
How about the sales rep themselves? The sales force, well all of us on the panel have sold before so we know how hard it is to get to that bottom line, make those budgets. TP systems tend to be big ticket items. 

Peter Kastner 06:39
And if I can quote Steve Smith of Payne Weber, he said that DEC TP will drive the demand for bigger computers. Well that means if TP systems are big ticket items, there's big initial sales, there's the opportunity to sell services, there's the annuity really on expansion growth. 

Peter Kastner 06:55
These systems grow with the business. And finally there's an opportunity once we get in there to extend into other systems as well. So there's a win for everybody, the customer DEC and the DEC sales rep are our audience. 

Rod Sutherland 07:04
Absolutely, positively. Well Rick, where should we be selling transaction processing? Well I think there's two key questions that our sales reps can look at to determine whether this is a time sharing piece of business or a DEC TP piece of business. 

Rick Case 07:20
The first decision is whether or not the customer is looking to make their own application or whether they want to buy an application off the shelf. If they want to buy a currently existing application then the sales rep should go through the same channels he always goes through to get an existing application solution such as our SCMPs or CMPs, the software source book, the video text databases that we have that can help locate one of the thousands of application solutions we have for our customers. 

Rick Case 07:48
Now if the customer wants to make an application solution, do his own application development perhaps for a strategic advantage in his particular marketplace, then the sales rep would have another choice to look at and that's whether or not the customer wants maximum flexibility or whether they want the maximum speed for a fixed set of functions. 

Rick Case 08:09
If the customer wants maximum flexibility, i.e. they want to be able to have their end users be able to do anything that they want at any time, office one minute, a transaction the next minute, that would probably be a time sharing environment and there are many applications and application development tools in that area. 

Rick Case 08:28
Now if the customer has a different set of functions, they want a set of fixed functions to be available to the end users with the maximum possible speed, with predictable response time. If you hear them say things like this, and that's a flag for DECTP, some of the other decision criteria would be to have the maximum control over what the end users are doing at any given moment, also things such as data integrity. 

Rick Case 08:55
If the customer says that this information is absolutely vital to my corporation, I want to make sure that we don't lose any particular piece of information, any particular transaction, then that's a flag that this might be a DECTP type of environment. 

Rick Case 09:10
Now the last thing that our sales rep need to understand is that unique among our competition, Digital can supply a mixed environment where some applications are under time sharing and other applications are under transaction processing. 

Rick Case 09:25
And they can work together. They can work together. Now that is not true of our competitors. Our competitors typically need a separate environment for those two things. DEC can do it all on one architecture. 

Rod Sutherland 09:35
That's key. Thanks for that, Rick. Now, Gary, I mentioned when the broadcast came up, the announcement from the 14th of July of DECTP. Could you take just a minute and recap that announcement and set up a little comparison of DEC versus IBM? 

Gary Hoppe 09:52
Sure. Well, the July DBN really explained the fact that IBM has three transaction processing monitors. One is CICS. It has approximately 26,000 licenses installed worldwide. It's installed in environments where up to 40 to 50 transactions per second are required by the customer. 

Gary Hoppe 10:10
It runs under the VSE or the MBS operating system. On the other hand, IMS DC is an MBS operating system only transaction processing monitor. And it is installed in environments up to approximately 300 transactions per second. 

Gary Hoppe 10:27
There's about 3,500 licenses installed worldwide. On a specialized side, and in fact, where very high transaction processing requirement is in place, for example, the American Airlines Sabre system, a facility called the Transaction Processing Facility, which is a specialized transaction processing monitor, is installed. 

Gary Hoppe 10:47
The database environment for those transaction processing monitors on the IMS side, it's IMS DB or DL1 in the CICS environment, which are hierarchical database management systems. And of course, for relational databases, DB2. 

Gary Hoppe 11:03
In addition to that, for flat files, they have VSAM as their database. Now in comparison to that, Digital announced ACMS, the new version of ACMS. There are approximately 1,400 licenses installed worldwide. 

Rod Sutherland 11:16
It's been around and successful for quite a while. 

Gary Hoppe 11:18
It has been very successful. ACMS has a fourth generation-like programming interface, as opposed to DEC-INTAC, which is more of a CSCS procedural language type of interface. DEC-INTAC, on the other hand, has 400 licenses installed also. 

Gary Hoppe 11:33
And really, its origins came out of the financial services industry, in which it was developed on a VAX platform. And it highlighted the fact that the customers who have CICS installed can move very quickly and easily into the DEC-INTAC environment. 

Gary Hoppe 11:52
Now, the database systems for ACMS and DEC-INTAC are DBMS, RDB, and of course, RMS for hash file environment. And of course, what ties the two environments together is VAX-LINK. 

Rod Sutherland 12:08
Oh, that's nice. That gives our customer an out if they want to hold their investment in IBM and still move into the DEC side. Provides a bridge. Beautiful. Thanks an awful lot, Gary. Peter, if you could, could you identify for the Salesforce the five really strategic areas for TP? 

Gary Hoppe 12:26
Yeah, sure. Let me count them all. 

Gary Hoppe 12:29
off. There's offloading existing mainframes. There's developing new software for mainframes. There's distributing applications, distributed applications, and then interoperability and finally new applications themselves. 

Gary Hoppe 12:41
Let me just spend a moment talking about this. Yeah, do that in a little detail on it. Offload is a situation where the mainframes run out of gas, where the customer is looking either buying a new model up the line or in some cases such as DOSVSE where they run out of steam, they've got to look at a major operating system conversion such as to MVS. 

Gary Hoppe 13:01
That's a big change and if the customer is going to migrate and have to convert, why not VAX? Let's ask that question. Secondly, we've got some really happy customers out there who are running and developing software on the VAX which they then port over and run in production environments on their host machine. 

Gary Hoppe 13:18
That's a heck of a way to get a VAX in there and show them how simple, easy, efficient, and productive our environment is to get the job done. It's like the old Syncom story, right? Well, if we get our foot in the door, we can show them how good things are and go from there. 

Gary Hoppe 13:31
Thirdly would be the distributed environment. Anytime the customer has got, say, a central site but they want to talk to warehouses or remote factories, manufacturing facilities, that's where Digital has it all over the competition because we are the networking leaders. 

Gary Hoppe 13:45
We can do distributed processing and demonstrate that better than anyone. Great story there. The interoperability area is, as one consultant has called, that's our thief in the night. That's where we can cap off the processing on the mainframe by putting in VAX link pipes to the IBM databases, stopping application growth there, moving the data down onto the VAX in the RDB or other environment, letting customers get available of that. 

Gary Hoppe 14:11
Fifth, and probably most important because it's a clean slate for everybody, would be looking for new applications. That's where the cost of ownership and all the other things we're going to talk about tonight. 

Gary Hoppe 14:24
So I would compete most vigorously there. Well, with the strong tools we have in the VAX development environment, I should think we'd have a very strong story to tell. Absolutely, yes. A lot of the same selling points apply here as well as in other sales situations. 

Rod Sutherland 14:36
Well, what messages around transaction processing should the sales reps that are tuned in tonight be delivering to these different levels of audience that we talked about earlier, the different levels of the customer? 

Gary Hoppe 14:48
What are the messages there? Well, let's talk about three different classes of customers. One, the end user, the MIS department, and thirdly, the chief executive. And they all get separate messages. To the end user, it's almost selling as usual because the DECTP story is probably less of a technical environment than in the other environments. 

Gary Hoppe 15:14
The customer's looking for a business solution and they need to concentrate on that. In the MIS environment, in particular in installed IBM accounts, we need to sell all the things that we're talking about, but we need to do so in such a fashion that we don't threaten that MIS director. 

Gary Hoppe 15:28
After all, we're coming in there saying we can do it quicker, we can do it less expensively, and we just don't want to threaten that person with the judgment that they've made in the past. It could be a threat. 

Gary Hoppe 15:40
They have those big IBM investments. We want to show them how they can increase their productivity, but not increase their costs. With our interoperability story, they can make that switch gradually to the VAX environment. 

Gary Hoppe 15:52
And then finally, to the chief executive officer, chief financial officer, deliver these high level messages that we can reduce their MIS backlog through the VAX productivity tools. The whole comprehensive cost of ownership story, of course, is going to save them money. 

Gary Hoppe 16:09
And we've got the studies to prove that we can show large differences, lower staffing costs, and what that means to the customer. And the staffing costs would be lower even in this quote, new environment of TP? 

Gary Hoppe 16:21
Oh, yes, because TP allows you to handle those large users in a very efficient fashion. We've got several different styles to do that as well. And then finally, I guess you tell this chief executive officer, perhaps what you wouldn't tell the MIS manager, and that's Digital can do the same work for less cost. 

Gary Hoppe 16:37
And that is the key to the bottom line. Absolutely the bottom line. Well, we've identified the opportunities for TP. We've taken a look at the recent DEC TP products, and thank you for that, Gary. We've compared them with IBM. 

Rod Sutherland 16:52
We've discussed the strategic areas that we should get focused on as a sales force. And some of the messages at the various levels, now we'll role play. You guys that have been on before know how much I enjoy this. 

Rod Sutherland 17:06
Let's role play the strengths and weaknesses between DEC and IBM. And if I could, Rick and Peter, would you guys play the role of the DEC sales rep? And Gary, if you'd be so kind, if you can handle this. 

Rod Sutherland 17:22
Big blue. Big blue. OK, you got it. And I'll play, again, the role of the customer. I'm a customer who's looking for a vendor who can meet my requirements, my business requirements in transaction processing. 

Rod Sutherland 17:36
Gary, a lot's been said about IBM's heritage and transaction processing and its strength. As a customer, I'm concerned about my vendor's experience. I'm betting my business on this system. How does IBM stack up on this score with TP? 

Gary Hoppe 17:52
Well, Rod, as you know, the transaction processing environment is a very complex environment. So that the success of your installation depends very much on the experience of the vendor. IBM has been in the business for over 20 years of installing TP solutions. 

Gary Hoppe 18:09
IBM has, in the Fortune 100 companies, a majority of those customers whose day-to-day operations are dependent on IBM teleprocessing solutions. In addition to that, tens of thousands of licenses of CICS are installed worldwide. 

Gary Hoppe 18:26
IBM has the experience to solve your business problems. 

Rod Sutherland 18:31
Well, Rick, as a new entrant into transaction processing, how does Digital compare with IBM? Well, Rod, first of all, let me point out that Digital is not a new entrant into transaction processing at all. 

Rick Case 18:44
We have nearly 2,000 installed licenses for our transaction processing monitors in such areas as manufacturing and in the financial areas. And there are many very nice reference sites in those areas. 

Rick Case 18:57
The kind of experience that IBM has been talking to you about is in the areas of centralized transaction processing, the old way of doing things. More modern solutions and the future require distributed transaction processing. 

Rick Case 19:10
That's what most of the outside consultants are advising customers. Now, Digital is, in fact, one of the major vendors in transaction processing. We have more than a billion dollars a year in transaction processing revenues. 

Rick Case 19:23
That puts us equal to, or even exceeding, one of the market technology leaders, tandem computers. So Digital is a very major vendor in this area. Digital is number two? If you would. And the last thing to say there is that if the key thing you need is distributed application, applications distributed transaction processing, no other vendor can match Digital's experience track record in distributing applications. 

Rod Sutherland 19:49
Well, I'll grant you then that you're not really new to this. But I'm interested in a vendor who can provide me, and maybe, Gary, you can enlighten me on this, provide me with a wide range of transaction processing solutions. 

Rod Sutherland 20:02
How does IBM look on that score? 

Gary Hoppe 20:05
All right, IBM has a wide range of application solutions across multiple industry segments, with hundreds of IBM and third party application solutions available to you. In addition to that, we offer the flexibility of multiple operating systems environments tailored to your needs. 

Gary Hoppe 20:22
IBM has your solution from the desktop to the 100 MIPS mainframes. 

Rod Sutherland 20:28
Interesting. Well, excuse me for a moment. I'm going to talk to my other vendor. Digital. Peter, if you would, how does Digital stack up on the solutions side with transaction processing? Good question. 

Peter Kastner 20:42
Digital also has hundreds, if not thousands, of solutions to solve business problems across hundreds of industries as well. Key point to you, Rod, is that the DECTP announcement doesn't obsolete all the existing software that already runs in the VAX environment and that may be doing transaction processing. 

Peter Kastner 21:00
In fact, part of the announcement was the Digital distributed transaction architecture, which gives us a vision, a five-year or more view into the future that will protect your investment. Now, when our competitor talks about having multiple solutions for multiple situations, that's many operating systems, many different places for you to spend more. 

Peter Kastner 21:22
When, in fact, Digital has got single architecture with the VAX, single operating system with VMS, that's going to allow you to grow much more flexibly. In fact, the VAX 6210 that we talked about for you, we could start and develop your prototype application on that 6210, grow that in production up through a 6240 with four processors and more than three times the power. 

Peter Kastner 21:46
That 6210 that you quoted me can grow to four processors? Absolutely. That's the beauty of symmetric multiprocessing. Furthermore, we can even put that on a VAX cluster and on a DEC net around the world to handle your distributed requirements all without even recompiling your programs. 

Peter Kastner 22:03
That, to me, is the ultimate inflexibility. No change whatsoever to grow to that level. No change. That's right. That's the VAX environment. That is interesting. Very interesting, I might say. Now, there's another area that concerns me, though, and if I may, I'm going to bet my business on this, this system that you're offering, Gary. 

Rod Sutherland 22:21
What kind of support can I expect from IBM on this as a business partner? 

Gary Hoppe 22:27
Well, Rod, building on the field service organization that's second to none in the industry, IBM has the best support in the industry. We have systems engineers that work with you in your site, not only in the design, but also in the implementation of your applications. 

Gary Hoppe 22:47
We also provide on-site support. Couple that with some sophisticated electronic tools that we make available to our support folks as well as to you, that support is free. 

Rod Sutherland 23:00
Free, and you'll be there when I need you. Your people will? We're behind you all the way. I love it. Peter, it's your shot. Digital and supporting a client's business needs in TP. Well, Rod, I'm a little bit surprised to hear our competition talking about their service and support being free. 

Peter Kastner 23:19
Let's put that in relative terms. If that's true, then why do the studies that we showed you show that Digital has a third of the staffing costs of IBM? And in the price performance that we showed you associated with DEC TP, it costs a third as much for a same level of performance with DEC TP than it does with a competitive. 

Peter Kastner 23:38
So I'm not so sure there is anything that's free here at all. Let's look at another aspect. And that's the fact that many of the products associated with DEC TP are new versions of existing products. 

Peter Kastner 23:48
RDB, for example, has been in the field for several years. And Digital has more than twice as many licenses in the field installed than our competition. We have a lot of people in the field and customers to back that up who have a lot of experience with these products today. 

Rod Sutherland 24:03
I'm amazed. Wow. Now, one other thing I'd like to point out, and that is that some of our early customers working with DEC intact have shown that they can take CICS trained programmers from the IBM environment and move them over to DEC TP with five days worth of training. 

Rod Sutherland 24:20
Now that can not only get your applications done quicker, but we're not talking about a lot of training investment here to get that. That shows you how easy and productive we are. Certainly minimize any ripples. 

Rod Sutherland 24:30
Right. Finally, let's talk about our commitment. We're so confident of being able to support you that we want to develop a support plan to address your needs and work with you further on it. And we can jointly develop the support plan. 

Rod Sutherland 24:44
Yes. Digital and my own people. We want to set mutual expectations and then meet them and exceed them. I like what I'm hearing. I like what I'm hearing a lot, Peter. In fact, I have a question from my friend from IBM if I may. 

Rod Sutherland 24:56
Has to do with investment protection. In fact, as you know, I've got a lot invested in the equipment you've put in and your counterparts have put in over the years. How can I be sure that my investment in this current system will be protected? 

Peter Kastner 25:10
Well, that's an excellent question, Rod. IBM understands your investment in our products and services. And in fact, IBM's systems application architecture is designed to protect just that investment, primarily on the application. 

Peter Kastner 25:24
SAA. In addition to that, the IBM Corporation spends over a billion dollars a year in research and development to develop leadership products in the industry. And before you make a choice that would take you out of the IBM fold, I would be glad to work with you in identifying the cost of making that kind of a decision, both in additional staffing that would be required, plus the additional training that would be required to support that new environment. 

Rod Sutherland 25:54
Well, this SAA question is one that I'm having a little trouble with. We may need to talk more on that. I don't quite understand it all. I do have a question for Digital though. And it's the same question, in fact, Mr. 

Rod Sutherland 26:06
Case. What are you going to do to protect my investment on your equipment, hardware and software? I'm very happy to address that question. Let me perhaps explain SAA to you for a moment, if I might. There's about 50,000 pages of documentation on SAA. 

Rick Case 26:20
And what SAA from IBM is going to require you to do is basically to rewrite your present applications and to replace your present PC investment that you have on your user's desk, as well as retraining all of your people to be able to use that new environment. 

Rick Case 26:36
Now, that is not investment protection. And you're facing three to seven years of that conversion to get to SAA. That is not investment protection. Let's talk to you more about what Digital can do to protect the investment that you have, not only in Digital equipment, but also in IBM equipment as well. 

Rick Case 26:53
Now, we've discussed in the past the fact that you want to attack that three or four year application backlog that you have in your data processing requirements, that you want to expand your business and attack your strategic competitive advantage by doing so. 

Rod Sutherland 27:06
Now, when you expand that, you're going to need to put in place more computer systems and more staff to be able to handle those new applications. So the real question that is on the table is, where can you make the best investment that you can to get the best return on that investment? 

Rod Sutherland 27:22
We've talked to you about the differences in the staffing level requirements between IBM and Digital solutions, where Digital will require half or even a third of the level of staffing that is required for an equivalent IBM solution. 

Rod Sutherland 27:37
That equates to direct dollars, direct return on your investment in terms of what you have to pay for those solutions. Now, as far as the track record of Digital and maintaining your investment in Digital solutions, we have an outstanding record. 

Rod Sutherland 27:53
We've talked to you about the fact that you can buy a Digital VAC system, you can expand it into a multiprocessor system, you can expand it into a VACS cluster system, you can expand it into a network, all using the present equipment that you have. 

Rod Sutherland 28:06
Without any changes. Without any changes. Now, that's protecting your investment and your hardware investment in Digital. Then again, since we have a single application architecture that lets you develop an application on a small VACS and run it on a big VACS, or develop it on a big VACS and run it on a small VACS, now that's maintaining your application investment across your Digital systems. 

Rod Sutherland 28:28
And since we have a single consistent user interface across our systems, you can train your users once and how to be productive in the Digital environment and not face the massive retraining costs that you're gonna have to face with IBM. 

Rod Sutherland 28:41
And finally, using our DECLINK, VaxLINK products and our SNA gateway, we even allow you to tie in the VACS systems with your IBM systems and maintain the investment that you have in your IBM databases and all that you put together over there. 

Rod Sutherland 28:56
Current systems? That's right. So Digital even protects your investment in your IBM systems as well. Now that's an unparalleled investment protection from Digital Equipment Corporation. I understand that. 

Rod Sutherland 29:08
I appreciate that in fact. I'm glad to see you're focusing on that need I have and the investment I have. There's one final thing though, if I may. I've been hearing an awful lot about performance, about MIPS, in fact, is a consultant's view of MIPS comparing IBM and Digital Equipment. 

Rod Sutherland 29:28
And it looks to me like there's some interesting trade-offs, an awful lot that I need to talk to you about, Gary. 

Gary Hoppe 29:35
Well, IBM is very concerned about this comparison, Rod. We believe that using these MIPS comparisons by industry analysts that it clearly underrates IBM's products and clearly overrates our competitor's products. 

Rod Sutherland 29:51
Well, how would you position your products, then, if this isn't a fair comparison, this consultant view? 

Peter Kastner 29:55
Well, we've invested a substantial amount of time and resource and money into the development of a benchmark calledRAMP-C.RAMP-C is designed specifically for the transaction processing environment. 

Peter Kastner 30:07
And we have used that successfully to compare our systems with competitor systems. And in fact, I happen to have a brochure with me that indicates that there's a substantial difference based on aRAMP-C benchmark versus the MIPS benchmark rating, where it shows IBM is actually two to one versus our competitors. 

Rod Sutherland 30:32
No, it does look interesting, I guess. How does Digital view the performance issues? All right, what we feel is that RAMC is a proprietary IBM benchmark. Only IBM can run that benchmark. It's a closed benchmark, it's not public. 

Peter Kastner 30:51
Now let's equate this to a scientific experiment it would for a moment. One of the things that you do in a scientific experiment is you make it open in public so that other scientists can run the same experiment, obtain the same results, and then you know the experiment was run correctly. 

Peter Kastner 31:06
That cannot be done with RAMC because IBM has not released any of the information to make that happen. What's necessary here is a public, above-board benchmark that you can run, that we can run, that IBM can run, that external consultants can run, and we can all compare our audited results to one another. 

Peter Kastner 31:27
That benchmark is the debit-credit industry-standard transaction processing benchmark. We believe that debit-credit is the proper benchmark to use to compare Digital and IBM and other competitor systems. 

Peter Kastner 31:40
In this brochure, we have performance information that clearly shows what Digital did with the industry standard debit-credit benchmark and how we would position the performance and the price of Digital systems and IBM systems in transaction processing. 

Rod Sutherland 31:58
Role plays over. Now as a customer, I get to make my decision. And I got to tell you, it's coming pretty clear to me. But let's take a little more time, Rick, and talk about this performance brochure and share with the sales force how to use this powerful information in their transaction processing sales. 

Peter Kastner 32:18
Could you share some detail on the performance brochure? Absolutely. First of all, we think that it's very important that our sales representatives don't just drop off the brochure, pass that out to thousands of customers, and hope for the best. 

Peter Kastner 32:32
What needs to happen is that our sales representatives have to address the specific concerns that the customers have for their application requirements and to address the things that IBM has been claiming about us. 

Peter Kastner 32:44
Now, again, what we say, what we have said in past presentations, is that RAMP-C is a proprietary, closed, undocumented benchmark that IBM is using. And in fact, we know that IBM did not run the VAC systems that they're quoting in there for the maximum possible performance. 

Peter Kastner 33:04
We believe, for instance, that IBM did run a VAC's time-sharing environment versus an IBM transaction processing environment. And everyone knows that you can support many, many, many times more terminals in a transaction processing environment doing fixed functions versus a flexible time-sharing environment. 

Peter Kastner 33:24
Now, IBM could have compared a DEC transaction processing environment and an IBM transaction processing environment. They didn't do that. They could have compared an IBM time-sharing environment versus a Digital time-sharing environment. 

Peter Kastner 33:38
They did not do that. They could have shown Ethernet terminal interconnects on Digital systems. They used asynchronous direct terminal interconnects, which have a much higher performance penalty than Ethernet. 

Peter Kastner 33:50
If you take all those factors combined, what you get is about a two to three hundred percent factor that IBM is off in terms of positioning the Digital systems. Up to three hundred percent? Rick, why did we choose the debit-credit benchmark in the first place? 

Rick Case 34:06
Well, the very first reason for choosing debit-credit is because it is a benchmark which Digital does not control. It is a public, open benchmark that was defined publicly in a 1985 Data Nation article. 

Rick Case 34:19
So that's the first point, that it's public and open, that anyone can run it, vendors, customers, and consultants. The second reason for picking that benchmark is that it's a very comprehensive benchmark. 

Rick Case 34:31
It tests all the components of a computer system and runs them very thoroughly. So it is a very good way of comparing computer systems using transaction processing. Now, the results of all the benchmark tests that we run are shown in this new six-page brochure that is now available. 

Rick Case 34:49
Now, this brochure was inserted in the July Competitive Update article, the initial version of this, and is even now, as we speak, available in the sales reps literature distribution centers in the field, and is available in quantity from the Northboro Distribution Center. 

Rick Case 35:06
And the order number for obtaining more of this brochure is now on the screen. So this is what Digital... That has a lot more information in it than the first one I saw. How do the sales reps get a hold of that? 

Rod Sutherland 35:18
Well, they ordered from the Northboro Distribution Center. It's available in their offices today? That's right, right this minute. Okay. Well, let's... That states some of the specifics on the debit-credit. 

Rick Case 35:30
What do we find in there? While using that publicly available benchmark, the graphs that we're now going to show are the absolute performance that we measured on the various systems that we obtained in this brochure. 

Rick Case 35:43
And along the vertical axis, you see the transactions per second. Along the horizontal axis, you see the various Digital IBM and TANM systems that we tested. At the top of each column on the brochure is the five-year costs for the systems that we tested. 

Rick Case 36:00
That includes hardware, software, and five-year services costs on each system. What you see there is that a VAX8830 nearly matched the performance of an IBM 3090 Model 200E, costing almost five times as much. 

Rick Case 36:15
And a 4-processor 6240 system outperformed a 4-processor TANM system, costing almost twice as much. The next graphic shows our results for the 9370 and for the AS400. As you can see from this graph, the most powerful AS400 was only one-third faster than our MicroVAX product and cost three times as much. 

Rick Case 36:37
The same system, the most powerful AS400, is 20% more powerful than the 6210 at 50% more money. And the 6210 can grow to be over three times the power of the most powerful AS400. The second most powerful AS400 is 15% less powerful than the MicroVAX 3600, yet costs twice as much. 

Rick Case 37:00
And finally, the 9370 Model 90, the top of the line for the 9370. equals the performance of the MicroVax 3600 and costs three times as much. That's a very powerful positioning site. I guess. With all of this information, how does that position Digital then against IBM with a debit-credit information? 

Rick Case 37:20
Well, if you add up all the systems that we tested, all the IBM systems, all the Digital systems, all the tandem systems, cost per transaction, or the price performance. And in fact, if you even throw away the two most expensive IBM systems, just ignore those two. 

Rick Case 37:34
Not a bad idea, by the way. In order to make the comparison as conservative as possible, we get the graph you see now that shows that Digital's cost per transaction is less than one third that of IBM's. 

Rick Case 37:48
Now, what that means is that Digital's price performance is three times as great as IBM and twice that of tandem. That's a very powerful message. And cost per transactions, that's one of the key measurements that the customers talk about. 

Rod Sutherland 38:01
Now, wait a minute. This is some pretty powerful information. How can we expect IBM to respond or react to this kind of information on the street? It's surprising that IBM really has not reacted very much at all yet. 

Rick Case 38:13
But what they might come back with is to claim that theRAMP-C benchmark is a more comprehensive, more complete benchmark than debit-credit. Is it? Well, no, it isn't. In fact, debit-credit appears to be the more comprehensive benchmark. 

Rick Case 38:28
But the first point that we need to look at is continue to hammer home thatRAMP-C is a proprietary benchmark. No one else can run it except IBM. That's the first point. And that point alone should disqualifyRAMP-C from further consideration. 

Rick Case 38:43
But let's take a look at whether or not which one is the more comprehensive benchmark. If debit-credit, or rather, ifRAMP-C were the more comprehensive benchmark, it should place a heavier load on the computer system and therefore have fewer transactions per second as a result of the heavier load. 

Rick Case 39:01
If you take a look at the graph we see now, what we see is thatRAMP-C actually has more transactions per second than debit-credit. What that means is that debit-credit is most definitely the harder, heavier workload. 

Rick Case 39:14
It is the more comprehensive workload of the two. Now, if IBM has any further objections to what we have said here with debit-credit, it is a publicly, openly available benchmark. They can run the same tests that we did. 

Rick Case 39:27
They can have it audited as we are having ours audited by outside concerns. And then we'll be happy to accept their numbers. I'd love to see it. In fact, as a salesperson myself, I think I'll be calling for my customers to ask them to do just that. 

Rod Sutherland 39:42
One other thing, though, that IBM tends to do is tout high performance and mention successful installations of TP reference sites. How about us? What do we get to say there? Well, in that case, what we have to do is force IBM to give them distributed transaction processing reference sites. 

Rod Sutherland 40:01
Because what they're going to give them and what the vast majority of IBM reference sites are, are centralized transaction processing solutions. So if you drive IBM to come up with a distributed transaction processing solution, they're going to have far fewer reference sites than we do because we are obviously in the distributed application environment. 

Rod Sutherland 40:22
The second thing that IBM might try to do here is to keep notching the customer's performance needs, absolute performance, higher and higher, try to get it into a bigger and bigger processor and thereby squeeze out Digital. 

Rod Sutherland 40:35
And this is the classic distributed processing versus centralized processing approach. No matter how big the central engine is, it has a limit. Ultimately, you get up to the point where they can't add any more transactions. 

Rod Sutherland 40:48
So our point to come back with is in a distributed processing environment where you have many, many small engines, there is no limit to the number of transactions that you can handle. So actually, distributed transaction processing can handle far, far more transactions per second than a centralized approach ever can. 

Rod Sutherland 41:07
We can get a lot more performance out of a distributed system than they ever could out of a center. Absolutely. Peter, how much performance is too much? That's that's a key question and one it's important for for us to understand customers right now are really confused by all this benchmarking Information if you pick up any trade Trade magazine you'll see all sorts of articles fact is we've got to get out there and identify what the customers requirements really are Frankly a lot of customers don't know or if they know they might say gee I do 10,000 transactions in my peak hour. 

Peter Kastner 41:39
We need to know what kind of transactions those are Frankly 10,000 an hour is is about three a second three train three tips Could could be well within our range in fact with the dev accredited benchmarks. 

Peter Kastner 41:52
We've shown that at 50 plus transactions per second When when most applications require less than ten we can do 90 plus plus plus percent of all applications On a single vax or a vax cluster, so we shouldn't be shy about tp Yeah, the other point I like to make though is that IBM? 

Peter Kastner 42:08
it's typically adding up the tips from the many applications that run on that mainframe and Digital selling that distributed environment and the fact that you can put an application On a box or on a cluster and then tie those together and in a distributed, but networked fashion. 

Rod Sutherland 42:24
That's different We need to understand how IBM would position us versus them. We can do that work in many of the cases That's good information What where should we and how should we use some of this information Rick in terms of selling tactics today right now? 

Rod Sutherland 42:37
Well, it's it's vitally important that we properly position Digital systems against appropriate IBM systems That means that the sales representatives need to ask their customer who they're competing against what IBM is bidding for instance And make sure that we are bidding the appropriate Vax processor that solves the customers application needs And if IBM is bidding the inappropriate processor or attempting to force Digital into a larger processor You can use the performance information that we've given you to properly position IBM and Digital systems And if you can get that positioning Proper than all the rest of our benefits and price performance and so on and in cost of ownership We'll be made manifest and we will win that business. 

Rod Sutherland 43:21
So we've got to set it right out front. Absolutely You've been quiet over there. You know, you're not IBM anymore. You can be Digital 

Gary Hoppe 43:28
mentioned, you can't sell just price performance alone. You really have to look at the overall comprehensive cost of ownership. And my suggestion would be to have your customers really analyze the staffing and support cost of their current IBM environment. 

Gary Hoppe 43:42
In a competitive situation, have those customers thoroughly look at what it's taking today to support an IBM environment. And use the Digital comprehensive cost of ownership model combined with the staffing studies that have been done, Digital versus IBM in a 370 environment. 

Gary Hoppe 44:01
Combine that into a financial case that you present to your customer to illustrate Digital advantages. 

Rod Sutherland 44:07
this case. Thanks, Gary. That whole cost of ownership thing we've discussed so many times. It's key. Oh, absolutely. The last thing that we talked about was the distributed versus centralized approach that we've done here. 

Rod Sutherland 44:23
And what that is is, again, the classic argument of IBM versus Digital. We have to make sure that IBM is identified with the older way of solving problems, the older, centralized transaction processing way of solving problems. 

Rod Sutherland 44:37
And in fact, what we've heard now is that Digital is associated with the more modern way of solving problems. If you look at what Steve Smith from Payne-Weber has said. Well, Peter, did you have anything else to add on that? 

Peter Kastner 44:49
Oh, well, in fact, my two selling points would be to go out and sell the case environment and the fact that Digital can speed development with its tools, cut that MIS backlog, get the applications online so they're paying back to the customer from the simplicity of the VAX environment versus the complexity of IBM. 

Peter Kastner 45:09
The other point would be to talk about the DEC link, the interoperability capability that can get that data off the IBM machine without disruption and therefore get us that foot in the door to move on to other applications. 

Peter Kastner 45:21
Those would be my two points. And Rick, what was that quote? Well, from Steve Smith at Payne-Weber, when he positioned what Digital was doing with DEC TP against what IBM has done, what he basically said was DEC TP opens the door for Digital. 

Rod Sutherland 45:35
The dinosaur mainframe approach to transaction processing is being challenged. That's quite a quote. Are they a Tyrannosaurus Rex or are they a vegetarian dinosaur? Well, now you have the opportunity to ask my guests any questions regarding tonight's topic or to discuss specific customer situations you'd like some help with. 

Rod Sutherland 45:54
The phone number to call is DTN2494800 or area 617-276-4800. Your site manager will be happy to place the call for you if you'd like. We'll be back to take your calls after this short DEC world 88 break. 

Rod Sutherland 46:12
Thank you. Hello, I'm Buzz Luttrell for Digital Video Network with some exciting news about DECWorld 88, the world's largest single vendor computing exposition. This year in Cannes, France, September 12th through the 23rd. 

Rod Sutherland 46:31
In addition to the executive level seminar, sessions and demonstrations featured during the two weeks, there will also be a series of support events focused by industry held at 11 ACTs across the U.S., so customers who could not make the trip to Cannes can still benefit from DECWorld. 

Rod Sutherland 46:45
Another feature this year, exclusively for the U.S., I might add, is a telecast of a panel discussion of an executive survey on how technology can fulfill the visions of America's business leaders. ABC's Ted Koppel will moderate that event. 

Rod Sutherland 46:58
We spoke with Koppel about his plans for that special telecast, which will air on September 14th at 2 p.m. 

Speaker 3 47:06
During its brief history, computing has revolutionized the way we handle information, first at corporate accounting and clerical centers, and then on a personal level. And now, we're on the threshold of a third wave of impact, reaching the heart of business and industry. 

Speaker 3 47:23
As network computing becomes essential throughout organizations, integrating the entire global enterprise, the need for business leaders to understand this impact becomes critical. Yesterday's vision of advanced computing is now a strategy on the corporate executives table today. 

Speaker 3 47:41
I'll be working with Digital Equipment Corporation during DEC World to produce and moderate a televised forum for business leaders who are trying to identify and understand the impact of this technology. 

Speaker 3 47:53
My role will be to provoke some thoughtful discussion among panel members and live audiences linked up through participating application centers for technology. Our interactive teleconference will be broadcast live from New York at 2 p.m. 

Speaker 3 48:08
September 14th, giving Digital customers a national forum for questions about the future directions of integrated computing. Our starting point, the results of an exclusive survey of prominent executives on how computing is changing the way they do business across global markets. 

Speaker 3 48:27
Commissioned by Digital, the Roper organization conducted this study in conjunction with the Harvard Business School. Their conclusions will be revealed for the first time during our broadcast. Our panel will analyze these issues, including automation, U.S. 

Speaker 3 48:44
response to foreign competition, global markets, and the acceleration of product and business cycles. We expect valuable insights on the future of integrated enterprise across the globe delivered in what we hope will be an exciting interactive broadcast forum. 

Speaker 3 49:01
I look forward to talking with you on September 14th, some in person and others over the DEC World 88 DVN network. 

Rod Sutherland 49:11
Another program that will give you important information regarding DEC world straight from the project leaders is the DVN DEC World Orientation Telecast that will air on August 25th at 1 p.m. Eastern Standard Time. 

Rod Sutherland 49:21
And you can call in and ask questions as well. Hope to see you then. For Digital Video Network, I'm Buzz Luttrell. Welcome back. We're ready to answer your questions, but before we do, here's the number again. 

Rod Sutherland 49:36
DTN2494800 or area 617-276-4800. And we've already got calls stacked up. I'm going to go to Rochester, New York first. Rochester, go ahead with your question, please. 

Gary Hoppe 49:49
Hi Rod, this is Jay Schillwalter from Manchester. 

Rod Sutherland 49:51
Hello Jay. I'd like to thank you for your role play. That was probably one of the best parts of the presentation. 

Gary Hoppe 49:57
I've got a couple of questions for information, though, rather than about what you were saying. On the debit-credit benchmark, is it possible to get... 

Rod Sutherland 50:05
some public description of what it is so that we can help our customers understand it? Okay, the question on it, I have to repeat the question, is can we get information, public information on what the debit-credit benchmark is? 

Peter Kastner 50:17
Perhaps that 85 datamation? Sure. The April 1985 datamation issue is the seminal article. Now, the benchmark has been defined over time as various vendors have run it and refined some of the ambiguities. 

Peter Kastner 50:34
I'd refer to the July 14th special competitive update issue which has several articles talking about debit-credit and how various vendors have run it, how we run it. And thank you, Rochester, for that question. 

Rod Sutherland 50:48
Does that answer your question? One more addition to that? Go for it. Okay. Would it be possible as a learning experience to get access to... 

Gary Hoppe 50:56
to the actual code that we used in the benchmark so that we can understand in the field how we ran that benchmark. 

Peter Kastner 51:03
Steve, you want to jump on that one? That's a reasonable question. We're going to make all of the detailed results that go to back up the brochure that Rick was talking about. In the October time frame, we're going to publish a whole book on that. 

Peter Kastner 51:16
And our customers and market research people will get to look at it then. We have not decided whether or not we're going to make the source code public or not. But I'd be glad to take that question offline as a possibility. 

Rod Sutherland 51:28
OK, Peter. Thanks. Thanks for that. Rochester, thanks for those two questions. Appreciate you calling in with them. Now, Santa Clara, I know you've been holding on out there. Why don't you go ahead with your question from California. 

Gary Hoppe 51:42
Claire. I have two questions. One is of Peter. He made reference to the case tools to be used reporting from Digital to IBM and reference sites. Peter, could you tell me who they are? I've been searching for that for a long time. 

Rod Sutherland 52:01
I'm not sure I understood the question. I'll try and paraphrase it if I can. You mentioned case tools for migration to the VAX environment was the question. Can you first go with that one? Are there any specific tools or special tools? 

Peter Kastner 52:17
There are a number of tools that are in process. Some of them haven't been announced yet, but the corporate systems group at Digital can help you with that. If you would call the hotline tomorrow, we can put you in touch with someone who can get you that information. 

Rod Sutherland 52:34
I think I remember your reference to case tools more in terms of the richness of the development environment in DEC. That's correct. As opposed to just migration tools. There was a second part to the question, though, having to do with reference sites. 

Rod Sutherland 52:47
I assume, Santa Clara, you're looking for reference sites in that area. Anything you can add on that side? I think also the hotline should be the source for that information. We did make a number of customer sites available with the product announcement, and I think that should go through the hotline in natural fashion. 

Peter Kastner 53:06
I would think, too, that the refer database probably has quite a bit of ACMS reference sites anyway, which are successful TPUs. The comment I would make, if Dennis, by the way, hello, is asking about actually converting IBM applications over to Digital, I think a point needs to be made that we're primarily looking for new applications to go after, as point number one. 

Peter Kastner 53:30
But you have not heard all that we have to say yet about having some easy to use ways of quickly converting IBM applications over to DEC platforms. And you'll see more on that in the coming months. So there is a lot rolling. 

Rod Sutherland 53:43
As important as this marketplace is, this transaction processing marketplace, I expect an awful lot of strong tools to come out of DEC for you and I to win sales out there. And by the way, Peter mentioned a couple of times the hotline. 

Rod Sutherland 53:56
We will be giving you that hotline number at the end of the broadcast, right? Absolutely. I'll be standing by. I think one thing that I'm looking forward to digging into and really understanding this time around is the information you've got there in that brochure. 

Rod Sutherland 54:11
But let me go back to Santa Clara for a second. Santa Clara, did those answer your questions? 

Gary Hoppe 54:18
Thank you for tuning in. A second question is on the AS-400, the IBM, did we benchmark that with the debit and credit or did we just extrapolate? 

Rod Sutherland 54:31
Can I restate or repeat the question? Did we benchmark the AS-400 specifically, or did we extrapolate or do that mathematically? No, IBM has not delivered any AS-400s as yet. We did indeed extrapolate the AS-400 numbers based upon our actual testing of 9370 model 90 numbers. 

Peter Kastner 54:53
IBM came out with RAMP-C numbers that related the performance of the 9370 to the AS-400. And therefore, we were able to use that relative positioning in order to predict the position of the AS-400. We have some suspicions that the AS-400 will not perform as well as we have predicted. 

Peter Kastner 55:15
And we are moving now to actually benchmark an AS-400 to determine how well it really performs. As soon as one of those dinosaur eggs hatches? That's right. All right. Well, it's two hours worth of broadcast at one hour. 

Rod Sutherland 55:29
You got W money. Santa Clara, did that answer your question? Yeah, thanks, Ron. Thanks for calling in. Thanks to all of you for tuning in. Now, as I mentioned, there are some additional resources available to you on the subject of transaction processing. 

Rod Sutherland 55:43
There, the July 12, 1988 issue of competitive update, there's special TP issue of sales update. That was the July 12, 1988 edition. That Aberdeen Group report is available by calling the competitive hotline. 

Rod Sutherland 55:59
The number is 296-4748 or 508-480-4748. And July 14, OLTP DVN, remember that broadcast, is available by contacting Ellen Spears at exit 26 colon colon Spears. Now, we'd like your feedback in the program. 

Rod Sutherland 56:17
We've set up an all-in-one and a VAX mail account for you to respond to. The all-in-one account is Risa Blondin at OGO, and VAX mail is CSTVAX colon colon Blue Monday. In addition, if you subscribe to the Audiocassette program, you'll be receiving an Audiocassette of this telecast along with the hard copies of the graphics used on tonight's program. 

Rod Sutherland 56:37
If you don't subscribe to the Audiocassette program but would like to, contact Nancy Williams at OGO. Now, please take a minute to write down these account names and let us know what you thought of this telecast and other topics you'd like to see discussed on Blue Monday. 

Rod Sutherland 56:50
I'd like to remind you to fill out the Blue Monday evaluation forms before you leave. Now, our next telecast is Monday, October 3. Because of DEC world, there won't be a September Blue Monday telecast. 

Rod Sutherland 57:02
But before we go, help me in thanking these gentlemen for joining me here tonight in the studio. I'm looking for a quick summary, see if we can go away with just one key. And you want to start us off, Gary? 

Gary Hoppe 57:13
Well, there's no doubt that what we represent right now is leadership price performance. But don't ignore Digital's comprehensive cost of ownership. Start early in the game with your customer and work with them and identify the financial advantages that you do have over the IBM solution. 

Rod Sutherland 57:29
OK, thanks, Gary. It's absolutely vital that we properly position IBM and Digital systems so that we're comparing like performance computers as much as we possibly can. If we can do that, then Digital has a three-fold price performance advantage over IBM, and that should be a tremendous advantage to our sales force. 

Peter Kastner 57:48
I think I can sell with that one. Peter? Well, DECTP really completes the foundation for our push into enterprise-wide computing solutions. We need to get out there and aggressively look for those new applications, that new business that will fuel our expansion. 

Rod Sutherland 58:03
And I'd say interoperability is our way to fence in the old applications and so that we can migrate them onto the VACs and get it all. The opportunity is there, isn't it? Absolutely. Are we agreed? Well, until then, thanks, guys, for joining us on the broadcast. 

Rod Sutherland 58:19
We'll see you all October 3. Tell him good selling, and I'll see a few of you at DECWorld in the US and in Con. Good selling. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-dec-blue-monday-8-1-1988-dect-a89117 |
| title | DEC Blue Monday Telecast: Transaction Processing Competitive Training (August 1, 1988) |
| author | Peter S. Kastner |
| date | 1988-08-01 |
| type | transcript |
| subject_domain | OLTP |
| methodology | oral-history |
| source_file | transcript-dec-blue-monday-8-1-1988-dect-a89117.txt |
| license | CC-BY-4.0 |

### Abstract

Internal DEC sales training telecast (Blue Monday series) focused on positioning DEC's transaction processing (TP) products against IBM. Host Rod Sutherland is joined by Peter Kastner (DEC marketing executive, corporate systems group), Rick Case (competitive support), and Gary Hoppe (former IBM, now DEC competitive sales). The session covers the $21 billion TP market, DEC's less-than-5% market share with projections to triple, IBM vs DEC TP product comparison (ACMS/DEC-INTAC vs CICS/IMS DC), the debit-credit benchmark vs IBM's proprietary RAMP-C benchmark, five strategic TP sales areas, and selling tactics by customer level. Kastner was serving as a DEC internal marketing executive at this time (not yet at Aberdeen Group).

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rare primary source from inside DEC showing competitive intelligence strategy against IBM at a critical juncture; documents DEC's TP positioning, benchmark methodology, and sales training approach in 1988. |
| **Relevance** | high | Kastner is a key presenter throughout, serving as DEC's chairman of the DECTP task force on performance and competition; shows his pre-Aberdeen analyst career inside DEC. |
| **Prescience** | high | Kastner's framing of distributed TP as DEC's advantage over centralized IBM mainframe TP proved directionally correct; though DEC ultimately lost the broader battle, distributed computing paradigm did win. |

### Prescience Detail


**Prediction 1:** DEC TP market share growth prediction
- **Claimed:** Everyone projects Digital will grow to more than triple its size in transaction processing in the next several years
- **Year:** 1988
- **Confidence at time:** medium

**Actual Outcome 1:** DEC TP growth actual
- **Result:** DEC's transaction processing growth did not materialize as predicted. DEC struggled through the 1990s as client-server undermined minicomputers; was acquired by Compaq in 1998 for $9.6B, far below its 1980s peak valuation.
- **Confidence:** verified
- **Notes:** DEC's revenue peaked around 1989 at ~$13B then declined; acquired 1998 per Wikipedia and Britannica


### Entities Referenced (14)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Rod Sutherland | person | active |  |
| Rick Case | person | active |  |
| Gary Hoppe | person | active |  |
| Digital Equipment Corporation (DEC) | company | acquired | Hewlett Packard Enterprise |
| IBM (International Business Machines) | company | public |  |
| Tandem Computers | company | acquired | Hewlett Packard Enterprise |
| Stratus Computer | company | merged | Penguin Solutions |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| John Logan | person | active |  |
| Payne Webber | firm | acquired | UBS |
| American Airlines | company | public |  |
| NCR Corporation | company | spun-off | NCR Voyix / NCR Atleos |
| Applied Expert Systems | company | defunct |  |

### Technologies Referenced (20)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| DEC ACMS (Application Control and Management System) | middleware | Digital Equipment Corporation | growth | obsolete |
| DEC-INTAC | middleware | Digital Equipment Corporation | growth | obsolete |
| VAX/VMS | platform | Digital Equipment Corporation | mature | legacy |
| VAX Cluster / SMP | hardware | Digital Equipment Corporation | growth | obsolete |
| VAX-Link (Interoperability with IBM) | middleware | Digital Equipment Corporation | growth | obsolete |
| DEC RDB (Relational Database) | database | Digital Equipment Corporation | growth | legacy |
| DECnet (Distributed Networking) | protocol | Digital Equipment Corporation | mature | obsolete |
| IBM CICS (Customer Information Control System) | middleware | IBM | mature | legacy |
| IBM IMS DC | middleware | IBM | mature | legacy |
| IBM TPF (Transaction Processing Facility) | middleware | IBM | mature | legacy |
| IBM DB2 | database | IBM | growth | active |
| Debit-Credit Industry Standard TP Benchmark | framework | Industry (Datamation 1985) | growth | obsolete |
| IBM RAMP-C Benchmark | framework | IBM | declining | obsolete |
| Distributed Transaction Processing | framework |  | emerging | evolved |
| DEC Distributed Transaction Architecture | framework | Digital Equipment Corporation | emerging | obsolete |
| IBM AS/400 | hardware | IBM | emerging | legacy |
| IBM 9370 | hardware | IBM | mature | obsolete |
| MicroVAX | hardware | Digital Equipment Corporation | mature | obsolete |
| VAX 6200 Series (6210, 6240) | hardware | Digital Equipment Corporation | growth | obsolete |
| VAX 8830 (vs IBM 3090) | hardware | Digital Equipment Corporation | mature | obsolete |

### Observation Summary

- Total observations: 45
- By type: expert-opinion: 22, market-data: 7, benchmark-result: 6, strategy-classification: 4, personal-recollection: 3, actual-outcome: 2, viability-prediction: 1
