# Informix Competitive Update: RDBMS Market Analysis — February 17, 1994

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1994-02-17 |
| Type | transcript |
| Domain | database-market |
| License | CC-BY-4.0 |

## Abstract

Peter S. Kastner, VP of Aberdeen Group, presents a comprehensive competitive analysis of the RDBMS market to Informix's worldwide sales team. The presentation covers the financial standing of Oracle, Sybase, Ingres, and Informix; technology differentiators including scalability, distributed data access, development tools, and performance (TPC-C benchmarks); competitive threats and strategies; and Aberdeen's frank assessment of Informix's strengths and weaknesses. Kastner predicts Informix's stock will reach $44/share and positions Informix as a strong but underrecognized player in the enterprise database market.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 14 |
| technologies.csv | 17 |
| observations.csv | 40 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1994). Informix Competitive Update: RDBMS Market Analysis — February 17, 1994.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
