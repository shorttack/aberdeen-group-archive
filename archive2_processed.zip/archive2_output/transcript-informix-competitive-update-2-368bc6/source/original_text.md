# Informix Competitive Update: RDBMS Market Analysis — February 17, 1994

> Archived from: transcript-informix-competitive-update-2-368bc6.txt
> Original publication date: 1994-02-17
> Author: Peter S. Kastner

---

## Original Document Text



Informix competitive update 2_17_1994

⏰Sat, 11/16 14:49PM · 42mins

AI Notes

 
 Summary
 This meeting transcript features Peter S. Kastner, Vice President of Aberdeen Group, presenting an analysis of the RDBMS market to Informix's sales team. Kastner provides a comprehensive overview of Informix's position relative to its competitors, focusing on Oracle, Sybase, and Ask Ingress. He discusses various aspects of the market including financial performance, product announcements, and technological capabilities. Kastner emphasizes Informix's strengths in scalability, performance, and development tools, particularly their 4GL technology. He also highlights areas where Informix needs improvement, such as in replication technology and large database support. The presentation covers market trends, competitor strategies, and predictions for the future of the RDBMS market. Kastner provides actionable insights for the Informix sales team to leverage in their sales strategies and customer interactions.
 Chapters
00:00:03 Introduction and Background of Peter S. Kastner
 Speaker0 introduces Peter S. Kastner, Vice President of Aberdeen Group and General Manager of their Commercial Systems Practice. Kastner is described as a leading analyst in client server, distributed data processing, OLTP, and the database industry. His background includes roles at Digital, Prime, and Stratus, as well as 10 years as a consultant with Arthur D. Little.
00:01:23 Overview of the RDBMS Market
 Peter Kastner describes the RDBMS market as a 'jungle', highlighting the confusion for both salespeople and customers. He mentions Aberdeen's relational database buying guide, which will be distributed to the sales force. Kastner outlines his presentation, which will cover important issues in database technology, competitor ratings, and Informix's position in the market.
00:03:11 Common Playing Field Features
 Kastner discusses features that are common across all major RDBMS products, including architecture, ANSI SQL, referential integrity, stored procedures, triggers, and two-phase commit. He advises not to spend much time competing on these features but to ensure customers understand their benefits.
00:04:00 Key Technologies Buyers Should Look For
 Kastner outlines important technologies that differentiate RDBMS products, including extensibility, scalability, development tools, ease of use, performance, distributed data access, large database support, and standards awareness. He then details Informix's responses to these areas, highlighting strengths in scalability, development tools, and performance.
00:07:52 Financial Comparison of Major Competitors
 Kastner compares the financial performance of Informix, Oracle, Sybase, and Ask Ingress. He notes that while Informix is in fourth place in terms of revenue, it has the best profit margin at 15.3%. Kastner emphasizes the importance of profitability for future investments.
00:10:02 Market Position and Direction of Competitors
 Kastner uses transportation metaphors to describe the market positions of the major competitors. He portrays Sybase as a fast race car, Oracle as focused on future models, Ingress as slow and late, and Informix as a reliable, efficient van for transporting data and information.
00:11:50 Recent Product Announcements and 1994 Expectations
 Kastner reviews recent product announcements from each competitor and outlines expectations for 1994. For Informix, he highlights Online version 6.0, SE on Windows NT, and upcoming 4GL++ announcement. He also discusses Oracle's multimedia focus and Sybase's System 10 rollout.
00:19:39 Key Issues for Customers in 1994
 Kastner identifies four main issues customers are considering: parallel processing, higher power tools, replication, and enterprise connectivity. He notes that these align well with Informix's themes.
00:21:02 Detailed Analysis of Competitor Strengths and Weaknesses
 Kastner provides a detailed analysis of each competitor's strengths and weaknesses in areas such as scalability, distributed technology, open technology, and distributed tool technology. He rates Informix as better than average in several areas, particularly in scalability and development tools.
00:38:11 Informix's Current Position and Future Outlook
 Kastner concludes by summarizing Informix's current market position from various perspectives (Wall Street, trade press, analysts, customers, prospects). He predicts Informix's position in a year, highlighting expected strengths in object-oriented tools, parallel database technology, and large database support. Kastner also provides a positive stock price prediction for Informix.
 Action Items
00:35:36 Informix sales team should leverage their strong 4GL-based tools for high productivity programming in commercial applications.
00:35:50 Informix should emphasize their scalability from desktop to enterprise scale in sales pitches.
00:36:10 Informix should highlight their vertical market dominance in areas such as retail, financial services, and services.
00:36:28 Informix sales team should emphasize the ease of administration and low DBA hours required for Informix installations.
00:36:55 Informix should focus on gaining more customers with large databases (100+ gigabytes) to strengthen their enterprise position.
00:37:16 Informix should leverage their price performance leadership in sales discussions.
00:37:52 Informix sales team should explain their per-user pricing model as a competitive advantage.
00:38:11 Informix should prepare for the rollout of object-oriented graphical and 4GL-based tools.
00:38:32 Informix should focus on practical parallel database technology through DSA for symmetric multiprocessors.
00:39:38 Informix should work on improving their replication capabilities to catch up with competitors by late 1994.

Transcript

It's my pleasure to introduce Peter S. Kastner, whose presentation I think you're going to find most interesting. We've had the pleasure of working with Peter in the past as he has addressed our sales training classes on the subject of our industry, our competitors, and how they fit, how they rank. 

Let me give you just a brief introduction of Peter and his background. Peter is currently Vice President of the Aberdeen Group and General Manager of their Commercial Systems Practice. He's one of the leading analysts of trends in client server, distributed data processing, OLTP, and the database industry at large. 

Prior to joining Aberdeen, Peter spent some time in the hardware business with both Digital and Prime as a marketing executive, and also with Stratus in helping to architect their entree into the fault-tolerant business. 

I think one of the things that gives Peter a unique insight into our industry is that he spent over 10 years as a consultant with Arthur D. Little, taking a very close look at complex systems and being involved in many such developments in a variety of industries, ranging from manufacturing to financial services, healthcare, and government industries. 

And now, let's spend some time with Peter and take a very close look at our competition. 

Thanks, Ed, for the opportunity to get in front of you as an audience around the world again. Sorry I can't be there in person. I know I've met many of you at the Informed Exhales training courses over the last couple of months. 

Well, we think that the RDBMS battlefield right now is literally a jungle. It's tough for you, and even without some rock and roll by Guns N' Roses, you can all imagine, as you see every day, getting out there and competing. 

We also see how difficult it is for your customers as well. And the confusion has led Aberdeen as a market research firm to put together a relational database buying guide written to assist buyers in rating databases and seeing how they can help select databases for what they really want to do. 

Each of you in the sales force around the world will be receiving one of Aberdeen's buying guides in the month of March 1994. What I'm going to do is spend some time talking with you today, kind of in a fireside chat fashion, about what the important issues are in competing in the database arena in the first quarter of 1994. 

We know it's gonna change, but we think it's important to communicate to you what's important in database technology, how we rate the different competitors in the areas of finance, in the areas of positioning and the products they're talking about. 

We'll take a look at a detailed look at the competitors themselves, the features in their products, and how we would rate them vis-a-vis Informix. And then lastly, we'll give you Aberdeen's frank assessment of where Informix is strong, where you're well positioned, where your weaknesses are, and where we think you're gonna be in a year. 

Let's first take a look at what Aberdeen calls the common playing field features. These are relational database features that basically everyone has, and they're not worth spending a lot of sales cycle time in comparing yourself with the competition. 

Things like an architecture, everyone has an architecture, everyone does ANSI SQL. Referential integrity and stored procedures and triggers are all technology that all your main competition has. Two-phase commit, high performance, et cetera. 

We don't think you should spend a lot of time competing on these features, but clearly it's important to make sure your customers understand that you do have these common playing field features and what the benefits could be in the customers using them. 

Well, let's move on then to the technologies that buyers should be looking for. And we think this is important because there are differentiations that are important to Informix. How extensible is the architecture? 

How much scalability can we have? Can we grow from the desktop all the way up to enterprise scale? Everyone has development tools, but how easy are they to use? How robust and strong are there? Performance is always an issue, but Informix is a leader in all around performance. 

Distributed data access is becoming more important as people begin to distribute their processing out around their enterprises, organizations, and oftentimes now around the world. We need to access data from clients. 

We need to access data from our legacy systems, the old mainframes as well. How do we do that? Increasingly now, we've got the need to support large databases, which to customers means 100 gigabytes and up. 

And many now, including Informix customers like Walmart are looking at databases of over a terabyte, big scale up from what we've seen before. And lastly, standards are important. Let's be aware of standards. 

So let's take a look for a moment now at these issues and what Informix's responses should be. In the architectural extensibility area, Informix has the dynamic server architecture, a strong positioning for where processing and users should think of going in the future. 

In the scalability area, Informix has a strong differentiation because you have Informix SE, a very strong product that runs on the desktop and small work group servers. And yet you have online that can take you up to the largest enterprise installations. 

In the development tools area, you have three different tools today. In Informix 4GL and in Hyperscript and Hyperscript tools, you'll soon have in Informix 4GL++, a highly differentiated object oriented tool. 

Fourth area would be administrative ease of use, with tools like Informix DBA, Superviews, and although it's hard to describe to your customers your ability to install quickly, to require less database administrator at time, these are all very important features that are better than the competition. 

And all around performance, well heck, you've probably all seen the Aberdeen viewpoint by now that says TPCC is the way to go, and we've seen your ads that say it's Informix 15, competition, nothing. 

The TPCC is an important benchmark and your customers should understand why it's important and why Informix does so well. In the distributed data access area, we have the dynamic scalable architecture and Informix's replication technology, the ability to move data around an organization to other servers as it's necessary. 

In the 100 gigabyte and up space, yeah, you have some customers beginning to do this, but frankly, few customers are doing it yet. The important point is to make this a checklist item that you can do it and prove that with the stronger, more robust tools in online version six, you have the opportunity to do this better. 

And lastly, standards awareness in Formix is at least as good as the competition in the major areas of ANSI SQL, Xopen, ODBC, and importantly in the government markets, particularly V1 Security. So having set the stage in what's important and what's not, let's look at the RDBMS jungle. 

Let's compare the suppliers, first on their finance and their positioning, and then head to head in the various areas of database technology. First, let's take a look at the financials of the four major competitors. 

And I do this in three different ways because the Wall Street types can look at Informix from three different standpoints. If we look at Informix from the financial standpoint, you're in last place in terms of revenues. 

In 1993, the last 12 months, clearly Oracle was in first place. Sybase is now noticeably bigger on revenues. And if we take all the revenues of Ask Ingress, the database, and the manufacturing software side of the house, they can say they're bigger too. 

So in this point of view, Informix comes in fourth place. And if we look at reported growth over the last 12 months, Sybase has been growing at a wicked pace and everyone knows it, some 62% in the last 12 months. 

But even Oracle has been moving along well at 28%. Ask, having faltered, and we'll talk more about that shortly, had grew at a negative 6% rate, they shrank. And Informix is clipping long at a very respectable 25% rate, respectable compared to the rest of industry, but again, not first place in terms of the rapid growth that we're seeing in the RDBMS market itself. 

What Wall Street really likes in Informix is in your profitability. The fact that Informix has the best profit margin at 15.3% compared to 11% for Oracle and 10% for Sybase. Ingress, last place again, they're showing a deficit of 4%. 

So your profitability is important. Profits, as you can explain to customers, are important because you need to make money in order to invest for the future. Let's move on and look at the market position and direction of the four major competitors. 

And I show them here as forms of transportation. I'll leave you a moment to guess which of the four competitors go with each of the four icons. Time's up. Well, I think most of you probably picked Sybase as the fast race car. 

Fast on Wall Street, claiming to be the fast, hot company. And that's certainly where they've positioned themselves. The car keys go to Oracle. They're talking about the 1996 model to their customers, things like Oracle version eight and object orientation. 

When people want to buy databases this quarter, this year and implement with what they can use and deploy today. Ingress, although they've had really strong technology in the past, has been late and slow in delivering new updates of their technology to their customer base, and they're frankly leaving them behind. 

So that leaves Informix, and the icon of the Aerostar Oconovan. Is this bad? Am I making fun of Informix? Not at all, because I think if you define and describe Informix to your customer base and prospects of MIS buyers who are looking for robustness, for the ability to transport goods, i.e. 

data and information, economically and with few breakdowns, there's nothing wrong with a van as being a very efficient and excellent mode of transportation. I wouldn't be embarrassed at all to call yourself a van. 

Let's look at the recent product announcements, because by looking at the product announcements of the competition, you'll be able to determine what they're liable to be talking about to their customers and your prospects. 

Informix of course has been pretty busy in the last few months talking about online version 6.0 and the dynamic server architecture. Good stuff. Make sure your prospects know about it. Another important announcement was the availability of SE on the Windows NT operating system. 

While NT is going to grow in 1994, you'd be amazed at how much buyer interest there is in this operating system. You have it, the competition, certainly Oracle does not, as they work away in the labs as we speak on Oracle Lite, whatever that might be. 

Ask Ingress is talking about their open Ingress product, a very good set of replication capabilities, but they have some other problems we'll get to in a little bit. Oracle's on two main tracks right now. 

They also have had a product update in version 7.1 and some replication capabilities that go with that. They're also talking, as was in the news yesterday with glitzy Hollywood presentations about multimedia and the 500 channel capabilities of Oracle in the future. 

Now as to when we actually get 500 channels on our desktops and when we actually sell some systems in this area, that's another story. Sybase talking about shipping system 10. Remember that thing they announced in November of 1992? 

System 10, a lot of the pieces are shipping. Replication, another area where they expect to take leadership role. It's another hot area for them and the fact that they're finally, finally getting their build momentum tools replacement out in the beta test. 

Here's what Aberdeen expects we'll see in 1994 from the major database competitors. From Informix, clearly you'll be rolling out your online version 6 for enterprise class servers. You'll be rolling out DSA on more platforms and later in the year version 7, all good stuff. 

Around mid-year, an important announcement with 4GL++ that will give you more graphical and object-oriented tools. At the low end, you'll be gaining market share with your Novell NetWare loadable module and with the SE4NT. 

And later in the year, you'll come online with your replication products. Next is Ask Ingress. They've got a tough role and if you want a marketing job from hell, that might be the place to be right now. 

They've got to tell people they haven't died. The company in the last two weeks has announced the resignation of its 

hub. 

vice president in charge of worldwide sales, and the chief executive officer of Left the Company. This on top of pretty large 1993 deficits means Ingress first has to open with, we're going to be a viable customer going forward in the future. 

Beyond that, if they get beyond that step, we expect them to have a new Windows 4GL product announcement and later on in the year a relational database open Ingress product announcement as well. Oracle's going to have a busy year. 

One thing you should worry about is that it looks like Oracle's finally going to get a corporate marketing organization in place that can actually support the field. Should that happen, Oracle with their almost $2 billion dollar size is a juggernaut that anyone would want to stay away from in the RDBMS jungle. 

Fortunately, Informix has a number of differentiating factors that we'll talk later about. In 1994, we expect Oracle to bang the table about enterprise scalability. And of course, as we talked about earlier, the multimedia platform of choice and major deals with Bell Atlantic and US West Hollywood movie stars, desktop sets and protocols for fast 500 channel media serving is a great interest and will move a lot of pages of newspapers, 

but it won't sell a lot of licenses. With their massively parallel capability, we see Oracle challenging IBM mainframes and putting the cards down saying now is the time buyers to downsize. That helps Informix because with your Unix and NT base, you gain as people think about downsizing. 

Oracle's consulting organization is growing leaps and bounds, therefore Oracle is pitching the fact that they can help people put the various pieces together in building the client server applications that people want. 

On the other hand, Oracle's applications themselves continue to lag behind in technology and frankly are not as client server as Oracle would have you believe. We also expect product updates in the area of Oracle version 7, a second version of their cooperative development environment and in the Oracle case area. 

Next, we have Sybase and they too have a busy agenda as their marketing juggernaut keeps rolling. They're getting out the word that they've delivered on most, but not all, of their System 10 products and the database itself seems to be out there and working well on quite a few platforms at this point. 

Sybase is clearly pitching the fact that they're a Wall Street superstar. They're fast growing, they're growing in all their major areas, they're growing around the world and therefore the world should be coming to their doorstep. 

We know that's not true. The replication server they believe is a truly differentiating product and they're beating the drums on why people want to replicate data around organizations in order to do decision support or to funnel transaction processing information to other areas. 

This is an area where Informix needs to be careful during the nine months before you roll out your replication products above and beyond the snapshot capability you've got coming. Build Momentum, which is Sybase's tool set, is a real problem area for them, but they're putting the best light on it. 

It's a Windows-oriented product that won't be available until the third quarter of this year. That means the same old APT tools that are mostly character mode are the ones that Sybase Salesforce will really have to flog. 

On the other hand, there's Gain Momentum, the product Sybase brought with their gain acquisition last year. Gain works now on a number of Unix platforms, IBM, Sun, Hewlett-Packard, and is working well in those. 

Sybase is focusing the multimedia capabilities of Gain Momentum into the federal government marketplace and into the retail marketplace where they see it being used in real-time kiosks. Good news for Informix is there probably will never be a Microsoft Windows version of Gain Momentum, and Microsoft's operating system transition to Chicago will probably cause Sybase to put off until late 94, or practically speaking 95, 

a multimedia gain on a Windows environment. Navigation server, which is Sybase's response to the need for parallel processing, continues to slip. We don't expect this to hit the marketplace until late 94 and maybe even 1995, and then it'll only be on a single platform at first, the NCR3600. 

Finally, this broad-based thing called enterprise momentum, that's Sybase's way of saying instead of coding in 3GLC, we're going to have everyone code in process case terms. And I don't think that product will do nearly as well as all the hype they're putting around it. 

Time will tell. Again, it's not even in the marketplace yet. Now let's take a look at the four issues that Aberdeen thinks customers are really thinking about in 1994. And the good news is they're right on target with many of Informix's themes. 

First, we have parallel processing. How can we harness the power of today's symmetric multiprocessors in order to get more users or speed up queries? Next, we always have an incessant need for higher power tools for the ability to get applications out quicker so our customers can get to market with their applications faster. 

Third, replication, the fact that we need to move information around the organization to where it needs to be acted on for decision support. And four, the fact that slowly but surely we're seeing enterprise connect all the islands of automation together through middleware, through the connectivity capabilities as well. 

Now I'd like to spend a few minutes really summarizing the quantitative analysis that Aberdeen has done in the relational database buying guide I talked about you all receiving soon. We're going to look at six different areas of technology in turn and based on the sum of different features which you can read in much more detail and you will read the book please because it's important to your success. 

Look at these features and how the various competitors do in those features. And in each area we'll rate competitors as being less than average, as being average with the competition, as being better on average or being best in class. 

First, let's talk about scalability. In the area of scalability we're really asking the question can I write an application once, one time and have it scale from desktop all the way to fit into the enterprise. 

And the areas that we look at in terms of technology include your non-parallel performance, your IE, TPCA benchmarks, TPCC benchmarks, your parallel performance which will show up as your DSA architecture comes to the front, your ability to satisfy the need for large databases, those hundred gigabyte and up sizes, and then your high availability capabilities. 

In this area in form it clearly gets a plus. You're better than the average. AskIngress is about average. Interbase is less than average. Oracle gets a plus primarily because of its large database and Oracle parallel server clustering capability. 

Progress is below par and software AG and Sybase are about the norm. Let's look at Informix's position in scalability. You're very strong. In fact, you're potentially the best in class in this area. With proven parallel performance and the benchmarks I hope you get out soon and more customers who are supporting greater than hundred gigabyte databases, Informix definitely could lead the industry in this important area. 

We think you've got best in class non-parallel performance as based on all the TPCC and many TPCA benchmarks that you've run. Your parallel performance sure looks good on paper and we're dying to see what you do with DSA in harnessing all the capabilities of the dynamic scalable architecture. 

Can only give you a so-so rating in terms of database scalability because frankly Informix only has barely a handful of customers who are now pushing the 100 gigabyte barrier. But you're gonna need to show a lot of customers doing very large databases in order to prove that you can take over a mainframe size application or the need for customers to put together the data warehouses they realize they must put together in order to do the decision support and information mining applications they really wanna put together. 

Lastly DSA with its replication capabilities gives you a higher level of performance, a higher level of availability as well, important to customers as they move towards the 24 hours a day, seven day a week, high availability necessary and mission critical systems. 

Now let's take a look at distributed technology and the question our users and customers are trying to answer is, can I distribute my computing and my data out into my organization and still be able to effectively administer it? 

In this area we give Informix an average grade and ask Ingress and Sybase a better than average grade primarily because of their newly announced replication products, the ability to move data automatically out throughout the organization. 

The areas of technology that Aberdeen looks at in weighing these grades is the ability to deal with tightly coupled data and loosely coupled data such as replication. Ask alone scores highly in the simultaneous update data area and then data administration particularly as we picture the dozens and ultimately thousands of sites becomes an absolutely critical area if we want to keep cost security and other issues under control. 

There are two areas to Informix's position in distributed data processing. Two phase commit is fine, you do it as well as anybody else but the competition is now moving the marketing to this thing called replication. 

You're behind right now in loosely coupled replication and it's an area you'll have to be careful of. You're likely to catch up though in late 94 with replication products as part of DSA. Ingress frankly leads, that's the good news but Ingress as a company as we've discussed is gonna have a hard time gaining a lot of market interest in these products as it goes through its financial troubles. 

No one frankly is outstanding in this distributed administration. This is an area where you're liable to get some questions but the tough ones probably won't come till 1995. What about open technology? 

And here the question is will my applications work with other data sources? In this arena Aberdeen takes a look at standards, at gateways, at open clients, at the use of open OLTP monitors such as Tuxedo and at the ability to access other suppliers' RDBMSs with tools. 

In this arena we think Informix is average amongst the competition and that Sybase in particular is leading the pack primarily because of its open client and open server technology. Let's talk about that and Informix's position. 

Informix is good, you're as good as anyone in terms of security with your B1 level and your online secure product. This plays well in the government markets in particular also in financial services where security is an important area. 

You're behind in gateway areas and Sybase clearly with their MDI acquisition of a week or two ago is going to decouple their need to hook SQL Server to their connectivity products and basically sell distributed open connectivity capability as a major advantage and as a separate product line. 

Informix is good in open OLTP and your open OLTP toolkit is unique. In conclusion, be aware of Sybase because they have the best story and the broadest suite of products in the open distributed data area. 

However, while Sybase may play this up, the reality is that the gateway products and the connectivity products that Informix has today will solve the vast majority of real world problems that customers are asking for today like connecting to DB2 for instance. 

Next, we look at distributed tool technology. And the question here is, how can I efficiently develop, deploy, and maintain distributed open production systems applications? Informix is strong in the tool area. 

You're definitely better than average. Ask Ingress also gets a good grade primarily on the fact of their Windows 4GL product. Software AG and Progress, two minor competitors, also have better than average grades. 

What's common to all of those? In Aberdeen's opinion, it's a 4GL. We're strong believers in programmers having to write fewer lines of code, fewer lines to maintain, fewer lines to deploy, faster time to market. 

You look at Sybase, for instance, and you will find the vast majority of Sybase applications are put together with the C language. And in fact, some of Sybase's most enthusiastic users are unionized C programmers at US West, for instance. 

Let's take a look at how Informix rates in this area. Ingress's Windows 4GL, because they already have an object oriented version, has to rate higher than the tools you have today. Obviously, Informix's 4GL++ will help change that situation. 

Sybase's 3GL bias is going to cause them to win in an open tool environment with things like open client, but we think that 4GLs in general and Informix's 4GL has proven in tens of thousands of installations is more productive. 

That's got to be an advantage to you and one of your significant differentiators. Oracle is going to talk about their 15 tools in their cooperative development environment, CDE. It's as wide as the Mississippi River, but it's only an inch deep. 

That's 2.5 centimeters for you international viewers. Oracle's going to talk about the fact that they have integrated case. But Informix's response is that you tie into best in class individual case tools from third parties. 

In conclusion, Informix is best at the high productivity commercial applications that commercial users really need to put together today. That your 4GL++ product will be a major advantage because it will modernize the look and feel and add object orientation, a technology that Aberdeen finds the commercial market and users looking to adapt over the next couple of years. 

You'll be right on time and right on target with 4GL++. Spend a brief moment looking at what we call the other technologies. What else is needed to develop a high quality distributed open production system? 

Two areas here being business rules processing and binary large objects blobs. In this arena, there are a few differences amongst the competitors in the business rule area. And frankly, we'd suggest you avoid the rat hole, the diversion of getting into how many business rules and policies can fit inside a stored procedure. 

Won't gain much there. We see the competition gaining in blobs and binary large object support. Oracle clearly is making a huge splash with their media server, their ability to move movies on demand, kinds of things around. 

This is not, however, what users practically want to do, which is, for example, put a picture onto a screen of a human resources system. Sybase is also making a great deal of the cross platform capabilities of their gain momentum product. 

But remember, this takes a 32 megabyte Unix workstation today in order to work. The platform of choice for 70% of all users today is Microsoft Windows in 4 to 8 megabytes. And here's where your tools really shine. 

And lastly, let's take a look at end user solutions. Because it's not just the products the customers are asking for, it's what services, what third party solution applications can be brought to the table, what consulting and services. 

Here, primarily through Informix's wide variety of third parties, your ISVs and their solutions, your multiple channel strategy, and your international support, then Informix gets a better than average grade. 

So does Oracle, mainly because of the Oracle financials and their strong consulting capabilities? So let's wrap up this tape with where is Informix? What does Aberdeen think is going on? Let's start by asking this question from the eyes from the perspective of various audiences. 

From Wall Street's perspective, Informix is in third place behind the larger Oracle and the hot, fast-moving and fast-growing Sybase. But the reality is that Informix is returning a huge return on equity, and your stock has huge upside potential, as has been demonstrated in the last couple of weeks of February when we're shooting this tape by the strong move up on Informix's strong fourth quarter. 

What does the trade press think about Informix? Well, the opinion on the street where the street press is, there's no story here with Informix, pohum. But the reality is, as we've discussed on the tape today, there's a lot going on in Informix, and some very exciting stories, and some leadership positions that you've taken in the last year or so. 

How about analysts like Aberdeen Group or Gartner or others? They still have the perception that Informix is for low-end systems. They really haven't got the message that Informix is rapidly moving up into strong online enterprise scale, running large Fortune 1000 global type customers. 

People like Kentucky Fried Chicken, Walmart, thousands of servers at Dresner Bank in Germany, et cetera. You have a very good large company base. Get lots of good quotes, and you should get more respect. 

What about Informix's customer base? Ask them. You ought to ask that question, is what they're saying. Because the reality is that Informix has never been better at what it's doing. Sure, there'll always be quibbles, but a lot of things have been improved by Aberdeen surveys over the last year or so. 

And finally, what about your prospects? The new name accounts you need to bring new blood into the company. Well, they're still asking the question, who's Informix? Because so many of Informix's sales in the past have been hidden. 

They've been embedded in systems like it, high at hotels, where they're not largely visible. Getting the Informix name out is the job of Informix's marketing department. And you've seen a lot more vigor and things coming out of them in the last year than we ever have in the past. 

Right now, you're in industry secret success with every indication that you're gonna do a lot better. Where do we think, where does Aberdeen Group think Informix's best position today? Well, number one, you have excellent 4GL based tools. 

Tools that lead to high productivity programming for the bread and butter commercial applications that people need to put together today. As they move towards client server, you're also moving your capability to work well there as well. 

Not only in character base, which won't go away, but also with graphical user interfaces. Next, you have that scalability, an important point to work from desktop or work group with SE and scale all the way up into small and medium enterprises to enterprise scale. 

And then your vertical market dominance in areas such as retail, financial services and services in general. We give you credit for great scalability. It's proven that benchmarks document your strong scalability and high performance capability. 

We also think you don't get enough credit for the administration capabilities, the installation ease of use, the deployment, the lack of database administrator hours that are necessary to keep an informics installation up and going. 

Work at selling that concept to your prospects and customers because it's an important one. You're certainly positioned to move up on the enterprise food chain of the jungle we've been talking about. 

As you have more customers, work with larger databases, as your replication products come out, and as the DSA architecture comes into play and shows your ability to support more users, faster processing, ultimately on massively parallel machines that will do much more than any mainframe can do today. 

Clearly, your benchmarks show you're a price performance leader. And I got to tell you, when it gets to the bottom line, many users are very concerned today about what is the cost per user, not only at initial purchase time, but over the lifecycle of the application, which ties back to your leadership in productivity as the applications are built, maintained, and deployed. 

Finally, you ought to take to the bank the fact that you've been very upfront in terms of changing your pricing algorithms. And per user pricing has got your competition being very antsy, very unsure of themselves. 

And therefore, take your openness on pricing to the bank, explain those capabilities to your customer, and help it become a win-win situation between Informix and its customers. Well, I've been asked to rub out the crystal ball here. 

And while it's difficult to do, let me give you our opinion of where Informix will be in a year. You're going to be known as an excellent provider of object-oriented graphical and 4GL-based tools, an important market as customers begin to sort out the wheat from the chaff in client-server development tools. 

A lot going on there. Next, you're a leader and will be in practical parallel database technology. No smoke and mirrors, no really sophisticated stuff that works only on massively parallel machines, but real bread and butter stuff through DSA that will get users more performance at lower cost out of their symmetric multiprocessors, or later their clusters. 

Third, your customers are going to prove your ability to move up to those large databases, 100 gigabytes today, and within a very short period of time, a terabyte or more. Why? As we discussed in our viewpoints about why parallel scalable technology will break the downsizing log jam, Aberdeen sees a three to five fold increase in enterprise queries over the next several years. 

Users are demanding to get a data and your technology, your architecture with DSA is very strong in this area, something that needs to be articulated and explained in common household terms to buyers. 

We think even with your plans for a replication later on in 1994, you'll still be average in the industry and perhaps behind the leaders. However, this will still a year from now not be the most important differentiating factor, although clearly there'll be a lot of marketing hype involved. 

We believe Informix has better integrated tools for both developers and users. And as you move things like Hyperscript closer to 4GL++, the integration will start to become more apparent. And lastly, important to all the stockholders in Informix, we think the stock will be at, oh, can't read that. 

I think it's gonna be at $44 a share. Now, Phil White's told me that won't happen because you'll split the stock before then, but that's not a number that we just picked out out of the year. Informix is only at 19 times your trailing earnings. 

Oracle and Sybase are up at 50 to 60 times earnings. So if Informix's great story just gets out there, we could see your multiple increasing and the stock going up with it. That would be success for all of us. 

So thanks, ladies and gentlemen, for this opportunity to come talk to you. We hope that you take a look at the Distributed Open Relational Database Buying Guide that you all be getting. Feel free to call me personally in Boston if you have any questions. 

And I hope to talk to you again soon. Thank you and goodbye. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-informix-competitive-update-2-368bc6 |
| title | Informix Competitive Update: RDBMS Market Analysis — February 17, 1994 |
| author | Peter S. Kastner |
| date | 1994-02-17 |
| type | transcript |
| subject_domain | database-market |
| methodology | oral-history |
| source_file | transcript-informix-competitive-update-2-368bc6.txt |
| license | CC-BY-4.0 |

### Abstract

Peter S. Kastner, VP of Aberdeen Group, presents a comprehensive competitive analysis of the RDBMS market to Informix's worldwide sales team. The presentation covers the financial standing of Oracle, Sybase, Ingres, and Informix; technology differentiators including scalability, distributed data access, development tools, and performance (TPC-C benchmarks); competitive threats and strategies; and Aberdeen's frank assessment of Informix's strengths and weaknesses. Kastner predicts Informix's stock will reach $44/share and positions Informix as a strong but underrecognized player in the enterprise database market.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Provides rare insider view of RDBMS competitive landscape at a pivotal moment; includes financial metrics, benchmark data, and forward-looking product roadmap predictions for all major 1994 database vendors. |
| **Relevance** | high | Kastner is the sole presenter throughout; primary source for Aberdeen's database analytical framework and competitive ratings methodology in early 1994. |
| **Prescience** | high | Kastner's prediction of Informix's trajectory (4GL tools, parallel DSA, large databases, replication gap) proved highly accurate; stock and market predictions partially correct though Informix later faced accounting scandal. |

### Prescience Detail


**Prediction 1:** Stock price prediction 1-year
- **Claimed:** Kastner predicts Informix stock will be at $44/share in approximately one year; currently at 19x trailing earnings vs Oracle/Sybase at 50-60x
- **Year:** 1994
- **Confidence at time:** medium

**Actual Outcome 1:** Stock price 1-year actual
- **Result:** Informix stock peaked in 1996 but collapsed in 1997 due to securities fraud by CEO Phil White; share price fell from ~$48 to ~$7. The company was eventually acquired by IBM in 2001 for $1B.
- **Confidence:** verified
- **Notes:** SEC enforcement action against Phil White (SEC.gov); IBM acquisition confirmed by multiple sources

**Prediction 2:** Navigation Server availability
- **Claimed:** Don't expect Navigation Server to hit the marketplace until late 1994 and maybe even 1995; only on single platform NCR 3600 at first
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 2:** Navigation Server actual release
- **Result:** Sybase Navigation Server (parallel database) was eventually released but did not achieve broad commercial success. Sybase lost market share through the late 1990s and was acquired by SAP in 2010.
- **Confidence:** high
- **Notes:** Sybase Navigation Server shipped but underperformed; Sybase's parallel database strategy was eclipsed by Oracle Parallel Server and IBM's offerings

**Prediction 3:** 4GL++ product readiness
- **Claimed:** Informix 4GL++ will be announced around mid-year; will modernize look and feel and add object orientation; commercial market adapting OO over next couple of years
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 3:** Stock price 1-year actual
- **Result:** Informix stock peaked in 1996 but collapsed in 1997 due to securities fraud by CEO Phil White; share price fell from ~$48 to ~$7. The company was eventually acquired by IBM in 2001 for $1B.
- **Confidence:** verified
- **Notes:** SEC enforcement action against Phil White (SEC.gov); IBM acquisition confirmed by multiple sources

**Prediction 4:** 1-year DSA impact prediction
- **Claimed:** In a year, Informix will be known as leader in practical parallel database technology through DSA; bread-and-butter stuff on symmetric multiprocessors
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 4:** Stock price 1-year actual
- **Result:** Informix stock peaked in 1996 but collapsed in 1997 due to securities fraud by CEO Phil White; share price fell from ~$48 to ~$7. The company was eventually acquired by IBM in 2001 for $1B.
- **Confidence:** verified
- **Notes:** SEC enforcement action against Phil White (SEC.gov); IBM acquisition confirmed by multiple sources

**Prediction 5:** Replication position in 1 year
- **Claimed:** Even with replication plans for late 1994, Informix will still be average in the industry and perhaps behind the leaders a year from now
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 5:** Stock price 1-year actual
- **Result:** Informix stock peaked in 1996 but collapsed in 1997 due to securities fraud by CEO Phil White; share price fell from ~$48 to ~$7. The company was eventually acquired by IBM in 2001 for $1B.
- **Confidence:** verified
- **Notes:** SEC enforcement action against Phil White (SEC.gov); IBM acquisition confirmed by multiple sources

**Prediction 6:** Large database terabyte prediction
- **Claimed:** Within a very short period of time, Informix customers will demonstrate 100 gigabytes today and a terabyte or more; three to five fold increase in enterprise queries over next several years
- **Year:** 1994
- **Confidence at time:** medium

**Actual Outcome 6:** Stock price 1-year actual
- **Result:** Informix stock peaked in 1996 but collapsed in 1997 due to securities fraud by CEO Phil White; share price fell from ~$48 to ~$7. The company was eventually acquired by IBM in 2001 for $1B.
- **Confidence:** verified
- **Notes:** SEC enforcement action against Phil White (SEC.gov); IBM acquisition confirmed by multiple sources


### Entities Referenced (14)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Informix Software | company | acquired | IBM |
| Oracle Corporation | company | public |  |
| Sybase | company | acquired | SAP |
| ASK/Ingres (Computer Associates) | company | acquired | Computer Associates / Broadcom |
| Phil White | person | active |  |
| Walmart | company | public |  |
| Gartner Group | firm | public |  |
| Kentucky Fried Chicken (KFC) | company | public |  |
| Dresdner Bank | company | merged | Commerzbank |
| Bell Atlantic | company | merged | Verizon |
| US West | company | merged | Lumen Technologies |
| MDI (Sybase acquisition) | company | acquired | Sybase |

### Technologies Referenced (17)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Informix Online / Online OLTP | database | Informix | growth | merged-into-IBM-Informix |
| Informix SE (Standard Engine) | database | Informix | growth | legacy |
| Informix 4GL | language | Informix | mature | legacy |
| Informix 4GL++ (Object-Oriented) | language | Informix | emerging | obsolete |
| Informix Dynamic Scalable Architecture (DSA) | framework | Informix | emerging | merged-into-IBM-Informix |
| Oracle Version 7 (and 7.1) | database | Oracle | mature | obsolete |
| Oracle Media Server / Multimedia Platform | platform | Oracle | emerging | obsolete |
| Sybase System 10 | database | Sybase | emerging | obsolete |
| Sybase Replication Server | middleware | Sybase | emerging | legacy |
| Sybase Build Momentum (Tools) | application | Sybase | emerging | obsolete |
| Sybase Gain Momentum | application | Sybase | emerging | obsolete |
| Sybase Navigation Server (Parallel) | database | Sybase | emerging | obsolete |
| Ingres Open Ingress | database | ASK/Ingres | declining | legacy |
| TPC-C Benchmark | framework | Transaction Processing Performance Council | growth | active |
| Microsoft Windows NT | platform | Microsoft | emerging | evolved |
| Oracle Cooperative Development Environment (CDE) | application | Oracle | growth | obsolete |
| ODBC (Open Database Connectivity) | protocol | Microsoft | growth | legacy |

### Observation Summary

- Total observations: 40
- By type: expert-opinion: 15, technology-assessment: 7, viability-prediction: 6, actual-outcome: 6, market-data: 4, benchmark-result: 1, personal-recollection: 1
