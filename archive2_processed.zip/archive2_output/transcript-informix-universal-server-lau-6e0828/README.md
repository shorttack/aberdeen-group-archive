# Informix Universal Server Launch Event — December 1996

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996-12-01 |
| Type | transcript |
| Domain | database-market |
| License | CC-BY-4.0 |

## Abstract

Full transcript of Informix Universal Server product launch event (~91 minutes). Phil White (CEO), Mike Stonebreaker (CTO, founder of Ingres and Illustra), Ed Zander (President, Sun Microsystems), Malcolm Colton (Director of Database Marketing), Dave Cope (GM DataBlade Business Unit), and multiple beta customers and DataBlade partners present. Peter Kastner is quoted in the event as an analyst endorsing the product. The launch introduces the first object-relational database combining Informix Online's scalability with Illustra's object extensibility, including DataBlade plugin modules. The event demonstrates applications from insurance, financial services, entertainment (Creative Artists Agency/Planet Hollywood Online), geospatial (MapInfo, CitySearch), imaging (Kodak PIX Factory), time-series (FAME), text retrieval (Excalibur), and internet commerce (Open Market). Informix is named most influential database for two consecutive years.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 30 |
| technologies.csv | 21 |
| observations.csv | 50 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). Informix Universal Server Launch Event — December 1996.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
