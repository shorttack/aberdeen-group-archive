# Informix Universal Server Launch Event — December 1996

> Archived from: transcript-informix-universal-server-lau-6e0828.txt
> Original publication date: 1996-12-01
> Author: Peter S. Kastner

---

## Original Document Text



Informix Universal Server launch (12_1996)

⏰Sat, 11/16 14:58PM · 91mins

AI Notes

 
 Summary
 This transcript covers the launch event for Informix Universal Server, a groundbreaking object-relational database system. Phil White, CEO of Informix Software, introduces the product as a reinvention of database technology. Mike Stonebreaker, Chief Technology Officer, explains the concept of object-relational databases as the next great wave in database technology. The Universal Server is presented as a single engine that can manage not just numbers and characters, but also complex data types like images, video, and spatial data. Ed Zander from Sun Microsystems discusses how this technology aligns with the growing trend of network computing. Malcolm Colton, Director of Database Marketing, emphasizes the ease of use, speed, and extensibility of the Universal Server. The event showcases various applications of the technology across industries, from insurance to entertainment. Dave Cope, General Manager of the DataBlade Business Unit, introduces the concept of DataBlades, which are plug-in modules that extend the functionality of the Universal Server. Several partners present their DataBlades, demonstrating the versatility and potential of the technology. The event concludes with Phil White highlighting Informix's position as the most influential database in the industry for two consecutive years.
 Chapters
00:00:18 Introduction and Overview of Informix Universal Server
 Phil White introduces the Informix Universal Server as a redefinition of database performance, extending it into new dimensions. He emphasizes the product's ability to handle complex data types beyond just numbers and letters. White positions this launch as the beginning of a new era in databases.
00:01:34 The Evolution of Informix's Database Technology
 Phil White discusses Informix's journey from 1994, when they introduced the Dynamic Scalable Architecture, to the present launch of the Universal Server. He highlights the company's focus on parallelization and the development of a product line that can seamlessly scale from workgroup to massively parallel systems.
00:05:22 Object-Relational Databases: The Next Great Wave
 Mike Stonebreaker, Chief Technology Officer, explains the concept of object-relational databases. He argues that this technology will replace traditional relational databases as the mainstream database technology over the next few years. Stonebreaker emphasizes the ability of object-relational databases to manage complex data types beyond simple numbers and character strings.
00:10:17 Informix's Time-to-Market Advantage
 Phil White discusses Informix's advantage in shipping the Universal Server ahead of competitors. He presents analyst opinions praising Informix for delivering advanced technology on time, giving them a 12 to 18-month lead in the market.
00:12:22 The Potential of Object-Relational Databases
 Phil White explains the market potential of object-relational databases. He estimates that current relational databases only handle 15-20% of the data needed for day-to-day operational decisions, while object-relational technology can manage the remaining 70-80%, including complex data types like text, video, and spatial data.
00:14:41 Sun Microsystems Partnership and Java Integration
 Ed Zander from Sun Microsystems discusses the partnership with Informix and how the Universal Server aligns with trends in network computing, internet growth, and Java technology. He emphasizes the importance of managing both structured and unstructured data in a single, seamless environment.
00:23:44 Universal Server Features and Benefits
 Malcolm Colton, Director of Database Marketing, presents the key features of the Universal Server. He emphasizes its ease of management, development, and maintenance, as well as its superior performance compared to middleware solutions. Colton demonstrates a performance comparison showing the Universal Server completing a query significantly faster than a middleware approach.
01:13:28 DataBlade Technology and Partner Ecosystem
 Dave Cope, General Manager of the DataBlade Business Unit, introduces the concept of DataBlades - plug-in modules that extend the functionality of the Universal Server. He announces the availability of 29 DataBlades and the announcement of 51 additional ones, covering areas from multimedia to geospatial applications. Cope also introduces several partners who present their DataBlades, demonstrating the versatility of the technology.
01:28:40 Conclusion and Industry Recognition
 Phil White concludes the event by highlighting Informix's recognition as the most influential database in the industry for two consecutive years. He credits the talent of the Informix team, including Mike Stonebreaker and other key individuals, for this achievement.
 Action Items
00:53:15 Phil White mentioned shipping the Universal Server product by the end of December on Sun and SGI platforms.
00:53:33 Phil White stated the plan to add NT and other Unix platforms by mid-1997.
01:14:41 Dave Cope announced the delivery of 29 DataBlades in December, with 51 additional DataBlades being announced.
01:15:27 Dave Cope mentioned that hundreds more DataBlades are in development with partners.
01:28:10 Phil White emphasized the need to continue setting the standard for performance, scalability, and extensibility in database technology.

Transcript

Information is everywhere. In everything, yet the technology to manage information has been limited by its inability to handle anything more complex than numbers and letters. Today, Informix redefines database performance, extending it into new dimensions. 

The new standard is performance with extensibility, innovation without limitations. Informix Universal Server. The universe is expanding. Ladies and gentlemen, please welcome the President and CEO of Informix Software, Mr. 

Phil White. Good morning. Maybe I should say good morning, great morning. It's welcome to all the worldwide press, the analysts, customers and prospects to what I think is going to be the beginning of a new era in databases. 

You know, the interesting part in a career, it's very seldom that you get to see a company reinvent itself. In 1994, we looked out at the marketplace and saw all these fast commodity processors being shipped into the marketplace and thought, you know, as those become more clustered into boxes, the biggest opportunity is going to be to parallelize queries and sorts and to re-architect a product to take advantage of production. 

parallelization. And in 1994, in January of 1994, we shipped that product called Dynamic Scalable Architecture. Today, in fact, as of July, we've completed the product line on that relational model. In July, we announced both the most graphical, easy-to-use, internet-enabled work group product for Unix and NT that can migrate transparently from a shared nothing and a shared everything from a UNI processor to a cluster to a massively parallel machine. 

And in July, we again announced our first massively parallel product that, for us, is equivalent of MVS DB2 for Unix and shortly for NT. And so for the first time, a true architected product would allow customers to write an application and migrate that application through any hardware architecture through Unix and NT without rewriting any code. 

Analysts have said we have the most scalable, most highest performance-oriented database in the industry, and I think we've proven that with industry-standard benchmarks like TPCCs and Ds, where we've led on almost every platform, the industry, and all of our competition. 

Most of the major application companies, like SAP PeopleSoft and VON, have shown their best performance on our technology. And going forward, we think it's that base that will allow us to reinvent the company again in December of 1996, with the first truly object-relational integrated architected database that would allow that relational foundation to migrate transparently into the object-relational world without rewriting code. 

So our competition talks about marketecture, marketing architecture. We talk about architecture and ship products. And I'm happy to announce that today we are shipping the world's first true universal server. 

Now, the interesting thing about the universal server is it's not just that it has object and relational combined. It's that for the first time, we give you the ability to extend to new data types, extend while being integrated, to ensure performance, scalability, manageability, tunability, and migratability. 

And again, between Unix and early next year, NT. Now, this all became possible with an acquisition we made last year of a company called Illustra. And in December of last year, for those of you who don't remember, Illustra was recognized by Database Programming and Design as the most influential database in the database industry. 

And I want to introduce to you the man who not only founded Illustra, but also the man who made it. but also Ingress, who is now our Chief Technology Officer, Mr. Michael Stoneberg. Now, you know, Mike, you know, you've written this book called Object Relational Databases, The Next Great Wave. 

Why don't you tell us what you mean by the next great wave? Great, Phil. Since I have some gray hair, I'm happy to let you know where this all came from and give you a little history lesson. And what happened was I was the founder of Ingress Corporation, and I worked on relational database systems in the research community in the 70s. 

This was the technology that got commercialized in the 80s and replaced CODASIL as the mainstream database technology. However, the research community in the early 80s had already figured out that relational database systems were only good for numbers and character strings. 

Because we tried applying them to geographic information systems. We tried applying them to mechanical CAD. We tried applying them to document imaging systems. We tried applying them to medical systems. 

And relational technology laid an egg outside of simple numbers and character strings. Why did that take place? Well, relational systems were designed only to manage numbers and character strings. That was what we were trying to do in the 70s. 

So the research community started trying to build a database system that would manage the rest of your data. There were two ideas that were exploited by this community. The first one was to add persistence to a programming language such as C++. 

This led to object-oriented database systems that had been on the marketplace for about five years. But as you can notice from this slide, acceptance has not been all that high because they don't scale very well to very large production environments. 

And they don't support SQL. The idea that seems much better, next slide, is to investigate what I chose to work on, which was object-relational database systems, which is to add objects to SQL. And in my opinion, this will be the next great wave. 

It will replace relational databases as the mainstream database technology over the next few years. What exactly is an object-relational DBMS? What it is is it's simply a single engine that instead of being designed to manage merely numbers and character strings, also manages objects. 

What do you need to do? Well, you need to add the standard object-oriented concepts, sets as a tool. a type constructor, polymorphism, inheritance, what are called row types, specialized indexes. You, of course, have to have typed large objects. 

And because I only get five minutes, I can't give you an academic lesson on what exactly this stuff is, but consult any object-oriented book or read my book. I'm not above hyping my own book. For $29.95, right? 

Absolutely, and I get a royalty on every one. So basically, it's an engine that adds objectness to SQL. But in addition, it does one other key thing. Next slide. It's not a black box, which is only changeable by the vendor at infrequent releases of new versions of the software. 

Instead, it's an open system into which you can add new kinds of objects and their behavior to customize universal server to your specific application needs. So it's an engine which instead of just managing numbers and character strings, will do that plus manage the rest of your data. 

And this will mean that the range of database technology is vastly extended from merely numbers and character strings to everything you've got. As Phil likes to say, if you can imagine it, we can manage it. 

Now the thing that I want to just close with is to say you want to do this in a single engine. This is not a technology based on band-aids and chewing gum and duct tape around a relational engine. You need a single engine that will manage objects and numbers and character strings, not a conglomeration of stuff surrounding an old technology. 

We are the only company shipping this integrated technology. Thank you very much. Mike, thanks for it. It's great. Thank you very much. That looked like Redwood Shores blowing up, by the way. Mike didn't talk about a band-aid and three warts, so it was interesting to see. 

You know, I think the great part about shipping a new technology is having a time to market advantage. And time to market advantage says you have to ship product. Now the interesting thing I think about this business is most of our competitors said that we couldn't ship this product. 

What they didn't know was that Mike Saranga and Mike Stonebreaker in May of 1995 started looking at how could we integrate the two technologies. We didn't announce the merger until December of 1995. And in fact, as you see on the charts, in February of 1996, we said we'd ship the product before Q4. 

September 30th, we shipped it to 20 to 30 customers, and here we are today announcing general availability, a full 12 to 18 months ahead of anybody in the industry, a full architected product ahead of anybody in the industry. 

And that's what's important. Let's hear from some analysts about what they think about shipping on time and what it really means. The fact that Informix can ship Universal Server this month I think is a surprise to many people, including me, and I think the fact that it can ship it this month gives it an opportunity to define what a Universal Server should be and what people should expect from an object relational database. 

Informix is first to market with Universal Server technology. Competition has to catch up. Unlike Informix's Universal Server, the Oracle network computing architecture at this point is primarily marketing talk. 

In the database industry, the ability to deliver advanced technology on time is key to credibility. Informix has succeeded in doing this with the Universal Server. It doesn't really surprise me that Informix is shipping when they said they would. 

They have been very good about keeping their commitments. Informix Universal Server is at least 18 months ahead of the competition at this point in time. You know, the other interesting thing about shipping an object relational model is if you look at today's relational database, it's estimated to be an $8 to $10 billion market. 

There are only a few competitors. As a matter of fact, they're getting fewer, not more. The barrier to entry is so high that I think this is the only segment of any industry where we don't see anybody new coming into the marketplace. 

And if it's an $8 to $10 billion market, and we handle only numbers and characters today, and that's if you look at the day-to-day operational decisions that are made using numbers and characters, that's only 15 to 20 percent of the data that customers need to really make day-to-day operational decisions. 

The other 70 to 80 percent is what you see on the screen. Text, video, spatial data, time series data, and that's what this is all about. So imagine a market that's growing at 30 to 50 percent. There's only a couple of players, no new players coming into the marketplace, and you've got an 80 percent growth opportunity, and you've got a 12 to 18 month lead on everybody that's currently in the marketplace. 

That's what's exciting. And our customers can get from where they are today to the new object relational model today without reprogramming. Now what I'm going to do is talk about data blades and why it's so important, because data blades are simply the giving you the ability to imagine data and allowing you to manage that data and create new and creative applications. 

with the ultimate goal being a picture is worth a thousand words. And I've yet to find a technology other than what we're shipping today that would dramatically increase in-user productivity without rewriting a lot of code to do it. 

Now I want to have somebody who's a great friend of mine personally, a great friend of Informix, and somebody who can tell you about new things happening in the industry and how the Universal Server and those new things play well together. 

Join me in welcoming Ed Zander, president of Sun Microsystems. Ed is in town because he's giving a keynote at DB Expo in an hour or so. So, Ed, thanks for joining us. By the way, what's the toaster? It's to dress up your PCs. 

We'll just talk about that in just a little bit. I'll come back, but that is our new thin client model. First of all, congratulations. Thanks for inviting Sun and myself here today. It's really exciting to see this technology, we think, very much with what we've been talking about for the last year or two, plus this technology. 

Users can now even go at a faster rate to this new network age. In many respects, as you know, Sun has been talking about the network as the computer for the last 10 years. In fact, in the last 18 months or so, we've seen three major technology dislocations, which I think plays very nicely to today's announcements. 

One is the growth of internet, intranet. And what that means is lots more users, and users that want information anytime, anywhere, any place. Second thing is bandwidth. People are wiring up. Wiring up their homes, wiring up their schools, but more important, their businesses. 

And bigger pipes mean allowing for richer data types, audio and video and graphics and imaging across these networks. And the third thing is Java, which is, we believe, a great technology to allow for networked applications, write once, run anywhere, safely, allow object-orienting component. 

What this all means for computer companies like ourselves is we now have the infrastructure to really deliver our network computing. But I think what the industry needs is a new approach to database technology. 

We need to think about structured and unstructured technology merged into one seamlessly. We need to think about traditional transaction processing and rich data types together. We need to think about conventional relational technology with this new object technology. 

And we're very excited because we've been working with our informics and your scalable, reliable database technology together with this new extensibility. It's got all the right words, doesn't it? I'm actually being hired by informants to give you a pitch. 

Well, we want to sell some servers. In fact, we see these PCs up here. But no, I think the universal server, and the really nice thing that we're pleased about today is that the universal server has Java support. 

The Java virtual machine is embedded in the universal server, which leads me to this little box over here. This is a product that we announced about a month ago. This is Java Station. and you bring the Java. 

That's right. It does copy on the top, too. So it does it. But very simply, this is a thin client. And as we know, we announced this product, as I said, in November for around $750 quantity one list. 

We think this, over the next several years, is going to really, really define the way desktops and mini applications are going to look like. And what's really great is that we can now talk about database technology, like your universal servers on Sun servers and other servers that can, Java Ready, that can provide the applets, provide the database technology to serve these very simple devices. 

As you know, we five cables, plug it in, downloads the operating system, downloads the user environment, and then you access Java applets. And since the universal server is Java Ready, we basically can go from there. 

So we think this is going to be a great front end for many applications, such as customer management systems, reservation systems, any transaction-oriented type systems for this area. A couple more things before I leave. 

First of all, we'd like to thank you for developing on Sun, even though you don't have the Sun boxes out here. I don't know what these PCs are doing here, but let's just put this in front of it. The Sun machines are in the back. 

I checked. Yeah, they are. I knew you would. And also delivering software on time, which I think is really novel for this industry these days. And congratulations on that. Thank you very much. Teach the boys up in Redmond something on that. 

Thank you very much. Thank you. Thank you. We also, by the way, I want to point out that we believe so much in your technology that we run our entire Catalyst ISV program on this new technology. We have one of the more premier ISV programs, so over 10,000 applications, thousands of ISVs, and companies like Informix can go in and update your own web-based ISV page that's online for all of our users to get at. 

And finally, we're also taking advantage of your data blades technology. We're announcing today a video data blade that hooks in with our video servers so that the universal server can now access video clips off of our servers providing desktop users with this kind of technology. 

Congratulations, and good luck. We'll see you. Thanks. Thank you. The world runs on all sorts of information, but only a small percentage of it is numbers and letters, which is all your database can handle. 

No more. Thanks to data blade technology, Informix universal server can manage virtually anything. Ladies and gentlemen, here's Informix Software's director of database marketing, Malcolm Colton. Thank you. 

You know, in the last few years, there's been a big debate in the industry. industry about whether people need to manage complex data. And this debate is over. The answer is yes. Everyone has said yes. 

We need to manage complex data. We need to manage images. We need to manage sound and video. The web is driving a huge need to take care of this complex data. We need to model our own corporate data, which doesn't fit in the straitjacket of the old relational system. 

And we see our competitors scrambling after us, trying to produce products that will manage this kind of complex data. So this question is finished with. The new question is, how do we do it right? And there are really two choices, two schools of thought here. 

One is in Formics and IBM, who is saying the right way to do this is to extend the database, to natively model complex data inside the database and make the database deal with this correctly. The second choice. 

with CA, Sybase, and Oracle, is that you should manage data in middleware. Now, middleware is a great solution if what you're building is distributed object applications, where the objects are talking to each other and sending messages. 

It's not a good solution for managing data. It's a very poor architecture. And the result of that poor architecture is that these applications built using this kind of architecture are not going to perform very well. 

And we see that embedding the complex data in the database is the right thing to do. But we're not the only ones who think this. Let's see what some of the analysts say about complex data. Combining what Informix has done in its traditional relational market with an object relational approach and providing scalability of the same order that they have in the past is a genuine contribution to the state of the practice. 

Informix has a truly elegant model for moving information processing about data close to the database itself. The other approach, being very highly layered, beautifully architected, may be very pretty from an academic point of view. 

It remains to be seen whether it will perform well enough to be useful in operational applications. We like the way Informix is actively creating a market for data blades. Some will be created by Informix, some by Informix partners like Verity, and some that IS organizations will make themselves for their specific applications. 

People who knew how to use Informix products will find it a very evolutionary, easy step to go forward. It's not entirely new thinking. They don't have to drop the way they do business. They don't have to rework their applications. 

They can put this in their environment and just start doing new things as it becomes necessary. So it's evolution, not a revolution. Other approaches often force people to throw away work, start over again, rethink. 

and it creates chaos. We think that IS organizations should take a hard look right now at how universal server technology can benefit their applications for 1997 and beyond. And I have to agree with Peter Kastner. 

This is technology that's available now and the time is right to embed this technology in new applications. So in Formix, universal server is a single object relational server. And the benefits of having this single object relational engine for all the complex data is that it's easy, it's easy to manage, easy to build, it's easy to maintain. 

It's very fast. And this technology is proven in production applications. Let's look at each of these points in turn. Firstly it's easy to manage. If you compare universal server with the layered middleware approach, there are just fewer moving parts. 

There are fewer pieces that you have to take care of. And so naturally This is just easier for you to manage. There's also less code. Because of the object-oriented nature of the product, the code that's in the server, the code that's in the data blades is reusable. 

So more applications can use the same piece of code. There's less code for you to write. Less code to write is less code to manage. It also extends the environment you're used to. This is a SQL database. 

So all your SQL applications run, and then you extend the SQL along the standard SQL lines to deal with complex data. All of the standard system management tools work. This product is built on dynamic, scalable architecture. 

So all the system management tools that work with DSA work with Universal Server as well. One of the important things about this product is different from the middleware federated database approach is all the data is in one place. 

So to back up and restore these routine, but very important tasks, they're very simple with Universal Server compared with other architectures. And for Informatics customers, the migration is incredibly easy. 

What happens with Universal Server is you can just take your Informatics application and run it on Universal Server. You don't touch the code, you don't recompile, you don't relink, you don't touch the data, you don't build new indexes, it just works. 

So you can install Universal Server, have all your applications work at least as fast as they did before. And then as you see the need, you can extend the applications with these new data types, new rich complex data, and your own corporate data model. 

And in fact, most Illustra customers have been doing this today. So it's easy to develop. We talked about management. Development is simple too, that you can build your own data model into the database. 

You can take how your data looks, how it works, and you can install this. in the database and have the database intelligently model what it is that your corporation does that's different to everybody else. 

For example, in telecommunications, a company may need to model how they build customers and how their discounting system works so they can put together their offerings to their customers, their customers' usage patterns, and make sure they're providing the best solution to their customers to keep their customers happy and loyal. 

But also, you don't have to build all this stuff yourself. Because of the database program, you can take pre-built modules from experts in the field and embed these into your application. And then you can integrate the pieces that you build and the much larger pieces that you buy from experts to very rapidly build very innovative applications that help you to become competitive. 

So it's easy to build, and you have a choice of ways to build your application. The Informix new era tool has been specifically engineered to manage the complex and rich data types that Universal Server can handle. 

So you can use that as your development environment. And our web data blade module lets you take your environment and very easily put it on the web. In fact, rather than just putting your database on the web, what this is doing is taking your website and putting it inside your database. 

The result of this is your website becomes very dynamic, very easy to manage, very easy to change. And we'll see an example of this later in the conference. You can write your application in third generation language, C or C++, if that's what you want to do. 

There are also a number of higher level language partners who are working with us. Forte is a great example where they're re-engineering their product and extending it so that it can take advantage of the extensions that you get from Universal Server. 

In the Java environment, we just heard from Ed Zander that Universal Server is a great platform for Java. It supports the Java Everywhere concept. And JWorks, one of our early Java tools, is helping you build applications that play in that environment. 

There's a wide variety of ways to build applications. But for the application developer, the environment looks very simple. What they do is they write to a single API, a single programmer's interface. 

And behind that interface is all the data they need and data that behaves intelligently in exactly the way they need it for their particular application. And the database itself deals with the problems of optimizing across these multiple data types, integrating all the data, and just returns it to the user, a very, very simple environment. 

And fast. Universal Server is incredibly fast, compared with the competing architectures. We expect to see applications run 10 to 1,000... and times faster on universal server than on a standard relational database with middleware. 

And we're going to see examples of this in a little while. But to put this in context, there's about 84,000 seconds in a day. So if you can run 1,000 times the speed, instead of running your computer all day and all night to answer a question, you can do it in 1 and 1,000 minutes. 

The result of this kind of leap in speed is that new kinds of applications become possible for the very first time. Underneath the extensibility of universal server is the core dynamic scalable architecture, which is architected for large boxes, multiple CPUs, multiple disk drives. 

And it runs in parallel all the SQL operations across all the hardware that you have available. And that's automatically available in universal server. So it's parallel. and it's very scalable, and it's integrated. 

All of this data is in one place, and the advantage of having the data and the code that manages in one place is largely responsible for this dramatic increase in speed. So let's take a look at this. 

I'm going to run a test on one simple query on one simple kind of data. And here to help me is Scott Simmons. Scott is a principal technical consultant looking after Universal Server. And what Scott has got for us here is a demonstration running a query against Universal Server and the same query on the same data against a different architecture, right? 

Yes, Malcolm. Actually, what we've done here is to design a solution for the problem that you just spoke of. A telecommunications company has many billing records, and associated with that is a discounting schedule. 

What we've actually done is we've built that discounting algorithm in the server as a server function, a central component of a data blade. We're actually going to be running that then as part of this Universal Server environment. 

In addition, on the lower section, what we'll see is a solution that we've simulated with a middleware remote procedure call technology, very similar to what we're hearing being proposed in the industry by some of the other vendors currently in our marketplace. 

The important thing is that with the middleware solution, in this case, we're not even using CORBA. And CORBA, in addition, would layer another level of indirection on this. So what we're going to see, I think, is some clear changes in terms of the performance kind of capabilities we have by layering that very complex function directly into the server. 

So the top then is going to show this query running in Universal Server, and the bottom one is simulating it in middleware. That's correct, Malcolm. OK, let's run the query. And we see that the Universal Server is plugging along here. 

It's going right in. It finished in six seconds. So Universal Server is finished in six seconds. The middleware is still running this application. So what is taking all the time? Why is this so slow? 

This whole concept of middleware is, in fact, moving mountains. massive amounts of information back and forth across the network. I like to go ahead and relate this to an analogy of trying to play chess over the U.S. 

mail. You can do it. It's extraordinarily slow. It's not very efficient, but it works as we're seeing right now in the lower half of this. But that issue of all that data transport is what really brings this type of bottom solution, a middleware solution, to its knees. 

So this is data moving from the server to the middleware, results coming back again, and this massive data movement is taking up this endless time that the middleware is taking. Do you know, CORB is a great technology for object broker type applications, but it is not suited for this type of application. 

I think we've shown clearly the advantage that a data blade has in terms of doing data management operations. And we see it's finished, and so it was roughly 10 times slower to run in middleware. So even for this simple query, we get a 10 times performance increase. 

Exactly. Thanks, Scott. Thanks for helping us. So this was just a simple query on a single data type, and it ran ten times as fast. And the key to this kind of speed is that you can extend the database. 

It's extensibility in the database. So let's hear what some of our customers and partners have to say about extensibility. More than 90% of the information in an organization is stored in other formats, whether it be paper, whether it be text, microfilm, video. 

And the question is, how can we bring the same kind of accessibility to that kind of information that we do to the traditional data-oriented, record-oriented data that we've done in the past? Companies who are not addressing their issues from the core of their databases and from the core of how they're handling complex media are going to be in trouble. 

Those that start predicting that and structuring for it now are the ones that are really going to take advantage of what we call this global village or this global network. A data blade developer can specify how the database engine will store the data, how it will retrieve it, and how it will index it. 

This enables potentially very fast performance combined with the power of rich data types. It allows them to deal with not only text characters, the standard stuff of databases, but with these new kinds of multimedia objects, images, sound, movie tracks, as first-class objects. 

That's where the sort of technology that's available in Universal Server meets our needs better than anything else. We need something which enables us to deal with the object and all its elements efficiently, flexibly. 

And we plan to evolve the data blades in the FlashPix objects which they access over time. The chemical objects we deal with don't naturally fit into the structure of numbers and data. And so we're using the Informix data blade technology to allow the racial system to be extended to handle chemical stretches and reactions. 

The key to our success is time to market. does for us is it allows us to take their object-oriented technology embedded in our applications and deliver functionality to our customers much quicker. Informix gets it. 

They understand the importance of what's going on in the world right now in terms of technology. Without a universal server, it would be extremely difficult, if not impossible, for us to do what we're doing. 

The future is happening now for me. I have medias now where I can have all my information stored in one system. I can have multiple applications using the same piece of content. I can share that information with anyone 24 hours a day around the world. 

It's amazing. It really is amazing with this extensibility, the kinds of questions that can be answered. And without it, a lot of business questions are just too hard to answer in all kinds of industries. 

Let's take some examples. For example, in transportation, managing fleets of vehicles that are moving in space A truck breaks down. What we need to know is what trucks are going to bypass this area and have enough free capacity that I can move the data off the stalled truck and get it to move the data, move the packages off my stalled truck, put them on the other trucks, and get them to my customers on time, 

managing geographical data as well as the normal relational data that describes what's traveling on the trucks, or in retail. A customer calls into my 1-800 number and says, I'm looking for a particular item. 

Find me the stores that are nearby that have this product in stock so that I can go and search for it and buy it. So again, geographical information mixed with lots of the standard alphanumeric data. 

Internet Commerce extends this again, where the catalog now is not sitting on the customer's table, but is on the web. And the customer wants to browse the web catalog saying, here's something that's interesting. 

Show me products that are like this, but maybe in different colors, different sizes, with different features so that I can do my commerce directly over the web. Or in the legal profession, the legislation changes. 

The government shifts. Legislation changes. I have a number of contracts that I've made assuming the old legislation. Find me all the contracts that may be impacted by this legislative change. A sophisticated query against a large text database of complex textual documents. 

In sales management, a sales rep leaves an organization. I need to subdivide his territory to the surrounding territories. But I don't want to just draw arbitrary lines on a map. I need to take equal value pieces of this territory and reallocate it to the surrounding ones. 

So I need to integrate geographical information with demographic and sales information. In financial services here in New York, I have a portfolio full of stocks. I can calculate for my portfolio. portfolio that there is a moving average risk-reward ratio that tells me how I'm exposed compared with how much upside there is on my portfolio. 

Go through all the high-tech stocks. Calculate their 30-day moving average risk-reward ratio. Compare it with my portfolio and tell me which other stocks I should be looking at. Very complex queries against a historical set of data that's very poorly managed by existing relational databases. 

And as we've seen, these things play well on the web. The web is a great interface for providing both internal and external customers access to this data and universal server, because it can understand HTML, becomes a very intelligent repository for your website and extending this into managing huge amounts of data and data warehousing applications. 

So all kinds of applications, all kinds of industries, one of the great examples is the insurance industry. The insurance industry naturally manages lots of alphanumeric data, but there's a lot of complex data that they'd like to bring under control as well. 

And let's see how this would work. James Attridge. Oh, hi, Lise. I know, I know, I know. I was sideswiped this morning. Didn't you catch me on metro traffic control? I was half the fender bender that backed up traffic all the way to central. 

No, I'm not responsible for making you late. That honor goes to the guy on the Land Cruiser who was trying to drink coffee and talk on his cell phone and pretend he was Dale Earnhardt. OK. Yeah, I can be there. 

Sure, what room are we in? Um, OK. Satan has seat. I just want to get this insurance hassle underway, OK? OK. You have 18 new messages. Hello, Mr. Attridge. This is Lori Spaulding of Horizon Insurance. 

I'm the adjuster assigned to your claim. I don't know if you'll be free around 1, but I had a cancellation, and I can take a look at your car around then. Please page me at 1-800-555-9930, and let me know if that'll work for you. 

Thank you. Bye-bye. My only consolation is Mr. Land Cruiser got coffee spilled all over his lap. So how does it look? Uh, I don't think he's bent the frame. But either way, we'll fix it up and make you happy. 

Okay, I'm just gonna send these photos off to Arnett and add them to your file. Um, you should be getting an e-mail probably later on this afternoon, which will give you two options of the approved body shops where you can have the work done. 

So one will be near your home, one will be closer to here. All you have to do is hit reply. Tell us which one you've chosen, and we'll pay them as soon as the work's completed. Oh, but you have to pay for your deductible directly. 

And that's $250. That's it? That's it. James Attridge. Oh, hey, Lise. What's up? I'm fine. Shouldn't I be fine? Tense this morning? I wasn't tense this morning. Anyway, that's all taken care of now. I got it taken care of. 

Well, I'm a take charge kind of guy. You know that. So the video showed us what it would be like if an insurance company could manage all of this kind of information. We see the customer is happy. The claim has settled very quickly. 

It's very expeditious. But let's look at what happens behind the scenes inside the insurance company. And to help me look at that is Erin Kinneken. Erin is director of server product management. And she is one of the people responsible for managing the project that actually brought out Universal Server on time. 

Erin, thanks for joining us. And it must feel great to have this product actually ship. Malcolm, it feels fantastic. The entire team really took this on as a challenge. Everybody worked really hard. And the result is that we're able to show a real business application here on stage running live on the Universal Server. 

Yeah, thanks. So let's see how Horizon Insurance uses all this complex data. OK. The application is running on the Universal Server and using three data blades. We're using the web data blade from Informix, a third party text data blade, as well as the 2D spatial data. 

So we really are using multiple types of data. If I were an insurance examiner, this is the screen that I would see in order to see all of the new claims. So we look up a claim. And this is the photograph, this is the digital photograph that was uploaded across the net. 

That's right. Here it is, available. We can check the policy information. We can find out that James does have a collision deductible. And by the way, because Universal Server manages all types of data, we can see the car that he insured and make sure that this is not preexisting damage. 

We can also look at other documents. For example, the police report can be scanned. And part of the record. And we can actually see what the police. as he was there on site. So this is the kind of data that a relational database would have a lot of trouble managing, right? 

Absolutely. And if the claims that Justin had made a video or had taken audio notes at the scene, you could look that up as well using the same interface. Anything that's relevant to the accident can be stored in the server. 

So one of the next steps then was to build an estimate, right? The insurance company needs to know how much this will cost. How do they do that? Well, actually, it's very simple. We can go here and we can actually search on previous accidents that have occurred in the last six months. 

So if we were looking for right quarter panels, then we could actually do that search. Again, any words, not just keyword, as you would be limited to in a relational database, but we can actually do that. 

And actually, scroll here, some very painful accidents. We can see here the damage to the car. And actually, calculated for us is the average claim, so that we could go ahead and enter that in the reserve. 

Right. So then, as part of satisfying this customer, we need to find repair shops, right? So we need a repair shop that's either near him or near where he works. And this involves doing some other kinds of data search. 

Absolutely. Because we captured the information in its native data form, we can now go look at a scene of the accident location. What you can see here is exactly where the accident occurred, where the car is currently located. 

And now, in order to give a list of repair shops, what we can do is actually visually specify the area that we're interested in, specify that we're interested in paint, as well as body repairs, and do a search. 

So this is integrating text and geographical data. In a single query. And here we see this is actually implemented using our new Java interface, so you can actually interact with the data, see on screen what options there are. 

And actually, because our Java API is SQL enabled, actually go get further information from the database. So with the Universal 7 managing all of these kinds of complex data, integrating it into this kind of application is a cinch, right? 

Absolutely. And this is just the beginning. If you think about an insurance company, we have actuaries who are doing rate calculations. We have underwriters who are doing risk exposure with complex calculations. 

And we have the marketing people who want to see who's getting on the web, what they're looking at, and doing market segmentation. Great. So with Universal Server, if you can imagine it, you really can't manage it. 

Absolutely. And thanks very much. And thanks for managing the project. My pleasure. So what we saw in here, one of the things that made this really compelling was that we used the web as the interface both for the customer and on the intranet to provide the interface for the examiners and the adjusters and all the people who are working behind the scenes inside the insurance company. 

Let's look at another web application. This is a live one. This is an application that's running at DB Expo today that we call 72 hours in DB Expo. And to take us on a short tour of this is Scott Simmons and Mark Itzkowitz. 

Thank you, Malcolm. Well, through the miracle of internet technology, we're going to try and go behind the scenes of what's going on at DB Expo in Javits today with the help of Scott. Seventy-two hours at DB Expo is an intranet application built for DB Expo using universal server technology, with the goal of allowing attendees to have a more enriched experience by getting at the information they want, 

and also to show how templates and inform its technology together can allow people to rapidly build their own intranet applications. If we look at the site, it's divided into two major sections. We've got the conference information section, where you can get session schedules, exhibit hall maps, speaker bios, and one of my favorite things, the yearbook, where people can actually take pictures of themselves and actually find other people at the conference from the site. 

Now if you look at an intranet terminology, these are things like facilities maps, customer and employee information, and you name it, can be put up on your intranet. But what's nice with universal server technology is I can actually build myself a customized itinerary by searching the site. 

So for example, if I go to search, we're actually able to use data blades to type in, find me all information about Informix, because I want to find out what to do at the show regarding Informix. I type in Informix, and using a combination of server-resident data blades like spatial, image, text, and audio, I see the kind of sessions I should go to, the exhibitors I should talk to, the people I should schmooze with at the parties, 

and I also get a dynamically generated map that shows me where to go in the show. I can even click on that map or fly over that map, and using a Java integrated applet from the server, I can actually see who's in what booth and drill down on that booth to get more information. 

Very powerful in things that you couldn't do without having things resident in the server. With all the data blades working together, I can actually put together sophisticated applications like this. 

If I try a middleware approach, it's very slow, it's uncontrolled, and the data types are unaware of one another, so I can't get Java interacting with spatial. But data management in the server isn't enough. 

As we found out through cyber publishing data flow is the key. It's not just that data is in your system it's how it gets into your system how it gets approved and for that we have the cyber zine or real-time show newspaper. 

So simply by going to what's news we can actually take a look at what's going on at the conference and what's the latest update but it gets more sophisticated than that. We click on a news story and what comes back is not just a newspaper with text and pictures but also using other data blades we've integrated real-time streaming video that's coming directly from the server. 

Much like the technology we're using today to stream the audio out from here we can stream back from the Javits Center a video. Simply click play like on your VCR and away you go with a full motion video being streamed from the database to the server up to date and constantly interactive and as you add new data blades you'll be able to add new types of experiences to your application page and to your news. 

Now what's key here is we've used a web browser to surf this. But we don't just use a web browser to surf and look at the information. We use a web browser to manage the information, so you get all the advantages on the management side. 

And for that, let's go behind the scenes, admission control, where all of this is going on, to look at how we actually use Java and the web browser to manage our database. As we can see here, we can edit a story with a native Java applet on the left and a sophisticated interface that's platform independent. 

So even here, three miles away from the Javits Center, I'm able to update and manage my information, much in the same way as we do with Sun in their Catalyst ISV catalog. I could choose a story, a block in a story, and then I can go and upload new text to that story without having to ever leave my browser. 

Very powerful way of updating information. Content conversion is done automatically. Let's say you upload a Word document, it's converted to HTML. I can, in fact, load any document, a spreadsheet, a presentation, a Word document, an image. 

It only depends on whatever data blade I have installed. And with new data blades, I'll be able to load new types of information through a browser. But before publishing this, we have to go through an approval process. 

And here's where we've stored workflow in the universal server alongside of the data. This allows us to model our business data, put our rules and data together, and is only possible inside the server where data needs to be aware of rules and rules need to be aware of data. 

And so in short, by doing this type of browser publishing and browser management, it's easy to operate, easy to do this type of application. You can update and manage information anywhere in the world where you have proper access. 

Anyone can do this. In fact, actual journalists are contributing stories to this right now, and if any journalists out here are interested in cyber publishing with us today, let me know and we'll talk about coming into the booth. 

So in summary, with the universal server, it's easy to create sophisticated web applications or any applications just by snapping blades together. Content and workflow live together on stage in one area. 

You can produce dynamic targeted information to each specific user, and it's all in technology available today. Thank you very much. Thanks, Mark. So Universal Server is a proven technology. This is technology that has been in production in over 1,500 applications today, many of them building exciting websites like we've seen and integrating both customer information and also data blades coming from our third party data blade partners. 

What we're announcing today is the availability of this product on a variety of platforms. We're announcing at the end of December this will be available on Sun and on SGI. We'll be adding NT and the other Unix platforms by. 

the middle of 1997, with subsequent platforms to follow. The product's fully internationalized, so it can be localized into multiple languages and participate in applications that are running in Kanji, in Korean, in even the multibyte languages of the world. 

There are a number of DataBlade partners that are announcing availability. 29 DataBlade are becoming available this month, in December. You remember, we shipped to DataBlade partners in September. During the last three months, we've been building these DataBlades together with our partners. 

51 new DataBlades are being announced today. And in our booth at DB Expo, you can see 30 DataBlade partners demonstrating their technology. Hundreds more DataBlades are on the way with our partners. So InformX Universal Server is fast. 

It's fast to build applications. It's fast to run the applications. It's easy to manage, easy to build against. And it's proven in production. And most of all, it's available right now. Thank you very much. 

Thank you. Thank you. Thank you. Ladies and gentlemen, once again, Mr. Phil White. Thank you. A quick question while our beta customers come out. How many of your shareholders here? How many shareholders are here? 

All right. Well, for those of you who bought in a couple of weeks ago at 17, I'm happy to tell you that we just went through 27 and a half in the first... Thanks to Michelle, you know, from First Boss, and the first 40 minutes of trading, we trade almost 3 million shares, so there is some activity with a good technology and a time to market advantage. 

What I wanted to do is introduce our customers who have been in our beta program. Actually, I'm going to have them introduce themselves and talk a little bit about what they do in their company, and then we'll get into how they're using the technology. 

Bruce, why don't you start? Hello, I'm Bruce Chobnick, Vice President with GE Information Services. We're the world's leading provider of electronic commerce services. Our consulting and systems integration business is constantly seeking game changer technologies like Informus Universal Server, which adds great flexibility to our systems integration business. 

I'm Terry Strader from GDE Systems, and GDE Systems is a trade core company. Trade core is the fastest growing defense electronics firm. Our primary business at GDE though is the extraction of data, two-dimensional and three-dimensional data from imagery and video. 

We have about, well, we service all the branches of the military and the National Imagery and Mapping Agency, 25% of our customers next year are international. We have products in 42 countries. We service mission planning, targeting, mapping, and intelligence markets. 

And in fact, our job is to find the locations and changes on very large images for everything from artillery to agriculture. Great. Michelle? Hello. My name is Michelle Kildun. I work for CS First Boston, a Wall Street investment bank. 

As a director in the fixed income trading technology department, I'm always looking for ways to generate revenues and reduce costs. To that end, we selected Informix to develop the global research library, which is a web-based application which distributes in near real-time research publications to traders and analysts around the world. 

We're using the web data blade to dynamically generate web content and the PLS data blade to provide full-text search capabilities to our users. The application is currently available on the intranet, and we'll be providing it to our clients on the intranet sometime early next year. 

Great. Jeff, tell us a little bit about your business. Hello. My name is Jeffrey Brewer, and I'm the vice president of technology at City Search. And City Search is a company developing complete and current online guides to communities around the U.S. 

and internationally. We cover everything from arts and entertainment events to government information, nonprofit volunteer opportunities, as well as a complete directory listing of goods and service providers. 

One of the primary things that is enabled by Informix technology on the City Search site is a rich personalization feature which allows people to specify their interests such that we can actually notify them. 

what's going on in their community that would be of interest to them. You can check us out at www.citysearch.com. And in fact, we have a site here in New York for those of you in town if you're interested in finding out about the local movies, theater events, or just a good restaurant to go to. 

Great. Hassan? Hi, I'm Hassan Nied. I'm head of New Media for Creative Artists Agency. We're a Hollywood talent agency that represents actors, writers, directors, producers, and musicians. And we are behind such movies as Independence Day, 101 Dalmatians, television shows such as ER, and Beverly Hills, 90210. 

We believe that the advent of the connected computer in the home will profoundly change the media and entertainment industry because it will allow consumers to actually have a very personal and one-to-one experience with content providers, as well as provide an immediate feedback loop while they're experiencing their entertainment. 

And we think that the key to the growth of this market is that we have content management systems that can dynamically deliver these custom experiences as well as be able to provide the feedback between the consumer and the supplier. 

Great. See, we're taking a lesson from CAA. We put our good customers on front of information week. And Bruce and I were featured in an article. Bruce, why don't you tell us a little bit about how you're using this technology. 

OK, I'll tell you about a couple applications. One is a photo finder application which allows us to capture and index photographic images with a lot of textual information about those images and then allows for the real time retrieval and search over the internet of those photos. 

Another application that we're working on is one for a financial institution where they can capture in real time transactions so that those transactions can subsequently be analyzed by member banks. Terry, I know we've got a lot in common in addition to horses. 

Why don't you tell us a little bit about the use of these. Sure. We're using the universal server on our third generation imagery exploitation system. And here, an analyst takes images in that his job is to find precise location and changes in images that may be as large as 100 kilometers by 100 kilometers with a ground spot size of one meter. 

The associated ancillary data, which can be everything from video clips to audio to text, maps, all of those kinds of things can have anywhere from 1,000 to 3 million records. And this analyst workspace must be able to do the job of finding the changes, locating them precisely, and getting reports out to, in this case, put iron on targets. 

We chose the Informatics product because of the speed. And also, they were really the only commercial off-the-shelf guy that had two-dimensional information. and three dimensional spatial queries. The extensibility is very important because we have up to 33 terabytes online. 

We have a beta version right now and so far the speed and capabilities have been very much as advertised. Great, so commercial off the shelf, that's COTS, huh? Yes, COTS. For all your defense. Well, it sounds like a great use of blades. 

It is. Michelle, it's great to see, Michelle had a trial two years ago when we announced the essay and she decided she'd stay in line with our announcements and was about to, like we are, about to birth another one. 

And Michelle, great to have you. Thanks for coming and tell us a bit more about First Boston. Well, at First Boston, I'm responsible for the web infrastructure for the firm as well as cross business unit web application development. 

The first application that went live in this area was the Global Research Library, which I described briefly earlier. We selected in... In particular, because of the integrated nature of the data blade technology. 

And what we've seen is it allowed us a faster turnaround time for application development, easier to prototype new features into the application. And it also provided a simpler platform for developing a distributed system, which is important because we've got offices and users all over the world. 

So you take responsibility for this 3 million trading volume early on with us? Yes. So Jeff, I know you just opened up in the San Francisco. Tell us a bit more about your product. Well, the product, and you probably want me to talk about how it uses informings technology, so I'll do that. 

And I didn't even have to put him on the cover. Well, the product basically utilizes informings technology in two big ways. One is in the search interface, the interface to actually searching the volumes of content which we store in local communities. 

And the second is actually managing all the content which is served up in search returns. Each of our search returns can offer the user the ability to specify a keyword, a geospatial, and a temporal criteria such that I can say, give me an Italian restaurant within five miles of my home that is open at 10 o'clock on Friday night. 

The keyword component of that utilizes the text data blade. The geospatial component utilizes the 2D data blade. And without the informings 2D data blade, we really wouldn't be able to do that search in any sort of an acceptable search return performance time. 

And then the third, the temporal search, is something we wrote our own data blade to accommodate that. And we're actually thinking about licensing that. Managing the content, all the pages in our site are actually published through the web data blade, such that when you go to the site, you're actually looking at content as it's dynamically retrieved out of the database. 

We have so much content that's being added to the site on a daily basis. Thousands of pages are changing as businesses list additional sales events. movie times and volunteer opportunities, as all that stuff comes in the database, it's changed on an intraday basis, and then actually has to be served up on the site. 

So without the web data blade, it would be really hard for us to manage all that content. So here's an example. He's got four data blades, three of which were supplied by the outside infrastructure, one of which he wrote himself as a customer. 

And we think that's what's unique about allowing customers to extend their own data types with the data blade technology and the developer's kit. Hassan, you know, a year ago, we'd never be together. 

Here you are, Arnold Schwarzenegger and the crowd. And now we got a joint venture. Why don't you tell us a little bit about our joint venture? Well, we think that the key to the growth of the internet as an entertainment medium is one to have great brand names and to have good digital asset management systems that are capable of pulling together dynamic video and audio and that type of thing. 

And we had a relationship with Planet Hollywood, which is a rapidly growing entertainment facility, over 20 million visitors a year, and it's growing quite rapidly. And when I looked at it and I said, well, what is the key to really making this a dynamic site? 

One thing is that they're merchandising this the majority of their revenue, so there's a business model involved. Fans have a very keen appetite for being connected with the stars, and that's the key reason why they go with Planet Hollywood. 

So we looked at that and said, well, that's a great brand name, but the key is that they need the type of content management and digital asset management system that would be able to deliver this rich audio and video content in such a way that would get people to come back again and again and again and hopefully buy a lot more t-shirts and cups and caps and that type of thing. 

So with that in mind, we put together a joint venture called Planet Hollywood Online that is a joint venture between Planet Hollywood and Formic Software and Tandem Computers, which we think will become the definitive Hollywood website where people will be able to have a virtual experience with the stars and to visit the stores through this website. 

T-shirts online, the true meaning of software. You know, we have a data blade being developed by NEC called Watermark, Digital Watermark, that protects digital assets. That's got to be key to all the stars when they put all their assets online. 

No question about it. I don't know how much you followed like the whole thing with DVD, which is a technology for putting movies under a regular CD. That technology has been around for a while, but its actual launch was delayed because of concern in our industry about copyright protection and piracy and that type of thing. 

The technology is developed by Informix with the NEC, with the Digital Watermark, makes it possible to be able to manage and to ship thin digital material and video audio only to those you want to send it to when you want to send it to them. 

which is the biggest concern that our industry has relative to putting any of their content and making it available to consumers online. And now that is something that is possible. And the 12th of December, there's something big going down at CA. 

What's that? Well, because we are such strong believers in the possibilities of technology and what it can do for the creative community, we worked in partnership with Intel in creating a media lab at our facility in Beverly Hills in which we will showcase how technology can enhance and enlarge the creative possibilities that can be made. 

And this lab is a place where we'll be showcasing the various PC technologies and content possibilities, and Informix is a very big part of that, where we'll be demonstrating a couple things. One, how database technology can actually be used to improve the process of filmmaking. 

Through such things as right now when a filmmaker is looking at creating new projects. They often have They spend a lot of time researching what kind of locations with what are the active backgrounds and pulling all these various elements and now with the visual database Capabilities of Informants it's possible to actually look at film clips and other things and actually be able to drill down and see what the see what's behind And the scene so to speak will be showcased in that technology at the lab as well as other Ways in which you can actually leverage this medium for creative new creative possibilities The song called me said hey Sharon stone Demi Moore coming you want to come down? 

Okay, I can refuse that right well listen I hope you believe that in fact this stuff is alive as well It's working with got lots of people using this Content in different ways across a variety of different industries The biggest of which now I think will be entertainment as people go to really bring entertainment up entertainment I think online in a content sense will drive electronic commerce It'll make shopping and exciting experience and so that's why we're excited about working with CAA and Planet Hollywood In driving what we think is going to be the key to our future and that's content so to all of our beta customers I want to thank you very much And now we've got some beta developers are going to come and talk to us about their experiences with the product. 

Thanks much There is no monopoly on great ideas Open safe and flexible Informix universal server frees you to follow the path of innovation that leads most directly to your goals One of the exciting things about universal server is that it is open to this development by third parties, the DataBlade plugins. 

This means that it unleashes the innovative power of all of these developers. It's not just the innovation coming from Informix, but from these hundreds of DataBlade developers who are building exciting new plugin modules that you can use to build your applications. 

This rate of innovation is gonna be completely matched in the, this is what's gonna set Informix universal server apart. And let's listen to what some of our analysts and partners have to say about the power of innovation of this platform. 

It's not necessarily the ability to produce a single application. It's the ability to change when your environment changes. There's not an industry that Aberdeen has researched that can't take advantage of universal server technology. 

An example, for instance, would be perhaps in the financial services market where a very particular stream of data might be crucial to their business and the need to store it, catalog it, manage it and retrieve it effectively may mean many millions of dollars to them. 

One of the important advantages that the Universal Server brings is to deal with the unanticipated requirements that our joint customers have. It's very difficult for a customer today to know what kind of data he's going to be encountering in a year or two years from now, but what he does know is he probably wants to be able to store that in a unified environment. 

The ability to have access to a library of third party data plates is great. Why should we reinvent the wheel when someone has already done it before us? What's the natural way for me to express what I want to do? 

I need to travel from point A to point B on the earth. Maybe I express that as a coordinate system and I suddenly now have functions that talk about the distance and I automatically compute a great circle distance and I want to know a minimum route and I can build that kind of system naturally instead of forcing it into the straight jacket of traditional data types. 

That's the great thing about blade technology. It's extensible. Okay, so it doesn't understand. That's no problem. We modify the blade. We make it understand. What we have is a database that you can effectively teach about things, teach about the real world. 

Our customers are always happy when things are easier and with Informix's data blade for internet commerce, customers have a much easier time of solving the problems that are related to doing commerce on the internet. 

We could produce this product without using the data blade or universal server. It's just, why make our lives so difficult? The data blade and universal server architecture, it's just perfectly matched to what we need to Ladies and gentlemen, here's the general manager data blade business unit for Informix software, Dave Cope. 

Great. Thank you very much and good afternoon. You know, you've heard a lot, a lot about the Informix universal server this afternoon and it's clearly a remarkable milestone, not only for Informix but also really the database industry as a whole. 

Well, I'm here to talk about another wonderful milestone and that's data blade technology and also specifically the data blades that are being announced with the Informix universal server this month. 

Many of you have heard several times this morning and now early afternoon, Phil White talk about standing up in February after the merger with Alustra and committing to the world that he would deliver the Informix universal server on time in December of 1996. 

And of course, here we are and with your thanks, with my thanks to you. we are, of course, celebrating the launch of the Informix Universal Server product. What many of you may not have known is Phil White, also at that time, also announced that with the Universal Server, he would make available 25 data blades so that customers that receive the Universal Server could immediately start to build rich, 

innovative, and competitive applications that use other data types other than simple numbers and letters. Well, I'm happy to announce, as Malcolm Colton mentioned earlier, not only did Informix deliver on the commitment to deliver the Universal Server on time, but we are, in fact, delivering on the commitment to provide 25 data blades. 

But we're going beyond that. We're actually going to be making available during December 29 data blades, and we'll be announcing an additional 51 data blades that provide technology that spans anywhere from multimedia to geospatial to highly specific, innovative industry applications and solutions. 

As impressive as the 29 data blades are that are shipping and the 51 additional data blades that we are formally announcing, you should also know that there are literally hundreds and hundreds of additional third parties located around the world that are in the process of developing data blades. 

As important as the Universal Server is as a milestone in the industry, and as important as the data blade delivery is to the database industry, I can tell you that data blades are becoming very, very hot. 

As a matter of fact, there's not a day that goes by in the press today that you don't read something about data blade technology or specific data blades. As a matter of fact, data blades are becoming so hot that we're finding that data blades are becoming so hot DataBlades are becoming the industry standard approach to extending a database. 

As a matter of fact, many of you may be familiar with the fact that Tandem recently announced an object relational database that will ship in 1997, and in fact, it will use DataBlades as its form of extendability. 

Now we're very involved with the number of leading vendors in the marketplace, and I can tell you that as other database companies refocus on their core assets and their core strengths, you can expect to see more announcements in this arena in the next coming months. 

To take technology and to turn technology into true innovative business applications, it takes more than just developers. It really takes a community, and in my organization, we refer to that community as the DataBlade community. 

That community really spans a value chain. that goes from your data blade developers to your tool and application providers to your systems integrators and consultants and finally customers. What I'd like to do is share with you a number of individuals that really represent different parts of our data blade community and let them share with you their thoughts on data blades and how that's helping their firms and also their customers. 

So let me bring out the panel one at a time. First of all, from FAME Information Services, I'd like to bring out the Chief Technology Officer, Howard Bomsie. Howard, thank you. From Open Market, the Vice President of Product and Industry Marketing, Gail Goodman. 

From MapInfo, the Vice President of Marketing, Elizabeth Ireland. From Eastman Kodak, the Vice President for Strategic Corporate Accounts, Ben Lamarca. And finally, from Excalibur Technologies, the Vice President for OEM Development, John McGrath. 

John? Okay, well thank you all for coming and let's get started. So tell me, you all have very successful, very busy businesses. Tell me about your data blades, what they do and how they're going to help your firm and your customers. 

Let's go down the panel. Okay Dave, FAME Information Services is building the TimeIQ data blade which provides a high performance storage and retrieval of time series data along with a rich suite of statistical and analytic functions and sophisticated time scaling techniques. 

In addition, we will be providing a seamless interface to our API and 4GL time series enabled environments. Okay, terrific. Gail, what are you up to? Open Market's Internet Commerce Data Blade enables companies easily build dynamic, scalable, and multimedia-rich web applications for internet commerce. 

Using the Informix universal server and the open market internet commerce data blade allows companies to use the internet to create revolutionary new channels to their existing and new customers. Great. 

Experiencing a lot of growth these days in internet commerce. It's wild out there. Elizabeth, how are you doing at MapInfo? Good. MapInfo is actually creating two data blades and the first is our MapInfo geocoding data blade. 

This is a data enhancing tool that takes advantage of MapMarker, our address matching technology and so it actually assigns the geographic coordinates to the data in the database so it can be used in a mapping application. 

The second is our Spatialware data blade and it's a data management tool that incorporates mapping for use in visualization, decision support, so it can be used in enterprise applications and data warehouses. 

So it's a combination of both these data blades. that really provide all the mapping functionality needed in any application. You know, it seems like it obviously would be very powerful to map, render new applications. 

But can you actually extend the functionality of existing applications? Absolutely. 85% of databases have a geographic component. So map enabling is a very logical and powerful extension to really any existing application. 

Ben, why don't you tell us what Kodak's up to? Well, Kodak is up to extending their market leadership position in imaging. We enjoy a very strong reputation in providing superior solutions in the image capture, storage, manipulation, and output of images, serving a wide range of customer constituencies. 

As an example, in the entertainment industry, we have worked closely with customers in the film studios, the major sports franchises, as well as the cable services companies, to name a few. And we have found that there is a pent-up demand for a specific imaging requirement so that they can take their unstructured image archives and convert them into a structured format or a digital image library so they can access those images, 

repurpose them for a host of new applications. We are quite pleased to be able to announce today in concert with the Universal Server launch the Kodak PIX Factory, which includes the Kodak DataBlade or the Kodak PIX Factory DataBlade module. 

This is integrated into the Universal Server, which will provide our customers with the tools, when combined with the Universal Server, to provide digital media management to those customer constituencies. 

We're quite excited about the growth opportunities that might provide both of us. Sure. You know, it seems like your DataBlade would go a long ways towards solving a lot of the challenges of transmitting digital media over the internet. 

Is that true? Oh, absolutely. In fact, the Kodak PIX Factory DataBlade module is based upon the FlashPIX image standard. That is a new image format that Kodak led an industry-wide effort on, to create an easy way of managing. 

and distributing color image files. It'll provide for speedy network transmission as well as efficient database storage of image types of all kinds. Great. Okay. Thank you. John, I know you've got a lot going on in Excalibur. 

Why don't you tell us about it? Yeah, we've been busy, Dave. Excalibur is real excited about the data blade architecture and the supporting partners program. So much so that we're developing five data blades for release with the universal server. 

These data blades from Excalibur are high performance information retrieval data blades for image, text, and video. We're releasing a text retrieval data blade using Excalibur's adaptive pattern recognition capabilities, which is exceedingly good for document management applications. 

A real-time profiling data blade for intelligent agent and automatic categorization. On the image side, we're releasing an image blade suite for image recognition and retrieval of color images. We also have a specialized data blade that's particularly tuned for facial recognition, for authentication, and positive ID. 

And we also have a video data blade for scene detection, which allows for automatic segmentation of video for multimedia applications. Wow. You know, with all that going on, actually, you'd be a great person to ask this. 

Recently in the press, a lot of people are really debating the maturity of the object relational database market overall. With all that you're working on, I think you'd be a perfect person to comment on that. 

Well, object relational is a natural progression for high performance database applications. Companies are demanding intranet and intranet commerce applications that support multimedia data types. If I can build on that. 

In addition to rich data types, internet commerce also requires performance, reliability, and scalability. As our customers are racing their competition to create new internet-based competitive advantages, they're really betting their business. 

And they're betting their business on open market and also on the proven performance, reliability, and scalability of the Informix universal server. So you two are finding it's not a question of, is the market mature? 

It's one of the tools available, and now they are available. Well, as I mentioned earlier, I know all of you have very successful companies, and you're all very busy. But you've also been working with the universal server actually for some time now in developing your data blades. 

Why the universal server? Why Informix? Elizabeth? MapInfo's customers, especially in industries like telecommunications, insurance, and utilities, have been asking for a server-based mapping solution simply because of the inherent speed and safety of the server solution. 

And it hasn't been difficult to develop a data blade either. MapInfo took delivery of a very stable Informix universal server in September. We were trained in using the data blade developer kit. And And Informix has been a good business partner in providing development support in addition to just the tools. 

So the next step is the certification of our data blades, and Informix will do that for all data blades to ensure both the quality and the fact that they work together. That's terrific. Dave, if I could piggyback on Elizabeth's statement. 

A great example of the comprehensive nature of your certification process is really demonstrated by our PICS factory data blade module. In fact, it made the interoperability between our data blade and that of Verage, another certified data blade company who has an object in the image recognition area, made it very attractive and easy for us to have those come together. 

Terrific. Terrific. Well, that's really, that's interesting. So let me ask a wild question. Tell me something that your customers can do today with your data blades that they couldn't do before. Howard, why don't you answer that one? 

Sure. One example is to make trading decisions. Financial services clients need to join. transactional data, such as portfolio holdings, along with intraday time series data from the markets and historical data from the performance of corporations and their financial instruments. 

Time series are a critical data type in this process and are not handled well by traditional relational technology. They are typically stored in separate proprietary databases. With universal server technology, all of these data types can now be stored in a single enterprise database, thereby easing the management of this critical data-rich environment while still maintaining the performance of the proprietary databases. 

My guess is in your market, your customers are looking for performance too. Is that true? Speed is a critical element. The markets move quickly and decisions must be made instantly. The lack of performance and efficient storage have been the critical shortcoming in traditional relational technology. 

The data blade technology solves these problems. Thank you. Well, again, I know you're all busy. I want to thank you very much for joining us and sharing your information with the audience here. And I'd like to thank the audience. 

We really do think the data blades will change the world. So we want to thank you and turn it over to Phil. Well, you know, all of our customers and our developing partners will be available for the press analysis immediately after we conclude. 

What I want to just say is we've set the standard on the relational model for performance and scalability. I think hopefully now you're convinced that we now have set it for extensibility, all integrated and architected as one product. 

Migratable, high performance, safe Unix and NT. Most interesting. part, though, I think is how and why you can do this. And that is our theme. If you can imagine it, you can manage it. I want to just read a little quote, if I get the next slide up, that says, it's a huge challenge and a big investment, but informics has the talent to carry it off. 

The whole industry is awaiting the outcome, and that's what we mean by influence. This is the database magazine that I mentioned early in the program that ranked Illustra as the most influential database in the database industry. 

And tomorrow, the 1997 version of that magazine ranks informics as the most influential database in the database industry. I think it's unique to be ranked. I think it's unique to be ranked. the most influential in the industry tiers in a row. 

And I think that's a great testimony to the talent, as mentioned in the article itself. And the talent from our side are these people. You heard from Mike Stonebreaker, Mike Sarangus here, Mike Olson sits right here in front, Paula Hawthorne, Eric Miles, and our architect, Gary Kelly. 

Without these folks, it couldn't happen. Companies are people, not products, people. So I thank all of you for hopefully attending what is setting the stage for a new era in database development, database computing, and a new era for content for 1997 and beyond. 

Thanks again. Have a great day. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-informix-universal-server-lau-6e0828 |
| title | Informix Universal Server Launch Event — December 1996 |
| author | Peter S. Kastner |
| date | 1996-12-01 |
| type | transcript |
| subject_domain | database-market |
| methodology | oral-history |
| source_file | transcript-informix-universal-server-lau-6e0828.txt |
| license | CC-BY-4.0 |

### Abstract

Full transcript of Informix Universal Server product launch event (~91 minutes). Phil White (CEO), Mike Stonebreaker (CTO, founder of Ingres and Illustra), Ed Zander (President, Sun Microsystems), Malcolm Colton (Director of Database Marketing), Dave Cope (GM DataBlade Business Unit), and multiple beta customers and DataBlade partners present. Peter Kastner is quoted in the event as an analyst endorsing the product. The launch introduces the first object-relational database combining Informix Online's scalability with Illustra's object extensibility, including DataBlade plugin modules. The event demonstrates applications from insurance, financial services, entertainment (Creative Artists Agency/Planet Hollywood Online), geospatial (MapInfo, CitySearch), imaging (Kodak PIX Factory), time-series (FAME), text retrieval (Excalibur), and internet commerce (Open Market). Informix is named most influential database for two consecutive years.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Landmark product launch for object-relational database technology; first commercially available integrated object-relational database engine, 12-18 months ahead of competition; historically significant in database evolution. |
| **Relevance** | high | Kastner is quoted directly in analyst endorsements as an authoritative voice; his quote stating the technology is available and the time is right to embed it in new applications provides his 1996 assessment of the product launch. |
| **Prescience** | medium | Object-relational technology did become mainstream but Oracle ultimately dominated; Informix accounting scandal in 1997 cut short the company's leadership; DataBlade concept was ahead of its time for database extensibility. |

### Prescience Detail


**Prediction 1:** DataBlade as industry standard
- **Claimed:** DataBlades becoming the industry standard approach to extending a database; Tandem recently announced object-relational DB for 1997 that will use DataBlades as extensibility approach
- **Year:** 1996
- **Confidence at time:** medium

**Actual Outcome 1:** DataBlade as industry standard actual
- **Result:** DataBlade did not become an industry standard. The DataBlade ecosystem was confined to Informix and was absorbed into IBM's product line after the 2001 acquisition. Oracle and IBM pursued different extension mechanisms.
- **Confidence:** verified
- **Notes:** DataBlade technology became legacy after IBM's Informix acquisition; no independent standard emerged

**Prediction 2:** Thin client market prediction
- **Claimed:** Java Station at $750 quantity-one list; over the next several years this is going to really define the way desktops and mini applications are going to look like
- **Year:** 1996
- **Confidence at time:** medium

**Actual Outcome 2:** Thin client market actual
- **Result:** The thin client market (Sun JavaStation) did not take off as predicted. JavaStation was discontinued by 1999/2000. The thin client concept was later partially realized through web browsers, Chromebooks, and cloud computing, but Sun's specific approach failed.
- **Confidence:** verified
- **Notes:** JavaOS for Business cancelled by IBM and Sun in 1999 (ZDNet); JavaStation discontinued; concept evolved into cloud/browser model decades later

**Prediction 3:** Entertainment driving electronic commerce
- **Claimed:** Entertainment online in a content sense will drive electronic commerce; will make shopping an exciting experience; content is the key to future
- **Year:** 1996
- **Confidence at time:** medium

**Actual Outcome 3:** DataBlade as industry standard actual
- **Result:** DataBlade did not become an industry standard. The DataBlade ecosystem was confined to Informix and was absorbed into IBM's product line after the 2001 acquisition. Oracle and IBM pursued different extension mechanisms.
- **Confidence:** verified
- **Notes:** DataBlade technology became legacy after IBM's Informix acquisition; no independent standard emerged


### Entities Referenced (30)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Informix Software | company | acquired | IBM |
| Phil White | person | active |  |
| Mike Stonebraker | person | active |  |
| Ed Zander | person | active |  |
| Malcolm Colton | person | active |  |
| Dave Cope | person | active |  |
| Mike Saranga | person | active |  |
| Sun Microsystems | company | acquired | Oracle |
| Oracle Corporation | company | public |  |
| Sybase | company | acquired | SAP |
| Illustra Information Technologies | company | acquired | IBM (via Informix) |
| GE Information Services | company | acquired | OpenText (via GXS/IBM) |
| GDE Systems (Tracor) | company | acquired | BAE Systems |
| CS First Boston | company | merged | UBS (via Credit Suisse) |
| CitySearch | company | merged | IAC / Ask.com |
| Creative Artists Agency (CAA) | company | private |  |
| Planet Hollywood Online | company | defunct |  |
| Tandem Computers | company | acquired | Hewlett Packard Enterprise |
| FAME Information Services | company | acquired | FIS Global |
| Open Market | company | defunct | Oracle (via FatWire) |
| MapInfo Corporation | company | acquired | Precisely (via Pitney Bowes) |
| Eastman Kodak | company | public |  |
| Excalibur Technologies | company | merged | Oracle (via Convera/FAST/OpenText) |
| SAP | company | public |  |
| PeopleSoft | company | acquired | Oracle |
| NEC Corporation | company | public |  |
| Ingres Corporation | company | acquired | Actian Corporation (open-source Ingres) |
| Intel | company | public |  |

### Technologies Referenced (21)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Informix Universal Server | database | Informix | emerging | merged-into-IBM-Informix |
| Informix Dynamic Scalable Architecture (DSA) | framework | Informix | mature | merged-into-IBM-Informix |
| DataBlade Technology | framework | Informix | emerging | obsolete |
| Illustra Database System | database | Illustra Information Technologies | declining | obsolete |
| Object-Relational Database (ORDBMS) | database |  | emerging | standard |
| RDBMS Market ($8-10B) | platform |  | mature | active |
| Java | language | Sun Microsystems | emerging | standard |
| Sun Java Station (Thin Client) | hardware | Sun Microsystems | emerging | obsolete |
| TPC-C Benchmark | framework | Transaction Processing Performance Council | mature | active |
| Oracle Network Computing Architecture (NCA) | framework | Oracle | emerging | obsolete |
| Middleware/Federated Database Approach | middleware | CA/Sybase/Oracle | emerging | evolved |
| TimeIQ DataBlade (FAME) | framework | FAME Information Services | emerging | obsolete |
| Spatialware DataBlade (MapInfo) and Geocoding DataBlade | framework | MapInfo | emerging | obsolete |
| Kodak PIX Factory DataBlade | framework | Eastman Kodak | emerging | obsolete |
| Excalibur DataBlade Suite (5 DataBlades) | framework | Excalibur Technologies | emerging | obsolete |
| Informix Web DataBlade | framework | Informix | emerging | obsolete |
| NEC Digital Watermark DataBlade | framework | NEC | emerging | obsolete |
| Open Market Internet Commerce DataBlade | framework | Open Market | emerging | obsolete |
| FlashPIX Image Standard | framework | Kodak (consortium) | emerging | obsolete |
| SQL / ANSI SQL | language |  | mature | standard |
| Informix New Era Development Tool | application | Informix | emerging | obsolete |

### Observation Summary

- Total observations: 50
- By type: technology-assessment: 19, expert-opinion: 12, market-data: 10, actual-outcome: 4, viability-prediction: 3, personal-recollection: 2
