# Ingres Windows 4GL — Analyst and Customer Panel (May 1990)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1990-05-01 |
| Type | transcript |
| Domain | database software / graphical user interfaces / 4GL development tools |
| License | CC-BY-4.0 |

## Abstract

An ~8-minute video featuring Peter Kastner (VP, Aberdeen Group) and multiple customer/user speakers discussing the challenges of graphical user interface development and the Ingres Windows 4GL product. Kastner frames the market problem: end users demand intuitive workstation interfaces but GUI programming has been 'exceedingly complex and beyond the knowledge base of most programmers.' Customer speakers describe painful transitions from character-based terminals to GUI, the lack of productivity tools for graphical environments, and their enthusiasm for Ingres 4GL Windows as a product that enables non-expert programmers to build commercial workstation applications. Kastner delivers a brief opening statement establishing Aberdeen Group research context, while customer speakers provide the bulk of the commentary on usability, productivity, and market opportunity.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 8 |
| observations.csv | 27 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1990). Ingres Windows 4GL — Analyst and Customer Panel (May 1990).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
