# Ingres Windows 4GL — Analyst and Customer Panel (May 1990)

> Archived from: /home/user/workspace/archive2_raw/transcript-ingres-windows-4gl-(may-1990)-a92e41.txt
> Original publication date: 1990-05-01
> Author: Peter S. Kastner

---

## Original Document Text



Ingres Windows 4GL (5_1990)

⏰Sat, 11/16 14:49PM · 8mins

AI Notes

 
 Summary
 The transcript discusses the importance of user-friendly interfaces in computer applications, particularly in the context of the emerging information age. Several speakers highlight the challenges faced by users and programmers when dealing with complex, character-based interfaces. They emphasize the need for graphical user interfaces (GUIs) that are intuitive and easy to use, reducing training costs and improving productivity. The speakers also discuss the difficulties programmers face in developing GUI applications and the need for tools to simplify this process. The Ingress 4GL Windows product is mentioned as a potential solution to these challenges, offering a way to create GUI applications more easily and expand the use of workstations in commercial applications.
 Chapters
 The need for user-friendly interfaces
 Speaker0 emphasizes the importance of user-friendly interfaces in computer applications. They highlight the challenges users face with complex systems, including the need for extensive training and support. The speaker uses the example of airport reservation systems to illustrate how difficult-to-use interfaces can hinder productivity and efficiency.
00:01:24 Rising expectations for application interfaces
 Speaker0 discusses how user expectations for applications have increased. People now expect sophisticated applications with high-quality, intuitive interfaces that require minimal documentation. The speaker notes that users are comparing enterprise applications to consumer products like Macintosh computers.
00:01:55 The importance of user interface design
 Speaker0 compares the user interface to the 'clothing' of an application, emphasizing its critical role in user adoption. They stress the importance of making interfaces comfortable and approachable for non-technical users, likening the ideal experience to playing a video game rather than interacting with a 'scary, complicated black box'.
00:02:43 The dilemma for information managers
 Peter Kastner from Aberdeen Group highlights the challenge faced by information managers. They are under pressure to deliver modern, high-quality applications quickly, but programming graphical user interfaces has been complex and beyond the skills of most programmers.
00:03:15 Challenges in transitioning to GUI programming
 Speaker0 discusses the difficulties programmers face when moving from character-based terminals to graphical user interfaces. They note that this transition requires a completely different approach to application development and highlights the need for tools to simplify this process.
00:04:32 The need for productivity tools in GUI development
 Speaker2 points out that the main problem has been the lack of productivity tools for programmers to easily write applications within a graphical environment. Speaker0 emphasizes the need for a tool that allows simultaneous development of the graphical user interface and database interface.
00:05:25 Introduction of Ingress 4GL Windows product
 Speaker0 expresses enthusiasm for the Ingress 4GL Windows product, highlighting its potential to simplify GUI development. They describe how the product allows for quick screen layout and testing of graphical elements. The speaker suggests that this tool could change how information technology is approached, shifting focus from database technology to information itself.
00:06:10 Expanding the market for application development
 Speaker0 discusses how 4GL-type products like Ingress 4GL can expand the market for application development. These tools allow less technically sophisticated individuals to create applications, potentially increasing the number of people who can develop software.
00:06:30 Potential for commercial applications on workstations
 Speaker0 highlights the importance of the Ingress 4GL Windows product in enabling the use of technical workstations for commercial applications. They see this as a key opportunity to expand their business into more commercial applications.
00:07:16 Positive outlook on Ingress Windows 4GL
 Speaker0 concludes by praising the Ingress Windows 4GL as a higher-level programming environment that allows developers to focus more on solving customer problems and less on user interface details. They express optimism about the product's potential to advance the use of powerful workstations in the commercial market.
 Action Items
00:02:43 Information managers should explore tools like Ingress 4GL Windows to simplify GUI application development.
00:03:15 Programmers need to adapt their thinking and approach when transitioning from character-based to graphical user interfaces.
00:06:10 Companies should consider investing in 4GL-type products to expand their pool of potential application developers.
00:06:30 Businesses should evaluate the potential of using technical workstations for commercial applications using tools like Ingress 4GL Windows.
 

Transcript

Speaker 1 
express themselves in multiple ways. First of all, of course, you need to spend a lot of time on training your users, on using the applications that exist today. Second is that when they get stuck, when they make an error, they get stuck. 

Speaker 1 
They cannot continue any further. And so you need a pretty strong backup team to help them out in case that there is some problems. And in general, just it frightens people off. They are afraid of it. 

Speaker 1 
It's unfriendly. And it just doesn't permit them to use computers with confidence. The most frustrating environment is watching the poor reservationists at the airport try and book or change a ticket for you, and watching the codes and the shift control Ds and all the rest of it that they have to hit to try and change, whereas if they just had a mouse click graphical user interface-oriented environment, 

Speaker 1 
the training costs would be much lower. The retention of those training environments would be much higher, and the productivity and the missed buttons hitting would be a lot lower. If you really believe that this is the information age, and that information is the most important competitive tool that a company can have, especially a manufacturing company, then you want to make that information as accessible and as intuitive to a user as you possibly can. 

Speaker 1 
Application expectations are higher than they ever have been. People expect applications that are sophisticated, that have very high quality user interfaces, that are trivial to use, so simple that you don't even need to use the documentation that comes with the application. 

Speaker 1 
We start hearing more and more about people who want workstations, and we're constantly getting questions like, well, gee, I can do this with my Macintosh. Why can't I do it with the application that you're building for me on a great big Vax? 

Speaker 1 
You have to think of the user interface as truly the clothing you give to your application. And that's all the user sees. It's not a cosmetic issue. It is the part of the application and the solution that touches the customer, the user first. 

Speaker 1 
And it is very important in getting the user, who is not a computer scientist in any way, shape, or form, very comfortable with sitting down in front of the screen and feeling it's more like the video game their children are playing with, as opposed to some scary, complicated black box technology that they're very uncomfortable with. 

Peter Kastner 
Hello. My name is Peter Kastner, Vice President of Aberdeen Group. Our research shows end users demanding the intuitive learning and ease of use capabilities of intelligent workstations. This creates a dilemma for the information manager, who's under fierce corporate pressure to deliver modern quality applications quickly. 

Speaker 2 
But to date, the programming of graphical user interfaces has been exceedingly complex, and frankly, beyond the knowledge base of most programmers. 

Speaker 1 
Moving from character cell terminals to graphical user interfaces quite a shock for most programmers requires they think about the application in a totally different way. And this is where the real challenge comes in for providing tools to simplify this. 

Speaker 1 
When we started looking at the workstation technology and what it would take to put applications out in that technology, our initial response was that this would be an almost impossibility with the size staff that we had. 

Speaker 1 
We saw the degree of complexity increase drastically over what we had been generating in terms of code. The amount of code was much higher. The degree of difficulty for the particular coding environment was more complex. 

Speaker 1 
And we have a lot of people who are not senior masters, computer engineering people from Berkeley or one of the other big colleges of the country. And consequently, we just have to be able to get applications out the door. 

Speaker 1 
It's been very difficult to build such applications because they rely on new tools and new methods and new techniques that most programmers haven't yet had the opportunity to really learn how to use. 

Speaker 1 
And the tools to use them conveniently and easily have not been readily available in the past. 

Peter Kastner 
The problem is very simple. The productivity tools, the ability for a programmer to write an application within a graphical environment, has not been provided by any software supplier to date. 

Speaker 1 
So the tool we really need is a tool that allows us to do the graphical user interface and the database interface at the same time. Thank you. I don't know that I'm impressed very easily, but I was very impressed with what I saw about the product and what I saw as potential for us to use the product in our environment. 

Speaker 1 
We can do the screen layout, we can get all the graphics, entities, buttons and radio buttons and text boxes and all of those sorts of control features on the screen very quickly and tested in a matter of minutes, really. 

Speaker 1 
I think this will open some doors about how we think about information technology and I think now we can rightfully start seeing information as opposed to database technology. The Ingress 4GL product is exciting in that I think it provides a lot of tools to people who would otherwise not develop a graphical user interface application because it's too hard. 

Speaker 1 
We've gone a long way as well as other vendors in providing ways to simplify creating applications, but what we see in the 4GL type of products is a way to move the boundary of who can create an application from somebody who's very technically sophisticated to someone less so and that greatly expands the market for who develops applications. 

Speaker 1 
The problem we are having today of course is that these workstations are built for technical applications so there's very little commercial, if I can say, application tools available. So therefore for us this is a very, the Ingress 4GL Windows product is a very, very key product because it allows us to take our technical workstations and use them for commercial applications and there is absolutely a need for that. 

Speaker 1 
So for us it's a very good way to expanding our business with our workstation into the more commercial applications. Ingress Windows 4GL is one of those very fine tools that is a higher level programming environment to allow you to spend less time on the user interface and more time on solving the customer problem. 

Speaker 1 
I see a lot of software. I see a lot of exciting new software. I see a lot of old software that still sells a lot, but I don't often see software that I think has the opportunity to rapidly advance the use of powerful workstations in the commercial market. 

Speaker 1 
I think it's a great product. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-ingres-windows-4gl-(may-1990)-a92e41 |
| title | Ingres Windows 4GL — Analyst and Customer Panel (May 1990) |
| author | Peter S. Kastner |
| date | 1990-05-01 |
| type | transcript |
| subject_domain | database software / graphical user interfaces / 4GL development tools |
| methodology | oral-history |
| source_file | /home/user/workspace/archive2_raw/transcript-ingres-windows-4gl-(may-1990)-a92e41.txt |
| license | CC-BY-4.0 |

### Abstract

An ~8-minute video featuring Peter Kastner (VP, Aberdeen Group) and multiple customer/user speakers discussing the challenges of graphical user interface development and the Ingres Windows 4GL product. Kastner frames the market problem: end users demand intuitive workstation interfaces but GUI programming has been 'exceedingly complex and beyond the knowledge base of most programmers.' Customer speakers describe painful transitions from character-based terminals to GUI, the lack of productivity tools for graphical environments, and their enthusiasm for Ingres 4GL Windows as a product that enables non-expert programmers to build commercial workstation applications. Kastner delivers a brief opening statement establishing Aberdeen Group research context, while customer speakers provide the bulk of the commentary on usability, productivity, and market opportunity.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Earliest transcript in the archive (1990); captures GUI transition pain and analyst/customer perspectives on 4GL tools at a pivotal moment in commercial computing. Kastner's VP-of-Aberdeen framing provides archival evidence of his analyst role and firm's research direction circa 1990. |
| **Relevance** | high | Documents Kastner's involvement in the Ingres product ecosystem as an analyst endorser, consistent with his later Crossroads role. Provides early data on his Aberdeen Group positioning and his research focus on end-user productivity and GUI adoption. |
| **Prescience** | high | The predictions proved highly accurate: GUI interfaces became universal, training costs dropped dramatically, 4GL tools democratized application development, and workstations expanded into commercial applications. The 'information age' framing (1990) anticipated trends that materialized throughout the 1990s. |

### Prescience Detail


**Prediction 1:** gui-training-cost-reduction
- **Claimed:** training costs would be much lower. The retention of those training environments would be much higher, and the productivity...would be a lot lower
- **Year:** 1990
- **Confidence at time:** high

**Actual Outcome 1:** gui-training-cost-reduction-actual
- **Result:** GUI became universal standard by mid-1990s; training cost reduction broadly validated
- **Confidence:** high
- **Notes:** Prediction in OBS-004 proved accurate; Windows 95 and Mac OS mainstreamed GUI; training costs did drop

**Prediction 2:** information-vs-database-shift
- **Claimed:** I think this will open some doors about how we think about information technology...now we can rightfully start seeing information as opposed to database technology
- **Year:** 1990
- **Confidence at time:** medium

**Prediction 3:** democratization-of-app-development
- **Claimed:** move the boundary of who can create an application from somebody very technically sophisticated to someone less so and that greatly expands the market for who develops applications
- **Year:** 1990
- **Confidence at time:** high

**Actual Outcome 3:** democratization-actual
- **Result:** 4GL/RAD/low-code tools did expand developer base significantly through 1990s–2000s
- **Confidence:** high
- **Notes:** Prediction in OBS-020 broadly validated; VB, Access, and later low-code platforms democratized development

**Prediction 4:** workstation-commercial-app-opportunity
- **Claimed:** these workstations are built for technical applications so there's very little commercial application tools available. Ingress 4GL Windows product is a very key product because it allows us to take our technical workstations and use them for commercial applications
- **Year:** 1990
- **Confidence at time:** high

**Actual Outcome 4:** workstation-commercial-app-actual
- **Result:** Workstations and PCs became primary commercial computing platform through 1990s; prediction fully validated
- **Confidence:** high
- **Notes:** The shift of workstations to commercial use was fully validated by Windows/PC dominance in 1990s

**Prediction 5:** workstation-commercial-advance
- **Claimed:** I don't often see software that I think has the opportunity to rapidly advance the use of powerful workstations in the commercial market. I think it's a great product.
- **Year:** 1990
- **Confidence at time:** medium


### Entities Referenced (3)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Ingres Corporation | company | acquired | HCL Technologies (via Actian) |

### Technologies Referenced (8)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Ingres Windows 4GL | framework | Ingres Corporation | launch/early-adoption | legacy |
| Ingres RDBMS | database | Ingres Corporation | mainstream | legacy |
| Graphical User Interface (GUI) | framework | generic | emerging/transition | standard |
| Character-Cell Terminals | hardware | generic | declining | obsolete |
| Fourth-Generation Language (4GL) Development Tools | framework | generic | emerging | legacy |
| Technical Workstations | hardware | generic | transition-to-commercial | evolved |
| Apple Macintosh | hardware | Apple | mainstream | active |
| DEC VAX | hardware | Digital Equipment Corporation | mainstream | obsolete |

### Observation Summary

- Total observations: 27
- By type: expert-opinion: 11, technology-assessment: 8, viability-prediction: 5, actual-outcome: 3
