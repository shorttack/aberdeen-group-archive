# MSNBC News Segment: AOL Modem Shortage and Service Crisis (2001)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 2001-01-01 |
| Type | transcript |
| Domain | broadband |
| License | CC-BY-4.0 |

## Abstract

Short MSNBC TV news segment (approx. 10 minutes) in which Peter Kastner, Group VP at Aberdeen Group, provides expert commentary on America Online's network congestion crisis. AOL faced busy signals and customer refund demands after its shift to $20/month unlimited internet access caused daily usage to double. Kastner explains the supply-demand imbalance (250,000 modems for 8 million subscribers), discusses competition from Microsoft, AT&T, CompuServe, and Prodigy, and offers a 5-year outlook suggesting society must adjust its expectations about online service reliability.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 8 |
| technologies.csv | 4 |
| observations.csv | 16 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (2001). MSNBC News Segment: AOL Modem Shortage and Service Crisis (2001).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
