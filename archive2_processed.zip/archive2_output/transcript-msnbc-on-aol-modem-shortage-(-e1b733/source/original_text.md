# MSNBC News Segment: AOL Modem Shortage and Service Crisis (2001)

> Archived from: transcript-msnbc-on-aol-modem-shortage-(-e1b733.txt
> Original publication date: 2001-01-01
> Author: Peter S. Kastner

---

## Original Document Text



MSNBC on AOL (2001)

⏰Sat, 11/16 14:58PM · 10mins

AI Notes

 
 Summary
 This transcript is not a typical meeting record, but rather a news broadcast discussing America Online (AOL) and its recent challenges. The main speaker appears to be a news anchor, with contributions from CNBC's Ron Insana and Peter Kastner, a group vice president with the Aberdeen Group. The discussion centers around AOL's recent problems, including network congestion, accounting issues, and customer dissatisfaction. Key points include:
 1. AOL is offering refunds to customers who have been experiencing difficulty logging on due to busy signals.
 2. The company has seen rapid growth, adding 1.2 million subscribers in the last quarter to reach 8 million total.
 3. Usage per customer has doubled from 15 to 30 minutes per day after introducing unlimited access for $20 per month.
 4. AOL only has 250,000 modems, resulting in a ratio of one modem for every 32 customers.
 5. Small businesses are particularly affected by the service issues, as they rely on email for communication with suppliers and customers.
 6. AOL is facing competition from other providers like Microsoft, AT&T, CompuServe, and Prodigy.
 7. The company has addressed some accounting issues, such as no longer artificially inflating profits.
 8. Peter Kastner suggests that the current problems will likely sort themselves out in a few weeks.
 9. AOL needs to balance marketing efforts with technological growth to remain competitive.
 10. The discussion touches on broader issues of online service reliability and societal expectations for constant connectivity.
 While this is not a traditional meeting with action items, the discussion provides insights into the challenges faced by early internet service providers and the rapidly evolving online landscape of the late 1990s.
 Chapters
00:02:44 AOL's Network Congestion and Customer Refunds
 The news anchor introduces the topic of America Online's recent troubles, including network congestion leading to busy signals for customers trying to log on. AOL has agreed to offer refunds to affected customers. CNBC's Ron Insana reports on the company's public acknowledgment of the issue and their promise to address it.
00:05:52 AOL's Rapid Growth and Capacity Issues
 Peter Kastner explains that AOL has grown by 1.2 million subscribers in the last quarter, reaching 8 million total. The introduction of unlimited usage for $20 per month has doubled average daily usage from 15 to 30 minutes per customer. With only 250,000 modems for 8 million subscribers, the system is overwhelmed.
00:06:38 Impact on Small Businesses
 The discussion turns to how AOL's service issues are affecting small businesses that rely on email for communication with suppliers and customers. Kastner emphasizes the frustration experienced by business users who depend on reliable online services.
00:07:57 Competition and AOL's Future Prospects
 The news anchor and Kastner discuss AOL's competition, including Microsoft, AT&T, CompuServe, and Prodigy. Kastner explains that AOL needs to balance aggressive marketing with technological growth to remain competitive in the evolving online service market.
00:09:13 Long-term Outlook for Online Services
 Kastner provides a five-year outlook, suggesting that society will need to adjust expectations regarding the reliability and availability of online services. He indicates that the current issues are part of a broader trend as more people come online.
 Action Items
00:07:30 AOL mentioned they will contact customers by email regarding refunds for service issues.
00:08:12 Peter Kastner suggested AOL needs to balance marketing efforts with technological growth to remain competitive.
00:09:38 The news anchor indicated that efforts are underway to improve sportsmanship in sports, to be discussed in an upcoming segment.

Transcript

That's the very latest from here. Back to Lisa. Thanks Ted. Trying to log on or log off AOL. You're not alone. That story is coming up right after the break here on M.S. and B.C. You're connected to M.S. 

and B.C. We're going to get your feet wet on the internet. A.T. and T. makes it easy to catch the wave. Every day A.T. and T. helps thousands of businesses, big and small, search for information, send email, and set up websites where they can do business with their customers. 

So whether you're a little kahuna or a big kahuna, grab your board and hop on. A.T. and T. It's going to be a great ride. I was at my daughter's for the weekend. I was just settling in for the night when the pain started. 

I knew I wouldn't get a good night's sleep. And I was worried about taking something about how I'd feel the next morning. Then Susie told me to try her tile an RPM. The pain stopped. I slept through the night. 

A tile an RPM worked great. The next morning I was up even before the kids. And I had so much energy. I wore that. out. Rest easy, it's Tylenol PM. Bleach. It is a little strong for the nose. Would I use bleach more if it smelled better? 

Yes, I would. Introducing Fresh Scent Clorox Cleanup. You cannot believe that there's bleach in here. It's just a fresh clean smell. It does smell very good. Try new Fresh Scent Clorox Cleanup. Now get 24 issues of the new New Yorker week after week for just $19.98. 

Save $40 off the cover price and get this special cartoon collection free with your paid subscription. Call 1-800-952-2626. It has been a tough couple of months for America Online and now AOL is agreeing to give refunds to customers who keep getting a busy signal when they try to log on. 

But that's not AOL's only problem. CNBC's Ronin Sana reports. America Online lately dubbed America offline, used the New York Times to say we feel your pain and we're going to fix the problem. For now, though, angry customers are facing a new bottleneck on the AOL telephone hotline. 

Please remain on the line, and the next available representative will be with you shortly. Speaking of lines, this week, the company's network CEO said... I've been in the theme park business. You know, some people walk in a theme park and look at a line and go, I'm not going to stand in a line, and they leave. 

And if we've had people doing that, we want to do right by them. But experts say the traffic in cyberspace is just one of many recent problems at AOL, not the least of which was the company's inability to make any real money. 

They were spending much, much more than was coming in, but they were, for accounting purposes, treating a very sizable portion of those monies going out, not as an expense which would have reduced their earnings, but treating them instead as an asset. 

AOL has recently put its accounting problems behind it. For example, it stopped counting certain expenses as assets. In other words, it's not artificially inflating its profits anymore. But one asset they may want to guard well, those customers tired of getting a busy signal. 

I think the people who are loyal to AOL's content are likely to stay loyal. But the casual user, the person who just sees them as one of many online services, they're very likely to look at other choices. 

Microsoft, AT&T, CompuServe, and Prodigy may all have a shot at stealing business from AOL, but they'll have to capitalize quickly while the company's back is on the mat. That was CNBC's Ron Insana reporting. 

Well, Peter Kastner is a group vice president with the Aberdeen Group. That's a computer industry market research analysis and consulting organization. He joins us now from our affiliate WHDH in Boston. 

Welcome, Mr. Kastner. Thank you. You know, they put out, AOL put out this unlimited internet access rate. And shouldn't they have expected so many people to sign on and then have all these busy signals? 

Well, they certainly did ignore the rules of economics that you have to balance supply and demand. But understand that they've been fighting essentially a two-front war. On the internet side, the internet providers have been offering free unlimited time for $20 a month. 

And their competitors on the other side, the other online services such as CompuServe, Microsoft Network, Prodigy, et cetera, have also been competing heavily and offering comparable plans. So AOL has been trying to grow their customer base at a very expensive but very rapid rate. 

At the same time, they've been trying to gear up their technology. And basically what we've seen is a catastrophic train wreck here as the company has grown a lot in the last 90 days, but also not been able to take the growth. 

Here's what's gone on. In the last quarter, the company grew. by 1.2 million subscribers to 8 million, that alone is a huge growth. But what happened is that the change to allowing people to dial in any time for only $20 a month, unlimited usage caused the amount of usage per customer to double from 15 to 30 minutes per day. 

Now, AOL only has 250,000 modems, a huge number, but they've got 8 million subscribers all trying to get in there at the same time often. So one modem for every 32 customers, it just hasn't worked out as everyone says, hey, let me check my email more often or check the news, et cetera. 

And who is being affected the most? Not necessarily just the private citizen, but small businesses as well, right? Oh, I agree completely. In fact, we've seen in the last couple of years that small businesses trying to change themselves, re-engineer, just like the big companies have, have taken to things, for instance, like electronic mail, talking to their suppliers, talking to their customers so that if you interfere with this service, 

what do people at the other end think? Gee, I sent an email. I haven't gotten a reply back. They must not like me. Maybe I'll take my business somewhere else. And that just isn't true. It's obviously been enormously frustrating for customers, but particularly on the business side. 

And it continues to be frustrating, even though AOL said earlier this week, we'll give you refunds. People who are trying to call in or log on to get off of AOL are getting busy signals or are on hold for an eternity. 

Right. Well, this is going to go on for a while. My advice would be, I would expect AOL to contact you by electronic mail, believe it or not. So they will get to you soon and your money will be delivered to you in short period. 

This is a little bit like everyone picking up the phone on mother's day or Christmas day and trying to place a phone call at the same time. We find that everything is, is jammed. This will sort itself out in a few weeks. 

Well, it may. sort itself out in a few weeks. But can AOL continue being, as they say, a prosperous company with maybe MSN, Prodigy, CompuServe trying to get in on this as well, get the customers to come to them if they're so frustrated with AOL? 

Well, AOL is trying to be one of the surviving information service providers. And in order to do that they're going to have to continue to keep their foot on the marketing accelerator but also keep growing their technology at comparable rates and avoiding what they've done in the past, obviously, of not having enough product in order to deliver the services that customers want. 

They certainly have a lot of competition but they're going to just have to work those break and accelerator pedals a lot more carefully. Is there a way that AOL, America Online, can go one step further to appease their customers? 

Well, uh, besides the e-mail? That's... that's difficult. They're doing what they can not only under the law and their settlement with the attorneys general, but as I said earlier there just aren't enough phone line connections for AOL or for any other online service at this time. 

And there probably won't be for the indefinite future. We just have to get used to as a society the fact that even though we're more online that things that we come to count on won't necessarily be there all the time. 

I think that's the five year scenario. Okay, thank you very much Mr. Kastner. Peter Kastner, group vice president with the Aberdeen Group. That's a computer industry market research and consulting organization. 

Thank you very much for talking with us. Up next there are athletes who kick, spit and behave in an uncivil manner. But now efforts are underway to put the sportsmanship back in sports. That's coming up here right on MSNBC. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-msnbc-on-aol-modem-shortage-(-e1b733 |
| title | MSNBC News Segment: AOL Modem Shortage and Service Crisis (2001) |
| author | Peter S. Kastner |
| date | 2001-01-01 |
| type | transcript |
| subject_domain | broadband |
| methodology | oral-history |
| source_file | transcript-msnbc-on-aol-modem-shortage-(-e1b733.txt |
| license | CC-BY-4.0 |

### Abstract

Short MSNBC TV news segment (approx. 10 minutes) in which Peter Kastner, Group VP at Aberdeen Group, provides expert commentary on America Online's network congestion crisis. AOL faced busy signals and customer refund demands after its shift to $20/month unlimited internet access caused daily usage to double. Kastner explains the supply-demand imbalance (250,000 modems for 8 million subscribers), discusses competition from Microsoft, AT&T, CompuServe, and Prodigy, and offers a 5-year outlook suggesting society must adjust its expectations about online service reliability.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | medium | Short but vivid snapshot of early internet service growing pains; Kastner's commentary provides context on AOL's structural capacity problems and transition to always-on internet expectations. |
| **Relevance** | high | Kastner is the sole expert commentator interviewed; provides direct analysis of AOL's situation from Aberdeen Group's IT research perspective. |
| **Prescience** | high | Kastner's prediction that society would need to adjust expectations about online reliability proved accurate; his assessment of AOL needing to balance marketing with infrastructure investment was validated by AOL's subsequent struggles. |

### Prescience Detail


**Prediction 1:** Near-term resolution timeline
- **Claimed:** This is a little bit like everyone picking up the phone on Mother's Day or Christmas Day; this will sort itself out in a few weeks
- **Year:** 2001
- **Confidence at time:** medium

**Actual Outcome 1:** AOL resolution actual timeline
- **Result:** AOL resolved its modem capacity crisis within 6-12 months (1997) by expanding network capacity. However, AOL's long-term resolution came through the merger with Time Warner (2001) and eventual transition to broadband. AOL ultimately declined as broadband replaced dial-up; dial-up service ended in August 2025.
- **Confidence:** verified
- **Notes:** AOL/Time Warner merger 2001; Britannica notes AOL's dial-up service shutdown in September 2025; AOL now owned by Bending Spoons

**Prediction 2:** 5-year online reliability outlook
- **Claimed:** Just have to get used to as a society that even though we're more online, things we count on won't necessarily be there all the time — that's the five year scenario
- **Year:** 2001
- **Confidence at time:** medium

**Actual Outcome 2:** Online reliability society adjustment actual
- **Result:** Society's adjustment to online service reliability was gradual. The expected normalization of outages and service issues did not fully occur; instead, consumers raised expectations for reliability. Broadband replaced dial-up and reliability concerns fundamentally changed in nature.
- **Confidence:** medium
- **Notes:** The online reliability landscape evolved through broadband adoption rather than societal acceptance of dial-up limitations


### Entities Referenced (8)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Ron Insana | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| America Online (AOL) | company | acquired | Bending Spoons |
| Microsoft (MSN) | company | public |  |
| AT&T | company | public |  |
| CompuServe | company | defunct | AOL |
| Prodigy | company | defunct |  |

### Technologies Referenced (4)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Dial-up Modem / POTS Internet Access | hardware |  | mature | obsolete |
| Unlimited Flat-Rate Internet Access ($20/month) | application | AOL | growth | obsolete |
| Electronic Mail (email) | application |  | growth | standard |
| Consumer Online Service Platform | platform | AOL | growth | obsolete |

### Observation Summary

- Total observations: 16
- By type: expert-opinion: 9, market-data: 3, viability-prediction: 2, actual-outcome: 2
