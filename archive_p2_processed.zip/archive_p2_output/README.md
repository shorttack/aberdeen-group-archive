# Aberdeen Group Archive — Presentations Batch 2 (Archive-P2)

**Processed:** 2026-04-09
**Skill version:** archival-ingest v16
**Repository:** github.com/shorttack/aberdeen-group-archive

## Contents

This archive contains 8 unique study packages from Aberdeen Group sales training and consulting presentations, 1995–1996, authored by Peter S. Kastner.

### Studies

| Study ID | Title | Date | Client | Observations |
|---|---|---|---|---|
| `hartford-insurance-win95-notes-388db6` | ITT Hartford's Corporate Platform Decision | 1995 | ITT Hartford | 21 |
| `ibm-1996-training-fbf9dc` | IBM Power Academy RDBMS Sales Training 1996 | 1996 | IBM | 30 |
| `ibm-rs6000-detroit-c74f4a` | RS/6000 RDBMS Sales Training (Detroit) | 1995 | IBM | 28 |
| `ibm-midrange-training-1995-9293d0` | RS/6000 RDBMS Sales Training (Midrange) | 1995 | IBM | 20 |
| `ibm-re-rdbms-partners-e35775` | Power Academy RDBMS Sales Training (Partners Edition) | 1996 | IBM | 25 |
| `informix-1995-bf3b98` | Informix Software Overview | 1995 | Informix | 28 |
| `informix-cs-train-1996-49b7e0` | Choosing The Right Markets and the Right Partners for Informix | 1995 | Informix | 28 |
| `informix-dsa-presentation-747767` | Choosing The Right Markets and the Right Partners for Informix (DSA Edition) | 1996 | Informix | 25 |

**Total observations:** 205

### Duplicates Skipped

| Study ID | Duplicate Of | Reason |
|---|---|---|
| `ibm-power-academy-1996-d0eebb` | `ibm-1996-training-fbf9dc` | Byte-for-byte identical |
| `ibm-re-competitors-f979e6` | `att-ncr-dg-etc-14f7ce (Archive-1)` | Byte-for-byte identical |

## Collection Themes

These presentations represent Aberdeen Group's paid consulting and training work for IBM and Informix in the mid-1990s RDBMS market, plus one corporate platform advisory for ITT Hartford. Key themes:

- **RDBMS competitive landscape (1995–1996):** Comparative analysis of Oracle, Sybase, Informix, IBM DB2, Microsoft SQL Server, CA-Ingres, Software AG Adabas D, Progress Software, Red Brick Systems
- **IBM RS/6000 and SP2 positioning:** Sales training for IBM field reps on positioning RS/6000 against HP 9000, Sun, Digital, AT&T GIS
- **Aberdeen Three-Tier-Plus architecture model:** Kastner's framework for distributed enterprise computing
- **Informix channel strategy:** Vertical market targeting (telecom, retail, banking, manufacturing, government) and partner channel framework
- **Corporate platform decision-making:** Windows 95, dual Unix/NT strategy, Novell NetWare

## Files

- `master_index.csv` — Study metadata for all 8 packages
- `master_observations.csv` — All 205 observations combined
- `archive_p2_web_results.json` — Phase 3 web verification cache
- `_known_entities.csv` — 139 entities (cumulative cache)
- `_known_technologies.csv` — 231 technologies (cumulative cache)

## Entity/Technology Cache

Seeded from Presentations Archive-1 (131 entities, 217 technologies). This archive adds:
- **8 new entities:** itt-hartford, lotus-development, red-brick-systems, bgs-systems, cincom-systems, sas-institute, ken-leech, csc
- **14 new technologies:** microsoft-office, lotus-notes, oracle-rdbms, sybase-sql-server, sql-server, aix, adabas-d, three-tier-plus, decision-support, informix-xps, informix-online-secure, informix-online-optical, informix-sql-suite, newera-viewpoint
