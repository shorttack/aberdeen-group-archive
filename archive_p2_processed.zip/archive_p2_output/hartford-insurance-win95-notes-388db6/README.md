# ITT Hartford's Corporate Platform Decision

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | employer-record |
| Domain | desktop OS strategy; network OS strategy; application platform; Windows 95; Unix; Windows NT; Novell NetWare; Microsoft Office; Lotus Notes; AT&T GIS; Sun; HP; IBM; corporate platform decision |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group consulting presentation delivered to ITT Hartford to guide their Corporate Platform Decision in 1995. Peter Kastner recommends Windows 95 for desktop OS, a dual Unix/NT strategy for application and database servers, and a dual Novell NetWare/NT strategy for network OS. The document includes competitive evaluations of AT&T GIS, Sun, HP, and IBM platforms and recommends Microsoft Office plus Lotus Notes for desktop productivity.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 10 |
| technologies.csv | 7 |
| observations.csv | 21 |
| codes.csv | 28 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). ITT Hartford's Corporate Platform Decision.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=ITT Hartford; format=presentation; collection_type=employer-record
