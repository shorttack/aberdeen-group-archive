# ITT Hartford's Corporate Platform Decision

> Archived from: hartford-insurance-win95-notes-388db6.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

1
ITT Hartford’s
Corporate Platform 
Decision
Aberdeen Group, Inc..
One Boston Place
Boston, Mass.  02108
(617) 723-7890
2
AberdeenGroup 
 2
Agenda
• Aberdeen’s Assignment
• Analysis, Implications, Recommendations
• Desktop operating system
• Application/DB operating system
• Network operating system
• Network management
• Desktop applications
• Groupware
• Desktop office automation
• 3270 emulator
• Electronic mail
• Group calendar
• Supply cabinet functionality
• Platform management tools
In 1994, Aberdeen Group reviewed the project status and potential platform changes in the 
Commercial Lines reengineering project.
Our 1995 assignment is to examine and comment on ITT Hartford’s plans for a common cross-
business-unit set of client and middle-tier servers. 
AberdeenGroup 
 3
Aberdeen’s 
Assignment
•
Background is 1994 Commercial Lines Coop review
•
Analyze the business impact of the planned 
Corporate Platform, focusing on:
• technology suitability
• maturity
• vulnerabilities
• likely timing scenarios
• synergy of prior ITT Hartford experiences
• ongoing Aberdeen research
• other factors
Although ITT Hartford’s work to determine common platform alternatives has progressed rapidly, 
Aberdeen Group is pleased with the level of depth shown in analyzing technology alternatives and 
their potential business impact upon ITT Hartford.  Our conclusion is that ITT Hartford will be well 
served by the final results of the common-platform determination study.
AberdeenGroup 
 4
Summary Findings
•
ITT Hartford planning has been excellent, and 
preliminary plans show considerable effort at finding 
the devil in the details
•
Microsoft Windows95 is the runaway choice as 
desktop OS, but general availability timing will be 
later than required
• Using beta version of Windows95 to enable new 
Commercial Lines functionality is a calculated 
risk versus an unacceptable implementation delay
•
A dual workgroup-OS strategy built around 
Windows NT/AS and Novell NetWare is pragmatic
•
System and network management, particularly 
distributed software management, deserve on-going 
planning attention
•
Other planned corporate platform technology choices 
are sensible
Aberdeen believes the PC operating system is the most important component in ITT Hartford’s 
selection process.  The PC-OS affects how all users interface with computing services.  Limitations in 
a PC-OS (e.g.., DOS 640KB memory limit) have a profound effect upon in-house and purchased 
applications.
Looking ahead, Microsoft Windows95 will be a runaway market winner, and thus drag innumerable 
ISV applications and mindshare with it.
IBM’s OS/2 Warp is a technology runner-up (if not running ahead) of Windows95.  Nevertheless, 
IBM has lost the battle of software developers.  There are few best-in-class development tools and 
fewer applications available off the shelf for Warp.  This dramatically limits The Hartford’s choices 
for purchased development tools and applications.  For example, Microsoft Office only runs in 
Windows 3.1-compatibility mode.  While we believe IBM will not abandon its OS/2 commercial 
customers anytime soon, we do not expect OS/2 to reach double-digit market share on corporate 
desktops.
Windows NT Workstation requires a 32MB PC -- a big footprint.  Moreover, NT must change in the 
next year to mimic the Windows95 GUI.
Aberdeen does not consider desktop Unix as a viable option.
AberdeenGroup 
 5
Desktop OS
•
Candidates
• Microsoft Windows95
❻Not shipping
• IBM OS/2 Warp
❻Little ISV support, commitment
• Microsoft NT Workstation 
❻GUI will change to Win95, big footprint
•
Microsoft Windows95 is the best choice
• Everybody proclaims it the market winner
• Windows 3.1 is the largest Hartford desktop
• Huge ISV support for applications
• Will work well with either NT or NetWare as the 
workgroup server
• Full compatibility with existing 16-bit apps
• Good built-in support for remote access
• More crash-proof than DOS/Windows
While Windows95 will provide the technology platform that ITT Hartford requires, it is not generally 
available.  And only Microsoft knows what the critical bug count is and whether or not Windows95 
will meet its planned August 1995 general availability.
ITT Hartford has a new version of Commercial Lines application functionality that requires the 
advanced architecture of Windows95.  Aberdeen was asked our opinion on shipping the new 
application versions to run on the not-yet-production version of Windows95.
On paper, there is always considerable risk in roll-outs based on pre-production software.  To 
minimize the risk of technology failure, ITT Hartford would wait for the final release of Windows95.  
However, the business risk of such a delay is unacceptable.
AberdeenGroup 
 6
Desktop OS Timing
•
Aberdeen’s Prioritized Prudent Choices
• 1.  Wait for Windows95 to ship and settle down
• 2.  Stay with Windows 3.1 until Win95 is ready
• 3.  Use Windows NT Workstation until Win95 is 
ready
•
Waiting for Windows95 has the least risk of 
technology failure
•
But Commercial Lines is between a Win 3.1 rock and 
a Win95 hard place!
ITT Hartford has extensively tested the new Commercial Lines functionality against the Windows95 
beta version and believes there are limited risks.
Aberdeen Group has installed Windows95 on a variety of Intel 386, 486 and Pentium platforms, both 
desktops and laptops.  We have had a number of installation failures, but have understood why, and 
were successful in subsequent attempts.  We have diagnosed more than a dozen bugs.
In spite of the problems, we conclude:
 
. We are unable to crash Windows95
 
. All DOS applications work that we have tried
 
. Most Windows 3.1 applications work flawlessly, but not all.
We concur with The Hartford’s decision to deploy on Windows95 on a standard set of Commercial 
Line PCs.
We recommend working closely with up-front commitments from AT&T GIS and Microsoft.
AberdeenGroup 
 7
Windows95 Timing 
Resolution
•
ITT Hartford assessment is that Win95 today is more 
stable than Win 3.1 and DOS on The Hartford’s 
typical desktops
•
Aberdeen Group has no research to dispute The 
Hartford’s assessment ...
•
But Win95 beta program is a moving target
•
Recommendations
• Continue plans for laboratory review
• Do an early pilot office in next 60 days
• Get commitments from AT&T GIS and Microsoft 
for as much support & partnering as you can 
negotiate
• What is the backup plan if the Win95 beta roll-out 
fails?
It is Aberdeen’s opinion based on extensive field research that Unix is mature enough today to handle 
virtually any application -- including mainframe applications.
Windows NT/AS fits well as an application/DB server OS for applications requiring limited 
processing power and/or limited numbers of users.  NT will not scale today to support more than 4 
processors effectively.  Also, NT is not commonly used with more than 100 - 150 users.
AberdeenGroup 
 8
Application/DB 
Operating System
•
ITT Hartford choices narrowed to Unix and Windows 
NT/AS (NT)
•
Unix
• There is not and never will be one Unix
• Most common variants are (listed alphabetically)
❻AT&T’s  SVR4 
❻HP’s HP-UX
❻IBM’s AIX
❻Sun Microsystem’s Solaris
• Unix for application/DB serving is today a better 
choice than NT
❻More ISV’s and applications
❻Proven robustness and scaleability
❻Considerable hardware vendor support
One of The Hartford’s server partners, AT&T GIS, is working with Microsoft to better scale towards 
8 processors.  We expect some of this code to be available in NT 3.55 later in 1995.
We emphasize that NT is almost exclusively an Intel-based OS.  Few ISV applications exist for the 
RISC variants of NT, and we would expect the Intel platforms to get the newest applications (and 
versions) first for some years to come. 
AberdeenGroup 
 9
Application/DB 
Operating System
•
Windows NT/AS
• A good start by Microsoft
• NT is 85% Intel.  Beware of NT on RISC due to 
limited support.
• scaleability will improve to 8 processors in 1995, 
16  by 1997
• Many ISV’s are porting to NT -- more apps in the 
future, sooner
• NT will cost less, slowly force lower Unix app 
costs
Our high-end/low-end strategy allows for the realities of today’s market while expecting the 
dynamics to change over time.
In order to minimize long-term support costs, we recommend that The Hartford limit the number of 
Unix and NT variations  -- one of each would be ideal but might limit negotiating best prices.
AberdeenGroup 
 10
Application/DB OS 
Recommendations
•
Use a high-end/low-end dual-standard strategy
•
Unix for the high end.  
• Tie Unix variant to Processor Strategy Initiative 
selection(s)
•
NT/AS for low-end servers
• Probably Intel-based
• Gain economies of scale since NT is a choice for 
NOS server
•
As NT/Intel platforms prove ability to scale up, raise 
the low-end/high-end threshold
•
Be prepared to support both NT/AS and Unix for at 
least five years 
• Neither OS is apt to out-muscle the other
• Breed competition on a project-by-project basis
11
AberdeenGroup 
 11
Network OS Strategy
• Team recommends dual-NOS strategy of Novell’s 
NetWare and Microsoft’s NT/AS
• NetWare has a huge installed base of NetWare 3.1 at 
ITT Hartford
• It works well ... 
❻very mature technology in 3.1, less so in 4.x
❻mostly print & file sharing
❻few databases and application directly tied to 
the NOS
• Many trained administrators and CNE’s
• No business justification to change
• Windows NT/AS
• Close integration with Windows95 client
• But supports NetWare clients well too
• Facility to do a robo-migration from NetWare to 
NT
• Future Microsoft desktop apps will be client-
server enabled to NT
Aberdeen believes that Novell has seen its high-water mark and is headed towards considerable 
difficulties.  We expect serious financial problems by year-end 1996.  
Thus, using Novell merely for new file-and-print servers while investing heavily elsewhere in 
Microsoft makes little sense.  NT provides equivalent LAN services to NetWare 3.1x, and now has 
good facilities for robotically migrating a NetWare server to NT in a manner that is transparent to 
clients.
NT is less mature than NetWare in the BackOffice area -- electronic mail, other messaging, and 
systems management.  New product releases including SQL Server95 and Exchange are expected 
later this year.
AberdeenGroup 
 12
Network OS Strategy 
Conclusions
•
Aberdeen concurs with dual NOS strategy
•
NT and NetWare are about equal today in print-and-
file sharing
•
We expect NT to gain NOS market share at an 
increasing rate
•
Novell has numerous business obstacles to overcome 
in order to remain a top-tier software supplier in the 
future
• Unixware, WordPerfect, etc.. are largely 
diversions from core NOS cash-cow
• Implication:  lack of profitability will be a bad 
sign (e.g.., Borland)
•
Microsoft will be later than expected in maturing NT
• BackOffice components are delayed
• Cairo is still the project name, but when will the 
OO-part arrive?
Since Sun is not a major platform player at The Hartford, we would not normally introduce another 
platform into the mix without a significant reason.  In this case, the compelling reason is The 
Hartford’s major investment in Cisco hubs and Bay Networks routers.  These hubs and routers are 
well managed by Sun’s SunNET Manager.
AberdeenGroup 
 13
Network Management
•
Selection of Sun’s SunNET Manager is primarily 
based on tight integration with major investment in 
Cisco and Bay Networks hubs and routers
•
SunNET Manager is and will continue to be a major 
network management player
•
Aberdeen concurs with selection of SunNET Manager
•
HP’s OpenView is a viable competitor
• Major system management thrust beyond Sun’s 
network management
• Large supplier of PCs, workstations, and servers, 
so HP understands more network requirements 
than Sun
•
IBM’s Karat is still a strategy
• Lacks internal IBM buy-in
• Products will be late
• Not a viable contender for ITT Hartford
Microsoft Office and Lotus Notes are best-in-class applications.  Their choice does not require 
extensive justification or comment.
AberdeenGroup 
 14
Desktop Applications
•
Microsoft Office is the OA choice
• There is no other rational choice
• Is there a need for a standard desktop access tool?
❻Office Professional includes MS Access
❻Software AG’s Esperant is best-in-class
❻There are numerous others
•
Groupware choice is Lotus Notes 
•
Both will work well with desktop OS and NOS 
choices
We expect Microsoft Schedule+ to gain market share over the next three years.
Supply Cabinet functionality for software deployment could be replaced/supplanted by:
 
. CA Unicenter for NT
 
. Enterprise Data Management by Novadigm
AberdeenGroup 
 15
Minor Pieces
•
3270 Emulator will remain Dynacomm Elite
•
Electronic Mail standard is ccMail
•
Group Calendar standard is Campbell Services’ 
Ontime
• Microsoft will increasingly compete
•
Supply Cabinet Functionality
• Software distribution
By manufacturing CA-Unicenter for NT on behalf of Computer Associates, Microsoft is down-
playing the future role of Hermes (i.e.., Microsoft Systems Management Services).  First, we believe 
Microsoft is wise to let the market fill this systems management hole -- rapidly.  Moreover, CA-
Unicenter is rapidly emerging as the distributed server manager of choice.
AberdeenGroup 
 16
Platform Management 
Tools
•
Systems Management
• LAN-based
• Server
•
Performance/Capacity Planning
•
Problem Management
•
Library Management
•
Software Distribution
17
AberdeenGroup 
 17
Discussion


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | hartford-insurance-win95-notes-388db6 |
| title | ITT Hartford's Corporate Platform Decision |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | employer-record |
| subject_domain | desktop OS strategy; network OS strategy; application platform; Windows 95; Unix; Windows NT; Novell NetWare; Microsoft Office; Lotus Notes; AT&T GIS; Sun; HP; IBM; corporate platform decision |
| methodology | client_org=ITT Hartford; format=presentation; collection_type=employer-record |
| source_file | hartford-insurance-win95-notes-388db6.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group consulting presentation delivered to ITT Hartford to guide their Corporate Platform Decision in 1995. Peter Kastner recommends Windows 95 for desktop OS, a dual Unix/NT strategy for application and database servers, and a dual Novell NetWare/NT strategy for network OS. The document includes competitive evaluations of AT&T GIS, Sun, HP, and IBM platforms and recommends Microsoft Office plus Lotus Notes for desktop productivity.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 7 |  |
| **Relevance** | 8 |  |
| **Prescience** | 7 |  |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (10)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| ITT Hartford | organization | historical |  |
| Microsoft | organization | active |  |
| Novell | organization | historical |  |
| Lotus Development | organization | historical |  |
| AT&T Global Information Solutions (GIS) | organization | historical |  |
| IBM (International Business Machines) | organization | active |  |
| Hewlett-Packard (HP) | organization | historical |  |
| Sun Microsystems | organization | historical |  |

### Technologies Referenced (7)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Microsoft Windows 95 | operating-system |  | emerging/mainstream | legacy |
| Microsoft Windows NT | operating-system |  | emerging | legacy |
| Unix | operating-system |  | mature | legacy |
| Novell NetWare 4.1 | networking |  | mature/declining | legacy |
| Microsoft Office | middleware |  | mainstream | legacy |
| Lotus Notes | middleware |  | mainstream | legacy |
| IBM RS/6000 | hardware |  | growth | legacy |

### Observation Summary

- Total observations: 21
- By type: competitive-assessment: 7, recommendation: 6, technology-assessment: 6, prediction: 1, event-record: 1
