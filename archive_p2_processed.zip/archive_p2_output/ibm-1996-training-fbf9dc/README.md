# IBM Power Academy RDBMS Sales Training 1996

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996-01-01 |
| Type | employer-record |
| Domain | RDBMS competitive analysis; IBM RS/6000; IBM DB2; Oracle; Informix; Sybase; SQL Server; Computer Associates Ingres; Progress Software; Red Brick; Software AG Adabas D; Unix platform market share; IBM Power Academy |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group competitive intelligence presentation to IBM's Power Academy, equipping RS/6000 sales representatives with detailed RDBMS vendor analysis across nine competitors. Kastner provides market share, revenue, and financial data for Oracle, Informix, Sybase, and others, along with Aberdeen's 1996 six-category RDBMS rating system covering Scalability, Distributed Data, Open Data Access, Development Tools, Other Technology, and End-User Solutions. Includes IBM RS/6000 positioning and ISV partnership propositions.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 16 |
| technologies.csv | 12 |
| observations.csv | 30 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). IBM Power Academy RDBMS Sales Training 1996.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=IBM; format=presentation; collection_type=employer-record
