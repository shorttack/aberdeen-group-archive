# RS/6000 RDBMS Sales Training (Midrange)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | employer-record |
| Domain | IBM RS/6000; RDBMS; midrange platform; IBM SP2; DB2/6000; decision support; data mining; OLTP; CSC survey IT management issues; hardware competitive analysis; HP 9000; DEC; Sun; AT&T GIS; platform revenue and market share |
| License | CC-BY-4.0 |

## Abstract

A 30-page variant IBM RS/6000 RDBMS sales training delivered in 1995 with a different agenda than the Detroit version. Kastner adds Decision Support/Mining Data, Opportunities for Open OLTP, and The RS/6000 with DB2/6000 sections. Includes detailed hardware specs for all five midrange vendors, CSC survey data on top IT management issues, and specific SP2 data: up to 512 Power2 processors, 370 systems installed, $200M 1994 revenue.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 9 |
| technologies.csv | 8 |
| observations.csv | 20 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). RS/6000 RDBMS Sales Training (Midrange).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=IBM; format=presentation; collection_type=employer-record
