# RS/6000 RDBMS Sales Training (Midrange)

> Archived from: ibm-midrange-training-1995-9293d0.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

IBM Sales Training
© AberdeenGroup 1995   1
RS/6000 RDBMS Sales 
Training
Peter S. Kastner
Group Vice President
Aberdeen Group, Inc.
One Boston Place
Boston, Mass. 02108
(617) 723-7890
IBM Sales Training
© AberdeenGroup 1995   2
Agenda
•
Impact of Information Technology on Business
•
Midrange Platform Technology & Leading Suppliers
•
Decision Support:  Mining Data for Information
•
Opportunities for Open OLTP
•
Introducing the RDBMS Players
•
Partnering with an RDBMS Sales Rep
•
Positioning the RDBMS Suppliers
•
The RS/6000 with DB2/6000
IBM Sales Training
© AberdeenGroup 1995   3
Summary
•
Business is continuously in a state of change
•
Information technologies grow only when they solve real world 
business problems
•
Many business executives have learned how to use IT for the 
benefit of their enterprises.  Many have not and tend to blame 
their IS staffs
•
The IS function within an enterprise is charged with evaluating 
new information technologies and implementing them as 
appropriate for the benefit of the entire enterprise
–
The technologies are changing too rapidly to keep abreast of 
all
–
Business goals and requirements are unclear and changing
IBM Sales Training
© AberdeenGroup 1995   4
Top Mgt Issues For IT Executives
'95
Rank
'94
Rank
Issue
1
2
Aligning IT & corporate goals
2
4
Instituting cross-functional Information Syst
3
3
Organizing & utilizing data
4
1
Implementing business reengineering
5
9
Improving the IT human resource
6
NR
Enabling change and nimbleness
7
16
Connecting to customers or suppliers
8
5
Creating an information architecture
9
7
Updating obsolete systems
10
6
Improving the system development process
Source:  Computer Sciences Corp.
IBM Sales Training
© AberdeenGroup 1995   5
Aberdeen Three Tier Plus Model
Mainframe
(Massively) Parallel
Division,  Department
Replicated Branch
PC, Workstation
PC LAN
PC LAN Server
Production
System
Decision
Support
System
OLTP at POS
User Desktops and Workgroups
IBM Sales Training
© AberdeenGroup 1995   6
Increase Line Access to Data
Workgroup 
Server
and/or Router
Fat 
Clients
Enterprise 
Databases
Departmental/
Other 
Workgroup
Servers
IBM Sales Training
© AberdeenGroup 1995   7
Adopting Technology
Early
Adopters
Leading
Edge
Mainstream
Trailing
RDBMS
Unix
NT
ORDBMS
Downsizing
Warehousing
IBM Sales Training
© AberdeenGroup 1995   8
Examining the Midrange Leaders
•
IBM
•
Hewlett-Packard
•
Digital Equipment
•
Sun Microsystems
•
AT&T Global Information Systems
IBM Sales Training
© AberdeenGroup 1995   9
1994 Worldwide Commercial 
Multiuser Risc/Unix Market $10B
Source: Aberdeen Group, February, 1995
Millions
IBM Sales Training
© AberdeenGroup 1995   10
IBM Hardware Line-up
•
RS/6000 Servers
–
Second largest supplier of multiuser RISC/UNIX systems -- 
19% market share
–
52% revenue increase ‘93/94
–
1994 revenues = $2 billion
–
Product line is transitioning from uniprocessor, Power2 
(RIOS) systems to SMP, PowerPC 601 servers 
–
Following an IBM-first strategy, will frequently offer 
DB2/6000 RDBMS at considerable cost savings with 
platform
–
Value Proposition: IBM’s professional services 
organizations will help our customers implement 
RISC/UNIX-based open, client-server computing with the 
RS/6000
IBM Sales Training
© AberdeenGroup 1995   11
IBM Hardware Line-up
•
SP2
–
Up to 512 Power2 processors each running AIX 4.x for commercial 
and technical applications
–
1994 revenues = $200 million
–
370 SP1 and 2 systems installed; 
70 SP2s for commercial applications
–
Positioned as high-end of RS/6000 line and DB/2 offload for 
ES/9000
–
Major commercial applications: Complex Decision Support, LAN 
server consolidation, OLTP 
–
Has generated 380 ISV promises to port RDBMSs and applications
–
Futures: SMP Nodes and RIOS2 upgrades
–
Value Proposition: IBM’s entry into very large scale, open systems 
computing.  Hot new technology from IBM.
IBM Sales Training
© AberdeenGroup 1995   12
IBM Strengths
•
Size
–
Global support
–
Range of products
–
Talent pool to draw upon
•
Customer base and sales reps’ knowledge of customers
–
Shared history,  Customer Trust
–
Former IBM employees working now as customers
•
Services
–
Planning, Implementation, Operations, Outsourcing, Financing
•
Third-party support and competition
–
ISVs by the 1,000’s
–
PCM and peripheral suppliers
–
Professional service organizations (e.g., Andersen Consulting)
IBM Sales Training
© AberdeenGroup 1995   13
IBM Challenges
•
Processor technology -- PowerPC 600 will not be leading the 
industry for many years
•
Re-energizing and focusing the field organization
•
Gaining the trust of leading-edge, business line manager, and 
X-generation buyers
•
Learning how to work with ISVs as allies -- not enemies
•
Recognizing that its chief competition for IS executive 
allegiance is not other hardware suppliers such as HP but 
software solution suppliers such as Oracle, SAP, and Microsoft 
IBM Sales Training
© AberdeenGroup 1995   14
Points-You-Should Know: 
IBM RS/6000
•
Customers buy RS/6000 for support and historical relationship 
reasons and have replaced it until lately because of lack of high-
end growth path.  Sell SMP scalability to SP2.
•
Platform-of-choice for VARs whose customers cannot afford 
AS/400 but want IBM platform
•
RDBMS ISVs fear that if they recommend RS/6000 IBM will 
still switch customer to low priced DB2/6000
•
Expect growth to continue in 1995 as datacenter managers 
experiment with RS/6000 Tier-2 surround strategies
•
RS/6000 with DB2 is neither the fastest nor least expensive 
option
•
Whole story includes NetView, Data Propagator, DataHub
IBM Sales Training
© AberdeenGroup 1995   15
HP Hardware Line-up
Midrange:
•
HP 9000: 
–
Multi-user RISC/UNIX industry leader -- 45% share
–
60% revenue growth rate last 3 quarters
–
1994 revenues = $4.5 billion
–
Value Proposition: Leading platform for Unix applications 
in terms of technology and ISV application support
•
HP 3000:
–
Legacy MPE/IX system updated with HP’s PA-RISC 
technology. Same hardware as HP 9000 but with MPE/iX 
operating system
IBM Sales Training
© AberdeenGroup 1995   16
HP Strengths
•
Trusted-supplier by IS decision makers for making the 
transition to high-performance UNIX systems
•
Supports and is supported by ISVs and professional service 
organizations -- usually as a first among equals
•
One of a handful of hardware suppliers that can support 
enterprises on a global basis
•
Technology leadership perception
–
RISC processors
–
Complete Unix operating environment
–
OpenView systems management framework
•
HP Professional Service Organization knows Unix operating 
environment capabilities thoroughly
IBM Sales Training
© AberdeenGroup 1995   17
HP Challenges
•
Running as a lean and mean organization means business 
opportunities often slip by
•
Making the transformation from selling hot boxes on price and 
price/ performance to being seen as an incumbent supplier that 
can add value in additional ways
•
Current generation of PA-RISC, PA-7200, is not the fastest chip 
in the market
•
Does not have a very high-end RISC/UNIX product offering (i.e. 
clusters & MPP) and is being squeezed by Intel/NT at the low 
end
•
After 3 years as Top Gun, HP is getting arrogant, sloppy
IBM Sales Training
© AberdeenGroup 1995   18
Points-You-Should Know: HP
•
Is considered the mainframe alternative leader
•
In new sales deals, HP’s most common hardware competitors 
will be IBM and Sun
•
HP’s Computer Systems Organization (HP 3000/9000, 
Workstations, PSO) has a separate sales force from its Computer 
Products Organization (Vectras, LaserJets, NetManagers) 
resulting in sales confusion and annoyance for customers and 
prospects
•
Is consistently ranked as one of the computer industry’s most 
respected companies 
•
Should be respected but not feared.  HP is not invincible.
IBM Sales Training
© AberdeenGroup 1995   19
Digital Hardware Line-up
Midrange:
•
Digital ALPHAserver XX00: 
–
Multi-user RISC/UNIX 64 bit -- 3% market share
–
150% revenue growth rate 1994
–
1994 revenues = ~ 20% revenues or $2.5 billion - with all add-ons
–
Value Proposition: Faster processors capable of managing vast 
amounts of memory and disk
•
Digital VAX:
–
Legacy VMS system updated to OpenVMS
–
VAX revenues declining 35% to 50% per annum
–
1994 revenues = less than 10% of company revenues - with all add-
ons
–
Value Proposition: Hold base while selling evolution and 
migration (if possible) to OpenVMS and ALPHA AXP
IBM Sales Training
© AberdeenGroup 1995   20
Digital Strengths
•
Alpha performance combined with aggressive pricing has 
created the best price/performance in the industry.
•
Digital's UNIX (OSF/1) meets the specifications of more 
standards setting groups than any other Unix operating system.
•
Digital will deliver enterprise-class open platforms with 
Microsoft NT on Alpha.  Note recent TPC-C benchmarks.
•
Digital is creating software frameworks for enterprise-wide 
open computing to meet customer needs for applications 
interoperability from the desktop to datacenter.
IBM Sales Training
© AberdeenGroup 1995   21
Digital Challenges
•
Digital is not yet out of the restructuring woods.  As a result, 
customers and prospects remain concerned about:
–
who will sell to them
–
where support will come from
–
which support people will continue to be there
–
which promised products may be eliminated
•
With the current neutral attitude of prospects to Digital's 
limited number of Alpha UNIX systems, Digital has yet to 
establish a critical mass for long-term viability.
•
Alpha/NT looks like a rosy future, but lacks 1995 revenues to 
sustain the company
IBM Sales Training
© AberdeenGroup 1995   22
Points-You-Should Know: Digital
•
The company's diligence and resolve is regaining it respect 
from the industry and Wall Street.  Prospects becoming more 
willing to entertain a Digital solution.
•
Digital remains an excellent engineering company.  
Development of Large In-Memory Databases (LIMD) could 
revolutionize enterprise OLTP and complex DSS.
•
Digital and Oracle have been increasing their strategic 
commitments
–
Oracle acquires RDB and installed base
–
Oracle is the LIMD database
IBM Sales Training
© AberdeenGroup 1995   23
Sun Hardware Line-up
Midrange:
•
SPARCcenter 2000 and SPARCserver 1000 : 
–
Multi-user RISC/UNIX - 10% market share
–
Revenues = ~ 20%  of Sun / $1.1 Billion 
–
SPARCcenter -  2 to 20 processors
–
SPARCserver -  2 to 8 processors
–
Challenging IBM for number 2 position with ISVs for 
application support
–
Value Proposition:  The open systems, price leader for 
enterprises that want alternative high-risk, high-reward 
solutions
IBM Sales Training
© AberdeenGroup 1995   24
Sun Strengths
•
Originator and still a leader in the open systems client-server 
computing marketplace.  Customers and Prospects still may 
have Sun religion.
•
Large number of software applications available - a pound-for-
pound leader. 
•
Sun is regarded as an innovator in providing networked 
client/server solutions to the industry.
•
Sun’s positive working relationships with value-added resellers 
and third party distributors can mean  lower acquisition and 
maintenance costs.
•
Strong ISV relationships.  Most ISVs use Sun workstations to 
develop their client/server products and applications.
IBM Sales Training
© AberdeenGroup 1995   25
Sun Challenges
•
Sun direct field support is limited and is often contracted out to 
other firms.
•
There are very few  references for running SPARCcenter 2000s 
and SPARCserver 1000s for business critical production OLTP 
applications. 
•
Transitions between operating system releases has historically 
been problematic, compounded by minimal technical support 
from its corporate offices.  Problems with Solaris in 1994.
•
Real world scalability of applications appears to be very poor 
on all of Sun’s workstations and servers.
•
Loss of influence.  Sun does not appear to be a major player in 
the new generation of standards setting groups.  Many Sun 
products, such as its critical OpenLook GUI, may be excluded 
from future standards.
IBM Sales Training
© AberdeenGroup 1995   26
Points-You-Should Know: Sun
•
Large number of applications.
•
Champion of the “common” customer.
•
Strong alternate channel presence - will sell through any 
distributor.
•
Sun’s commercial client/server strategy is making inroads via 
Networking and application development.
•
Sun maintains both the lowest entry price and best 
price/performance point for commercial servers.
IBM Sales Training
© AberdeenGroup 1995   27
AT&T Global Information Solutions 
(i.e. NCR)
•
1994 total revenues of approx. $4.2 Billion
•
Revenues have been flat for several years -- with financial 
results running at break-even (1% profit for 1994)
•
Continues to have financial backing of parent AT&T (1994 
revenues = $75 Billion) -- but could also be spun out or sold at 
any time
IBM Sales Training
© AberdeenGroup 1995   28
AT&T Global Information Solutions 
(i.e. NCR)
•
Product strategy is to offer open systems based on desktop to 
massively parallel product lines -- Globalyst models from PC to 
departmental and Teradata for decision support
•
All servers based on Unix and Intel 486/ Pentium 
microprocessor -- no RISC server
•
Unix System V.4 MP OS with Reliability, Availability, 
Serviceability enhancements
•
Low-end servers also run OS/2, SCO Unix, NetWare, and 
Windows NT
•
Microchannel peripheral bus adapters migrates to PCI
•
Full line of peripherals, including RAID storage
•
High availability clustering with LifeKeeper
IBM Sales Training
© AberdeenGroup 1995   29
AT&T GIS Strengths
•
Breadth of compatible server products is excellent
•
Good, often leading, TPC price/performance
•
The backing of AT&T
•
Bullet-proof version of UNIX.  Known for stability.
•
The Intel multiprocessor market champion (vs. RISC) and 
leader --  $1.2 Billion in 1994
•
Market strength and broad solutions strength in retail and 
banking
–
Also Telecomm, Government, Transportation markets
IBM Sales Training
© AberdeenGroup 1995   30
AT&T GIS Challenges
•
While the leader in Intel/Unix servers, losing ground to leading 
RISC providers, not to mention Compaq
•
Intel is depending on AT&T GIS to be premier supplier of P6-
based servers for enterprise computing
•
Organization seems to lack the fire required to gain market 
share
•
Customer base is loyal due to product reliability and service 
orientation
•
Failure to properly manage Teradata for big customers has 
resulted in unexpected backlash and opened up new 
opportunities for data warehousing/complex DSS.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | ibm-midrange-training-1995-9293d0 |
| title | RS/6000 RDBMS Sales Training (Midrange) |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | employer-record |
| subject_domain | IBM RS/6000; RDBMS; midrange platform; IBM SP2; DB2/6000; decision support; data mining; OLTP; CSC survey IT management issues; hardware competitive analysis; HP 9000; DEC; Sun; AT&T GIS; platform revenue and market share |
| methodology | client_org=IBM; format=presentation; collection_type=employer-record |
| source_file | ibm-midrange-training-1995-9293d0.txt |
| license | CC-BY-4.0 |

### Abstract

A 30-page variant IBM RS/6000 RDBMS sales training delivered in 1995 with a different agenda than the Detroit version. Kastner adds Decision Support/Mining Data, Opportunities for Open OLTP, and The RS/6000 with DB2/6000 sections. Includes detailed hardware specs for all five midrange vendors, CSC survey data on top IT management issues, and specific SP2 data: up to 512 Power2 processors, 370 systems installed, $200M 1994 revenue.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 8 |  |
| **Relevance** | 8 |  |
| **Prescience** | 7 |  |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (9)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| IBM (International Business Machines) | organization | active |  |
| Hewlett-Packard (HP) | organization | historical |  |
| Digital Equipment Corporation (DEC) | organization | historical |  |
| Sun Microsystems | organization | historical |  |
| AT&T Global Information Solutions (GIS) | organization | historical |  |
| Computer Sciences Corporation (CSC) | organization | historical |  |
| NCR Corporation | organization | historical |  |

### Technologies Referenced (8)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 | hardware |  | growth | legacy |
| IBM SP2 | hardware |  | emerging | legacy |
| IBM DB2/6000 | database |  | growth | legacy |
| IBM AIX | operating-system |  | mature | legacy |
| Unix | operating-system |  | mature | legacy |
| HP-UX | operating-system |  | mature | legacy |
| Aberdeen Three-Tier-Plus Architecture Model | methodology |  | emerging | legacy |
| Decision Support / Data Mining | methodology |  | emerging | legacy |

### Observation Summary

- Total observations: 20
- By type: market-data: 6, competitive-assessment: 5, financial-data: 4, technology-assessment: 4, event-record: 1
