# Power Academy RDBMS Sales Training (Partners Edition)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996-01-01 |
| Type | employer-record |
| Domain | RDBMS competitive analysis, IBM partnership propositions, ISV platform support, Unix platform market share, Aberdeen RDBMS ratings, RS/6000 sales training |
| License | CC-BY-4.0 |

## Abstract

A 1996 IBM Power Academy sales training presentation by Aberdeen Group's Peter Kastner covering the competitive RDBMS landscape and IBM's partnership value propositions with Informix, Oracle, Sybase, and CA/Ingres. The study presents Aberdeen's 1996 RDBMS rating categories for major vendors and ISV Unix platform support percentages. Distinct from the base Power Academy study in its emphasis on IBM's partner ecosystem framing, including Slide 38's explicit IBM & RDBMS Partners: Partnership Propositions table.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 14 |
| technologies.csv | 17 |
| observations.csv | 25 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). Power Academy RDBMS Sales Training (Partners Edition).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=IBM; format=presentation; collection_type=employer-record
