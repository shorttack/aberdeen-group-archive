# Power Academy RDBMS Sales Training (Partners Edition)

> Archived from: ibm-re-rdbms-partners-e35775.txt
> Original publication date: 1996-01-01
> Author: Peter S. Kastner

---

## Original Document Text

IBM Power Academy
AberdeenGroup 1996      1
Power Academy RDBMS 
Sales Training
Peter S. Kastner
Group Vice President
Aberdeen Group, Inc.
One Boston Place
Boston, Mass. 02108
(617) 723-7890
IBM Power Academy
AberdeenGroup 1996      2
Computer Associates
• Second largest software company behind Microsoft -- $2.74B
• 22.2% net profit margin -- best in database industry
• Primary segments are applications, system software, systems 
management
• Client-server is now 30% of business; remainder is mainframe
• Legent acquisition adds more systems management focus and 
pizazz to CA-Unicenter
• Database products include IDMS, Datacom, and Ingres
• More open, more innovative but still selling around negative 
customer perceptions
IBM Power Academy
AberdeenGroup 1996      3
CA-Ingres 1996 Themes
• “We haven't died!  But we were acquired by Computer 
Associates.  And we are behind Oracle, Sybase, and Informix.” 
• New versions of OpenIngres RDBMS and OpenRoad tool
• Excellent connectivity into IBM MVS applications
• Higher product quality,  service offerings
 
• Ingres should not be ignored, but CA with Ingres is not much 
of a market factor today outside the installed base
IBM Power Academy
AberdeenGroup 1996      4
IBM DB2
• Typically a bundled sell with other IBM products, 
especially hardware and services
• Extensive, worldwide service includes 
outsourcing and system integration
• The future for DB2:
• Add more non-IBM platforms
• Match/surpass the independents in RDBMS 
technology
• Scale from high-end SMP, clusters to MPP SP2
• Better coordination between DB2 versions
IBM Power Academy
AberdeenGroup 1996      5
IBM 1996 Themes
• Build towards “best in class” image with best 
price/performance
• Make the SP the market leader for mission-critical 
applications, particularly data warehousing
• DB2/6000 version 2 brings new, leading levels of 
functionality
• Continue roll-out of RS/6000 SMP servers “the 
second generation”
• Innovative query tools for data analysis and complex 
decision support = Data Mining
IBM Power Academy
AberdeenGroup 1996      6
Informix
• Service and support receive good marks from users 
but is limited in scope
• Informix service revenues 25%
• Oracle service revenues 52%
• The future:
• Improve parallel-scalable technology with clusters 
and MPP soon-shipping Version 8
• Competitive replication technology
• Deliver OO DB framework in 1996
• Achieve better sales for top-notch 
NewEra OO-GUI development tool
IBM Power Academy
AberdeenGroup 1996      7
Informix 1996 Themes
• OnLine 7.1 for mass-market SMP servers
• OnLine 8.0 rollout for MPP, clusters
• NewEra for enterprise-class, client-server 
development
• Store-anything framework ... post-relational
• Lower priority
• Workgroup/OnLine for NT, Personal/SE
• Replication 
• Systems Management
• Gateways via DRDA
IBM Power Academy
AberdeenGroup 1996      8
Oracle
• New focus on services
• Services now exceed product revenues
• Vertical-industry services (telecomm, oil/gas, etc.)
• Sales reps carry a consulting quota
• The future:
• Competition with IBM, Microsoft and CA for 
overall IT market share
• Internet, multimedia set-top boxes and Hollywood
• Object-oriented technology in Oracle 8
IBM Power Academy
AberdeenGroup 1996      9
Oracle 1996 Themes
• Oracle 7.3 is still the performance champion
• Enterprise Scalability, one-stop-shopping
• You need consulting ... we have it
• Applications business: turn a liability into an asset
• Workgroup 2000 
• Personal, WG, wireless, easy to install/administer
• Multimedia platform-of-choice  (e.g., US West)
• Oracle 8 -- Sorry, not until 1997
IBM Power Academy
AberdeenGroup 1996      10
Sybase
• Second-largest independent RDBMS supplier
• Past 60-80% growth rate
• Powersoft acquisition beefs up tools
• Mostly direct sales, few ISVs and apps
• The future (System 11 is not just another release):
• Add parallel-scalable technology, shared-less
• “Leading-edge” distributed database management 
on Tivoli frameowrk
• Merge Navigation Server data warehousing,
sell IQ Accelerator for warehousing
IBM Power Academy
AberdeenGroup 1996      11
Sybase 1996 Themes
• System 11 fixes our performance problems.  Period.
• Replication -- we have it; you need it
• Powersoft 5.0 improves a leading toolset
• IQ Accelerator -- yes, we do complex decision 
support
• Navigation Server -- yes, we do parallel MPP
• Regain Wall Street superstar status
IBM Power Academy
AberdeenGroup 1996      12
Microsoft
• Windows NT Server moves Microsoft into the department 
and soon the distributed enterprise
• SQL Server 6.0
• Highly aggressive pricing 
• All-Microsoft code developed by a world-class team
• Tight integration between OS and RDBMS
• Excellent performance 
• Intel/Microsoft represent a definite threat to uniprocessor 
RS/6000
IBM Power Academy
AberdeenGroup 1996      13
Microsoft
• Service and support less extensive than other 
suppliers.  Few people & programs.
• The future:
• Scale towards the glass house in 1997
• Catch up with RDBMS technology leaders
• Grow market share
• Add support channels, applications
• Challenge:  gaining the trust of IT executives for 
enterprise-class computing assignments
IBM Power Academy
AberdeenGroup 1996      14
Progress Software
• Progress plays to the tune of a different drummer
• Avoids head-to-head battles with RDBMS leaders
• Sells effectively through VAR/ISV channel, has little direct 
sales
• Technology works for the workgroup/departmental 
applications they target
• RDBMS scales modestly, lacks pizzaz features
• Toolset is quite competent for Windows apps
• Selling Tips
• Qualify on need/desire for name-brand RDBMS, app fit
• VAR/ISV can benefit from IBM’s customer experience
• Best fit is RS/6000 uniprocessor or small SMP
IBM Power Academy
AberdeenGroup 1996      15
Red Brick
• Specialist in RDBMSs for decision support
• Uses pre-calculated Joins to make queries fast, but Inserting is 
slow due to complex index building
• Small (struggling) company, but focused on Data Warehouses, 
the hot data management topic
• Selling Tips
• Qualify on customer willingness to buy from small co.
• Don’t even think about Red Brick for an OLTP app
• Red Brick and IBM are best together for Data Warehouse on 
RS/6000 SMP
IBM Power Academy
AberdeenGroup 1996      16
Software AG’s Adabas D
• SAG is long-setablished and respected on S/390
• Adabas D on RS/6000 is top-selling platform for SAG
• “Windows NT Pricing Model” = low-cost proposals
• Tied with Informix for #2 RDBMS on SAP applications
• Interesting Features
• Location transparency; a federated database
• Distributed referential integrity
• NIST 127-2 secure database certification
• Good performance and scalability at low cost
IBM Power Academy
AberdeenGroup 1996      17
Aberdeen’s 1996 RDBMS Themes
•
“Mine is better than yours”
•
Store anything
•
WG, Personal and wireless
•
Replication = distributed
•
More OLTP performance
•
TPC-D = decision support
•
Better administration
•
Tool wars, round 3
IBM Power Academy
AberdeenGroup 1996      18
Aberdeen’s 1996 RDBMS Rating 
Categories
• Scalability
• Distributed Data
• Open Data Access
• Development Tools
• Other Technology
• End-User Solutions
Source:  Aberdeen’s Distributed, Open Production Systems 
Buying Guide
IBM Power Academy
AberdeenGroup 1996      19
Scalability
Can I write an application once and have it grow or 
shrink to fit changing enterprise needs?
• Non-parallel performance
• Parallel performance
• Large databases
• High-availability features
IBM Power Academy
AberdeenGroup 1996      20
Scalability Notes
• CA Ingres -- Modest scalability; no MPP
• IBM DB2 for AIX
• Competitive but not leading on SMP
• Only compatible SMP and MPP story except AT&T
• Informix
• Good scalability to 8 processors on SMP.  Many TPC-Cs.
• Now on SP2 and other loosely-coupled HW with version 8
• Microsoft -- Modest scalability; no MPP; good on Alpha
• Oracle
• Good scalability story from desktop to SP2 & ES/9000
• No TPC-C benchmarks until July 1995 -- Hot stuff
• Sybase
• System 11 improves scalability markedly.  Good on uni.
• Navigation Server: Poor on AT&T 3600 should get better in 
1996 on RS/6000 SP
IBM Power Academy
AberdeenGroup 1996      21
Distributed Technology
Can I move computing and data out to workers and still 
be able to effectively administer it?
• Tightly-coupled data -- two-phase commit
• Loosely-coupled data -- replication
• Simultaneous-update data -- peer-peer
• Distributed administration
IBM Power Academy
AberdeenGroup 1996      22
Distributed Technology Notes
• CA Ingres:  Was best functionality; now adequate
• IBM DB2 for AIX:  Good async replication in Data 
Propagator, but no peer-peer replication
• Informix: Adequate, including peer-peer
• Microsoft:  Limited replication in SQL Server 6 for 
NT
• Oracle:  Good replication including peer-peer
• Sybase:  OK asynchronous replication; no peer-peer; 
good heterogeneous replication
IBM Power Academy
AberdeenGroup 1996      23
Open Technology
How will my applications work with other data 
sources?
• Standards
• Gateways, open clients
• Open OLTP monitors
• Access to other supplier’s RDBMSs
IBM Power Academy
AberdeenGroup 1996      24
Open Technology Notes
• CA Ingres:  good mainframe gateways to ES/9000 DBMS
• IBM DB2 for AIX:  full 2-way DRDA, ODBC; limited non-IBM 
gateways.  Best choice in IBM homogeneous world.
• Informix: DRDA client; limited gateways, but IBI EDA/SQL 
ties.  Improving open APIs
• Microsoft:  great for PC apps; OLE; ODBC inventor
• Oracle:  DRDA client;  broad gateways.  Improving APIs.
• Sybase:  Open Client & Open Server appeals to 3GL bigots.  
Best gateway breadth.  Overall, most flexible.
IBM Power Academy
AberdeenGroup 1996      25
Distributed Tool Technology
How can I efficiently develop, deploy and maintain 
distributed applications?
• Distributed application support
• Open technology
• Programmer technology
• Other development technology
IBM Power Academy
AberdeenGroup 1996      26
Development Tool Notes
• CA Ingres:  OpenROAD is most mature OO CADE
• IBM DB2 for AIX:  No comparable tools for OO CADE.  More 
limited ISV selection than Informix, Oracle and Sybase
• Informix:  New Era is maturing as OO CADE
• Microsoft:  MFC as a 4GL is excellent for MS environment
• Oracle:  clunky tools only work on Oracle.  Oracle Objects is 
interesting but low-end, incompatible with Developer/2000.  
Sedona: True OO-Forms replacement in 1997.
• Sybase:  Powersoft & Watcom are among market leaders, but PB 
needs better scalability for enterprise apps
IBM Power Academy
AberdeenGroup 1996      27
Other Technologies
What other technologies are needed to develop superior 
distributed applications?
• Business-rules processing
• BLOBS, multimedia
• Non-standard data types
• Object extensions
IBM Power Academy
AberdeenGroup 1996      28
Other Technology Notes
• CA Ingres:  partnership with Fujitsu for 1st ORDBMS in ‘96
• IBM DB2 for AIX:  fast moving DB2 into searchable audio, 
video, user-defined data types.  Hot stuff.
• Informix:  Practical BLOB support today. In 1996, OO 
framework, same searchable data types as IBM
• Microsoft: OLE, futures
• Oracle:  Most aggressive in multimedia marketing; objects in 
1997; serious about video on demand
• Sybase:  more multimedia/OO talk than action
IBM Power Academy
AberdeenGroup 1996      29
Supplier Solutions
What else can my RDBMS supplier bring to the table?
• Applications
• Third-party support
• Consulting & services
IBM Power Academy
AberdeenGroup 1996      30
Supplier Added-Value Notes
• CA Ingres: almost no services; many ISVs plus CA apps
• IBM DB2 for AIX:  world-class, worldwide services; growing 
number of ISVs with many apps
• Informix:  low services; many ISV apps; never own apps
• Microsoft: no services; most apps are for workgroups
• Oracle:  tons of services; many ISVs; Oracle applications
• Sybase:  fewer services; fewer ISVs; no applications
IBM Power Academy
AberdeenGroup 1996      31
RDBMS Supplier Weaknesses
Nobody’s Perfect
IBM Power Academy
AberdeenGroup 1996      32
CA-Ingres Weaknesses
• RDBMS architecture is behind -- no parallel/scalable
• No Ingres people remain -- but few customers have defected
• CA sales force does not understand the Unix world well
• Product quality was poor; now much better
• OPENROAD left customers with character 4GL behind -- totally 
different, incompatible environment
• Hard to sell when you’re number four and trailing
IBM Power Academy
AberdeenGroup 1996      33
IBM DB2/6000 Weaknesses
• Perception is DB2/6000 is not a world-class product
• Old limits are still remembered.
• Must shatter perceptions of limited scalability
• Limited cross-platform, cross-OS capabilities & support
• Still caution by "open" zealots
• Note:  These weaknesses are relative.  DB2/6000 is now a 
competitive product.  
IBM Power Academy
AberdeenGroup 1996      34
Informix Weaknesses
• No-consulting policy slowed large enterprise growth
• Late with desktop & workgroup database/tools
• NewEra 2.0 makes the product more useable
• Behind in replication, fair in gateways 
• Slow to build direct sales force, marketing ...  missed growth 
opportunities over past two years
• No NetWare story — less a problem going forward
IBM Power Academy
AberdeenGroup 1996      35
Oracle Weaknesses
• RDBMS engine looks dated -- is version 7.3 a TPC-C stop-gap 
or a major re-write?
• No 2nd generation client-server tools, so-so on Windows
• Service/consulting drive makes ISV partnering tough
• Deal-driven, not partnership driven
• Unfocused: Hollywood multimedia, applications, TV set-tops
• Note:  Oracle has never been stronger in the 1990s than it is now
IBM Power Academy
AberdeenGroup 1996      36
Sybase Weaknesses
• 1980s architecture runs out of steam -- they need System 11 now
• Poor scalability in SMP
• database size = departmental RDBMS
• Poor GUI tools drove Powersoft acquisition
• Navigation Server is platform-limited to the NCR 3600, an 
OLTP dog (but SP2 version is imminent)
• Few application-solution partners & solutions
• Very high sales force turnover in 1995
• Over-reaching sales tactics turn off customers
• Momentum is downwards but could recover in 1996
IBM Power Academy
AberdeenGroup 1996      37
Where is IBM RS/6000 
Best Positioned Today?
• Worldwide support and service ... the SAP R/3 story
• Enterprises that commit to DB2 across IBM platforms
• With mainframe ISVs who have ported to client-Unix-server
• Departmental systems to 4 processors for OLTP
• Expandable workgroup-plus servers above/at OS/2 level
• SMP & SP improve ability to do bigger systems
• Modest-size data warehouses on SMP; larger on SP
• Products now in place.  Field experience will come over next 
year.  MCI is a good story.
IBM Power Academy
AberdeenGroup 1996      38
IBM & RDBMS Partners:
Partnership Propositions
Partner
Partnership Proposition
Computer Associates’
Ingres
Distributed systems for downsizing
enterprises
Informix
RS/6000 & Informix:  great
performance and price/ performance
IBM RS/6000 and DB2/6000
Optimized for each other;
one-stop shopping; one RDBMS
Oracle
Market leaders in unifying the
enterprise from desktop to datacenter
Sybase
Best performance on RS/6000;
PowerBuilder; IQ & Nav Server
IBM Power Academy
AberdeenGroup 1996      39
ISV Support for Unix Platforms
ISV
HP
IBM
Sun
DEC
AT&T Other
BGS Systems
30%
60%
10%
Cincom Systems
35%
35%
20%
10%
Genesys Software
30%
50%
20%
Information Builders
25%
25%
25%
20%
5%
Landmark Systems
20%
40%
40%
CA Unicenter
40%
35%
15%
2%
4%
4%
Cyborg
30%
20%
10%
10%
30%
Dun & Bradstreet
50%
30%
15%
50%
IRI Software
38%
25%
14%
15%
4%
4%
Lawson Software
50%
30%
10%
10%
SAP America
35%
22%
5%
11%
27%
SAS Institute
28%
20%
42%
4%
6%
Software AG
50%
30%
15%
5%
SPSS
40%
25%
35%
• Application solutions pull through hardware/RDBMS
• IBM gained market share in 1994, usually at the expense of HP
Platform Choices  by Hardware Supplier
Source: Aberdeen Group and ISVs
IBM Power Academy
AberdeenGroup 1996      40
Where RS/6000 with DB2 is 
Best Suited
• Product Strengths
• DB2 for AIX 2 engine -- functionally much improved but 
nobody knows about it
• Distributed technology using Data Propagator between 
mainframe and middle-server RS/6000s
• Good performance and price-performance
• Outstanding OLTP support with CICS, Ensina, & Tuxedo
• Promising scalability with HACMP and SP2
• Homework:  rehearse your CIO and CEO “Elevator Story”
IBM Power Academy
AberdeenGroup 1996      41
IBM Power Academy
AberdeenGroup 1996      42
Backup Material
IBM Power Academy
AberdeenGroup 1996      43
Informix
• Total 1994 corporate 
revenue equals $469 
million, up 33% from 1993; 
last 12 months at $568 
million
• Market value $4.3 billion, 
up from $1.5B in 1994
• Share prices up 207% in 
last 52 weeks!
Informix Revenues & 
Profits
179
492
469
353
284
0
200
400
600
1991
1992
1993
1994
1995 (Q3)
IBM Power Academy
AberdeenGroup 1996      44
Informix
• Started with medium-scale & departmental, now scaling 
to enterprise cluster/MPP with version 8, XPS
• Focus on Unix, indirect channels
• Leader in parallel-scalable (Dynamic Server 
Architecture)
• NewEra C-S toolset has second-generation technology 
• Third-largest RDBMS supplier
• Growth rate acceleration — now the fastest growing
• Expanding high-end direct sales with success of DSA 
in Unix/OLTP and data warehousing as a hot-box
IBM Power Academy
AberdeenGroup 1996      45
Oracle 
• 1994 total corporate revenue equals 2.4 billion, up 40% 
from 1993
• Market value $18.7 billion, up 100% from 1994 
• Stock up 134% in last 52 weeks (as of July 29, 1995)
Year
Billions
1992
$1.30
1993
$1.70
1994
$2.40
Last 12 months
$2.97
1992
1993
1994
Last 12 months
0
0.5
1
1.5
2
2.5
3
Revenue in Billions
1992
1993
1994
Last 12 months
 Oracle Total Corporate Revenue
(source:  Software Magazine and Business Week)
IBM Power Academy
AberdeenGroup 1996      46
Oracle
• Focus on high end & enterprise
• Oracle used to sell “runs on any platform”
• Now sells “broadest functionality, one-stop 
shopping” 
• New multimedia, text, desktop, and workgroup 
server products
• Largest independent RDBMS supplier
• On track for $3.6+ billion in revenues in fiscal 
1996
• Direct sales, but increasing indirect selling
IBM Power Academy
AberdeenGroup 1996      47
Sybase Inc.
• Total 1994 corporate revenue $826 million,  a 71% increase 
from 1993
• YTD Sales growth rate 51.9%
• Market Value $2.4 billion (July 28 1995)
• 41%  Stock price drop -- first week April 
1992
1993
1994
Last 12 mos.
0
100
200
300
400
500
600
700
800
900
Revenue in Millions
1992
1993
1994
Last 12 mos.
Sybase Total Corporate Revenue
(source:  Software Magazine and Business Week)
IBM Power Academy
AberdeenGroup 1996      48
Sybase
• Started with medium-scale & departmental, now 
scaling to enterprise
• “Leading-edge” reputation — fading
• Good replication and connectivity
• Strong fixation on competition with Oracle
•New decision support, workgroup products 
positioned against Oracle
•Advertising, sales force head-to-head focus


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | ibm-re-rdbms-partners-e35775 |
| title | Power Academy RDBMS Sales Training (Partners Edition) |
| author | Peter S. Kastner |
| date | 1996-01-01 |
| type | employer-record |
| subject_domain | RDBMS competitive analysis, IBM partnership propositions, ISV platform support, Unix platform market share, Aberdeen RDBMS ratings, RS/6000 sales training |
| methodology | client_org=IBM; format=presentation; collection_type=employer-record |
| source_file | ibm-re-rdbms-partners-e35775.txt |
| license | CC-BY-4.0 |

### Abstract

A 1996 IBM Power Academy sales training presentation by Aberdeen Group's Peter Kastner covering the competitive RDBMS landscape and IBM's partnership value propositions with Informix, Oracle, Sybase, and CA/Ingres. The study presents Aberdeen's 1996 RDBMS rating categories for major vendors and ISV Unix platform support percentages. Distinct from the base Power Academy study in its emphasis on IBM's partner ecosystem framing, including Slide 38's explicit IBM & RDBMS Partners: Partnership Propositions table.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 8 |  |
| **Relevance** | 9 |  |
| **Prescience** | 7 |  |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (14)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| IBM (International Business Machines) | organization | active |  |
| Oracle | organization | active |  |
| Informix Software | organization | active |  |
| Sybase | organization | active |  |
| Computer Associates | organization | active |  |
| Microsoft | organization | active |  |
| Software AG | organization | active |  |
| Red Brick Systems | organization | historical |  |
| Progress Software | organization | active |  |
| Hewlett-Packard (HP) | organization | active |  |
| Sun Microsystems | organization | active |  |
| NCR Corporation | organization | active |  |

### Technologies Referenced (17)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 | hardware |  | mature | legacy |
| IBM DB2 | database |  | mature | legacy |
| Informix Online / Online OLTP | database |  | mature | legacy |
| Sybase SQL Server / Adaptive Server | database |  | mature | legacy |
| Sybase PowerBuilder | application |  | mature | legacy |
| Sybase IQ / Navigation Server | database |  | emerging | legacy |
| Oracle RDBMS | database |  | mature | legacy |
| CA/Ingres RDBMS | database |  | mature | legacy |
| Software AG Adabas D | database |  | mature | legacy |
| Red Brick RDBMS | database |  | emerging | legacy |
| Microsoft SQL Server | database |  | growth | legacy |
| Unix | platform |  | mature | legacy |
| IBM AIX | platform |  | mature | legacy |
| Sun Solaris | platform |  | mature | legacy |
| HP-UX | platform |  | mature | legacy |
| IBM SP2 | hardware |  | emerging | legacy |
| TPC-C Benchmark | framework |  | mature | legacy |

### Observation Summary

- Total observations: 25
- By type: competitive-assessment: 13, market-data: 7, technology-assessment: 3, recommendation: 1, personnel-record: 1
