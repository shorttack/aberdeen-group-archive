# RS/6000 RDBMS Sales Training (Detroit)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | employer-record |
| Domain | midrange platform competitive analysis; RDBMS competitive analysis; Aberdeen Three-Tier-Plus model; RISC/Unix market size; IBM RS/6000; HP 9000; Digital Equipment; Sun Microsystems; AT&T GIS/NCR; CA-Ingres; DB2; Informix; Oracle; Sybase; SQL Server; Red Brick; Progress Software; 1994 market share; hardware selling points; RDBMS features comparison |
| License | CC-BY-4.0 |

## Abstract

The most comprehensive IBM RS/6000 RDBMS sales training document in the collection at 87 pages, delivered in Detroit in 1995. Peter Kastner presents a full competitive analysis of five midrange hardware platforms (IBM RS/6000, HP 9000, DEC, Sun, AT&T GIS/NCR) with 1994 market share and revenue data, followed by RDBMS competitive analysis across eight vendors. Introduces Aberdeen's Three-Tier-Plus architecture model and includes a humorous Top-10 Database Selection Outcomes list attributed to Ken Leech.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 16 |
| technologies.csv | 12 |
| observations.csv | 28 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). RS/6000 RDBMS Sales Training (Detroit).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=IBM; format=presentation; collection_type=employer-record
