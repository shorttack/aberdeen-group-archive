# RS/6000 RDBMS Sales Training (Detroit)

> Archived from: ibm-rs6000-detroit-c74f4a.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

IBM Sales Training
© AberdeenGroup 1995   1
RS/6000 RDBMS Sales 
Training
Peter S. Kastner
Group Vice President
Aberdeen Group, Inc.
One Boston Place
Boston, Mass. 02108
(617) 723-7890
IBM Sales Training
© AberdeenGroup 1995   2
Agenda
•
Impact of Information Technology on Business
•
Midrange-Platform Leading Suppliers
•
Introducing the RDBMS Players
•
Partnering with an RDBMS Sales Rep
•
Positioning the RDBMS Suppliers
–
Application development toolsets
–
Relational databases
•
Maximizing IBM’s Potential
IBM Sales Training
© AberdeenGroup 1995   3
Reality Check
•
Downsizing
•
Client-server
•
Distributed computing
•
Competitive advantage applications
•
Managing this mess
IBM Sales Training
© AberdeenGroup 1995   4
Aberdeen Three-Tier-Plus Model
Mainframe
(Massively) Parallel
Division,  Department,
Replicated Branch, ...
PC, Workstation
PC LAN
PC LAN Server
Production
System &
Administration
Decision
Support
System
OLTP at POS
User Desktops and Workgroups
IBM Sales Training
© AberdeenGroup 1995   5
Maxim: Increase Line Access to 
Data
Workgroup 
Server
and/or Router
Fat 
Clients
Enterprise 
Databases
Departmental/
Other 
Workgroup
Servers
IBM Sales Training
© AberdeenGroup 1995   6
Adopting Technology in 1995
Early
Adopters
Leading
Edge
Mainstream
Trailing
RDBMS
Unix
NT
ORDBMS
Downsizing
Warehousing
Source:  Aberdeen Group, Inc.
IBM Sales Training
© AberdeenGroup 1995   7
Examining the Midrange Leaders
•
IBM
•
Hewlett-Packard
•
Digital Equipment
•
Sun Microsystems
•
AT&T Global Information Systems
IBM Sales Training
© AberdeenGroup 1995   8
1994 Worldwide Commercial 
Multiuser Risc/Unix Market $10B
Source: Aberdeen Group, February, 1995
Millions
IBM Sales Training
© AberdeenGroup 1995   9
IBM Hardware Line-up
•
RS/6000 Servers
–
Second largest supplier of multiuser RISC/UNIX systems -- 
19% market share, 1994 revenues = $1.9 billion
–
52% revenue increase ‘93/94
–
Value Proposition: IBM’s professional services 
organizations will help our customers implement 
RISC/UNIX-based open, client-server computing with the 
RS/6000
–
Sales Tactic: will frequently offer DB2/6000 RDBMS at 
considerable cost savings with RS/6000 platform
IBM Sales Training
© AberdeenGroup 1995   10
IBM Hardware Line-up
•
SP2
– Positioned as high-end of RS/6000 line and DB/2 
offload for ES/9000
– Major commercial applications: Complex 
Decision Support, LAN server consolidation, 
OLTP 
– 1994 revenues = $200 million
– Value Proposition: IBM’s entry into very large 
scale, open systems computing.  Hot new 
technology from IBM.
IBM Sales Training
© AberdeenGroup 1995   11
IBM Strengths
•
Size
–
Global support
–
Range of products
–
Talent pool to draw upon
•
Customer base and sales reps’ knowledge of customers
–
Shared history,  Customer Trust
–
Former IBM employees working now as customers
•
Services
–
Planning, Implementation, Operations, Outsourcing, Financing
–
Third-party support and competition
• ISVs by the 1,000’s
• PCM and peripheral suppliers
• Professional service organizations 
(e.g., Andersen Consulting)
IBM Sales Training
© AberdeenGroup 1995   12
IBM Challenges
•
Processor technology -- PowerPC 600 will not be leading the 
industry anytime soon
•
Re-energizing and focusing the field organization
•
Gaining the trust of leading-edge, business line manager, and 
X-generation buyers
•
Learning how to work with ISVs as allies -- not enemies
•
Recognizing that its chief competition for IS executive 
allegiance is not other hardware suppliers such as HP but 
software solution suppliers such as Oracle, SAP, and Microsoft 
IBM Sales Training
© AberdeenGroup 1995   13
Points-You-Should Know: 
IBM RS/6000
•
Customers buy RS/6000 for support and historical relationship 
reasons and have replaced it until lately because of lack of high-
end growth path.  Sell SMP scalability to SP2.
•
Platform-of-choice for VARs whose customers cannot afford 
AS/400 but want IBM platform
•
RDBMS ISVs fear that if they recommend RS/6000 IBM will 
still switch customer to low priced DB2/6000
•
Expect growth to continue in 1995 as datacenter managers 
experiment with RS/6000 Tier-2 surround strategies
•
RS/6000 with DB2 is neither the fastest nor least expensive 
option
•
Whole story includes NetView, Data Propagator, DataHub
IBM Sales Training
© AberdeenGroup 1995   14
HP Strengths
•
Value Proposition: Leading platform for Unix applications in 
terms of technology and ISV application support
•
Trusted-supplier by IS decision makers for making the 
transition to high-performance UNIX systems
•
Supports and is supported by ISVs and professional service 
organizations -- usually as a first among equals
•
One of a handful of hardware suppliers that can support 
enterprises on a global basis
•
Technology leadership perception
–
RISC processors
–
Complete Unix operating environment
–
OpenView systems management framework
IBM Sales Training
© AberdeenGroup 1995   15
HP Challenges
•
Making the transformation from selling hot boxes on price and 
price/ performance to being seen as an incumbent supplier that 
can add value in additional ways
•
After 3 years as Top Gun, HP is getting arrogant, sloppy
•
Current generation of PA-RISC, PA-7200, is not the fastest chip 
in the market
•
Running as a lean and mean organization means business 
opportunities often slip by
•
Does not have a very high-end RISC/UNIX product offering (i.e. 
clusters & MPP) and is being squeezed by Intel/NT at the low 
end
IBM Sales Training
© AberdeenGroup 1995   16
Points-You-Should Know: HP
•
In new sales deals, HP’s most common hardware competitors 
will be IBM and Sun
•
Is considered the mainframe alternative leader by many IS 
executives
•
Is consistently ranked as one of the computer industry’s most 
respected companies 
•
Should be respected but not feared.  HP is not invincible.
IBM Sales Training
© AberdeenGroup 1995   17
Digital Equipment Strengths
•
Alpha performance combined with aggressive pricing has 
created the best Unix price/performance in the industry.
•
Digital will deliver enterprise-class open platforms with 
Microsoft NT on Alpha.  Note recent TPC-C benchmarks.
•
Digital's UNIX (OSF/1) meets the specifications of more 
standards setting groups than any other Unix operating system.
IBM Sales Training
© AberdeenGroup 1995   18
Digital Challenges
•
Digital is not yet out of the restructuring woods.  As a result, 
customers and prospects remain concerned about:
–
who will sell to them
–
where support will come from
–
which support people will continue to be there
–
which promised products may be eliminated
•
With the current neutral attitude of prospects to Digital's 
limited number of Alpha UNIX systems, Digital has yet to 
establish a critical mass for long-term viability.
•
Alpha/NT looks like a rosy future, but lacks 1995 revenues to 
sustain the company
IBM Sales Training
© AberdeenGroup 1995   19
Points-You-Should Know: Digital
•
The company's diligence and resolve is regaining it respect 
from the industry and Wall Street.  Prospects becoming more 
willing to entertain a Digital solution.
•
Digital remains an excellent engineering company.  
Development of Large In-Memory Databases (LIMD) could 
revolutionize enterprise OLTP and complex DSS.
•
Digital and Oracle have been increasing their strategic 
commitments
–
Oracle acquires Rdb and its installed base
–
Oracle Parallel Server was developed for VAX 1st
–
Oracle is the LIMD database for Alpha
IBM Sales Training
© AberdeenGroup 1995   20
Sun Microsystems Strengths
•
Originator and still a leader in the open systems client-server 
computing marketplace.  Customers and Prospects still may 
have Sun religion.
•
Large number of software applications available - a pound-for-
pound leader. Also, Strong ISV relationships
•
Sun is regarded as an innovator in providing networked 
client/server solutions to the industry.
•
Sun’s positive working relationships with value-added resellers 
and third party distributors can mean lower acquisition and 
maintenance costs.
IBM Sales Training
© AberdeenGroup 1995   21
Sun Challenges
•
Sun direct field support is limited and is often contracted out to 
other firms.
•
There are very few  references for running SPARCcenter 2000s 
and SPARCserver 1000s for business critical production OLTP 
applications. 
•
Real world scalability of applications appears to be very poor 
on all of Sun’s workstations and servers.
•
Transitions between operating system releases has historically 
been problematic, compounded by minimal technical support 
from its corporate offices.  Problems with Solaris in 1994.
•
Loss of influence.  Sun does not appear to be a major player in 
the new generation of standards setting groups.  Many Sun 
products, such as its critical OpenLook GUI, may be excluded 
from future standards.
IBM Sales Training
© AberdeenGroup 1995   22
Points-You-Should Know: Sun
•
Large number of applications.
•
Champion of the “common” customer.
•
Strong alternate channel presence - will sell through any 
distributor.
•
Sun’s commercial client/server strategy is making inroads via 
networking and application development.
•
Sun maintains both the lowest entry price and best 
price/performance point for commercial servers.
IBM Sales Training
© AberdeenGroup 1995   23
AT&T Global Information Solutions 
(i.e. NCR)
•
Product strategy is to offer open systems based on midrange to 
massively parallel product lines
•
All servers based on Unix or NT and Intel Pentium 
microprocessor -- no RISC server
•
Unix System V.4 MP OS with Reliability, Availability, 
Serviceability enhancements
•
Low-end servers also run OS/2, SCO Unix, NetWare, and are a 
leading platform for Windows NT
•
Recent “customer-focused solutions” thrust in marketing
IBM Sales Training
© AberdeenGroup 1995   24
AT&T GIS Strengths
•
The Intel multiprocessor market champion (vs. RISC) and 
leader --  $1.2 Billion in 1994
•
Bullet-proof version of UNIX.  Known for stability.
•
Market strength and broad solutions strength in retail and 
banking
–
Also Telecomm, Government, Transportation markets
•
The backing of AT&T — for another year
•
Breadth of compatible server products is excellent
•
Good, often leading, TPC price/performance
IBM Sales Training
© AberdeenGroup 1995   25
AT&T GIS Challenges
•
Huge question mark as AT&T prepares to spin-off/divest GIS
–
Customer concerns
–
Employee concerns
–
Restructuring around core markets and server business
•
Failure to properly manage Teradata for big customers has 
resulted in unexpected backlash and opened up new 
opportunities for data warehousing/complex DSS.
•
While the leader in Intel/Unix servers, losing ground to leading 
RISC providers, not to mention Compaq
•
Organization seems to lack the fire required to gain market 
share
IBM Sales Training
© AberdeenGroup 1995   26
Database Market Agenda
• Market Size
• Market Characteristics
• Suppliers
• Buyer Needs
IBM Sales Training
© AberdeenGroup 1995   27
Database Market Size
•
Overall WW market around $20 billion
•
RDBMS market is largest segment at $7.0 billion
•
Tracks the worldwide hardware markets
•
Unix-server DBMS revenue now greater than 
mainframe revenues
•
Major RDBMS suppliers are growing by 30-70% per 
year in revenue!
•
Pure decision support not yet over $2 billion.  Bulk is 
OLTP and product query
IBM Sales Training
© AberdeenGroup 1995   28
Computer Associates
•
Second largest software company behind Microsoft -- $2.74B
•
22.2% net profit margin -- best in database industry
•
Primary segments are applications, system software, systems 
management
•
Client-server is now 30% of business; remainder is mainframe
•
Legent acquisition adds more systems management focus and 
pizazz to CA-Unicenter
•
Database products include IDMS, Datacom, and Ingres
•
More open, more innovative but still selling around negative 
customer perceptions
IBM Sales Training
© AberdeenGroup 1995   29
CA-Ingres 1995 Themes
•
We haven't died!  But we were acquired by Computer 
Associates.  And we are behind Oracle, Sybase, and Informix.
•
$30,000,000 marketing campaign to revitalize Ingres
•
OPENROAD -- New Windows 4GL version competes head on 
with Informix NewEra for best-in-class OO/GUI tool
•
Open Ingres: RDBMS engine update
•
An early technology leader in Replication
•
Excellent connectivity into IBM MVS applications
•
Higher product quality,  service offerings
 
•
Ingres should not be ignored, but CA with Ingres is not much 
of a market factor today outside the installed base
IBM Sales Training
© AberdeenGroup 1995   30
IBM
•
Key Product -- DB2
•
Largest overall DBMS supplier, but hard to tell revenues
•
New-found competitiveness in DB2/6000 v2
– Parallel/scalable PQS and SP2
– Strong but proprietary replication technology 
– Lags in parallel-scalable but not by many months
IBM Sales Training
© AberdeenGroup 1995   31
IBM DB2
•
Typically a bundled sell with other IBM products, 
especially hardware and services
– Extensive, worldwide service includes 
outsourcing and system integration
•
The future for DB2:
– Add more non-IBM platforms
– Match/surpass the independents in RDBMS 
technology
– Scale from high-end SMP, clusters to MPP SP2
– Better coordination between DB2 versions
IBM Sales Training
© AberdeenGroup 1995   32
IBM 1995 Themes
•
DB2/6000 version 2 brings new levels of functionality
•
Build towards “best in class” image with best 
price/performance
•
Continue roll-out of RS/6000 SMP servers “the 
second generation”
•
Move the SP2 into general availability for mission-
critical applications, particularly data warehousing
•
Innovative query tools for data analysis and complex 
decision support
IBM Sales Training
© AberdeenGroup 1995   33
Informix 
•
Total 1994 corporate revenue equals $469 million, up 33% 
from 1993; last 12 months at $568 million
•
Market value $4.3 billion, up from $1.5B in 1994
•
Share prices up 207% in last 52 weeks!
Year
Millions
1992
284
1993
353
1994
469
Last 12 months
578
0
100
200
300
400
500
600
1992
1993
1994
Last 12 months
(source:  Software Magazine and Business Week)
(share price as of 7/29/95)
IBM Sales Training
© AberdeenGroup 1995   34
Informix
•
Key Shipping Product -- Informix-OnLine DSA 7.1
•
Started with medium-scale & departmental, now scaling 
to enterprise cluster/MPP with version 8, XPS
– Focus on Unix, indirect channels
– Leader in parallel-scalable (Dynamic Server 
Architecture) but lags in replication
– New toolset version (NewEra) with second-generation 
technology 
•
Third-largest RDBMS supplier
– Growth rate acceleration — now the fastest growing
– Expanding high-end direct sales with success of DSA 
in Unix/OLTP and data warehousing as a hot-box
IBM Sales Training
© AberdeenGroup 1995   35
Informix
•
Service and support receive good marks from users 
but is limited in scope
–
Informix service revenues 25%
–
Oracle service revenues 52%
•
The future:
– Improve parallel-scalable technology with clusters 
and MPP in just-announced Version 8
– Competitive replication technology
– Deliver OO DB framework in 1996
– Achieve better sales for top-notch 
NewEra OO-GUI development tool
IBM Sales Training
© AberdeenGroup 1995   36
Informix 1995 Themes
•
OnLine 7.1 for mass-market SMP servers
•
OnLine 8.0 rollout for MPP, clusters
•
NewEra OO tool - Motif, Browser, Partitioning
•
Lower priority
–
Workgroup/OnLine for NT, Personal/SE
–
Replication 
–
Systems Management
–
Gateways via DRDA
IBM Sales Training
© AberdeenGroup 1995   37
Oracle 
•
1994 total corporate revenue equals 2.4 billion, up 40% 
from 1993
•
Market value $18.7 billion, up 100% from 1994 
•
Stock up 134% in last 52 weeks (as of July 29, 1995)
Year
Billions
1992
$1.30
1993
$1.70
1994
$2.40
Last 12 months
$2.97
1992
1993
1994
Last 12 months
0
0.5
1
1.5
2
2.5
3
Revenue in Billions
1992
1993
1994
Last 12 months
 Oracle Total Corporate Revenue
(source:  Software Magazine and Business Week)
IBM Sales Training
© AberdeenGroup 1995   38
Oracle
•
Key Product -- ORACLE 7.1
•
Focus on high end & enterprise
– Oracle used to sell “runs on any platform”
– Now sells “broadest functionality, one-stop shopping”
– Supports both parallel-scalable and replication 
technology
– New multimedia, text, desktop, and workgroup server 
products
•
Largest independent RDBMS supplier
– On track for $3.6+ billion in revenues in fiscal 1996
– Direct sales, but increasing indirect selling
IBM Sales Training
© AberdeenGroup 1995   39
Oracle
•
New focus on services
– Services now exceed product revenues
– Vertical-industry services (telecomm, oil/gas, etc.)
– Sales reps carry a consulting quota
•
The future:
– Competition with IBM, Microsoft and CA for 
overall IT market share
– Internet, multimedia set-top boxes and Hollywood
– Object-oriented technology in Oracle 8
IBM Sales Training
© AberdeenGroup 1995   40
Oracle 1995 Themes
•
Enterprise Scalability, one-stop-shopping
•
Applications business: turn a liability into an asset
•
You need consulting ... we have it
•
Workgroup 2000: 
–
Personal, WG, wireless, easy to install/administer
•
Multimedia platform-of-choice  (e.g., US West)
•
Oracle 8 -- Sorry, not until 1997...
–
but 7.2 and 7.3 offer better performance, scalability
IBM Sales Training
© AberdeenGroup 1995   41
Sybase Inc.
•
Total 1994 corporate revenue $826 million,  a 71% increase 
from 1993
•
YTD Sales growth rate 51.9%
•
Market Value $2.4 billion (July 28 1995)
•
41%  Stock price drop -- first week April 
1992
1993
1994
Last 12 mos.
0
100
200
300
400
500
600
700
800
900
Revenue in Millions
1992
1993
1994
Last 12 mos.
Sybase Total Corporate Revenue
(source:  Software Magazine and Business Week)
IBM Sales Training
© AberdeenGroup 1995   42
Sybase
•
Key shipping product -- SQL Server/System 10
•
Started with medium-scale & departmental, now 
scaling to enterprise
– “Leading-edge” reputation — fading
– Good replication but lags in parallel-scalable, 
scalability poor beyond 4 processors
– Strong fixation on competition with Oracle
• New decision support, workgroup products 
positioned against Oracle
• Advertising, sales force head-to-head focus
IBM Sales Training
© AberdeenGroup 1995   43
Sybase
•
Second-largest independent RDBMS supplier
– Past 60-80% growth rate
– Powersoft acquisition beefs up tools
– Mostly direct sales, few ISVs and apps
•
The future (System 11 is not just another release):
– Add parallel-scalable technology, shared-less
– “Leading-edge” distributed database management 
on Tivoli frameowrk
– Merge Navigation Server data warehousing,
sell IQ Accelerator for warehousing
IBM Sales Training
© AberdeenGroup 1995   44
Sybase 1995 Themes
•
We will scale with System 11 enhancements
•
System 11 will fix our performance problems
•
Fast growth, Wall Street superstar company -- down 
but not out
•
Replication -- we have it; you need it
•
Powersoft acquisition fills the tools gap
•
IQ Accelerator -- yes, we do complex decision 
support
•
Navigation Server -- yes, we do parallel MPP
IBM Sales Training
© AberdeenGroup 1995   45
Microsoft
•
Key Product -- SQL Server 6.0
•
Windows NT Server moves Microsoft into the department 
and enterprise
•
SQL Server 6.0
– Highly aggressive pricing 
– All-Microsoft code developed by a world-class team
– Tight integration between OS and RDBMS
– Excellent performance 
• DEC Alpha @ 2,800 tpm_C with only 3 CPUs 
• leading price/performance on TPC-C
•
Intel/Microsoft represent a definite threat to uniprocessor 
RS/6000
IBM Sales Training
© AberdeenGroup 1995   46
Microsoft
•
Service and support less extensive than other 
suppliers.  Few people & programs.
•
The future:
– Scale towards the glass house
– Catch up with RDBMS technology leaders
– Grow market share
– Add support channels, applications
•
Challenge:  gaining the trust of IT executives for 
enterprise-class computing assignments
IBM Sales Training
© AberdeenGroup 1995   47
Red Brick
•
Specialist in RDBMSs for decision support
•
Uses pre-calculated Joins to make queries fast, but Inserting is 
slow due to complex index building
•
Small (struggling) company, but focused on Data Warehouses, 
the hot data management topic
•
Selling Tips
–
Qualify on customer willingness to buy from small co.
–
Don’t even think about Red Brick for an OLTP app
–
Red Brick and IBM are best together for Data Warehouse on 
RS/6000 SMP
IBM Sales Training
© AberdeenGroup 1995   48
Progress Software
•
Progress plays to the tune of a different drummer
–
Avoids head-to-head battles with RDBMS leaders
–
Sells effectively through VAR/ISV channel, has little direct 
sales
–
Technology works for the workgroup/departmental 
applications they target
• RDBMS scales modestly, lacks pizzaz features
• Toolset is quite competent for Windows apps
•
Selling Tips
–
Qualify on need/desire for name-brand RDBMS, app fit
–
VAR/ISV can benefit from IBM’s customer experience
–
Best fit is RS/6000 uniprocessor or small SMP
IBM Sales Training
© AberdeenGroup 1995   49
Partnering With an RDBMS Sales Rep: 
A View From a Hardware Supplier's 
Perspective
Which comes first?  The hardware or the RDBMS?
IBM Sales Training
© AberdeenGroup 1995   50
Why Talk About Hardware Partners?
•
They introduce you to new business
•
They can keep you away from new business
•
They have a different perspective on the sale
•
They have to eat too!
IBM Sales Training
© AberdeenGroup 1995   51
Rules of Thumb
•
Everybody is as nervous as a nineth grader at a school dance
•
Software Reps do not believe neutrality spiel either
•
Most reps will only wire an RDBMS if they have to, and late in 
the game at best
•
Hardware Rep thinks RDBMS rep will switch hardware on 
him/her
•
Hardware Rep will usually partner with a VAR Rep over Direct 
RDBMS Rep, believing they have more control
•
Account control perception is highly selective
IBM Sales Training
© AberdeenGroup 1995   52
Notes From a Hardware Rep -- 
Informix Software
•
Modest enterprise selling experience, but ... 
•
Viewed by many as the hottest RDBMS on the street today
•
An easy-to-do-business-with company
•
Very little channel conflict except on biggest deals
•
Thousands of VAR resellers for solution sells
•
Little support/consulting/SI -- looks to 3rd parties or hardware 
supplier for this
IBM Sales Training
© AberdeenGroup 1995   53
Notes From a Hardware Rep -- 
Oracle
•
Hardware rep is typically pleased if Oracle wants to partner
•
Regardless of contract type, Oracle Rep always 
wants/takes/steals the deal ...
•
This can still be good for the hardware rep!
•
Large reference base
•
Very fast growing VAR base
•
A call-brand supplier to many large buying organizations
IBM Sales Training
© AberdeenGroup 1995   54
Notes From a Hardware Rep -- 
CA-Ingres
•
Sales usually result when customer specifies Ingres
•
Ingres' poor visibility in U.S. would stop most Hardware Reps 
from leading with Ingres
•
Ingres leans towards a technology-superiority sell
–
Excellent at complex applications
–
First rate development tool in OPENROAD
•
Partnering is highly deal-oriented
•
Large VAR base
•
What does the customer think about CA?
IBM Sales Training
© AberdeenGroup 1995   55
Notes From a Hardware Rep -- 
Sybase
•
Can you spell SUN MICROSYSTEMS?  Sybase has blatantly 
proposed switching customers/prospects to Sun
•
Sun used to represent 40% of Sybase sales -- now about 25%
–
Best (only?) working version
–
Long-term local relationships with Sun reps
•
Sales of Sun now neck-and-neck with RS/6000 and HP 9000
•
Sybase is biased towards tier-1, top-5 hardware platforms, 
including RS/6000, HP 9000, Sun, Digital
•
Sybase is always focused on what Oracle is doing, never on the 
hardware platform (and its sales rep)
•
Recent Sybase problems have resulted in sales force turnover, 
lack of confidence
IBM Sales Training
© AberdeenGroup 1995   56
Notes From a Hardware Rep -- 
IBM DB2/6000
•
A Sun or HP hardware rep would never ever suggest IBM’s 
DB2/6000, even though it runs on their platforms
•
Besides the account control issues
–
HP and Sun reps know nothing about DB2/6000 on their 
platforms -- unable to assist customer
–
Customers will drive DB2/6000 selection here, but ...
–
Aberdeen in unaware of any significant sales motions for 
DB2 off of IBM hardware platforms
•
An IBM rep selling DB2/6000 has a compelling story, 
particularly to a (largely) IBM installed-base account
IBM Sales Training
© AberdeenGroup 1995   57
Weighting RDBMS Technology
•
Not all features should be weighted the 
same
•
Every competitor touts their best features
•
Customers are different
•
Customers become confused
IBM Sales Training
© AberdeenGroup 1995   58
RDBMS Common Features
An architecture  
 
4GL, report writer, DBA tools
ANSI SQL 
 
 
Referential integrity
20 GB-plus databases  
Stored procedures & triggers
Two-phase commit 
 
High-performance OLTP
Multiprocessing 
 
Distributed query support
Development tools 
 
Object-oriented
Special data types 
 
Mission-critical customers
Replication
 
 
 
No competitive advantage here!
IBM Sales Training
© AberdeenGroup 1995   59
User’s Top-10 
Database Selection Outcomes
10.  Your requirements today will not be your requirements 
tomorrow.  You will be told about tomorrow’s requirements 5 
minutes before you report recommendations to the Board of 
Directors.
9.  Whichever database is chosen, the loser will take the CIO to 
lunch and convince him/her the selection was done by idiots.
8.  It is your personal fault every time there is a bug found in the 
chosen database.
7.  The database not selected is always the one that would have 
been faster for this application.
6.  The vendor who loses will never speak to you again, 
considering your decision a personal insult.
IBM Sales Training
© AberdeenGroup 1995   60
User’s Top-10 
Database Selection Outcomes
5.  The tool you like the best and recommend is not the one chosen 
by management.
4.  As soon as you buy, 12 reviews will score your choice a 2 on a 1-
5 scale.  You will spend your life defending your decision.  Your 
best line is “wait until the next release.”
3.  A new benchmark will come out showing your database is half 
the speed of all others.
2.  As soon as you place your order, your second choice will 
announce a new release with all their deficiencies solved plus 
all your number 1 choice’s deficiencies solved.
1.  You’ll discover the perfect DBMS/development tool ... but you 
won’t be able to afford it.
Attributed to Ken Leech
IBM Sales Training
© AberdeenGroup 1995   61
Aberdeen’s 1995 RDBMS Themes
Replication for
distributing data
Parallel processing 
RDBMSs bring 
scale-up or speed-up
Middleware 
(gateways, open 
clients, servers, 
transparency) 
drive enterprise 
connectivity
Higher-powered 
tools -- objects 
everywhere
Enterprise 
administration
Personal/ 
workgroup 
databases
IBM Sales Training
© AberdeenGroup 1995   62
Aberdeen’s 1995 RDBMS Rating 
Categories
•
Scalability
•
Distributed Data
•
Open Data Access
•
Development Tools
•
Other Technology
•
End-User Solutions
IBM Sales Training
© AberdeenGroup 1995   63
Scalability
Can I write an application once and have it grow or 
shrink to fit changing enterprise needs?
– Non-parallel performance
– Parallel performance
– Large databases
– High-availability features
IBM Sales Training
© AberdeenGroup 1995   64
Scalability Notes
•
CA Ingres -- Modest scalability; no MPP
•
IBM DB2 for AIX
–
Competitive but not leading on SMP
–
Only compatible SMP and MPP story except AT&T
•
Informix
–
Good scalability to 8 processors on SMP.  Many TPC-Cs.
–
Soon on SP2 and other loosely-coupled HW with version 8
•
Microsoft -- Modest scalability; no MPP; good on Alpha
•
Oracle
–
Good scalability story from desktop to SP2 & ES/9000
–
No TPC-C benchmarks until July 1995 -- Hot stuff
•
Sybase
–
Poor scalability beyond 4 processors.  Good up to 4.  Wait 
for System 11
–
Navigation Server: Poor high-end MPP on AT&T 3600 
should get better in 1996
IBM Sales Training
© AberdeenGroup 1995   65
Distributed Technology
Can I move computing and data out to workers and still 
be able to effectively administer it?
– Tightly-coupled data -- two-phase commit
– Loosely-coupled data -- replication
– Simultaneous-update data -- peer-peer
– Distributed administration
IBM Sales Training
© AberdeenGroup 1995   66
Distributed Technology Notes
•
CA Ingres:  Best functionality
•
IBM DB2 for AIX:  Good async replication in Data 
Propagator, but no peer-peer replication
•
Informix: Behind; better next year
•
Microsoft:  Limited replication in new SQL Server 6 
for NT
•
Oracle:  Good replication including peer-peer
•
Sybase:  OK asynchronous replication; no peer-peer
IBM Sales Training
© AberdeenGroup 1995   67
Open Technology
How will my applications work with other data 
sources?
– Standards
– Gateways, open clients
– Open OLTP monitors
– Access to other supplier’s RDBMSs
IBM Sales Training
© AberdeenGroup 1995   68
Open Technology Notes
•
CA Ingres:  good mainframe gateways to ES/9000 DBMS
•
IBM DB2 for AIX:  full 2-way DRDA, ODBC; limited non-IBM 
gateways.  Best choice in IBM homogeneous world.
•
Informix: DRDA client; limited gateways, but IBI EDA/SQL 
ties.  Improving APIs
•
Microsoft:  great for PC apps; OLE; ODBC inventor
•
Oracle:  DRDA client;  broad gateways.  Improving APIs.
•
Sybase:  Open Client & Open Server appeal to 3GL bigots.  Best 
gateway breadth.  Overall, most flexible.
IBM Sales Training
© AberdeenGroup 1995   69
Distributed Tool Technology
How can I efficiently develop, deploy and maintain 
distributed applications?
– Distributed application support
– Open technology
– Programmer technology
– Other development technology
IBM Sales Training
© AberdeenGroup 1995   70
Development Tool Notes
•
CA Ingres:  OpenROAD is most mature OO CADE
•
IBM DB2 for AIX:  No comparable tools for OO CADE.  More 
limited ISV selection than Informix, Oracle and Sybase
•
Informix:  New Era is maturing as OO CADE
•
Microsoft:  MFC as a 4GL is excellent for MS environment
•
Oracle:  clunky tools only work on Oracle.  Oracle Objects is 
interesting but low-end, incompatible with Developer/2000.  
True OO-Forms replacement in 1997.
•
Sybase:  Powersoft & Watcom are among market leaders, but PB 
only plays on Windows and Mac
IBM Sales Training
© AberdeenGroup 1995   71
Other Technologies
What other technologies are needed to develop superior 
distributed applications?
– Business-rules processing
– BLOBS, multimedia
– Non-standard data types
– Object extensions
IBM Sales Training
© AberdeenGroup 1995   72
Other Technology Notes
•
CA Ingres:  partnership with Fujitsu for 1st ORDBMS in ‘96
•
IBM DB2 for AIX:  fast moving DB2 into searchable audio, 
video, user-defined data types.  Hot stuff.
•
Informix:  not much today.  Practical BLOB support. In 1996, 
OO framework, same searchable data types as IBM
•
Microsoft: OLE, futures
•
Oracle:  Most aggressive in multimedia marketing; objects by 
1997; serious about video on demand
•
Sybase:  more multimedia/OO talk than action
IBM Sales Training
© AberdeenGroup 1995   73
Supplier Solutions
What else can my RDBMS supplier bring to the table?
– Applications
– Third-party support
– Consulting & services
IBM Sales Training
© AberdeenGroup 1995   74
Supplier Added-Value Notes
•
CA Ingres: almost no services; many ISVs plus CA apps
•
IBM DB2 for AIX:  world-class, worldwide services; growing 
number of ISVs with many apps
•
Informix:  low services; many ISV apps; never own apps
•
Microsoft: no services; most apps are for workgroups
•
Oracle:  tons of services; many ISVs; Oracle applications
•
Sybase:  fewer services; fewer ISVs; no applications
IBM Sales Training
© AberdeenGroup 1995   75
RDBMS Supplier Weaknesses
Nobody’s Perfect
IBM Sales Training
© AberdeenGroup 1995   76
CA-Ingres Weaknesses
•
No Ingres people remain -- but no customers have defected
•
CA sales force does not understand the Unix world
•
Product quality was poor, getting better
•
RDBMS architecture is behind -- no parallel/scalable
•
OPENROAD left customers with character 4GL behind -- totally 
different, incompatible environment
•
Hard to sell when you’re number four and trailing
IBM Sales Training
© AberdeenGroup 1995   77
IBM DB2/6000 Weaknesses
•
Essentially a new player with SMP RS/6000's and DB2/6000 v2
–
Old limits are still remembered.
–
Must shatter perceptions of limited scalability
•
Limited cross-platform, cross-OS capabilities & support
•
Still caution by "open" zealots
•
Note:  These weaknesses are relative.  DB2/6000 is now a 
competitive product.  A year ago it wasn’t.
IBM Sales Training
© AberdeenGroup 1995   78
Informix Weaknesses
•
Late with desktop & workgroup database/tools
•
NewEra 2.0 makes the product more useable
•
Behind in replication, fair in gateways 
•
Slow to build direct sales force, marketing ...  missed growth 
opportunities over past two years
•
No NetWare story — less a problem going forward
•
No-consulting policy slowed large enterprise growth
IBM Sales Training
© AberdeenGroup 1995   79
Oracle Weaknesses
•
RDBMS engine looks dated -- is version 7.3 a TPC-C stop-gap 
or a major re-write?
•
No 2nd generation client-server tools, so-so on Windows
•
Service/consulting drive makes ISV partnering tough
•
Deal-driven, not partnership driven
•
Unfocused: Hollywood multimedia, applications, TV set-tops
•
Note:  Oracle has never been stronger in the 1990s than it is now
IBM Sales Training
© AberdeenGroup 1995   80
Sybase Weaknesses
•
1980s architecture runs out of steam -- they need System 11 now
–
Poor scalability in SMP
–
database size = departmental RDBMS
•
Poor GUI tools drove Powersoft acquisition
•
Navigation Server is platform-limited to the NCR 3600, an 
OLTP dog (but SP2 version is imminent)
•
Very few application-solution partners & solutions
•
A North American phenomena, hardly seen elsewhere
•
Over-reaching sales tactics turn off customers
•
Momentum is downwards but could recover in next year
IBM Sales Training
© AberdeenGroup 1995   81
Where is IBM RS/6000 
Best Positioned Today?
•
Worldwide support and service ... the SAP R/3 story
•
Enterprises that commit to DB2 across IBM platforms
•
With mainframe ISVs who have ported to client-Unix-server
•
Departmental systems to 4-6 processors for OLTP
–
SMP is new for RS/6000, old for competition
•
Expandable workgroup-plus servers above/at OS/2 level
–
SMP & SP2 improve ability to do bigger systems
•
Modest-size data warehouses on SMP or SP2
–
Products now in place.  Field experience will come over next 
year.  MCI is a good story.
IBM Sales Training
© AberdeenGroup 1995   82
IBM & RDBMS Partners
IBM Sales Training
© AberdeenGroup 1995   83
Wrap-up
•
RDBMS on midrange server is the hot market
•
Technology is incredibably fast-moving
–
Deemphasize today’s product speeds and feeds
–
Emphasize long-term cost-of-ownership benefits
•
Users are emphasizing scalability and flexibility
– Parallel-scalable technologies for multi-size OLTP 
and definitely for data warehousing
– Replication technologies for managing the process 
of moving data around the enterprise
IBM Sales Training
© AberdeenGroup 1995   84
ISV Support for Unix Platforms
ISV
HP
IBM
Sun
DEC
AT&T Other
BGS Systems
30%
60%
10%
Cincom Systems
35%
35%
20%
10%
Genesys Software
30%
50%
20%
Information Builders
25%
25%
25%
20%
5%
Landmark Systems
20%
40%
40%
CA Unicenter
40%
35%
15%
2%
4%
4%
Cyborg
30%
20%
10%
10%
30%
Dun & Bradstreet
50%
30%
15%
50%
IRI Software
38%
25%
14%
15%
4%
4%
Lawson Software
50%
30%
10%
10%
SAP America
35%
22%
5%
11%
27%
SAS Institute
28%
20%
42%
4%
6%
Software AG
50%
30%
15%
5%
SPSS
40%
25%
35%
•
Application solutions pull through hardware/RDBMS
•
IBM gained market share in 1994, usually at the expense of HP
Platform Choices  by Hardware Supplier
Source: Aberdeen Group and ISVs
IBM Sales Training
© AberdeenGroup 1995   85
Where RS/6000 with DB2 is 
Best Suited
•
Product Strengths
–
DB2 for AIX 2 engine -- functionally much improved but 
nobody knows about it
–
Distributed technology using Data Propagator between 
mainframe and middle-server RS/6000s
–
Good performance and price-performance
–
Outstanding OLTP support with CICS, Ensina, & Tuxedo
–
Promising scalability with HACMP and SP2
•
Elevator Story
IBM Sales Training
© AberdeenGroup 1995   86
RS/6000 Elevator Story
CIO & CEO
•
 
•
 
•
 
•
 
•
 
IBM Sales Training
© AberdeenGroup 1995   87
RS/6000 with DB2 Elevator Story
CIO & CEO
•
 
•
 
•
 
•
 
•
 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | ibm-rs6000-detroit-c74f4a |
| title | RS/6000 RDBMS Sales Training (Detroit) |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | employer-record |
| subject_domain | midrange platform competitive analysis; RDBMS competitive analysis; Aberdeen Three-Tier-Plus model; RISC/Unix market size; IBM RS/6000; HP 9000; Digital Equipment; Sun Microsystems; AT&T GIS/NCR; CA-Ingres; DB2; Informix; Oracle; Sybase; SQL Server; Red Brick; Progress Software; 1994 market share; hardware selling points; RDBMS features comparison |
| methodology | client_org=IBM; format=presentation; collection_type=employer-record |
| source_file | ibm-rs6000-detroit-c74f4a.txt |
| license | CC-BY-4.0 |

### Abstract

The most comprehensive IBM RS/6000 RDBMS sales training document in the collection at 87 pages, delivered in Detroit in 1995. Peter Kastner presents a full competitive analysis of five midrange hardware platforms (IBM RS/6000, HP 9000, DEC, Sun, AT&T GIS/NCR) with 1994 market share and revenue data, followed by RDBMS competitive analysis across eight vendors. Introduces Aberdeen's Three-Tier-Plus architecture model and includes a humorous Top-10 Database Selection Outcomes list attributed to Ken Leech.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 9 |  |
| **Relevance** | 9 |  |
| **Prescience** | 8 |  |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (16)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| IBM (International Business Machines) | organization | active |  |
| Hewlett-Packard (HP) | organization | historical |  |
| Digital Equipment Corporation (DEC) | organization | historical |  |
| Sun Microsystems | organization | historical |  |
| AT&T Global Information Solutions (GIS) | organization | historical |  |
| Oracle | organization | active |  |
| Informix Software | organization | historical |  |
| Sybase | organization | historical |  |
| Microsoft | organization | active |  |
| Computer Associates | organization | historical |  |
| Progress Software | organization | historical |  |
| Red Brick Systems | organization | historical |  |
| Ken Leech | person | historical |  |
| NCR Corporation | organization | historical |  |

### Technologies Referenced (12)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 | hardware |  | growth | legacy |
| Unix | operating-system |  | mature | legacy |
| HP-UX | operating-system |  | mature | legacy |
| Sun Solaris | operating-system |  | growth | legacy |
| IBM AIX | operating-system |  | mature | legacy |
| IBM DB2 | database |  | growth | legacy |
| Oracle RDBMS | database |  | mainstream | legacy |
| Informix OnLine | database |  | growth | legacy |
| Sybase SQL Server | database |  | growth | legacy |
| Microsoft SQL Server | database |  | emerging | legacy |
| Aberdeen Three-Tier-Plus Architecture Model | methodology |  | emerging | legacy |
| TPC-C Benchmark | standard |  | mature | legacy |

### Observation Summary

- Total observations: 28
- By type: competitive-assessment: 10, market-data: 8, financial-data: 7, technology-assessment: 2, event-record: 1
