# Informix Software Overview

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | employer-record |
| Domain | Informix company overview, RDBMS competitive positioning, financial performance, product line (SE/OnLine/DSA/XPS), development tools (NewEra/4GL), end-user tools, services, Aberdeen findings, database market share |
| License | CC-BY-4.0 |

## Abstract

A 1995 Aberdeen Group presentation for Informix covering the company's competitive positioning as the fastest-growing independent RDBMS vendor and a respected rival to Oracle and Sybase. The study details Informix's $470M 1994 revenue (with $150M from tools), 500,000+ licenses sold, and product portfolio spanning SE, OnLine, Dynamic Server Architecture, and the just-delivering Extended Parallel Server XPS. Aberdeen's key finding characterizes Informix as 'a secret success' with strong database architecture enabling parallelism and advanced tools led by NewEra.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 10 |
| technologies.csv | 15 |
| observations.csv | 28 |
| codes.csv | 26 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Informix Software Overview.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=Informix; format=presentation; collection_type=employer-record
