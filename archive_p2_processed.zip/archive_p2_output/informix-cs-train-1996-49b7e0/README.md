# Choosing The Right Markets and the Right Partners for Informix

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | employer-record |
| Domain | channel strategy framework, industry trends, SMP/MPP/clustering architecture, CSS competitive landscape, enterprise IS decision making, VAR/ISV/OEM/SI channel framework, Informix vertical markets (telecom/retail/banking/manufacturing/government), NT clustering prediction, SAP competitive landscape, Deloitte & Touche C-S implementation data |
| License | CC-BY-4.0 |

## Abstract

A confidential Informix training presentation by Aberdeen Group's Peter Kastner providing a comprehensive channel strategy framework across three sections: industry technology trends (Aberdeen Three-Tier-Plus model; SMP/clustering/MPP architectures; 1996 technology priorities), the changing customer perspective (CSS competitive landscape including SAP/PeopleSoft/Baan/Oracle; enterprise IS decision making by company size), and the right channels for the right markets (VAR/ISV/OEM/SI/Big 6 framework mapped to Informix's five strategic verticals). Contains prescient predictions about NT clustering emerging in 1996 and thriving in 1997, and critical assessment of AT&T GIS as a 'problem partner in 1996'.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 16 |
| technologies.csv | 10 |
| observations.csv | 28 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Choosing The Right Markets and the Right Partners for Informix.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=Informix; format=presentation; collection_type=employer-record
