# Choosing The Right Markets and the Right Partners for Informix

> Archived from: informix-cs-train-1996-49b7e0.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

Informix Confidential
Choosing The Right Markets ...
and the Right Partners for 
Informix
Peter S. Kastner
Vice President
Aberdeen Group, Inc.
One Boston Place
Boston, MA  02108
Informix Confidential
2
Agenda
I Industry Trends Drive the Markets
I The Changing Customer Perspective
I The Right Channels for the Right Markets
Informix Confidential
3
Industry Trends Drive the 
Markets
I Industry Trends Drive the Markets
– Architecture, systems, and platforms
– Database and tools
– Client-server solutions
I The Changing Customer Perspective
I The Right Channels for the Right Markets
Informix Confidential
4
The IT Industry Is About Change
I The IT industry is now in its most rapid growth stage ever
I User requirements and decision making criteria are 
continuously changing
I IT product offerings are new, fresh and advancing
I The skills required to be successful in the IT industry 
require continuous updating
I And the rate of change (and accompanying IS decision 
maker confusion) is accelerating!
Informix Confidential
5
Major Industry Trends
I Open Systems
I Increased LOB influence on Information Systems
I Quantum Leaps in Semiconductors
I Rapid Application Development (RAD)
I Distributed Computing
I Client-Server Feeding Frenzy
Informix Confidential
6
Today’s Distributed Computing 
Reality
Mainframe
(Massively) Parallel
Division,  Department,
Replicated Branch, ...
PC, Workstation
PC LAN
PC LAN Server
Production
System &
Administration
Decision
Support
System
OLTP at POS
User Desktops and Workgroups
6
Copyright 1995 Aberdeen Group Inc.
Informix Confidential
7
Client-Server Architecture
Best Practices
I As many as 4 tiers of computing
– Desktop, branch/region, enterprise
I Separate tiers for OLTP and DSS
– Avoid the “query from hell” impact on OLTP
– Need for central management
– Need for data migration and transformation
7
Copyright 1995 Aberdeen Group Inc.
Informix Confidential
8
Symmetric Multiprocessing
I Sweet spot in the market
– scalability
– higher profit margins for hardware & software
– highly competitive
I SMP is alive and well
– Was dead at 16 processors  
– New hardware and software give SMP new life
– Will still be maturing in 5 years
Informix Confidential
9
Clustering
I Very mature on Unix
I Typically used for high availability, particularly in 
manufacturing and telecommunications
I Windows NT clustering will emerge in 1996, 
thrive in 1997 (Compaq + Tandem; DEC)
I Best applications with Online XPS
– High-availability transaction processing
– Warehouse scalability after topping out SMP 
Informix Confidential
10
Parallel-Scalable (i.e., MPP)
I The heights of scalability
– Needed for large warehouses
I Driven by IBM with PowerParallel SP (e.g. SP2)
– AT&T GIS is focused on making profits while retaining 
customer base — a problem partner in ‘96
– High end OLTP
– Server consolidation
I An attack market for Informix with XPS
Informix Confidential
11
Systems & Platforms
I 1996 is the year of the application server
– Unix Tier-1 suppliers continue 20%+ growth rates
– NT Server steadily picks up steam at 
workgroup/department level
I Minor changes in desktop hardware & software
I MPP market is interesting but < 2% share
I 64 bit becomes hardware & software marketing 
weapon
I In short: better, cheaper, faster, smaller (again)
Informix Confidential
12
Database Technology Issues —
Prioritized List for 1996
I Parallel/scalable
I Workgroup and personal
I Replication
I Remote and disconnected users
I Point&click administration
I Store any data
I Performance on NT Server
Informix Confidential
13
Development Tools Technology 
Issues for 1996
I Note:  RDBMS tool growth is slowing
I Which tool is right?
I Windows 32-bit apps for Win95 and NT
I Object development without the learning curve
I Enterprise-scale, large project development
I Partitioning: a precursor to distributed objects
I Elegance: sophistication in hiding complexity
Informix Confidential
C-S Solutions — Packaged 
Applications
14
Informix Confidential
15
CSS Battle Lines
I Solution Set -- Fully-Integrated vs.. Best-of-Breed
I Architecture -- Application-centric vs.. 
Database-centric
I Toolsets -- Home-grown vs.. "Industry standard"
I Channel Mix -- Direct vs.. Alternate
I Midrange Market -- Unix vs. NT
Informix Confidential
16
Database-centric or Application-
centric
CSS Supplier Architecture Orientations
Category
Criteria
Database-centric
(mainly VARs)
• An application designed
for one database
• Performance
"optimized" for one
database
• Gateway access to
other databases
Application-centric
(mainly ISVs)
• An application designed
for a heterogeneous
database environment
• Performance
"optimized" for select
number of databases
• Native ANSI SQL
drivers and Gateways
Source: AberdeenGro up, 1995
Informix Confidential
17
Toolsets are Making a Difference 
I Home-Grown
– Many suppliers have built their own 
I Perceived lack of available functionality
I Majority are CASE-based  (i.e., ABAP from SAP)
I Industry Standard
– A growing percentage of newer suppliers
I Majority are C, Visual C++ and Visual Basic combos
I Few Gupta, Uniface, PowerBuilder
I Fewer use RDBMS supplied toolsets (guilt by association)
Informix Confidential
18
Channel Mix
Customers want direct -- Suppliers can't afford it
Can anyone make client-server turnkey?
I Direct
– Expensive
– High SGA-Impact
– Major System Suppliers are pulling back
I Indirect
– Outward burden-shifting
– Low & Mid Customers buy-through channels
– Resellers with highly-variable (outdated?) expertise
Informix Confidential
19
Who Gets the Midrange Market?
I Unix
– Dominant OS for RISC and open systems suppliers
– Major variants include HP-UX, IBM’s AIX, SVR4, Solaris
– Enormous historical burden from the academic 
community.  Only in 1990s has Unix emerged as 
practical and reliable for commercial applications
– From buyer’s standpoint, every Unix is different, often 
subtly
Informix Confidential
20
Who Gets the Midrange Market?
I Windows NT Server
– Fast-growing OS-of-choice for PC LANs, workgroup 
servers
– Has the look and feel of Windows; Runs almost all 
Windows programs
– Hardened, security, multiprocessors
– Versions for Intel (90%), Alpha, MIPS, PowerPC servers
– In 1995, Windows NT scales to handle 
department/divisional loads
– NT price/performance is giving Unix suppliers a real 
scare
Informix Confidential
21
Applications:  
A New Generation for a New 
Generation
I CSS is the catalyst for business reengineering, 
streamlining, and organizational change
I CSS has required a generational change in both 
enterprise management and technology to 
enable
I Implementation efforts are a process, not a 
project, that will never end and must become 
part of an enterprise's culture
Informix Confidential
22
Who are the Client-Server 
Solutions Market Suppliers?
I Independent Software Vendors (ISVs)
I Value-added Resellers (VARs)
I System Integrators (SIs)
I "Big 6" Consulting Firms
Informix Confidential
23
CSS Alternatives
I Turnkey 
– Enterprise CSS Going down market
I Developed In-house
– Luxury few can afford
I Fully Integrated
– Primarily from Manufacturing Suppliers
I Best of Breed
– Financial Suppliers
– HR Suppliers
– Process Manufacturers
Informix Confidential
24
CSS Market Characteristics
I Company Size & Revenue Dictate Requirements
–
$25 Million and less
I $500 to $5,000 per module
I PC LAN-based
I Primarily VARs
–
$250 Million and less
I $10,000 to $75,000 per module
I Fortune 1000 -- time-share surrounded by client-server
I Mostly direct
–
$251 Million and up
I $50,000 to $150,000 per module
I Fortune 500 -- legacy leveraged by  client-server
I Direct
Informix Confidential
25
CSS Implementation Timeframes
I Fortune 500
– Human Resources -- 3 to 6 months
– Finance & Accounting -- 6 to 18 months 
– Manufacturing & Distribution -- 12 to 36 months
–
I Fortune 1000
– Human Resources -- 1 to 3 months
– Finance & Accounting -- 3 to 12 months 
– Manufacturing & Distribution -- 9 to 24 months
I Small Business
– Human Resources -- 0 months
– Finance & Accounting -- 1 to 2 months 
– Manufacturing & Distribution -- 2 to 6 months
Informix Confidential
26
CSS 1996 Competitive Landscape
Enterprise
Midrange
SAP AG 
Dun & Bradstreet
Oracle 
Hyperion Software (IMRS)
PeopleSoft 
Lawson Software
DeskTop 
Dark Horses
Computer Assoc.
Baan International
Great Plains 
Computer Associates
Platinum Software 
FlexiInternational
SQL Financials
TAGs (Those AS/400 Guys)
Informix Confidential
27
Agenda
I Industry Trends Drive the Markets
I The Changing Customer Perspective
I The Right Channels for the Right Markets
Informix Confidential
28
Enterprise IS Decision Making
I Enterprises' typically make IT choices based on 
existing IS competencies and line management 
requirements
I There is no one IS decision maker -- and 
consensus acquisition decisions include line 
managers with minimal professional IT knowledge
I IT suppliers' ability to communicate effectively 
with both end-users and IS professionals is key for 
future success
Informix Confidential
29
Driving Forces
I Competitive Advantage
I Downsizing or Reengineering (increase internal 
efficiency)
I Strategic Technology Commitment
I Overburdened legacy applications & expensive system 
upgrade
I Original Supplier has changed
Informix Confidential
30
Who Are the Players?
I CEO -- Board of Directors
– Catalyst for Change
I CFO -- Chief Financial Officer
– Cost Containment, Optimization
I CIO -- Chief Information Officer
– Budgets, Standards, IT Leadership
I Division Vice President
– Revenue Production, P&L
I Plant GM or Technical Project Manager
– Product Development, Manufacturing
I Business Unit Managers -- End Users
– Distribution, Sales, Service
Informix Confidential
31
Top Mgt Issues For IT Executives
'95
Rank
'94
Rank
Issue
1
2
Aligning IT & corporate goals
2
4
Instituting cross-functional Information Syst
3
3
Organizing & utilizing data
4
1
Implementing business reengineering
5
9
Improving the IT human resource
6
NR
Enabling change and nimbleness
7
16
Connecting to customers or suppliers
8
5
Creating an information architecture
9
7
Updating obsolete systems
10
6
Improving the system development process
Source:  Computer Sciences Corp.
Informix Confidential
32
Challenges, Directives for IT Staff
I Evaluate, Deploy, Integrate Myriad New Technologies
I Accelerate Application Development
I Deploy New Network Infrastructure
I Cut Costs
– Reduce $$$ Dependence on Mainframe
– Contain Spiraling Costs for Systems Administration, 
Support
I Improve Distributed Management Capabilities
I Improve Responsiveness to Customer
Informix Confidential
33
SIZE of COMPANY
COST
DeskTop
Enterprise
Midrange
$10k
$150k
$250k
$500m
$250m
$50m
Rightsizing
Custom Implementations
Direct Sales & Support
Upsizing
Pre-Configured
Direct & Channel
Sales & Support
PC-LAN
Shrink Wrapped
Channel Sales & Support
Buying Habits
Targets, Price and Channel Preference
Informix Confidential
34
Source: Deloitte & Touche
New System Implementations in the Last Two Years
57
42
37
45
181
33
21
39
26
119
39
26
33
112
210
0
50
100
150
200
250
Accounting
Procurement
Distribution
Reporting
Total
Mainframe
Midrange
Client-Server
CSS Implementation 
Informix Confidential
35
Source: Deloitte & Touche
New System Implementations Planned for the Next Two Years
39
30
28
27
124
44
22
31
37
134
129
84
79
157
449
0
50
100
150
200
250
300
350
400
450
Accounting
Procurement
Distribution
Reporting
Total
Mainframe
Midrange
Client-Server
CSS Implementation 
Informix Confidential
36
Summary
I Multiple Decision Makers within each organization
I Different motivations driving each Profile
I Increasing emphasis on Business Relevance of New 
Systems
I IT Open Systems environment more complex than 
traditional proprietary 
I Less experience and personnel infrastructure available 
than ever before
Informix Confidential
37
Agenda
I Industry Trends Drive the Markets
I The Changing Customer Perspective
I The Right Channels for the Right Markets
Informix Confidential
38
The Real Market for Informix
I Relational Databases
– Enterprise, departmental, personal/workgroup
– OLTP, decision support
I Client-server application development tools
I Technical service and support
I New! Data retrieval end-user tools
– Stanford Technologies
Informix Confidential
39
The Informix Strategic Markets
I Workgroup solutions
I Client-server applications
I Customer-interaction applications
I End-user applications
I Custom/enterprise applications
I Imaging/workflow/document management
I Internet
I Data warehousing
Informix Confidential
40
Informix Vertical Markets
I Telecommunications
I Retail
I Retail banking
I Manufacturing
I State & local government
Informix Confidential
41
Introduction to Channels
I Direct sales
I Distributors
I Value-added resellers
I Solution providers (ISV’s)
I Original Equipment Manufacturers
I Computer hardware manufacturers
I System Integrators
I Big 6 Accountants & C-S service providers 
Informix Confidential
42
Off the Planning Table
I Direct sales
I Distributors
Informix Confidential
43
VAR’s
I Project consultancies
I SOHO business apps
I Specialized vertical 
solutions (e.g., hotel 
management)
I Single-source solution 
providers of turnkey 
hardware, application, 
system software, and 
installation/training
I Self-sustaining
I Trend
– Business remain good
– Continuous renewal 
process for CSS
I Issues
– VARs are smaller size firms
– Spotty geographical 
coverage
– Under capitalized — slow 
to change suppliers
– But can be very loyal
Informix Confidential
44
Solution Providers (ISVs)
I Require a hardware 
partner
I They sell 
– core business apps
– marketing/sales apps
– vertical-specific apps
I Can sell to small as well as 
large enterprises
I Large leverage factor (i.e., 
SAP to Informix)
I Trends
– What are the right 
development tools?
– Huge roll-over market as 
character-mode apps 
switch to C-S
I Issues
– Lots of partners required to 
present the “solution”
– How important is the 
RDBMS partner?
– “What’s in it for me?”
Informix Confidential
45
Original Equipment Manufacturers
I Build hardware/software 
product containing 
Informix technology (e.g., 
retail bank branch 
solution)
– specialized “embedded” 
solutions
– Technology service 
providers
I Trends
– Will buy, not make RDBMS 
technology
– Driven by C-S GUI
– Steady state overall
I Issues
– Slow sell .. hand-holding .. 
reduced margins
– Lack of Informix visibility in 
finished product
– Very long-term support 
obligations
Informix Confidential
46
Computer Hardware Manufacturers
I Source VAR, solution, 
OEM hardware provider
I Bundled packaging (i.e., 
HP Open Warehouse)
I Custom implementations 
– SI arms
I Vertical expertise
– DG in medical
– Sun on trader’s desks
I Trends
– Bundling and SI are up
– Neutrality directly 
proportional to revenues
I Issues
– Are bundles just a 
marketing pipe dream?
– Home office rhetoric vs.. 
field organization
– IBM, HP, Sun are top tier.  
Who else counts and why?
Informix Confidential
47
System Integrators
I Ability to provide
–
integration services 
– one-time labor
– training
– Custom implementations
I Turnkey solutions
I Vertical expertise
I Large-enterprise 
experience and capacity
I Trends
– SIs have embraced C-S apps 
and re-engineering as 
major new business just as 
mainframe business tanks
I Issues
– Project-driven vs.. long-
term ... partner profits
– Selling the up-front 
supplier selection vs.. just 
the implementation
– Conflicts of interest
– HQ vs.. local offices
Informix Confidential
48
Big Six Accountants et al
I Vertical expertise
I BPR
I Custom implementations
I Solution-provider 
implementations (e.g., 
SAP)
I Can be a systems 
integrator or manage SI 
process
I Trends
– See SI comments
– Business is people-
constrained
I Issues
– Project-driven vs.. long-
term ... partner profits
– Selling the up-front 
supplier selection vs.. just 
the implementation
– Conflicts of interest
– HQ vs.. local offices
Informix Confidential
49
Channel Critical Success Factors:  
What Partners Want
I Leads, leads, leads
I Programs, programs, programs
I Tiered, performance-based Cooperative 
Marketing funding
I Single-source HQ senior account management
I Direct access to technical support
I Local dedicated sales and liaison functions
I Ease of doing business
Informix Confidential
50
Irrelevant Critical Success Factors
I Price
I Switch incentives
I Best technology du jour
I Moral superiority
Informix Confidential
51
Roll Up Your Sleeves!
I 1.  Assign best channels to Informix strategic 
markets
I 2.  Assign Informix strategic markets to chosen 
vertical markets
I 3.  Prioritize channels by vertical market
I 4.  Calculate/weight investment by channel by 
vertical market
I 5.  Prioritize vertical markets
Informix Confidential
52
Where We Are Going ...
Total to $100
Horizontal &
Vertical
Telecom
$
Retail
$
Banking
$
Mfg.
$
G ov’t
$
Direct/
Distributor
V AR
ISV
O EM
Hardware
SI
Big Six
Total
100
100
100
100
100
$100
Informix Confidential
53
1.  Assigning Channels to Strategic Markets
Workgroup
C-S Apps
CIS Apps
EU  Apps
Custom
Apps
Direct/
Distributor
V AR
ISV
O EM
Hardware
SI
Big Six
Total
100
100
100
100
100
Informix Confidential
54
1.  Assigning Channels to Strategic Markets
Imaging/
Docs
Internet
Data
Warehousing
Direct/
Distributor
V AR
ISV
O EM
Hardware
SI
Big Six
Total
100
100
100
100
100
Informix Confidential
55
Telecomm Market
I Dynamic: mature but rapidly changing
I Time to market beats price in importance
I Informix has paid its dues, is respected
I Revenue potential is huge
– Internet, remote access, value-added services, 
competition over local access, etc.
I Many available channel partners
– They see the potential too
I Aberdeen Rating:  highly attractive
Informix Confidential
56
Telecomm
Workgroup
C-S Solutions
Customer Apps
End-U ser Apps
Custom Apps
Imaging/Docs
Internet
Data Warehousing
Priority      Strategic Market                           Comments/Maintain/Invest/Attack
Informix Confidential
57
Retail Market
I Dynamic:  Walmart dominoes keep falling
I Price is always important
– low margins, structural changes, many sites
I Informix is well known; warehousing is new
I Revenue potential is large but poor economy may 
hinder plans and growth
I Many channel partners and many “strategic 
market” means of penetration
I Aberdeen Rating:  Good with 50% chance rain
Informix Confidential
58
Retail
Workgroup
C-S Solutions
Customer Apps
End-U ser Apps
Custom Apps
Imaging/Docs
Internet
Data Warehousing
Priority      Strategic Market                           Comments/Maintain/Invest/Attack
Informix Confidential
59
Banking & Finance Market
I Dynamic:  restructuring and downsizing
I Many sites, many opportunities
I Informix is not broadly known
I Revenue potential is large as people & 
bricks/mortar are replaced by smart systems
I Numerous channel opportunities, but many 
partnerships already in place
I Aberdeen Rating: Good over time; fair in 1996 
Informix Confidential
60
Retail Banking
Workgroup
C-S Solutions
Customer Apps
End-U ser Apps
Custom Apps
Imaging/Docs
Internet
Data Warehousing
Priority      Strategic Market                           Comments/Maintain/Invest/Attack
Informix Confidential
61
Manufacturing Market
I Dynamic:  covers an awfully broad segment
I Solutions-oriented, so partners are critical
I Big market swing towards C-S hides downsizing
I Revenue potential is huge but diffuse
I Channel partners, particularly VARs and ISVs, are 
critical
I Aberdeen Rating:  Good short & long term
Informix Confidential
62
Manufacturing
Workgroup
C-S Solutions
Customer Apps
End-U ser Apps
Custom Apps
Imaging/Docs
Internet
Data Warehousing
Priority      Strategic Market                           Comments/Maintain/Invest/Attack
Informix Confidential
63
State & Local Government
I Dynamic: “Doing more with less” phenomenon
I Replacing old systems with client-server
I A natural for data warehousing, imaging, work-
flow
I Mostly buys solutions.  Direct selling hindered by 
bidding regulations
I Can be attacked with multiple channels
I Aberdeen Rating:  Fair due to long selling cycle, 
competition by/among partners
Informix Confidential
64
State & Local Government
Workgroup
C-S Solutions
Customer Apps
End-U ser Apps
Custom Apps
Imaging/Docs
Internet
Data Warehousing
Priority      Strategic Market                           Comments/Maintain/Invest/Attack
Informix Confidential
65
Strategic Market Worksheet: ________________________
[Spread Step #1 Across Vertical Markets]
Total to $100
Horizontal &
Vertical
Telecom
$
Retail
$
Banking
$
Mfg.
$
G ov’t
$
Direct/
Distributor
V AR
ISV
O EM
Hardware
SI
Big Six
Total
100
100
100
100
100
$100
Informix Confidential
66
Summary of Strategic Market Investments
Retail
Banking
Manufacturing
Government
Telecom
[Sum the Strategic Market Investments
and plot as a percentage]
Informix Confidential
67
Summary of Channel Investments
by Vertical Market
Total to $100
Horizontal &
Vertical
Telecom
$
Retail
$
Banking
$
Mfg.
$
G ov’t
$
Direct/
Distributor
V AR
ISV
O EM
Hardware
SI
Big Six
Total
100
100
100
100
100
$100
[Sum individual strategic market investments]


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | informix-cs-train-1996-49b7e0 |
| title | Choosing The Right Markets and the Right Partners for Informix |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | employer-record |
| subject_domain | channel strategy framework, industry trends, SMP/MPP/clustering architecture, CSS competitive landscape, enterprise IS decision making, VAR/ISV/OEM/SI channel framework, Informix vertical markets (telecom/retail/banking/manufacturing/government), NT clustering prediction, SAP competitive landscape, Deloitte & Touche C-S implementation data |
| methodology | client_org=Informix; format=presentation; collection_type=employer-record |
| source_file | informix-cs-train-1996-49b7e0.txt |
| license | CC-BY-4.0 |

### Abstract

A confidential Informix training presentation by Aberdeen Group's Peter Kastner providing a comprehensive channel strategy framework across three sections: industry technology trends (Aberdeen Three-Tier-Plus model; SMP/clustering/MPP architectures; 1996 technology priorities), the changing customer perspective (CSS competitive landscape including SAP/PeopleSoft/Baan/Oracle; enterprise IS decision making by company size), and the right channels for the right markets (VAR/ISV/OEM/SI/Big 6 framework mapped to Informix's five strategic verticals). Contains prescient predictions about NT clustering emerging in 1996 and thriving in 1997, and critical assessment of AT&T GIS as a 'problem partner in 1996'.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 9 |  |
| **Relevance** | 9 |  |
| **Prescience** | 8 |  |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (16)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| Informix Software | organization | active |  |
| Oracle | organization | active |  |
| SAP | organization | active |  |
| PeopleSoft | organization | active |  |
| BaaN | organization | active |  |
| Computer Associates | organization | active |  |
| Lawson Software | organization | active |  |
| Great Plains Software | organization | active |  |
| AT&T Global Information Solutions (GIS) | organization | historical |  |
| Compaq Computer | organization | active |  |
| Tandem Computers | organization | historical |  |
| Digital Equipment Corporation (DEC) | organization | historical |  |
| Andersen Consulting | organization | active |  |
| Deloitte & Touche | organization | active |  |

### Technologies Referenced (10)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Informix OnLine DSA (Dynamic Server Architecture) | database |  | mature | legacy |
| Symmetric Multiprocessing (SMP) | hardware |  | mature | legacy |
| Cluster Computing | hardware |  | emerging | legacy |
| Massively Parallel Processing (MPP) | framework |  | emerging | legacy |
| Microsoft Windows NT | platform |  | growth | legacy |
| Client-Server Architecture | framework |  | mature | legacy |
| ERP (Enterprise Resource Planning) Systems | application |  | growth | legacy |
| SAP R/3 | application |  | mature | legacy |
| Informix Dynamic Scalable Architecture (DSA) | framework |  | emerging | legacy |
| Aberdeen Three-Tier-Plus Model | framework |  | emerging | legacy |

### Observation Summary

- Total observations: 28
- By type: market-data: 12, competitive-assessment: 9, prediction: 4, technology-assessment: 2, recommendation: 1
