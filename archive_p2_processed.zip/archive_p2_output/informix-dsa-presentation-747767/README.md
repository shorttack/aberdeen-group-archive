# Choosing The Right Markets and the Right Partners for Informix (DSA Edition)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996-01-01 |
| Type | employer-record |
| Domain | channel strategy framework, Dynamic Server Architecture branding, industry trends, SMP/MPP/clustering architecture, CSS competitive landscape, enterprise IS decision making, VAR/ISV/OEM/SI/Big 6 channel framework, Informix vertical markets (telecom/retail/banking/manufacturing/government), NT clustering prediction, AT&T GIS assessment, Deloitte C-S implementation data |
| License | CC-BY-4.0 |

## Abstract

A DSA-branded variant/companion edition of the Informix channel strategy presentation (Study 7), rendered with different visual formatting (square bullet symbols instead of I-bullets) and explicitly tied to Informix's Dynamic Server Architecture brand. Contains the same three-section structure covering industry trends, changing customer perspective, and channel framework for Informix's five strategic verticals, with the same key data points including the NT clustering prediction, AT&T GIS problem partner warning, and Deloitte implementation statistics. The DSA branding suggests this version was prepared for audiences specifically focused on Informix's parallel database technology.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 16 |
| technologies.csv | 9 |
| observations.csv | 25 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). Choosing The Right Markets and the Right Partners for Informix (DSA Edition).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

client_org=Informix; format=presentation; collection_type=employer-record
