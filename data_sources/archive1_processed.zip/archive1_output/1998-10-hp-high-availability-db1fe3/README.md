# Aberdeen Group Flash Report: High Availability Marketing Messages

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998-10-28 |
| Type | white-paper |
| Domain | High availability computing — HP marketing strategy |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group Flash Report summarizing findings from an October 28 1998 meeting with HP's high availability marketing team. Confirms that 40%+ of commercial server buyers rank availability as a key purchasing criterion. Evaluates HP's proposed end-to-end HA strategy and identifies three differentiators: end-to-end HA vs. box-level, contractual uptime guarantees, and High Availability Observatory remote monitoring. Benchmarks HP against IBM, Sun, and Compaq. Recommends acquisition of Marathon Technologies for NT fault-tolerance and a transition away from five-nines messaging to broader end-to-end HA positioning.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 12 |
| technologies.csv | 9 |
| observations.csv | 24 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). Aberdeen Group Flash Report: High Availability Marketing Messages.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

document-review
