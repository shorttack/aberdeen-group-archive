# Aberdeen Group Flash Report: High Availability Marketing Messages

> Archived from: 1998-10-hp-high-availability-db1fe3.txt
> Original publication date: 1998-10-28
> Author: Peter S. Kastner

---

## Original Document Text

Aberdeen Group Flash Report: 
High Availability Marketing Messages 
This report is the result of a meeting held on October 28, 1998 with Jim Murphy, Grant 
Dodson, Jody Stiely, Gary Price, Bonnie Rogers, Wesley Sawyer, John Atwell, and 
Jennifer Carr of Hewlett-Packard.  Attending for Aberdeen Group, Inc. were Peter 
Kastner, Thomas Willmott, and John Logan. 
Summary 
Aberdeen Group field research confirms that a large minority (40%-plus) of commercial 
server buyers consider availability as an important buying attribute.  This research 
includes both the NT and Unix markets.  HP’s proposal to use high availability (HA) as a 
major computing message is in alignment with buyer’s concerns. 
High availability, per se, is a ho-hum message.  All market-leaders pay at least some 
attention in their messages to high availability.  Therefore, HP must make its HA 
message and market position stand out as clearly differentiated and superior to the 
competition.   
Three competitive differentiators that could be used to achieve such a differentiated 
position include: 
• A focus on end-to-end HA as opposed to box-level HA that everybody else talks 
about 
• Uptime commitments as contractual guarantees, perhaps with insurance 
• High Availability Observatory (HAO) remote monitoring. 
Market Considerations 
1. HA covers more than high-end Unix servers.  HP must ensure that its HA messages 
include both Unix and NT, directly sold and indirectly sold channels, and, where 
practical, mainstream ISV applications.  In addition, the “end-to-end” concept 
dictates more and deeper relationships such as that with Cisco and EMC. 
2. At this time, no single HP product can improve HA over both the NT and Unix 
platforms.  The lack of an NT version of MCservice Guard will not be fixed for 
technology reasons.  Therefore, the NT HA story will have to be part reassurance that 
“HP is doing everything practical to improve on Microsoft’s base platform, and that 
base platform, services, practices, and remote management can improve NT 
availability levels.”  Longer term, NT and Unix products and services should 
approach parity.  In 1999 and 2000, HP must clearly tell the market what the limits 
are for HA on Intel/NT.   
3. For a market-leading HA campaign, Aberdeen would recommend the acquisition of 
NT fault-tolerance provider, Marathon Technologies.  Such an acquisition would give 
HP the industry’s only “FT on NT” capability — a capability that can leverage much 
more in systems and service revenues than just the FT boxes because the buyers will 
strongly consider using HP for all of the application’s servers and infrastructure. 
4. HP’s single-Unix-system availability story is average today based on the September 
1998 clustering white paper by DH Brown and conceded by the HA marketing team.  
However, improvements in 1999 will make HP’s offering on single systems more 
competitive.  In the interim, Aberdeen recommends that HP consider bundling in 
MCservice Guard as the lowest level of HA – thereby improving the competitive 
picture against Sun and IBM. 
5. End-to-end HA almost requires that ISV applications plug into the HP HA 
infrastructure.  To an ISV, this represents a significant investment in a HP-only 
version of the ISV’s software – a generally unpalatable investment.    
6. While “high availability” resonates with a large market segment, Aberdeen does not 
believe that HP’s “five nines” message is understood by nearly as wide an audience; 
the lowest understanding for five nines would be in the critical line-of-business 
executive and CEO/CFO/COO management categories.  Aberdeen recommends a 
transition away from the techie-term “five nines” and towards a broader and better 
understood “end-to-end high availability” super-message. 
7. The HA application space should be painted with a broad brush.  It is significantly 
wider that just Unix OLTP, the current focus of HP’s HA marketing.  HP will gain 
the greatest advantage by widening the HA umbrella to include user-defined mission-
critical applications that include e-mail, data warehouses, e-business, supply chain, 
and call centers.  The vertical focus of HA starts with telcos, finance, and retail in-
store systems. 
8. Aberdeen believes that the “end-to-end HA” theme is credible.  HP already has 
considerable experience over time in this space.  Second, Aberdeen sees a 12-18 
month useful window for the end-to-end-HA umbrella message – a respectable life.  
Third, HP’s HA advantage has a high level of services components, raising the bar for 
box-technology-only competitors such as Sun and Compaq.  Overall, Aberdeen 
Group rates HP’s end-to-end HA position as defendable and sustainable. 
9. Competitively: 
• IBM clearly understands the technologies but has not said anything about HA on its 
four disparate hardware platforms nor has IBM made any market moves towards end-
to-end beyond custom projects by Global Services.   
• Sun is focused on single-box HA issues.  Sun is poor-to-fair in a cluster, lacks global 
services comparable to IBM and HP, and lacks any concept of end-to-end. 
• Compaq has limited its HA thrust to rack-mounted clusters.  The Digital services 
capability is not widely deployed in HA, and Compaq has not worked on end-to-end.  
While the Tandem division of Compaq certainly understands HA issues in depth, 
Tandem is presently focused on selling to its installed base with no likely change in 
that focus. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | 1998-10-hp-high-availability-db1fe3 |
| title | Aberdeen Group Flash Report: High Availability Marketing Messages |
| author | Peter S. Kastner |
| date | 1998-10-28 |
| type | white-paper |
| subject_domain | High availability computing — HP marketing strategy |
| methodology | document-review |
| source_file | 1998-10-hp-high-availability-db1fe3.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group Flash Report summarizing findings from an October 28 1998 meeting with HP's high availability marketing team. Confirms that 40%+ of commercial server buyers rank availability as a key purchasing criterion. Evaluates HP's proposed end-to-end HA strategy and identifies three differentiators: end-to-end HA vs. box-level, contractual uptime guarantees, and High Availability Observatory remote monitoring. Benchmarks HP against IBM, Sun, and Compaq. Recommends acquisition of Marathon Technologies for NT fault-tolerance and a transition away from five-nines messaging to broader end-to-end HA positioning.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Dense expert advisory document providing Aberdeen's specific actionable recommendations to HP's HA marketing team; captures competitive landscape of HA computing in late 1998. |
| **Relevance** | high | Directly documents Kastner/Aberdeen consulting methodology and competitive intelligence work; important record of HA market dynamics at a key transitional moment (NT vs Unix). |
| **Prescience** | high | Aberdeen's recommendation to broaden HA beyond Unix OLTP to include e-commerce, supply chain, and data warehousing proved prescient — these became standard HA application categories. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (12)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Hewlett-Packard (HP) | company | spun-off | HP Inc. / Hewlett Packard Enterprise |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Peter S. Kastner | person | active |  |
| IBM (International Business Machines) | company | public |  |
| Sun Microsystems | company | acquired | Oracle |
| Tandem Computers | company | acquired | Hewlett Packard Enterprise |
| Compaq Computer | company | acquired | Hewlett Packard Enterprise |
| Marathon Technologies | company | acquired | Stratus Technologies |
| Cisco Systems | company | public |  |
| EMC Corporation | company | acquired | Dell Technologies |
| Jim Murphy | person | private |  |
| Thomas Willmott | person | private |  |

### Technologies Referenced (9)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| High Availability (HA) Computing | framework |  | growth | mainstream |
| End-to-End High Availability Architecture | framework | Hewlett-Packard | emerging | standard |
| HP MC/ServiceGuard | software | Hewlett-Packard | mature | legacy |
| Five Nines (99.999%) Availability | framework |  | mainstream | standard |
| High Availability Observatory (HAO) | application | Hewlett-Packard | emerging | defunct |
| Fault Tolerance on Windows NT (FT-on-NT) | framework | Marathon Technologies | emerging | evolved |
| Microsoft Windows NT | platform | Microsoft | emerging | evolved |
| HP-UX | platform | Hewlett-Packard | mature | legacy |
| Contractual Uptime Guarantees (with Insurance) | framework | Hewlett-Packard | emerging | evolved |

### Observation Summary

- Total observations: 24
- By type: technology-assessment: 13, strategy-classification: 8, market-data: 2, expert-opinion: 1
