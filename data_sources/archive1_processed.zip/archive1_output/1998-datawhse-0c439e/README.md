# Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998-01-01 |
| Type | market-study |
| Domain | parallel-database / data-warehousing |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group slide-deck presenting the case that parallel-scalable relational databases (supporting SMP today, clusters and MPP tomorrow) are the key technology to relieve the enterprise 'downsizing logjam' — the surge in information demand (3-5x by late 1990s) driven by empowered users, ad-hoc queries, decision support, and client-server applications. Kastner frames the problem as relational databases being the biggest performance bottleneck on midrange servers, and positions parallel-scalable RDBMS as a 'free hardware upgrade' enabling dynamic resource scalability.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 2 |
| technologies.csv | 8 |
| observations.csv | 15 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
