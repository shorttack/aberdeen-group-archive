# Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?

> Archived from: 1998-datawhse-0c439e.txt
> Original publication date: 1998-01-01
> Author: Peter S. Kastner

---

## Original Document Text

Can Parallel-Scalable
RDBMSs Break the
Downsizing Logjam?
AberdeenGroup
AberdeenGroup
Agenda
ä Facing the downsizing logjam
ä Parallel-scalable relational databases
ä Benefits
ä What to look for
ä Wrap-up
AberdeenGroup
Parallel-Scalable RDBMS Benefits
ä Improved performance can be a 
hardware-upgrade equivalent
ä Increased robustness, availability
ä Lower-cost configuration flexibility
ä Improved scalability curve
AberdeenGroup
Downsizing Logjam
ä Driving forces
ä Good old days are gone
ä Information logs create a jam
ä Red summer dresses
ä Why empower users?
AberdeenGroup
Driving Forces
ä Global competition
ä Technology innovations
ä Social changes
AberdeenGroup
Good Old Days are Gone
Customers
Get Data
Add It
Store It
Sort It
Report It
AberdeenGroup
Information Logs Create a Jam
ä Online transaction processing
ä Production queries
ä New client-server applications
ä Desktop automation
ä Ad hoc queries and decision support
–
EIS
–
Enterprise data mining
–
Empowered users
AberdeenGroup
AberdeenGroup
Red Summer Dresses
ä It’s May in Miami. Your store manager 
has 1,000 red summer dresses that 
have not sold. Does the company:
– Put them on sale?
– Ship them to Boston?
ä Be careful. The correct decision drops 
directly to the bottom line!
AberdeenGroup
Why Empower Users?
ä Personnel downsizing 
is a reality
ä Computer literacy 
improving
ä Increased job-level 
productivity
ä Users are decision 
makers
ä New decision-making 
cycle
AberdeenGroup
ä Analyze
ä Decide
ä Transact
ä Report
New End User Decision-Making Model
AberdeenGroup
Information Demands Go Through the Roof
ä Online transaction processing
ä Production queries
ä New client-server applications
ä Desktop automation
ä Ad hoc queries and decision support
3-5x increase in information demand by late 1990s
AberdeenGroup
IS on a Hot Tin Roof
ä CEO pressure to reduce enterprise 
costs
ä Users demand more and better 
information
ä New client-server applications
ä Keeping up with the competition
ä Don’t forget legacy system migration
AberdeenGroup
Breaking the Logjam
AberdeenGroup
Technology Goals
ä Excellent 
cost-performance
ä Scalability
ä Availability
ä Fast response times
ä Open infrastructure
ä Development tools
ä Ease of administration
AberdeenGroup
Midrange Servers Win
ä Excellent cost-performace
ä Scalability beyond mainframes
ä High availability with clusters
®Fast response times
®Support for open standards
®Widely available 
development tools
®Open systems
management
AberdeenGroup
Midrange Server Technology Ingredients
ä Lots of microprocessors
ä Lots of memory
ä Fast I/O buses
ä Intelligent controllers
ä Unix-on-steroids
Competitive Pressures Force Technology Excellence
AberdeenGroup
Relational Databases are the Biggest Problem
ä Coarse-grain multiprocessor support
ä Administration bottlenecks
ä Poor scaleup in database size
ä Few ways to speed up response times
AberdeenGroup
Parallelizing the RDBMS Solves the Problem
ä Fine-grain multiprocessor 
support
ä Parallel administration
ä Dynamic resource 
scalability
ä Speed-up batch by 
parallelization
AberdeenGroup
Fine-grain Multiprocessor Support
ä Harness available CPUs
ä Sort, index, aggregate, 
scan, merge operations
ä Application scalability
–
SMP
–
Clusters
–
Massively parallel
Subtask
Subtask
Subtask
Task
CPU
CPU
CPU
AberdeenGroup
Parallel Administration
ä Bulk loading/unloading
ä Backup/recovery
ä Index building
ä Mass updates/deletes
ä Alter/reorg
AberdeenGroup
Dynamic Resource Scalability
ä Add processors ...
ä Add users while response time 
remains constant
ä Improve response time while users 
remain constant
AberdeenGroup
Speed-up Batch by Parallelization
Subtask
Subtask
Subtask
Subtask
Task
CPU
CPU
CPU
Batch Jobs
AberdeenGroup
Harnessing Today’s SMP Servers
ä SMP is today’s most prevalent 
hardware architecture
ä Hardware needs change 
dynamically
ä Buyer’s:
–
more users on same hardware 
–
faster response times
–
smaller, lower-cost initial
hardware investment
Parallel-scalable RDBMS is like a free hardware upgrade
AberdeenGroup
Clusters and Massively-Parallel 
Processors Tomorrow
Massively Parallel
SMP
Time
Clusters
AberdeenGroup
What to Look for in Parallel-Scalable RDBMSs
ä Hardware adaptation: SMP, cluster, 
MPP
ä Parallelization breadth and depth
ä Benchmarks
ä Administration
ä Technology invisibility
AberdeenGroup
Parallel-Scalable RDBMS Benefits
ä Improved performance can be a 
hardware-upgrade equivalent
ä Increased robustness, availability
ä Lower-cost configuration flexibility
ä Improved scalability curve
AberdeenGroup
Aberdeen Conclusions
ä Information-hungry users and 
applications demand better data 
management approaches
ä Technology pieces now fit together
ä Parallel-scalable RDBMS technology
ä Solves real-world problems
ä Is now being rolled out by RDBMS 
leaders
AberdeenGroup
Aberdeen Conclusions
ä Smashing the logjam, empowering 
users
ä SMP now, clusters and MPP soon
Parallel-Scalable RDBMS technology
IS should take a hard look now at
parallel-scalable solutions


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | 1998-datawhse-0c439e |
| title | Can Parallel-Scalable RDBMSs Break the Downsizing Logjam? |
| author | Peter S. Kastner |
| date | 1998-01-01 |
| type | market-study |
| subject_domain | parallel-database / data-warehousing |
| methodology | industry-analysis |
| source_file | 1998-datawhse-0c439e.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group slide-deck presenting the case that parallel-scalable relational databases (supporting SMP today, clusters and MPP tomorrow) are the key technology to relieve the enterprise 'downsizing logjam' — the surge in information demand (3-5x by late 1990s) driven by empowered users, ad-hoc queries, decision support, and client-server applications. Kastner frames the problem as relational databases being the biggest performance bottleneck on midrange servers, and positions parallel-scalable RDBMS as a 'free hardware upgrade' enabling dynamic resource scalability.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Establishes Aberdeen's parallel RDBMS framework — a foundational analytical lens used across multiple archive studies; quantifies information demand growth at 3-5x by late 1990s. |
| **Relevance** | high | Directly relevant to the evolution of enterprise database architectures from single-server RDBMS to parallel/distributed platforms, a defining IT trend of the 1990s-2000s. |
| **Prescience** | high | Correctly predicted SMP as near-term dominant architecture, clusters as mid-term, and MPP as emerging — the exact sequence that unfolded in the market (SMP commodity servers, then cluster/grid, then cloud-scale MPP). |

### Prescience Detail


**Prediction 1:** cluster_timeline
- **Claimed:** Near-future after SMP; Aberdeen projects as mid-term architecture
- **Year:** 1998
- **Confidence at time:** medium

**Actual Outcome 1:** cluster_timeline
- **Result:** Parallel database clustering for data warehousing achieved mainstream adoption by 2000-2005. Teradata, IBM DB2 PE, and Oracle RAC dominated large-scale DW deployments. MPP shared-nothing architectures (Teradata, later Netezza, Greenplum) proved the winning model for very large data warehouses.
- **Confidence:** verified
- **Notes:** Confirmed by academic literature (CMU parallel DB paper), Teradata market data, and subsequent industry trajectory through the 2000s.

**Prediction 2:** mpp_timeline
- **Claimed:** Longer-term after clusters; being rolled out by RDBMS leaders
- **Year:** 1998
- **Confidence at time:** medium

**Actual Outcome 2:** mpp_timeline
- **Result:** MPP became the dominant architecture for very large data warehouses (Teradata, Netezza, Greenplum), while SMP remained dominant for OLTP and smaller analytics. The 'logjam' in downsizing mainframe DW to open systems largely broke by 2002-2005 as parallel RDBMSs proved scalable.
- **Confidence:** verified
- **Notes:** Confirmed by Teradata's growth, emergence of MPP-based appliances, and Microsoft's own 2014 blog post on SMP-to-MPP transition.


### Entities Referenced (2)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Peter S. Kastner | person | active |  |

### Technologies Referenced (8)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Parallel-Scalable RDBMS | database |  | emerging | mainstream |
| Symmetric Multiprocessing (SMP) | hardware |  | growth | mature |
| Cluster Computing | hardware |  | emerging | mature |
| Massively Parallel Processing (MPP) | framework |  | emerging | mainstream |
| Data Warehousing | framework |  | growth | evolved |
| Decision Support Systems (DSS) / EIS | framework |  | growth | evolved |
| Enterprise Data Mining | framework |  | emerging | mainstream |
| Midrange Server Platforms | hardware |  | growth | evolved |

### Observation Summary

- Total observations: 15
- By type: technology-assessment: 6, expert-opinion: 3, viability-prediction: 2, actual-outcome: 2, market-data: 1, framework-factor: 1
