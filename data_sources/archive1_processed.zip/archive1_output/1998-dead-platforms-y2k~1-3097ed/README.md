# Y2K Live Dead & Wounded

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998-01-01 |
| Type | market-study |
| Domain | Y2K platform survival analysis |
| License | CC-BY-4.0 |

## Abstract

4-slide Aberdeen deck classifying computing platforms as Living, Dead, or Wounded in the context of Year 2000 compliance. Identifies IBM MVS/OS400/AIX, HP-UX, Sun Solaris, and NT as surviving platforms; classifies IBM System/3X, 308x/309x mainframes, HP 3000 MPE, Bull 6000, and DG Eclipse as dead. Highlights IBM VSE, Unisys, Wang VS, and old manufacturing apps as wounded. Also assesses downstream customer attractiveness for Y2K-driven migration opportunities.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 9 |
| technologies.csv | 20 |
| observations.csv | 24 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). Y2K Live Dead & Wounded.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
