# Enterprise Business Applications: The Questions No One Asks

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998-01-01 |
| Type | market-study |
| Domain | ERP market analysis and implementation best practices |
| License | CC-BY-4.0 |

## Abstract

27-slide Aberdeen deck presented by Kastner as Aberdeen CRO analyzing the ERP market with a contrarian framework. Covers ERP market segmentation by company size and cost; identifies four industry gorillas (SAP/BaaN/Oracle/PeopleSoft) and best-of-breed players; outlines six EBA trends; introduces Aberdeen's Infinite Resource Planning (IRP) model as ERP's successor; catalogs ten costly ERP implementation mistakes (titled Ten Costly Mistakes Others Made); and provides summary conclusions. ERP implementation cost advice includes: outside services exceed 50% of direct costs; server hardware/software equals ~10% of project costs; CEO must drive project; $200M fiascoes come from reengineering in parallel with ERP. Identifies Dell/Amazon/Cisco as exemplars of IRP.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 15 |
| technologies.csv | 11 |
| observations.csv | 33 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). Enterprise Business Applications: The Questions No One Asks.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
