# Enterprise Business Applications: The Questions No One Asks

> Archived from: 1998-enterprise-apps-14adab.txt
> Original publication date: 1998-01-01
> Author: Peter S. Kastner

---

## Original Document Text

Enterprise Business Applications:  
The Questions No One Asks
Peter S. Kastner
Chief Research Officer
Aberdeen Group, Inc.
One Boston Place
Boston, MA  02108
www.aberdeen.com
Agenda
ERP:  the standard view of the world
Beyond ERP: Infinite Resource 
Planning
Ten Tips from the walking wounded
Conclusions, observations, and 
questions
Enterprise Business 
Application Solutions
Packaged Applications for:
• Finance & Accounting
• Manufacturing & Distribution
• Human Resources
Open, Graphical, Distributed, 
Interoperable, Web-enabled
Value beyond line-of-business 
functionality
SIZE of COMPANY
COST
DeskTop
Enterprise
Midrange
$10k
$150k
$250k
$500m
$250m
$50m
Rightsizing
Custom Implementations
Direct Sales & Support
Upsizing
Pre-Configured
Direct & Channel
Sales & Support
PC-LAN
Shrink Wrapped
Channel Sales & Support
Enterprise Business 
Application
 Market Segmentation
Source:  Aberdeen Group
Major Players
■Industry Gorillas
– SAP AG
– BaaN
– Oracle
– Peoplesoft
■Best of Breed
– Computer 
Associates
– Great Plains
– JD Edwards
– Lawson
– Marcam
– System Software 
Assoc.
EBA Trends
Marrying manufacturing to sales: ERP + CIS = CRM
Advanced Planning Engines benefit manufacturers
Vertical market specialization expands
Application integration technologies emerge
Sales focus is now middle-market companies
Vendor consolidation has just started
But no one supplier will own it all
Beyond ERP: 
The Emergence of Infinite 
Resource Planning
Internet
Technologies
Enterprise
Systems
Planning &
Forecasting
EDI
Commodity
Brokerage
THE WEB
Aberdeen’s Infinite 
Resource Planning (IRP) 
Model
Internet
Technologies
Enterprise
Systems
Planning &
Forecasting
EDI
Commodity
Brokerage
THE WEB
Infinite Resource Planning:
 Business Model
Supply-chain push and pull
Customer delight, customer 
knowledge
Infinite resources due to continuous 
planning.  JIT becomes the norm not 
the exception.
Text-book examples:  
• Dell Computer, Amazon.com, Cisco
Internet Business-to-Business 
Leverage
N
Data
N
Internet 
desktop with 
Web Engine
Data
WWW Server
(any platform)
WWW Server
(any platform)
Distributed Web
Engine
Baan
System
Distributed Web
Engine
Order Entry
System
Product
Database
TCP/IP
HTTP
HTTP
TCP/IP
TCP/IP
Company A
Manufacturer
Company B
Supplier
TCP/IP
Internet desktop with 
Web Engine
IRP Technology Inhibitor:
Our Legacy Systems & Processes
MRP systems from the 1970s
• Great cost accounting
• Adequate inventory control
• Primitive scheduling & forecasting
 
ERP systems from the 1980s-1990s
• Single-vendor integration
• Fat clients -- big PCs on every desktop
• Little cross-vendor interoperability
• High costs of proprietary electronic data 
interchange
Companies must leverage what they have:
HR Mftg ActgOrders
Web Server
Any Web
Browser
Internet/
    Intranet
Leverage!
•
Over 20 years of embedded 
business processes and 
practices
•
Rich base of Make The 
Money applications
•
Business and System 
Security
•
Networks
•
Personnel -- Skills and 
Experience
IRP Critical Success Factors
Overcome Productivity Obstacles
• Interface with new, existing and 
packaged systems
• Support Enterprise and Internet 
infrastructures simultaneously
• Leverage low-maintenance thin clients
• Hide existing system complexity
• Ensure security
Ten Costly Mistakes Others 
Made
RIP CIO
#1 Skimping on Outside 
Services
“We’ll economize by cutting outside 
services.”
Skimping is false economy!
System Integrators do this every day
Do you really have IS staff sitting on the 
bench?
Plan on outside services being over 50% of 
direct costs
$
#2 Costs = Hardware + Software 
+ a Little
Server hardware and software equal ~10% 
of project costs
Under-estimated money pits
• user management time
• IS project management
• user training
• cross-system data exchange
• conversions
• performance tuning
#3 Installation is a 3-Day 
Weekend
An unnamed college book publisher …
No one does a big bang conversion and 
cut-over!
Convert and train and trial an application at 
a time
#4 IS Should Drive the Project
No.  CEO must drive the project
Senior management team must fight 
fires, conflicts
IS is the implementation arm of the 
management team
Timely conflict resolution 
mechanism is key process
#5 Your ERP Suppliers are a 
Team
They are Balkan allies … at best
• Every “partner” has own agenda
• These agendas often are at odds
• You are in the middle
Solution: 
• pick a manager
• make the manager financially 
accountable
Ideal ERP
#6 It’s a Canned, Best-
 Practices Solution
It’s really ideal for no one!
Trade-off:  customization & cost versus 
implementation time & flexibility
Avoid the extremes of over- or under-
customization
The smaller your organization, the more 
you depend on ERP supplier’s “best 
practices”
#7 One Size Fits All
Sure, just like Windows NT does …
Each ERP supplier is different and better 
suited for specific instances
• vertical market expertise
• geographic concentration of customers and  
support
• hardware and  OS platform
• Systems integration partner experience
• application functionality
Look for a local mirror installation to your 
site needs
#8 We’ll Train As We Go
Fact: These are enormously complex 
applications
Training is critical to short- and long-
term success
Tendency is to skimp on training time
User department management is the 
worst offender
#9 Reengineering is an Easy, 
Parallel Project
Nine women cannot have a baby in one 
month
Seriously reengineering your processes in 
conjunction with ERP installation is where 
the $200 million fiascoes come from
But focused reengineering on critical 
processes makes enormous sense
Needed: balance between “we always did it 
this way” and “the new system will only do 
it this way”.
December 31, 1999 12:59PM
#10 ERP Will Solve Your Year 
2000 Problems
Not your legacy application problems
Not your supplier-partner data interchange 
problems
Not your embedded computer applications
Not your hardware or OS
Aberdeen:  new ERP system decision this 
quarter may be the only way out for many 
mainframe customers
30
Summary Conclusions
ERP market is huge because it 
satisfies pent-up demand
ERP systems become IRP systems 
over next 5 years
Enterprise Business Application 
integration is a continuing saga
It’s easy to make costly mistakes.  
Don’t repeat history.  Planning is 
everything.
Aberdeen Group Resources
www.aberdeen.com
Enterprise Application Integration
Customer Interaction Solutions
Electronic Commerce
Vertical Industries
Enterprise Business Applications
Research, analysis, consulting
Technology Enablers
Objects
•
Reusable business-process logic units
•
Technology-transparent data and processing 
infrastructure (e.g., Object Request Brokers)
Internet
•
Universal Network to custumers and suppliers
•
Common technology building-block standards
Networked Computer Architectures
•
Thin clients (e.g., NC and NetPC)
•
Internet appliances for home, office, & mobile


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | 1998-enterprise-apps-14adab |
| title | Enterprise Business Applications: The Questions No One Asks |
| author | Peter S. Kastner |
| date | 1998-01-01 |
| type | market-study |
| subject_domain | ERP market analysis and implementation best practices |
| methodology | industry-analysis |
| source_file | 1998-enterprise-apps-14adab.txt |
| license | CC-BY-4.0 |

### Abstract

27-slide Aberdeen deck presented by Kastner as Aberdeen CRO analyzing the ERP market with a contrarian framework. Covers ERP market segmentation by company size and cost; identifies four industry gorillas (SAP/BaaN/Oracle/PeopleSoft) and best-of-breed players; outlines six EBA trends; introduces Aberdeen's Infinite Resource Planning (IRP) model as ERP's successor; catalogs ten costly ERP implementation mistakes (titled Ten Costly Mistakes Others Made); and provides summary conclusions. ERP implementation cost advice includes: outside services exceed 50% of direct costs; server hardware/software equals ~10% of project costs; CEO must drive project; $200M fiascoes come from reengineering in parallel with ERP. Identifies Dell/Amazon/Cisco as exemplars of IRP.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rich contemporaneous ERP market analysis from Aberdeen's CRO; the ten implementation mistakes section is actionable practitioner intelligence; the IRP concept anticipates supply-chain-internet convergence. |
| **Relevance** | high | Directly captures Aberdeen's ERP market framework and Kastner's contrarian analysis style; highly relevant for understanding 1998 enterprise software market dynamics and Aberdeen's intellectual approach. |
| **Prescience** | high | IRP concept (ERP + internet + supply chain) proved prescient; Dell/Amazon/Cisco examples as IRP leaders was validated; vendor consolidation prediction correct; ERP-to-SaaS evolution followed IRP-like path. |

### Prescience Detail


**Prediction 1:** erp-to-irp-timeline
- **Claimed:** ERP systems will become IRP systems over the next 5 years (by ~2003)
- **Year:** 1998
- **Confidence at time:** medium

**Actual Outcome 1:** erp-to-irp-outcome
- **Result:** The 'IRP' (Industry Requirements Profile) concept did not replace generic ERP as a distinct category. Instead, major ERP vendors (SAP, Oracle, Microsoft) added vertical-specific modules and industry editions to their platforms. True industry-specific ERP niches were addressed by vertical ISVs (e.g., Infor for manufacturing) rather than a new 'IRP' paradigm.
- **Confidence:** high
- **Notes:** ERP history literature shows verticalization happened within existing ERP brands, not via an IRP replacement wave. The term 'IRP' did not enter mainstream usage.


### Entities Referenced (15)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| SAP AG | company | public |  |
| Oracle | company | public |  |
| PeopleSoft | company | acquired | Oracle |
| BaaN | company | acquired | Infor (via SSA Global) |
| Computer Associates | company | acquired | Broadcom |
| Great Plains Software | company | acquired | Microsoft (Dynamics GP) |
| J.D. Edwards | company | acquired | Oracle |
| Lawson Software | company | acquired | Infor |
| MARCAM Corporation | company | acquired | Infor (via SSA Global) |
| System Software Associates (SSA) | company | acquired | Infor (via SSA Global) |
| Dell Computer | company | public |  |
| Amazon.com | company | public |  |
| Cisco Systems | company | public |  |

### Technologies Referenced (11)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| ERP (Enterprise Resource Planning) Systems | application | multiple | mainstream | evolved |
| Infinite Resource Planning (IRP) | framework | Aberdeen Group | emerging | prescient-precursor |
| MRP (Material Requirements Planning) Systems | application |  | legacy | niche |
| EDI (Electronic Data Interchange) | protocol |  | mature | declining |
| CRM (Customer Relationship Management) | application |  | emerging | mainstream |
| Advanced Planning and Scheduling (APS) Engines | application |  | emerging | mainstream |
| Enterprise Application Integration (EAI) | middleware |  | emerging | mainstream |
| Thin Clients (NC and NetPC) | hardware |  | emerging | evolved |
| Object Request Brokers (ORB) | middleware |  | emerging | declined |
| Internet B2B Integration | framework |  | emerging | mainstream |
| Microsoft Windows NT | platform | Microsoft | mature | evolved |

### Observation Summary

- Total observations: 33
- By type: expert-opinion: 22, market-data: 7, technology-assessment: 2, viability-prediction: 1, actual-outcome: 1
