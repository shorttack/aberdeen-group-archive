# U.S. Insurance Industry Overview

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998-01-01 |
| Type | market-study |
| Domain | US Insurance Industry IT landscape and Software AG positioning |
| License | CC-BY-4.0 |

## Abstract

18-slide Aberdeen deck presented by Kastner as Aberdeen CRO to Software AG North America (SAG NA). Covers US insurance market segmentation (P&C $260B premiums; L&H $330B premiums), business drivers (profitability erosion, expense ratios, M&A), industry trends (financial disintermediation, Y2K, e-commerce), and technology landscape (mainframe/NT hybrid architectures, data warehousing, 3-tier client-server). Assesses attractiveness of the insurance vertical to Software AG and identifies both positive factors (large market, RAS requirements, complex data) and negative (no new mainframe DB managers, competing with SQL Server/DCOM, immature middleware standards, need for ISV support). Lists potential partner companies in P&C, Life, and Systems Integration.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 22 |
| technologies.csv | 12 |
| observations.csv | 8 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). U.S. Insurance Industry Overview.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
