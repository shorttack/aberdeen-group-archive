# U.S. Insurance Industry Overview

> Archived from: 1998-software-ag-insurance-874781.txt
> Original publication date: 1998-01-01
> Author: Peter S. Kastner

---

## Original Document Text

U.S. Insurance Industry 
Overview
Peter S. Kastner
Chief Research Officer
Aberdeen Group, Inc.
Boston, Massachusetts
(617) 723-7890
Agenda
• Market Segmentation
• Business Drivers
• Industry Trends
• Technology in Insurance
• Attractiveness to SAGA
2
Aberdeen Group, Inc.
Market Segmentation
• Property & Casualty
– Home, business, liability, 
interruption
– $260B in premiums
– All consumers and 
businesses are customers
• Life & Health
– Life and health insurance
– $330B in premiums
– Personal and group are 
major sub-segments
– 80%+ of businesses and 
consumers are customers
3
Aberdeen Group, Inc.
Business Drivers
• Erosion of profitability due to competition and 
poor actuarial planning
– Breakdown in traditional business relationships, driving 
many to seek “lowest price” — commodity products
– Lack of product and service differentiation
– Relative disadvantage in consumer face-time
– Bad bets placed on coastal real estate, longevity, HMO 
savings
• High expense ratios, slowing growth, market-
share challenges, M&A
4
Aberdeen Group, Inc.
Business Drivers
• Customer Service
– A huge cost-center opportunity for $$$ savings
– A means of differentiation (e.g., 24x7, drive-in, etc.)
• Government regulation
– 50 states plus federal = high cost to enter market
• Complicated, multi-tier selling and service 
delivery schemes are traditional
– Agencies
– Group plan administration
5
Aberdeen Group, Inc.
Industry Trends
• Financial Disintermediation
– “Why not buy insurance from … a bank”
– Or over the Internet from the lowest-cost bidder
– The Citibank/Travellers merger was not an aberration
• Year 2000 Creates Supply-Chain Opportunities
– Safe HQ but failing agencies?
6
Aberdeen Group, Inc.
Industry Trends
• Health Care Remains a Wild Card
– Managed care will become more regulated by 
politicians
– Nationalized system unlikely
– Result:  be prepared for rapid systems change
• Electronic Commerce Proliferates
– supplier-to-consumer
– business-to-business
– supplier-to-intermediary
7
Aberdeen Group, Inc.
Technology in Insurance
• Architecture
– Mainframe tradition for OLTP and batch
– Agency systems are moving towards NT
– Multi-tier, geographically distributed systems are the 
norm
• Interface: almost all human-to-computer [unlike 
POS and ATM special terminals in retail and 
banking]
8
Aberdeen Group, Inc.
Technology in Insurance
• Vast Data Requirements
– Underwriting
– Actuarial
– Claims
– Regulatory
• Data Warehousing is a natural, growing fast
9
Aberdeen Group, Inc.
Technology in Insurance
• Computing Styles
– Large volumes dictate mature software
– Complicated transactions (volumes vary by segment)
– Client-server in local offices for speed.  Perhaps a local 
database
• Complex data (e.g., ORDBMS) slow to take off
– Imaging also slow uptake due to costs.  Is changing due 
to cheap digital cameras and printers.
10
Aberdeen Group, Inc.
Technology Problem Example
• Large, for-profit insurance company with huge 
investment in mainframe systems
• Slow information turnaround due to batch 
orientation and lack of a data warehouse
• Under market pressure to make casualty claims 
decisions faster in 500 local offices.  Walk-up 
claim resolution is the business goal.
• But fraud checking and cost-comparison data must 
be kept at headquarters
11
Aberdeen Group, Inc.
3-Tier Application Example:
Insurance Claims
Unix or NT 
cluster
Highly Parallel, Scaleable
8,000 users at 500 offices and 
headquarters
Local transaction 
processing 
against a replicated 
database
Data Warehouse
PC desktops and Intel/Risc Office Server
Economical, 
Scaleable
15-500 Users
5,000 
Users
OLTP 
Production
System &
Admin.
Aberdeen Group, Inc.
12
3-Tier Application Example:
Information Flow
Data Warehouse 
Transformation & 
Replication
Transaction Pull
Replication to every office
Transaction Push
Database of 
Record
Enterprise 
Superserver
No
Image
Java & HTML 
to Suppliers
No
Image
No
ImageNo
Image
No
ImageNo
Image
No
ImageNo
Image
Classic 2-Tier Client-Server
No
ImageNo
Image
Aberdeen Group, Inc.
13
Attractiveness to SAG NA: 
Positive
• Insurance is one of the “biggie” markets
– Industry focus by IBM, HP, Sun, SAP, and Microsoft
– Large, readily identifiable list of prospects.  Geographic 
distribution across the country.
• Business drivers and trends are compelling rapid 
changes in it to support new business initiatives
• Application issues are U.S-centric:  globalization 
does not matter much
14
Aberdeen Group, Inc.
Attractiveness to SAG NA: 
Positive
• Emergence of an electronic insurance supply chain 
is inevitable but will not happen over night
– Yes, software solutions connecting insurers, agencies, 
reinsurers, etc. are high value
• Major, long-standing appreciation of RAS, 
scalability, interoperability, security issues
• Large volumes of complex data and business 
processes: difficult data management problems
• Still a tendency to make rather than buy
15
Aberdeen Group, Inc.
Attractiveness to SAG NA: 
Negative
• Where does SAG fit among legacy and new-breed 
data management and middleware choices?
– No new mainframe database managers
– Fighting SQL Server/DCOM head on
• New application projects typically involve $10 
million to $200 million in costs (IT only part).  
Take years to complete.  Outside integrators.
• Middleware standard-based products are immature
• Need for ISV support
16
Aberdeen Group, Inc.
Questions Insurers Will Ask
• Where has SOM been in operation for a year at an 
insurance company?
• How could SOM possibly be plug-and-play into 
my legacy applications?  That’s ridiculous.
• I cannot afford the [network bandwidth/security/ 
response time penalty/etc.] of SOM.
• I only deal with six [five, ten] strategic suppliers 
and SAGA is not on the list.
• What makes you think that SAGA can out 
middleware IBM and Microsoft?
17
Aberdeen Group, Inc.
Partner Possibilities
•
Property & Casualty
– Agena
PRC
– AMS
Allenbrook
– Applied
PMSC
•
Life
– Continuum
Cybertek
– FDP
EZ Data
– Sterling Wentworth
ECTA
•
Integrators
– Andersen
EDS
– Deloitte & Touche
MCI SHL
18
Aberdeen Group, Inc.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | 1998-software-ag-insurance-874781 |
| title | U.S. Insurance Industry Overview |
| author | Peter S. Kastner |
| date | 1998-01-01 |
| type | market-study |
| subject_domain | US Insurance Industry IT landscape and Software AG positioning |
| methodology | industry-analysis |
| source_file | 1998-software-ag-insurance-874781.txt |
| license | CC-BY-4.0 |

### Abstract

18-slide Aberdeen deck presented by Kastner as Aberdeen CRO to Software AG North America (SAG NA). Covers US insurance market segmentation (P&C $260B premiums; L&H $330B premiums), business drivers (profitability erosion, expense ratios, M&A), industry trends (financial disintermediation, Y2K, e-commerce), and technology landscape (mainframe/NT hybrid architectures, data warehousing, 3-tier client-server). Assesses attractiveness of the insurance vertical to Software AG and identifies both positive factors (large market, RAS requirements, complex data) and negative (no new mainframe DB managers, competing with SQL Server/DCOM, immature middleware standards, need for ISV support). Lists potential partner companies in P&C, Life, and Systems Integration.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Detailed primary-source market sizing of US insurance IT in 1998; provides both macro-market metrics (premium volumes) and technology adoption patterns with direct Aberdeen research authority. |
| **Relevance** | high | Captures Kastner presenting Aberdeen intelligence to Software AG; documents how Aberdeen packaged and sold market intelligence to enterprise software vendors in the 1990s. |
| **Prescience** | medium | Kastner's predictions about insurance industry IT trends (e-commerce proliferation, data warehousing growth, financial disintermediation) proved broadly correct; agency channel disruption by internet was slower than implied. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (22)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Software AG | company | active |  |
| IBM (International Business Machines) | company | public |  |
| Hewlett-Packard (HP) | company | spun-off | HP Inc. / Hewlett Packard Enterprise |
| Sun Microsystems | company | acquired | Oracle |
| SAP | company | public |  |
| Microsoft | company | public |  |
| Citibank / Citicorp | company | merged | Citigroup |
| Travelers Group | company | merged | Citigroup |
| Andersen Consulting | company | evolved | Accenture |
| Electronic Data Systems (EDS) | company | acquired | Hewlett Packard Enterprise |
| Deloitte & Touche | company | active |  |
| MCI Systemhouse (MCI SHL) | company | acquired | EDS / HP Enterprise Services |
| Agena (P&C software) | company | defunct |  |
| PRC Inc. | company | acquired | Northrop Grumman |
| AMS (American Management Systems) | company | acquired | CGI Group |
| Applied Systems | company | private |  |
| Continuum (insurance software) | company | acquired | CSC / DXC Technology |
| Cybertek Corporation | company | acquired | Policy Management Systems Corporation (PMSC) |
| FDP Corporation | company | acquired | SunGard Data Systems |
| EZ Data Inc. | company | acquired | Ebix |

### Technologies Referenced (12)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| ADABAS (Adaptable DAta BAse System) | database | Software AG | mature | niche |
| Natural (4GL programming language) | language | Software AG | mature | niche |
| SOM (Software AG object middleware) | middleware | Software AG | emerging | obsolete |
| Mainframe Computing | hardware |  | declining | niche-mission-critical |
| Microsoft Windows NT | platform | Microsoft | emerging | evolved |
| Client-Server Architecture | framework |  | growth | evolved |
| Data Warehousing | framework |  | growth | evolved |
| Microsoft SQL Server and DCOM | database | Microsoft | growth | evolved |
| Object-Relational DBMS (ORDBMS) | database |  | emerging | evolved |
| Document Imaging Technology | application |  | emerging | evolved |
| Java | language | Sun Microsystems | emerging | standard |
| Electronic Commerce (e-commerce) | framework |  | emerging | mainstream |

### Observation Summary

- Total observations: 8
- By type: market-data: 4, expert-opinion: 4
