# Aberdeen and Intel Partnership Briefing

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1999-12-01 |
| Type | market-study |
| Domain | Aberdeen Group business overview and 2000 market trend forecast; Intel partnership |
| License | CC-BY-4.0 |

## Abstract

13-slide Aberdeen deck presented in December 1999 to Intel. Covers Aberdeen's positioning as IT market research firm; 1999 growth milestones (50+ analysts, Boston/Palo Alto/Amsterdam offices, e-Business advisory launch); Aberdeen's 2000 market trend forecast identifying under-rated and over-rated technologies; Aberdeen's research focus areas for 2000; review of prior Intel-Aberdeen collaboration; and proposed new projects. Key 2000 trend calls: B2B supply chain and storage area networks as under-rated; ASP business model and Windows 2000/Linux as over-rated.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 20 |
| observations.csv | 25 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1999). Aberdeen and Intel Partnership Briefing.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
