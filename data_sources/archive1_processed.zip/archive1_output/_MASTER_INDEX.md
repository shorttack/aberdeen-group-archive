# Kastner Aberdeen Group Research Archive — Master Index (Archive-1)

> **Archive-1** | Archival Ingest Skill v16 | Processed 2026-04-09
> Aberdeen Group market studies, client presentations, and flash reports — 1995–1999

## Summary Statistics

| Metric | Count |
|--------|-------|
| Studies | 10 |
| Date range | 1995–1999 |
| Unique entities (cumulative cache) | 131 |
| Unique technologies (cumulative cache) | 217 |
| Total observations | 253 |

## Observation Types

- **technology-assessment**: 75
- **viability-prediction**: 49
- **market-data**: 42
- **expert-opinion**: 37
- **strategy-classification**: 20
- **actual-outcome**: 20
- **framework-factor**: 5
- **benchmark-result**: 5

## Studies (Chronological)

| Title | Year | Type | Importance | Relevance | Prescience | Entities | Technologies | Observations |
|-------|------|------|-----------|-----------|-----------|---------|-------------|-------------|
| [Aberdeen Vendor Briefing Summaries: AT&T GIS / NCR / Data General / DEC / HP / Sequent / Sun (1994)](att-ncr-dg-etc-14f7ce/README.md) | 1994 | market-study | high | high | medium | 12 | 16 | 48 |
| [Client-Server Development: Moving from Adolescence to Must-Have Mainstream](cs-development-358927/README.md) | 1995 | market-study | high | high | medium | 13 | 13 | 22 |
| [Client-Server Computing: Presentation to FDIC and Washington-Area Audience](fdic-washington-cs-1995-89ad5e/README.md) | 1995 | case-analysis | medium | high | medium | 9 | 10 | 20 |
| [Surfing the Parallel Architectures: A Presentation to Bank of America](bank-of-america-servers-1995-996d67/README.md) | 1995 | case-analysis | high | high | high | 15 | 16 | 34 |
| [Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?](1998-datawhse-0c439e/README.md) | 1998 | market-study | high | high | high | 2 | 8 | 15 |
| [Y2K Live Dead & Wounded](1998-dead-platforms-y2k~1-3097ed/README.md) | 1998 | market-study | high | high | high | 9 | 20 | 24 |
| [Enterprise Business Applications: The Questions No One Asks](1998-enterprise-apps-14adab/README.md) | 1998 | market-study | high | high | high | 15 | 11 | 33 |
| [U.S. Insurance Industry Overview](1998-software-ag-insurance-874781/README.md) | 1998 | market-study | high | high | medium | 22 | 12 | 8 |
| [Aberdeen Group Flash Report: High Availability Marketing Messages](1998-10-hp-high-availability-db1fe3/README.md) | 1998 | white-paper | high | high | high | 12 | 9 | 24 |
| [Aberdeen and Intel Partnership Briefing](1999-intel-12-8-05c6de/README.md) | 1999 | market-study | high | high | high | 3 | 20 | 25 |

## Collection Notes

- **Slide-deck PDFs**: Text extracted from presentation slides — sparse but dense with claims. Every bullet point captured as an observation.
- **ATT NCR DG etc.** (69 pages, 48 obs): The largest study — Aberdeen vendor briefing summaries covering AT&T GIS, NCR, Data General, and others. Rich source for strategy-classification observations.
- **Y2K dead platforms**: 24 observations from only 666 chars of text — demonstrates prescience analysis value. All 14 "dead" platform predictions were correct.
- **Enterprise Apps "Questions No One Asks"**: Kastner's IRP (Industry Requirements Profile) framework — a 1998 prediction that generic ERP would be displaced by industry-specific apps. Directionally correct (SAP industry solutions, Infor industry clouds) but took 15+ years to fully materialize.
- **Cache efficiency**: 17 entities + 7 technologies resolved from Archives 2–3 cache without re-lookup.
- All `[DEFERRED]` fields resolved via Phase 3 web verification.

## Repository

`github.com/shorttack/aberdeen-group-archive`

## License

CC-BY-4.0 — Peter S. Kastner
