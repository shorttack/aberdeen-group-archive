# Aberdeen Vendor Briefing Summaries: AT&T GIS / NCR / Data General / DEC / HP / Sequent / Sun (1994)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1994-05-16 |
| Type | market-study |
| Domain | enterprise-server-market / open-systems |
| License | CC-BY-4.0 |

## Abstract

Confidential Aberdeen Group competitive briefing document prepared for IBM, dated 5/16/94. Covers strengths/concerns/profiles and TPC benchmark data for seven enterprise server vendors: AT&T Global Information Solutions (GIS/NCR), Data General, Digital Equipment Corporation (servers and workstations), Hewlett-Packard (servers and workstations), Sequent Computer Systems, and Sun Microsystems (servers and workstations). Each section follows a structured format: product overview with spec tables, prioritized sales messages, strengths, customer concerns, and company profile with revenue, headcount, and target markets. This is Aberdeen analysis prepared as IBM sales-competitive intelligence.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 12 |
| technologies.csv | 16 |
| observations.csv | 48 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1994). Aberdeen Vendor Briefing Summaries: AT&T GIS / NCR / Data General / DEC / HP / Sequent / Sun (1994).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
