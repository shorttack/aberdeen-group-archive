# Surfing the Parallel Architectures: A Presentation to Bank of America

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-04-05 |
| Type | case-analysis |
| Domain | parallel-computing / enterprise-server-architecture |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group presentation to Bank of America (April 5, 1995) reviewing the landscape of parallel computing architectures (uniprocessor, SMP, cluster/loosely-coupled, MPP) and their software ecosystems, with a specific focus on Tandem Computer's position in the parallel world. Aberdeen presents its 4-architecture framework with estimated 1995 market share data, evaluates hardware suppliers (IBM, HP, DEC, Unisys, Compaq, AT&T GIS) and parallel software suppliers (Oracle, Sybase, Informix, IBM DB2), and concludes with Aberdeen's viewpoint on Tandem's architecture, technology, and markets.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 15 |
| technologies.csv | 16 |
| observations.csv | 34 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Surfing the Parallel Architectures: A Presentation to Bank of America.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
