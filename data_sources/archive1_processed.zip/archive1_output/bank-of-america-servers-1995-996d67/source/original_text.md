# Surfing the Parallel Architectures: A Presentation to Bank of America

> Archived from: bank-of-america-servers-1995-996d67.txt
> Original publication date: 1995-04-05
> Author: Peter S. Kastner

---

## Original Document Text

©Aberdeen Group, 1995
Surfing the Parallel Architectures
A Presentation to Bank of America
April 5, 1995
Peter S. Kastner
Vice President
Aberdeen Group, Inc.
One Boston Place
Boston, Mass. 02108
(617) 723-7890
©Aberdeen Group, 1995
Agenda
●Why Parallel?
●Review of Parallel Architectures
●Review of Parallel Software
●Parallelism in Applications
●Supplier Approaches to Parallelism
●Aberdeen's Viewpoint on Tandem 
in a Parallel World
©Aberdeen Group, 1995
Why Parallel Processing?
●Technology is an enabler
❻Parallel hardware is widely available, inexpensive
❻Parallel software (i.e., RDBMS)
❻$2M per terabyte disk storage
❻Scalability beyond traditional (mainframe) architectures ...
●Demand is price elastic, business driven
❻Replace people with technology
❻Time really is money
❻“I can answer questions we never could before.”
❻"I'm running out of night!"
❻"I'm looking for a sustainable competitive advantage with IT."
©Aberdeen Group, 1995
Very Quick Review of Parallel 
Architectures
●Uniprocessor
●Symmetric Multiprocessor (SMP)
●Cluster (Loosely-coupled)
●Massively Parallel (MPP/SPP)
©Aberdeen Group, 1995
Estimated Market Share by 
Architecture
Uniprocessor
72%
Symmetric 
Multiprocessor
22%
Massively Parallel 1%
Clusters 5%
Uniprocessor
Symmetric Multiprocessor
Massively Parallel
Clusters
Uniprocessor has the largest share
Tandem’s architectures:
Enterprise Computing
©Aberdeen Group, 1995
Uniprocessor
●Examples: Compaq PC servers, 
IBM RS/6000's to date, Integrity NR 
entry, each Himalaya node
●No hardware parallelism
●Useful as a software parallelism 
platform
●Easy to design, manufacture, low 
selling price
●Potential entry point for SMP
●Benefits from 75% CAGR in 
processor/system performance
●Problems: No scalability except to 
upgrade CPU.  
Software
Hardware
Operating
System
Task1
Task2
Task3...
©Aberdeen Group, 1995
Symmetric Multiprocessors
●Examples: Tandem Integrity NR, 
HP 9000, IBM ES/9000, many more
●Multiple CPUs share common data 
highway (bus), memory and 
operating system
●Well understood technology.  New 
chip set accelerators. Inexpensive 
engineering.
●Scalability: Good to 4 processors; 
fair to 8; few do more than 10
Software
Hardware
Operating
System
Task1
Task2
Task3
Task4
Task n ...
Memory access is
a big problem
getting worse
Memory & I/O
Processors
©Aberdeen Group, 1995
Clusters
●Examples: Tandem 
Himalaya, Digital VAXcluster, 
IBM SP2 & ES/9000 Sysplex
●Each node can be a 
uniprocessor or SMP
●Multiple, independent 
computing nodes cooperate 
via messages
●Most common use is for 
high availability; second is 
resource sharing
●Issue: Message-passing 
resource expense
Message Bus
Node 1
Node 2
Node 4
OS
Tasks...
©Aberdeen Group, 1995
Cluster Reality
●Problems lie in software
❻Messaging between nodes is a very complex technology. 
Requires time to mature.  Example: Tandem's 20 years of 
experience.
❻Today's system software and customer applications are not 
cluster-enabled.  Require re-engineering to work in a cluster and 
may not scale well unless carefully architected
• Examples: Oracle Parallel Server, IBM ES/9000 Sysplex, SP2
●Trend
❻Distributed operating systems will evolve from a cluster 
technology base
©Aberdeen Group, 1995
Massively Parallel (MPP or SPP)
●Examples: nCube, Kendall 
Square, large Tandem 
Himalaya, large IBM SP2, 
Teradata, AT&T 3600
●No industry-accepted 
definition.  Aberdeen says any 
system with more than 100 
nodes is massive. 
●“Shared nothing” is required.
●Differentiators 
❻Merchant vs. custom micro-
processor
❻Standard (e.g., Unix) vs. 
proprietary architecture
❻Interconnect technology
©Aberdeen Group, 1995
MPP Markets
●Used today by bleeding-edge adopters in highly 
competitive markets
❻Dow Jones text retrieval (Thinking Machines)
❻Prudential Securities (derivatives)
❻American Express (mailing lists)
❻Retail & banking industry (Teradata for data warehousing)
●Market is most likely to evolve with existing large-
computer suppliers rather than MPP new-starts
❻Scale up from clusters: Tandem, IBM SP2, AT&T 3600
❻Possible exception: MPP as pure database platform (not a  
general purpose computer) -- for example, Teradata
©Aberdeen Group, 1995
MPP Reality
●Problems
❻Scalability in the real world.  ServerNet solves real problems.
❻Systems management software is lacking
❻Writing parallel commercial applications without tools
❻Lack of support at small MPP companies
●Aberdeen conclusion is that MPP will remain a 
side show to the SMP and cluster markets, but that 
MPP buyers will come from the attractive World-
1000 base
©Aberdeen Group, 1995
Hardware Supplier Approaches to 
Parallelism
●IBM ES/9000, PTS, SP2
●Hewlett-Packard
●Digital Equipment
●Unisys
●Compaq
●AT&T Global Information Solutions
●Others
©Aberdeen Group, 1995
IBM
●Mainframe markets are driven by largest customers.  Sysplex 
clusters will only appeal to existing customers, lack overall price-
performance value, are slow to mature.
●Parallel Query and Transaction mainframe products are a premature 
product reaction to market share losses to non-mainframe 
competition (i.e., Tandem, HP).  IBM microprocessors are too slow, 
software too limited, prices too high to be effective before 1997.
●SP2 cluster/SPP is all talk, little commercial product.  Awaits parallel 
database software, tools, applications.  Current products are two 
years and a generation from maturity.
●DB2 has four different variations under common product name.  
Technology is is getting better.
●Strategically, IBM cannot concede the parallel market.  Will they be 
the Russian army or the mouse that roared?  Mostly hot air for next 
two years.  Tough choices for water-cooled customers.
©Aberdeen Group, 1995
Hewlett-Packard
●Mediocre in SMP due to focus on ultra-fast RISC 
microprocessors, but improving.  "Fewer is better" 
approach.
●Has next-century microprocessor deal in place with Intel
●Surprisingly weak in clusters, even for high availability
●Appreciates distributed systems management
●Expect better clusters and marketing heat by mid-1995
●HP MPP vague, driven by customers, expected in 1997 or 
later.  Ignore Convex.
●But HP does understand the distributed computing market
©Aberdeen Group, 1995
Digital Equipment
●Good job on low-end SMP.  Fair scalability on high 
end.
●VAXclusters the original shared-resource facility.  
Slowly migrates to Alpha.
●Latest Large In-Memory DB initiative is exciting
●New focus on alternate distribution/box volume 
mentality will likely hurt high end R&D efforts
●Aberdeen is negative on Digital’s long term 
prospects
©Aberdeen Group, 1995
Unisys
●Focus is on maintaining Burroughs and Sperry 
installed bases
●Adequate clustered OLTP today
●Recent MPP plans lack credibility, but work with 
Oracle bears watching
●Unix is not strategic to Unisys, so Intel/SMP will 
progress with market
●Conclusion:  Unisys will be a minor parallel-market 
competitor 
©Aberdeen Group, 1995
Compaq
●Climbing up the enterprise food-chain from 
desktop/workgroup base
●Late 1995 Intel P6-based 4/8-way SMP will beat IBM 
mainframe ES/9000s in OLTP with RDBMS
●"Good enough" for many OLTP & moderate DSS 
applications
●The horse that Microsoft’s NT operating system 
will ride
●Compaq is deliberately delaying a major enterprise 
market thrust due to service concerns
©Aberdeen Group, 1995
AT&T Global Information 
Solutions
●#2 Unix server player with Intel-based line
●Owns the Teradata base of 400+ large sites
●SMPs and 3600 cluster that grows to MPP
●Best company-wide at understanding complex 
DSS issues and experience
●Retail and banking powerhouse.  Weak elsewhere.
●Often the bridesmaid.  More recent management 
changes.  Will they ever get on track?
©Aberdeen Group, 1995
Other Hardware Suppliers
●SMP specialists Sequent and Pyramid/SNI
●ICL Goldrush query parallelization OS features
●nCube's fate rests with Oracle push
●Cray Research invades Wall Street with ex-Tandem 
sales reps
●Kendall Square Research is dead
©Aberdeen Group, 1995
Review of Parallel Software
●SAP AG says "I need 300 SQL statements/second 
today, 3,000 per second in two years."
●Relational databases are the most important 
commercial technology
●Operating systems become more parallel to evolve 
to distributed computing/object world of 1998
●Applications evolve towards distributed computing 
with partitioning and objects
©Aberdeen Group, 1995
Relational Databases (RDBMS)
●New software versions unleash the power of 
parallel hardware
●Complex decision support is the killer application
●Major  suppliers are participating
❻Oracle
❻Sybase
❻Informix
❻IBM DB2
©Aberdeen Group, 1995
Independent Software Supplier 
Parallel Strategies
●Trend: Aberdeen sees a 3x-5x increase in 
information demand by the late 1990s.  Complex 
DSS is the next major hurdle for commercial 
computing.
●Oracle: “Beat IBM mainframes.  Protect Ellison's 
nCube investment.”  Technology is behind.
●Sybase: talks enterprise, does departmental.  
Navigation Server is an embarrassment.
●Informix: Bets the ranch on parallel RDBMS.  
Technology is good but company lacks board-
room visibility.
©Aberdeen Group, 1995
Aberdeen's Viewpoint on 
Tandem in a Parallel World
●Architecture
●Technology
●Markets
©Aberdeen Group, 1995
Architecture
●Tandem ought to be a leader in distributed, object-
based computing
●Tandem understands parallel issues in depth, with 
experience
●Market is recognizing that clustering (loose-
coupling) is required for high-end applications
●Objects communicate via messages.  Tandem 
does this better than others.  The late 1990s will be 
dominated by object-oriented software issues.
●ServerNet is a needed technology that will make 
“data shipping” practical in a distributed world
©Aberdeen Group, 1995
Technology
●Himalaya is at the enterprise-server market sweet-
spot
●Integrity NR/FT cover mass-markets for 
commercial servers.  High availability story great.
●“Open” Tandem will require by 1996 a better DCE 
and distributed-object technology roadmap.
●SGI/MIPS microprocessor faces enormous 
competition from Intel.  However, there are no 
signs that would raise undue concerns.
©Aberdeen Group, 1995
Markets
●Parallel computing profits are being made now in 
competitive-advantage markets (i.e., retail, telecomm, 
transportation, finance) where Tandem is already focused
●Tandem momentum has changed for the positive.  Company 
has a wonderful opportunity to re-establish itself in existing 
markets for new applications
●Best near-term, cross-market opportunity is data 
warehousing (complex decision support).  Tandem has the 
right-stuff technology, but needs partners in teaching buyers 
how to maximize their warehouse investments.
●Dual product strategy (Integrity & Himalaya) makes sense, 
recognizes that one-size-fits-all approach is unrealistic.
©Aberdeen Group, 1995
Backup Information
●The following material supplements the main 
presentation
●See also Aberdeen Group Viewpoints on Tandem, 
Digital Equipment, Parallel-Scalable Databases
©Aberdeen Group, 1995
SMP (cont'd)
●Most system software (e.g., RDBMS) today can 
harness SMP automatically
●Excellent for distributed OLTP nodes, 
departmental decision support
●Problems: Bus bottlenecks, cache coherency, 
memory bandwidth sap performance & growth
●Implementations
❻Poor: IBM AS/400
❻Medium (80% scalability): Hewlett-Packard, IBM ES/9000
❻Good (90%+ scalability): Sequent to 20 processors, SGI/Tandem
©Aberdeen Group, 1995
Clusters (cont'd)
●Excellent for high availability failover, shared-
nothing growth, resource sharing
●System software must be messaging-enabled to 
participate
❻Very uncommon today to find cluster-ready software
❻But distributed computing trend benefits cluster suppliers
❻Next 3 years will see explosion of messaging-aware systems 
software:
• Informix Dynamic Scalable Architecture 8.0 RDBMS
• Sybase Navigation Server
• Common Object Request Broker Architecture (CORBA)
• Distributed Computing Environment (DCE)
©Aberdeen Group, 1995
Informix
●Sub-process (threads) specialized tasks
●Both function and data parallelism
●Cluster and MPP versions in late 1995
●Closest architecture to Tandem with NonStop SQL
●Architecturally superior to competition
©Aberdeen Group, 1995
Oracle
●Parallel Server has VAXcluster roots, severe 
limitations in OLTP
●Parallel Query Option uses Unix process pool vs. 
Informix threads
●160 processor nCube MPP is slower than 20 
processor Sequent SMP
●No data partitioning.  Poor use of indexes 
(Mervyn's).
●Work with DEC on in-memory databases heralds a 
new class of applications for RDBMSs
©Aberdeen Group, 1995
Sybase Navigation Server
●Announced September 1994 for NCR/AT&T 3600 
(cluster).  Available 12/94.
●How it works
❻TP-monitor-like Control server manages execution plan
❻Parallel optimizer generates plan or invokes compiled 
procedure
❻Multiple SQL Server instances execute independently on their 
own data partition
❻Data is partitioned by Range, Hash Key, or schema 
●Problems
❻First version for DSS, not OLTP
❻NCR 3600 lock-in?
❻Not integrated with System 10 servers (i.e., Replication, 
Backup)
©Aberdeen Group, 1995
IBM
●ES/9000 Sysplex: a slowly unfolding cluster 
strategy aimed at IBM's largest mainframe 
customers
●Transactions (PTS): IMS clustered on 13 MIPS 
CMOS-based cluster.  DB2 in 1996.  Too pricey?
●Query (PQS): Query-only DB2 on CMOS-based 
cluster.  Low availability.  ES/9000 required.
●Massive (SP2): viable commercial cluster/MPP 
lacks RDBMS, tools.  IBM locks up the market now 
in evaluations.  Decent products & partners in late 
1996 and 1997.  Future products will obsolete first 
generation SP2 hardware & apps.
©Aberdeen Group, 1995
IBM DB2
●Parallel query I/O in MVS, HQS, and DB2 6000 for SP2
●Version 3 adds basics like stored procedures, triggers.  Still 
functionally weak, but getting better slowly.
●SP2 cluster version of DB2/6000 
❻Customers are going into production without GA 
software!
❻Realistically, a 1996 mainstream product
●DB2/6000
❻Common code base with OS/2
❻Presently works on uniprocessor hardware, moving to 
SMP
❻Considered not competitive with independent RDBMSs
❻IBM bids DB2/6000 against RDBMS partners, spoiling 
relationships
©Aberdeen Group, 1995
Other  Database Software
●Red Brick Software: RDBMS for decision support.  
Adding parallelism for SMPs.
●IRI Software:  Express multidimensional database 
provides Rubic Cube approach to aggregating 
data, instead of brute (parallel) force of merchant 
RDBMSs.
●Prism, Carlton et al:  Large DSS systems will need 
loading/preparation utility products
©Aberdeen Group, 1995
Parallel Operating System Issues
●SMP: How many processes can an OS juggle 
efficiently?
●Distributed OS near-future technology will change 
product requirements dramatically
❻Distributed computing via DCE
❻Distributed objects will turn the network into a big cluster
●Implication: Tandem already has the loosely 
coupled/distributed/parallel experience required to 
lead in this technology migration
©Aberdeen Group, 1995
Data Warehouse Specialists
●Red Brick: an RDBMS optimized for complex DSS
●IRI Software: multidimensional front-end to 
RDBMS and legacy data
●Prism, etc. -- specialists in getting data in and out 
of the warehouse
©Aberdeen Group, 1995
Parallelism in Applications
●High availability: requires a cluster
●Online Transaction Processing (OLTP): spread 
many short tasks over many CPUs
●Messaging applications: electronic mail, workflow, 
store-forward = Comm + transactional I/O
●Simple decision support systems (DSS): does not 
benefit appreciably from parallelism
©Aberdeen Group, 1995
Parallelism in Applications
●Online Analytic Processing (OLAP)/complex DSS
❻Ad hoc decision support by knowledge workers
❻Management by exception approach to work
❻Unknown number of queries -- the "quest"
❻Fast response time a plus.  Parallelism can help.
●Market Basket DSS
❻Large database scans benefit from many kinds of parallelism
❻Find product, customer affinities.  Huge ROI for customers.  
❻Example: large greeting card company
❻An obvious market target for Tandem
©Aberdeen Group, 1995
Parallelism in Applications
●Transaction managers have long parallelized 
available resources (i.e., IBM CICS, Tandem 
Pathway and TMF)
●Next client-server phase requires application 
process partitioning (a form of parallelism)
●Big Caveat: Programmers should NOT have to 
worry about parallelizing their code.  Scientific 
parallel market languished due to lack of  
automatic parallelization.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | bank-of-america-servers-1995-996d67 |
| title | Surfing the Parallel Architectures: A Presentation to Bank of America |
| author | Peter S. Kastner |
| date | 1995-04-05 |
| type | case-analysis |
| subject_domain | parallel-computing / enterprise-server-architecture |
| methodology | industry-analysis |
| source_file | bank-of-america-servers-1995-996d67.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group presentation to Bank of America (April 5, 1995) reviewing the landscape of parallel computing architectures (uniprocessor, SMP, cluster/loosely-coupled, MPP) and their software ecosystems, with a specific focus on Tandem Computer's position in the parallel world. Aberdeen presents its 4-architecture framework with estimated 1995 market share data, evaluates hardware suppliers (IBM, HP, DEC, Unisys, Compaq, AT&T GIS) and parallel software suppliers (Oracle, Sybase, Informix, IBM DB2), and concludes with Aberdeen's viewpoint on Tandem's architecture, technology, and markets.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rare client-facing Aberdeen presentation with explicit market share estimates by parallel architecture type; names specific customer use-cases for MPP; establishes Aberdeen's 4-architecture framework used across multiple studies. |
| **Relevance** | high | Captures the 1995 moment when parallel computing was moving from bleeding-edge to commercial mainstream; Bank of America as a major financial-sector IT buyer makes this an important demand-side perspective. |
| **Prescience** | high | Aberdeen's prediction that MPP would remain a 'side show' to SMP and clusters was largely accurate; Compaq's trajectory beating IBM mainframes predicted correctly; DEC negativity proved prescient. |

### Prescience Detail


**Prediction 1:** mpp_future_role
- **Claimed:** Aberdeen: MPP will remain a side show to SMP and cluster markets; MPP buyers will come from attractive World-1000 base
- **Year:** 1995
- **Confidence at time:** high

**Actual Outcome 1:** mpp_future_role
- **Result:** MPP achieved a significant but specialized role: dominant for large data warehouses (Teradata, Netezza, IBM) but not for general OLTP. SMP won for mainstream enterprise servers. MPP's 'future role' as predicted materialized in analytics but not in general computing.
- **Confidence:** verified
- **Notes:** SMP won general-purpose server market; MPP won data warehouse analytics.

**Prediction 2:** dec_long_term_prospects
- **Claimed:** Aberdeen is negative on Digital's long-term prospects
- **Year:** 1995
- **Confidence at time:** high

**Actual Outcome 2:** dec_long_term_prospects
- **Result:** DEC's long-term prospects proved bleak as predicted: acquired by Compaq in 1998, subsumed by HP in 2002, Alpha discontinued by 2004. The DEC brand and independence did not survive the decade.
- **Confidence:** verified
- **Notes:** DEC ceased to exist as independent entity by 1998.

**Prediction 3:** compaq_mainframe_beating
- **Claimed:** Late 1995 Intel P6-based 4/8-way SMP will beat IBM mainframe ES/9000s in OLTP with RDBMS
- **Year:** 1995
- **Confidence at time:** high

**Actual Outcome 3:** compaq_mainframe_beating
- **Result:** Compaq did grow to challenge mainframe economics for mid-range server workloads by the late 1990s (especially with NT and ProLiant servers), validating the prediction. However, Compaq itself was acquired by HP in 2002 after losing ground to Dell in PCs.
- **Confidence:** high
- **Notes:** Compaq ProLiant servers competed successfully with mainframe-class economics for many workloads by 1997-2001.

**Prediction 4:** unisys_parallel_future
- **Claimed:** Conclusion: Unisys will be a minor parallel-market competitor; Unix not strategic; MPP plans lack credibility
- **Year:** 1995
- **Confidence at time:** high

**Prediction 5:** ncube_oracle_dependency
- **Claimed:** nCube's fate rests with Oracle push; demonstrated that 160-processor nCube MPP is slower than 20-processor Sequent SMP
- **Year:** 1995
- **Confidence at time:** high

**Prediction 6:** distributed_objects_timeline
- **Claimed:** Next 3 years will see explosion of messaging-aware software: Informix DSA 8.0; Sybase Navigation Server; CORBA; DCE
- **Year:** 1995
- **Confidence at time:** medium

**Actual Outcome 6:** distributed_objects_timeline
- **Result:** Distributed objects (CORBA, DCE) were largely superseded by simpler web services (SOAP, REST) and later microservices architectures. CORBA and DCE never achieved the broad adoption predicted; the enterprise middleware market shifted to J2EE application servers and then SOA/REST.
- **Confidence:** verified
- **Notes:** CORBA/DCE failed to win mainstream; replaced by web services standards by early 2000s.


### Entities Referenced (15)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Bank of America | company | public |  |
| IBM (International Business Machines) | company | public |  |
| Hewlett-Packard (HP) | company | spun-off | HP Inc. / Hewlett Packard Enterprise |
| Digital Equipment Corporation (DEC) | company | acquired | Hewlett Packard Enterprise |
| AT&T Global Information Solutions (GIS) | company | evolved | NCR Corporation |
| Tandem Computers | company | acquired | Hewlett Packard Enterprise |
| Sequent Computer Systems | company | acquired | IBM |
| Oracle | company | public |  |
| Sybase | company | acquired | SAP |
| Informix Software | company | acquired | IBM |
| Compaq Computer | company | acquired | Hewlett Packard Enterprise |
| Unisys | company | public |  |
| nCube Corporation | company | acquired | ARRIS (via C-COR) |

### Technologies Referenced (16)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Symmetric Multiprocessing (SMP) | hardware |  | growth | mature |
| Cluster / Loosely-Coupled Computing | hardware |  | emerging | mature |
| Massively Parallel Processing (MPP/SPP) | framework |  | emerging | mainstream |
| Uniprocessor Servers | hardware |  | mainstream | declining |
| Informix Dynamic Scalable Architecture (DSA) 8.0 | database | Informix | emerging | merged-into-IBM-Informix |
| Sybase Navigation Server | database | Sybase | emerging | obsolete |
| Oracle Parallel Server | database | Oracle | emerging | evolved |
| IBM DB2 Parallel (SP2 / MVS) | database | IBM | emerging | evolved |
| IBM SP2 Cluster/MPP | hardware | IBM | emerging | obsolete |
| Tandem Himalaya Server | hardware | Tandem Computers | growth | evolved |
| Tandem Integrity NR and Integrity FT | hardware | Tandem Computers | growth | obsolete |
| ServerNet Interconnect Technology | hardware | Tandem Computers | emerging | evolved |
| Red Brick RDBMS | database | Red Brick Software | emerging | obsolete |
| IRI Software Express (Multidimensional Database) | database | IRI Software | emerging | obsolete |
| Intel P6 Processor | hardware | Intel | emerging | obsolete |
| CORBA and DCE (Distributed Computing Environment) | middleware |  | emerging | evolved |

### Observation Summary

- Total observations: 34
- By type: technology-assessment: 17, market-data: 6, viability-prediction: 6, actual-outcome: 4, expert-opinion: 1
