# Client-Server Development: Moving from Adolescence to Must-Have Mainstream

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | market-study |
| Domain | client-server-development-tools / application-development |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group 32-slide deck surveying the client-server application development tool market estimated at $2-3 billion. Kastner presents Aberdeen's taxonomy of C/S development tool submarkets (3GL, 4GL, Pure OO, CASE, CADE), buyer criteria framework (scalability, flexibility, programmer productivity, software lifecycle support, second-generation technologies), and profiles major suppliers: Microsoft Visual Basic, Powersoft/Sybase PowerBuilder, Oracle Developer/2000, TI Composer/IEF, Seer Technologies, Fortè Software, and Informix NewEra. Includes a market-share chart showing top 10 suppliers by revenue. Central argument: the market is moving from first-generation GUI-centric tools to second-generation tools with application partitioning, business modeling, and scalability to enterprise applications.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 13 |
| technologies.csv | 13 |
| observations.csv | 22 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Client-Server Development: Moving from Adolescence to Must-Have Mainstream.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
