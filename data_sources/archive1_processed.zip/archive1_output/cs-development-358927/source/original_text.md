# Client-Server Development: Moving from Adolescence to Must-Have Mainstream

> Archived from: cs-development-358927.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

© AberdeenGroup 1995   
 
 
 
 
 
 
1
Client-Server Development
Moving from adolescence to must-have mainstream.
© AberdeenGroup 1995   
 
 
 
 
 
 
2
Client-Server Development is Like 
Teenage Sex
• It’s on everyone’s mind all the time
• Everyone is talking about it
• Everyone thinks everyone else is doing it
• The few who actually are doing it are
– doing it poorly
– sure it will be better next time
– not practicing it safely
• Everyone is bragging about their successes, although very few 
have had any successes
© AberdeenGroup 1995   
 
 
 
 
 
 
3
Application Development Software 
Market Size
• Estimate $2-3 billion
– Conservative definition (major suppliers competing 
with each other)
– International supplier sales included
• Majority of sales in US, second most active market 
Europe -- same as hardware markets
• 3GL and Client-server Application Development 
Environment (CADE) sales now largest
• 3GL sales partially bundled by hardware suppliers, so 
underestimated
© AberdeenGroup 1995   
 
 
 
 
 
 
4
Market Characteristics
• An increasing number of application-server sales driven by 
development toolset, not hardware or RDBMS
• Focus on CADE market (where the action is) Key buyer criteria:
– Scalability
– Flexibility
– Programmer productivity
– Software-lifecycle support
– Second-generation technology, especially:
• Application partitioning
• Business modeling
• Channels predominantly low-end but moving toward high end, direct 
sales
• Service emphasizes training, “learning to fish”
© AberdeenGroup 1995   
 
 
 
 
 
 
5
C-S Directions
Second
Generation
Powerful
Object-
Oriented
Scalable
Robust
Cross
-
Platform
Manageable
Application Development Directions
© AberdeenGroup 1995   
 
 
 
 
 
 
6
C-S Application Architectures
User 
presentation
Business 
processes
Data
User 
presentation
Business 
processes
User 
presentation
Business 
processes
Business 
processes
Data
Data
Host-based
1st Generation C-S
2nd Generation  C-S
Shared business
processes
Informix
NewEra
is here
© AberdeenGroup 1995   
 
 
 
 
 
 
7
Comparing Generations
First Generation
•
Plain Windows applications
•
GUI centric
•
Ala carte tools
•
Easy visual environment
•
Desktop & Workgroup DBMS
•
Fat client does all the work
•
Client management an 
afterthought
•
Scales under extreme duress
•
Speedy performance is a 
black art
Second Generation
•
Distributed, cross-platform
•
GUI + DB + Processes
•
Tools Family
•
Life-cycle workbench
•
Unified desktop to enterprise
•
Partitioned, distributed
•
Complete systems 
management
•
Scales up and down
•
Performance by design & 
architecture
© AberdeenGroup 1995   
 
 
 
 
 
 
8
Different Tools for Different Jobs
Source: Aberdeen Group
Tool 
Description
Best Uses
Example
3GL
1st generation 
OO client-server
Pure Object 
3GL
Visual xBase
Enterprise 
Application 
Builder
Object COBOL
System 
infrastructure
Workgroup 
decision 
support
Visual 
prototyping
Workgroup & ad 
hoc apps
Mission critical 
OLTP, DSS
Logic 
investment 
protection
C, C++
Sybase PowerBuilder, 
Visual BASIC
SmallTalk, 
IBM VisualAge
Microsoft FOXpro
INFORMIX NewEra
CA-OPENROAD
MicroFocus COBOL
CA Visual Realia
Tool Classification
© AberdeenGroup 1995   
 
 
 
 
 
 
9
Reducing the Application Backlog
• Choose the right tool for the 
job!
• Give every programmer a big 
PC and develop on a LAN
• Use a GUI programmer’s 
workbench
• Share the development 
repository
0
2
4
6
8
10
1965
1975
1985
1995
Debugged Lines Per Day 
Objective is to improve on 30-year 
average productivity of 10 lines per day
Source: Aberdeen Group
© AberdeenGroup 1995   
 
 
 
 
 
 
10
Visual Programming Environments
• Instead of typing 3GL or 4GLcode
– drag-and-drop or draw to create a GUI item 
– VPE automatically generates the code that goes with it
• Different VPE for every supplier, but many similar features
– Microsoft’s Visual Basic and MFC, Sybase’s PowerBuilder, Forte, 
Oracle’s Developer/2000
– Toolsets increasingly support full software lifecycle but are usually 
supplemented by a 4GL
• Used for rapid development of small to medium-scale GUI desktop 
and client-server applications, and bundled with packaged 
applications
• VPEs can deliver reasonable performance and are approaching 
scalability to large-scale applications
© AberdeenGroup 1995   
 
 
 
 
 
 
11
User Requirements
• In the past, datacenter bought toolsets bundled with the hardware
• In desktop markets, departments and individual developers buy 
cheap toolsets for rapid development of small applications
• IS Buyers now emphasizing buying one server for each new 
application (application server)
– Aim is often to create a competitive-advantage application
– To customize that server, buyers buy a development toolset
• Users often forget today’s leading edge tool leads to tomorrow’s 
legacy application!
© AberdeenGroup 1995   
 
 
 
 
 
 
12
Submarkets:  3GLs
• Price varies widely
– $100 to $5,000 on PC per developer
– $50,000 on mainframe (shared)
• IBM leads bundled suppliers (COBOL)
• Microsoft leads unbundled suppliers (C/C++ compiler)
• Channels:  
– bundled in direct sales 
– retail outlets
– some mail-order
• Service
– You get what you pay for
• Informix:  Compiler add-ons (e.g., pre-compilers)
© AberdeenGroup 1995   
 
 
 
 
 
 
13
Submarkets:  4GLs
• High cost ($2000-$50,000)
– Desktop license at low end
– Mainframe licenses at high end
• RDBMS suppliers have led
– Oracle
– Informix
– Progress
– Ingres (pre-CA)
• CADEs replacing 4GLs (incorporate them)
• Channels:  bundled in direct sales, direct sales, some indirect and 
telemarketing
• Service:  often part of overall service (runtime fees)
• Informix:  Made its fame and fortune on character-based 4GL
© AberdeenGroup 1995   
 
 
 
 
 
 
14
Submarkets:  
Pure Object-Oriented
• Fairly high cost ($1000-$10,000) per seat
• Presently, a small but emerging market 
– IBM VisualAge
– ParcPlace PARTS
– Developers like Microsoft MFC
• Often sold as competitor to CADEs
• Channels:  telemarketing, indirect sales, some mail-order, 
increasing direct sales
• Service:  extensive training
• Issue for Informix:  Selling OO-CADE vs. pure OO to the 
religious zealots
© AberdeenGroup 1995   
 
 
 
 
 
 
15
Submarkets:  CASE
• High cost ($10,000 - $100,000)
• TI the market leader with Composer By IEF
• Second tier suppliers 
– Intersolv
– Cadre
– Knowledgeware
• The acronym CASE is a turn-off to many IS buyers
• Niche market for users with need for ongoing long-lifecycle 
large-scale development
– Channels:  mostly direct sales
– Service:  ongoing consulting
• Informix:  We don’t do CASE, but TI and Cadre can generate 4GL 
native code
© AberdeenGroup 1995   
 
 
 
 
 
 
16
Submarkets:  CADEs
• Three cost tiers 
– Low (free lead-in, $400-1000)
– Moderate ($1000-$3000)
– High-end ($3000-$30,000)
• Many submarkets
– Low-end leader Microsoft, Powersoft second
– RDBMS-supplier leader Oracle
– Most growing at 50%-125% per year
• Increasingly strategic to IS buyer
• Channels:  all types (increasing proportion of direct sales, no runtime 
fees at low end)
• Service:  training, sometimes bundled with consulting and systems 
integration in partnership with hardware and/or RDBMS supplier
• Informix:  NewEra is leading technology for sophisticated, long-term 
developers ... not a throw-away tool
© AberdeenGroup 1995   
 
 
 
 
 
 
17
Buyer Criteria:  
Scalability
• Performance scalability
– speed-up
– processor scale-up
• Development-process scalability
– Managing large IS projects
• Ability to leverage RDBMS technology for scalability
– Very Large Data Bases
– Many OLTP users
© AberdeenGroup 1995   
 
 
 
 
 
 
18
Buyer Criteria:  Flexibility
• Open interoperability
– de facto and de jure standards
– application programming interfaces
– code portability
• Multiarchitecture portability
• Ability to customize toolset 
• Ability to integrate with third-party toolsets and applications
© AberdeenGroup 1995   
 
 
 
 
 
 
19
Buyer Criteria:  Programmer 
Productivity
• Technologies:
– 4GLs/scripting languages
– Visual Programming Environments (VPEs)
– Object-Oriented Technology
© AberdeenGroup 1995   
 
 
 
 
 
 
20
Buyer Criteria:  
Software-Lifecycle Support
• Support for application generation from design specs and full 
integration of all tools across the software lifecycle
• Support for each lifecycle stage:
– Design
– Coding/testing
– Deployment
– Maintenance
© AberdeenGroup 1995   
 
 
 
 
 
 
21
Buyer Criteria:  
Second-Generation Technologies
• Application partitioning
• Business Modeling
• Other
– OLTP monitors
– Workflow/E-mail
– Multimedia and complex data types
© AberdeenGroup 1995   
 
 
 
 
 
 
22
Considerations for Buyers
• Choose a few client-server software tools -- wisely
– Can the software handle your apps now and into 
the future?
– Is the technology usable by mere-mortal 
programmers
– Does the software integrate well
• Buy the software company as well as the technology
– You will live with technology for 5 - 7 years
– Suppliers bring the cook-book & recipes
• Look for integration, synergy, vision, direction, the 
future
© AberdeenGroup 1995   
 
 
 
 
 
 
23
Wrap-up
• CADE is a hot market with enormous changes
• Technology is fast-moving (leapfrogging)
• Users are beginning to emphasize the long term 
– Scalability
– Repositories
– Second-generation technologies
© AberdeenGroup 1995   
 
 
 
 
 
 
24
Application Development Tools 
Market 
(source:  Aberdeen Group Inc..)
Pow erSoft 
Gupta
Seer Technologies
Texas Instruments
Uniface
Oracle
Easel
Microsoft
Informix
Progress
0
100
200
300
400
500
600
Revenue in Millions
Pow erSoft 
Gupta
Seer Technologies
Texas Instruments
Uniface
Oracle
Easel
Microsoft
Informix
Progress
Application Development Tools Market
 -based on revenue
© AberdeenGroup 1995   
 
 
 
 
 
 
25
Supplier Profiles:
Selection Criteria
• Visibility = Perceptions of Industry Influencers
– Microsoft, Oracle, and Sybase/Powersoft are today’s major 
players in revenue terms
– TI is the major player in the CASE submarket and has 
attracted major attention because of its repository deal with 
Microsoft
– Seer Technologies is frequently referenced-sold by IBM 
because of IBM’s lack of client-server development 
technology, and is relatively large ($100 million in revenues)
– Forte is always cited as the second-generation technology 
supplier
• Technology
– All of these suppliers except TI offer new client-server 
development technology that users perceive as valuable
© AberdeenGroup 1995   
 
 
 
 
 
 
26
Microsoft:  Visual Basic
• Focus on low end (desktop and PC LAN)
– Sells ease of use, de facto standard
– High visibility in IS shops
• Largest unit sales of any CADE supplier
– Claims 4 million developers
– Most channels (retail, indirect, direct)
• Minimal service, no runtime fees
• Key to the future:  OLE for distributed objects
– Moving slowly toward high end
– Selling OLE as standard basis for CADE client (aims to own 
the components)
– Keep Visual Basic in sync with Visual C++, Microsoft Access 
toolset
© AberdeenGroup 1995   
 
 
 
 
 
 
27
Powersoft (Sybase)
• Shrink-wrap/IS developer dual market strategy
– Sells “easy entry into client-server programming”, de facto 
standard due to high market penetration
– High visibility in IS shops
• Second to Microsoft in unit sales
– Claims approaching one million developers; 125% CAGR
– Both indirect and direct sales ... revenue neutral comp plan
– But Sybase and Powersoft sales forces are not integrated
• Weaknesses
– Thoroughly tied to Windows.  Not cross-platform
– No character-terminal support
– Poor scalability, no repository
– Client-only; no help for server part of application
© AberdeenGroup 1995   
 
 
 
 
 
 
28
Oracle Developer/2000
• Focus on high end
– Sell broad functionality, cross-platform support
– Workgroup and impressive high-end Developer/2000 
products, separate CASE product (Designer/2000) moved from 
UNIX to Windows
• Strong installed base
– Doing better than Oracle Applications, but well below Oracle 
RDBMS sales growth rates
– Mostly direct sales, often bundled with Oracle RDBMS and 
services/consulting
– Concerned primarily with Microsoft & Sybase
• Weaknesses
– Developer/2000 is new skin on old CDE toolset
– Forms 4.5 is starting to be Windows-competitive
– Only decent OO tool is Oracle Objects, a VB clone and 
incompatible with Developer/2000 tools
© AberdeenGroup 1995   
 
 
 
 
 
 
29
TI Composer by IEF
• Focus on very high end, CASE-oriented
– Sells leadership in CASE market, methodology
– New Composer CADE product hasn’t yet implemented many 
second-generation features
– TI-Microsoft repository joint development project in question
• Dominates mature CASE market
– Over $100 million in CASE revenues
– Direct sales by dedicated reps
• Service emphasizes training in methodology
• The future:
– Difficulty migrating from mainframe apps market to CADE 
market
– No clear delivery date for repository
– Client-server technology outpaces ability to generate apps
© AberdeenGroup 1995   
 
 
 
 
 
 
30
Seer Technologies
• Focus on high end
– Sells broad second-generation technology with consulting/SI
• Application partitioning
• Business modeling
• Mainframe-as-server emphasis
• Approaching $100 million in revenues
– Moving out of IBM’s shelter (IBM has resold Seer, as IBM 
lacks a good CADE story)
– Direct sales
• Emphasize service, including systems integration, training, 
support
• The future:
– Recent IPO
– Expanding second-generation capabilities
© AberdeenGroup 1995   
 
 
 
 
 
 
31
Fortè Software
• Focus on high end
– Sell leadership in application partitioning second-generation 
technology
• Start-up Company
– Exceptional visibility
– $6 million in revenues estimated in less than 2 quarters
– Deep $30M venture-capital pockets
– Some joint projects with Digital
– Direct sales model
• Services a key source of revenue
– Training in how to do application partitioning
• The future:
– Next release fills holes (more platforms, business modeling)
© AberdeenGroup 1995   
 
 
 
 
 
 
32
Positioning NewEra
• NewEra deserves a long, hard look
– Leading-edge OO-CADE
– Full object model
– Second-generation hot-buttons (partitioning, x-platform, 
scalability, OO, full Windows support)
– Informix core and third-party class library support builds an 
add-on business around the tool
• Selling strategy
– Qualify on need/desire for complex tool with long-term legs
– Demand an in-depth evaluation
– Go for the pilot project with a few in-house zealots
– Cost issues aside, NewEra is great for Informix ISVs


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | cs-development-358927 |
| title | Client-Server Development: Moving from Adolescence to Must-Have Mainstream |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | market-study |
| subject_domain | client-server-development-tools / application-development |
| methodology | industry-analysis |
| source_file | cs-development-358927.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group 32-slide deck surveying the client-server application development tool market estimated at $2-3 billion. Kastner presents Aberdeen's taxonomy of C/S development tool submarkets (3GL, 4GL, Pure OO, CASE, CADE), buyer criteria framework (scalability, flexibility, programmer productivity, software lifecycle support, second-generation technologies), and profiles major suppliers: Microsoft Visual Basic, Powersoft/Sybase PowerBuilder, Oracle Developer/2000, TI Composer/IEF, Seer Technologies, Fortè Software, and Informix NewEra. Includes a market-share chart showing top 10 suppliers by revenue. Central argument: the market is moving from first-generation GUI-centric tools to second-generation tools with application partitioning, business modeling, and scalability to enterprise applications.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Establishes Aberdeen's C/S development tool taxonomy and buyer criteria framework; includes rare market-size and vendor revenue data for 1995 CADE market. |
| **Relevance** | high | Documents the 1995 state of the client-server development tools market at the inflection point between first-generation (Visual Basic) and second-generation (partitioned, scalable, OO) approaches. |
| **Prescience** | medium | Aberdeen correctly identified PowerBuilder's Windows-only limitation as weakness; correctly identified Microsoft's trajectory toward owning the components via OLE; CADE market consolidation predicted accurately. |

### Prescience Detail


**Prediction 1:** ole_future_strategy
- **Claimed:** OLE for distributed objects is key to Microsoft's future; aims to own the components; moving VB toward high end
- **Year:** 1995
- **Confidence at time:** medium

**Actual Outcome 1:** ole_future_strategy
- **Result:** Microsoft's OLE/COM strategy evolved into COM+, then .NET, and eventually WCF and modern APIs. OLE as a distributed objects strategy was largely abandoned in favor of .NET and web services by 2002-2005. Microsoft's distributed object vision was partially validated but the specific OLE mechanism was retired.
- **Confidence:** medium
- **Notes:** OLE evolved into COM/COM+ then .NET; the distributed objects vision partially materialized via .NET remoting and later WCF.

**Prediction 2:** ti_cade_transition
- **Claimed:** Difficulty migrating from mainframe apps market to CADE market; no clear delivery date for repository; client-server technology outpaces ability to generate apps
- **Year:** 1995
- **Confidence at time:** high


### Entities Referenced (13)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Microsoft | company | public |  |
| Oracle | company | public |  |
| Sybase | company | acquired | SAP |
| Powersoft Corporation | company | acquired | SAP (via Sybase) |
| Informix Software | company | acquired | IBM |
| Texas Instruments (TI) | company | public |  |
| Seer Technologies | company | acquired | Blue Phoenix Solutions (via Level 8 Systems) |
| Fortè Software | company | acquired | Sun Microsystems / Oracle |
| IBM (International Business Machines) | company | public |  |
| Progress Software | company | public |  |
| Gupta Technologies | company | acquired | OpenText |

### Technologies Referenced (13)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Client-Server Application Development Environment (CADE) | framework |  | growth | obsolete |
| Microsoft Visual Basic | application | Microsoft | growth | declined |
| Sybase PowerBuilder | application | Powersoft/Sybase | growth | declined |
| Informix NewEra | application | Informix | emerging | obsolete |
| Oracle Developer/2000 | application | Oracle | growth | declined |
| TI Composer by IEF | application | Texas Instruments | mature | declined |
| Seer Technologies HPS | application | Seer Technologies | emerging | obsolete |
| Fortè Application Environment | application | Fortè Software | emerging | obsolete |
| OLE for Distributed Objects (Microsoft) | middleware | Microsoft | emerging | declined |
| Pure Object-Oriented Development Tools | framework |  | emerging | mainstream |
| CASE Tools (Computer-Aided Software Engineering) | framework |  | declining | niche |
| Visual Programming Environments (VPE) | framework |  | growth | mainstream |
| Second-Generation Application Partitioning | framework |  | emerging | mainstream |

### Observation Summary

- Total observations: 22
- By type: market-data: 7, technology-assessment: 7, framework-factor: 3, viability-prediction: 2, strategy-classification: 1, actual-outcome: 1, expert-opinion: 1
