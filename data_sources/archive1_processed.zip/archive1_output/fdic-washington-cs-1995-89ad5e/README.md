# Client-Server Computing: Presentation to FDIC and Washington-Area Audience

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-01-01 |
| Type | case-analysis |
| Domain | client-server-computing / government-IT / operating-systems |
| License | CC-BY-4.0 |

## Abstract

Highly text-sparse 81-page Aberdeen Group slide deck (presenter notes only, most slides blank or page-numbered only) presented to the FDIC and a Washington DC-area audience on client-server computing in 1995. The surviving text covers: Aberdeen's four-tier computing framework; OS survey including IBM MVS, proprietary midrange (walking dead vs. robust giants), IBM AS/400, Unix, workgroup OSs (OS/2, Windows NT), Novell NetWare, and Microsoft NT; key OS challenge: distributed transaction processing, data replication, directory services, security, and data warehousing. NT BackOffice cited at $500M; Microsoft's bet-the-business strategy to migrate from AS/400 to NT/SAP noted. The deck is almost entirely in speaker-notes format with minimal slide bullet content.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 9 |
| technologies.csv | 10 |
| observations.csv | 20 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Client-Server Computing: Presentation to FDIC and Washington-Area Audience.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

industry-analysis
