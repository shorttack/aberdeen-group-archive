# Client-Server Computing: Presentation to FDIC and Washington-Area Audience

> Archived from: fdic-washington-cs-1995-89ad5e.txt
> Original publication date: 1995-01-01
> Author: Peter S. Kastner

---

## Original Document Text

1995 Aberdeen Group Inc.
1
1995 Aberdeen Group Inc.
2
1995 Aberdeen Group Inc.
3
Here is the environment that an OS has to operate in today
Four-tier computing
Today’s Oss are faced with:
- Distributed transaction processing
- Data replication
- Directory services
- Security is much complicated
- Data warehousing has its own style of computiing
1995 Aberdeen Group Inc.
4
1995 Aberdeen Group Inc.
5
1995 Aberdeen Group Inc.
6
The goal of an OS is to save time and effort by your application 
programmers
Most OSs evolved to solve computing problems of the time:
- IBM’s MVS for batch multiprocessing
- Digital’s VAX VMS for timesharing
- Microsoft Windows as a GUI on cryptic DOS
Segway:  Today’s computing requirements are a long way from the 
historical roots of many OSs
1995 Aberdeen Group Inc.
7
Here is the environment that an OS has to operate in today
Four-tier computing
Today’s Oss are faced with:
- Distributed transaction processing
- Data replication
- Directory services
- Security is much complicated
- Data warehousing has its own style of computiing
1995 Aberdeen Group Inc.
8
IT organizations face significant problems in implementing enterprise-wide 
systems due in part to a lack of integrated services that could be found in 
an OS.  Instead, IT is making its own hand-crafted solutions.
1995 Aberdeen Group Inc.
9
Rest of the talk focuses on a survey of the industry’s major OSs -- and 
their suppliers.  
You have to look at the overall condition and strategies of the suppliers to 
be able to predict what is likely to happen to the supplier’s OS products
1995 Aberdeen Group Inc.
10
MVS will be around as long as I am alive -- another 40 years or so.
MVS is so critical to IBM’s most important customers -- suicide to halt 
support.  But note IBM’s willingness to drop out of the water-cooled 
bipolar battle
Bullet 1
Bullet 2 -- Modifying MVS is ridiculously difficult -- cannot induce errors, 
old architecture
Bullet 3 -- IBM is gradually rewriting large parts of MVS in C language.  
But tail is too large to allow market-leading fast responses.  Bad idea to 
short CA stock as surround needs for a long time.
1995 Aberdeen Group Inc.
11
Midrange is the fastest growing market segment $25K-$1M US
Midrange systems evolved from “poor man’s mainframe” base
Many styles of computing: early support for online, but character
Dragged into graphical world but (mostly) quick to pounce on client-server
Market is bipolar between the walking dead proprietary zombies and the 
robust giants
1995 Aberdeen Group Inc.
12
Suppliers cannot invest in proprietary midrange OS development because 
sales volumes have dropped off a cliff and the suppliers are trying to 
maintain profit margins
Nevertheless, computing inertia -- and those profit margins -- will keep 
these systems obsolescent but viable well into the next century
1995 Aberdeen Group Inc.
13
King of the proprietary midrange  vs.  Renewed health 
Lou Gerstner realizes the AS/400 is a profit cow, so expect continued 
rapid investments
Aberdeen is (pleasantly) surprised at how fast IBM has responded to 
market pressures .  However, they are having continued troubles in 
meeting their own dates for hardware and software delivery.
You could run a pretty large size company (I.e., Microsoft) with AS/400s 
and distributed computing
1995 Aberdeen Group Inc.
14
The panacea of Unix as a “one size fits all” is just a pipe-dream
Every Unix is different in the value-added enhancements.  You would be 
foolish not to take advantage of enhancements (e.g., Sun RDBMS file 
system).
Note all the Unix ISVs do custom ports to each Unix -- at great cost in 
support & R&D (see NT)
Unix can run any commercial application except maybe bank check-
processing
1995 Aberdeen Group Inc.
15
Over the last 5 years many of the world’s brightest OS developers have 
been working on the desktop and workgroup Oss
The workgroup computing unit with its clients and servers is a 
fundamental building block to geographically distributed offices, 
warehouses, agencies, branches, and stores
Workgroup computers including desktops now consumes the biggest 
segment of IT capital budgets, so it’s important
1995 Aberdeen Group Inc.
16
Bullets
Controversy: will IBM abandon OS/2.  Accountants say yes.  Customers 
say no (and win so far).
Opportunity Lost:  Leap Intel/Microsoft with PowerPersonal, OS/2 and 
voice UI
1995 Aberdeen Group Inc.
17
Comments:
1996:  
Windows 95 for average commercial “secretarial” desktop
NT for business-critical client-server applications
Write applications to the Windows 95 UI, use 32-bits as 
appropriate
1995 Aberdeen Group Inc.
18
NetWare 4.1 covers little new ground
AppWare is late
What business is Novell in?  Just rejected $4 bilion IBM offer.
1995 Aberdeen Group Inc.
19
NT Backoffice is a $500 million (US) business
NT/SQL Server 6.0/DEC Alpha outstanding performance, P/P..
Microsoft’s bet-the-business IT strategy is to migrate from AS/400 to 
NT/SAP
Issues
Modest scalability with 3 Alpha processors.  Note AT&T 
GIS work
Apps are on Intel
Where do we get 1st class, in-depth service & consulting
NT Server is not enough.  Unicenter on NT example of coopetition
1995 Aberdeen Group Inc.
20
Near-term issues from IT organizations to OS suppliers
1995 Aberdeen Group Inc.
21
1995 Aberdeen Group Inc.
22
1995 Aberdeen Group Inc.
23
1995 Aberdeen Group Inc.
24
1995 Aberdeen Group Inc.
25
1995 Aberdeen Group Inc.
26
1995 Aberdeen Group Inc.
27
1995 Aberdeen Group Inc.
28
1995 Aberdeen Group Inc.
29
1995 Aberdeen Group Inc.
30
1995 Aberdeen Group Inc.
31
1995 Aberdeen Group Inc.
32
1995 Aberdeen Group Inc.
33
1995 Aberdeen Group Inc.
34
1995 Aberdeen Group Inc.
35
1995 Aberdeen Group Inc.
36
1995 Aberdeen Group Inc.
37
1995 Aberdeen Group Inc.
38
1995 Aberdeen Group Inc.
39
1995 Aberdeen Group Inc.
40
1995 Aberdeen Group Inc.
41
1995 Aberdeen Group Inc.
42
1995 Aberdeen Group Inc.
43
1995 Aberdeen Group Inc.
44
1995 Aberdeen Group Inc.
45
1995 Aberdeen Group Inc.
46
1995 Aberdeen Group Inc.
47
1995 Aberdeen Group Inc.
48
1995 Aberdeen Group Inc.
49
1995 Aberdeen Group Inc.
50
1995 Aberdeen Group Inc.
51
1995 Aberdeen Group Inc.
52
1995 Aberdeen Group Inc.
53
1995 Aberdeen Group Inc.
54
1995 Aberdeen Group Inc.
55
1995 Aberdeen Group Inc.
56
1995 Aberdeen Group Inc.
57
1995 Aberdeen Group Inc.
58
1995 Aberdeen Group Inc.
59
1995 Aberdeen Group Inc.
60
1995 Aberdeen Group Inc.
61
1995 Aberdeen Group Inc.
62
1995 Aberdeen Group Inc.
63
1995 Aberdeen Group Inc.
64
1995 Aberdeen Group Inc.
65
1995 Aberdeen Group Inc.
66
1995 Aberdeen Group Inc.
67
1995 Aberdeen Group Inc.
68
1995 Aberdeen Group Inc.
69
1995 Aberdeen Group Inc.
70
1995 Aberdeen Group Inc.
71
1995 Aberdeen Group Inc.
72
1995 Aberdeen Group Inc.
73
1995 Aberdeen Group Inc.
74
1995 Aberdeen Group Inc.
75
1995 Aberdeen Group Inc.
76
1995 Aberdeen Group Inc.
77
1995 Aberdeen Group Inc.
78
1995 Aberdeen Group Inc.
79
1995 Aberdeen Group Inc.
80
1995 Aberdeen Group Inc.
81


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | fdic-washington-cs-1995-89ad5e |
| title | Client-Server Computing: Presentation to FDIC and Washington-Area Audience |
| author | Peter S. Kastner |
| date | 1995-01-01 |
| type | case-analysis |
| subject_domain | client-server-computing / government-IT / operating-systems |
| methodology | industry-analysis |
| source_file | fdic-washington-cs-1995-89ad5e.txt |
| license | CC-BY-4.0 |

### Abstract

Highly text-sparse 81-page Aberdeen Group slide deck (presenter notes only, most slides blank or page-numbered only) presented to the FDIC and a Washington DC-area audience on client-server computing in 1995. The surviving text covers: Aberdeen's four-tier computing framework; OS survey including IBM MVS, proprietary midrange (walking dead vs. robust giants), IBM AS/400, Unix, workgroup OSs (OS/2, Windows NT), Novell NetWare, and Microsoft NT; key OS challenge: distributed transaction processing, data replication, directory services, security, and data warehousing. NT BackOffice cited at $500M; Microsoft's bet-the-business strategy to migrate from AS/400 to NT/SAP noted. The deck is almost entirely in speaker-notes format with minimal slide bullet content.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | medium | Text-sparse but captures Aberdeen's OS landscape framework for government/banking IT audiences; includes rare NT BackOffice revenue figure and IBM AS/400 strategy commentary. |
| **Relevance** | high | FDIC as government banking regulator audience makes this significant for understanding how Aberdeen's client-server message was adapted for regulated industries and federal IT buyers. |
| **Prescience** | medium | Aberdeen's characterization of proprietary midrange as bipolar between 'walking dead' and 'robust giants' proved accurate; NT adoption trajectory and AS/400 as IBM profit cow proved correct. |

### Prescience Detail


**Prediction 1:** proprietary_midrange_survival
- **Claimed:** Computing inertia — and profit margins — will keep proprietary midrange systems obsolescent but viable well into the next century
- **Year:** 1995
- **Confidence at time:** high

**Prediction 2:** os_roadmap_1996
- **Claimed:** 1996 prediction: Windows 95 for average commercial/secretarial desktop; NT for business-critical client-server applications; write apps to Windows 95 UI; use 32-bits as appropriate
- **Year:** 1995
- **Confidence at time:** high

**Actual Outcome 2:** os_roadmap_1996
- **Result:** Microsoft's OS roadmap converged on Windows NT as the enterprise platform by 1996-2000 (Windows NT 4.0 in 1996, Windows 2000 in 2000). Windows 95 for consumers and NT for servers became the predicted split. The roadmap played out largely as forecast.
- **Confidence:** verified
- **Notes:** Windows NT 4.0 (1996) and Windows 2000 (2000) confirmed the OS roadmap prediction.


### Entities Referenced (9)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Federal Deposit Insurance Corporation (FDIC) | government | active |  |
| IBM (International Business Machines) | company | public |  |
| Microsoft | company | public |  |
| SAP | company | public |  |
| Digital Equipment Corporation (DEC) | company | acquired | Hewlett Packard Enterprise |
| AT&T Global Information Solutions (GIS) | company | evolved | NCR Corporation |
| Novell | company | acquired | Micro Focus / OpenText |

### Technologies Referenced (10)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Four-Tier Computing Architecture | framework |  | emerging | evolved |
| IBM MVS | platform | IBM | mature | niche-mission-critical |
| IBM AS/400 | hardware | IBM | mature | evolved |
| Microsoft Windows NT | platform | Microsoft | emerging | evolved |
| Microsoft Windows 95 | platform | Microsoft | emerging | declined |
| Unix as Universal Platform | platform |  | growth | mature |
| IBM OS/2 | platform | IBM | declining | declined |
| Novell NetWare 4.1 | platform | Novell | mature | declined |
| Workgroup Computing / Workgroup OS | platform |  | growth | evolved |
| Proprietary Midrange Operating Systems | platform |  | declining | declined |

### Observation Summary

- Total observations: 20
- By type: technology-assessment: 9, actual-outcome: 4, expert-opinion: 3, viability-prediction: 2, framework-factor: 1, market-data: 1
