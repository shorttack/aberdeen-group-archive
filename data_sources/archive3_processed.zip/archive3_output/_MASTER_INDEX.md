# Kastner Video Transcript Archive — Master Index (Archive-3)

> **Archive-3** | Archival Ingest Skill v16 | Processed 2026-04-09
> Peter S. Kastner video appearances: commercials, presentations, and TV programs

## Summary Statistics

| Metric | Count |
|--------|-------|
| Studies | 7 |
| Date range | 1994–2003 |
| Unique entities (inc. Archive-2 cache) | 85 |
| Unique technologies (inc. Archive-2 cache) | 106 |
| Total observations | 103 |

## Observation Types

- **expert-opinion**: 25
- **technology-assessment**: 24
- **actual-outcome**: 18
- **market-data**: 14
- **viability-prediction**: 11
- **framework-factor**: 5
- **strategy-classification**: 3
- **benchmark-result**: 3

## Studies (Chronological)

| Title | Year | Importance | Relevance | Prescience | Entities | Technologies | Observations |
|-------|------|-----------|-----------|-----------|---------|-------------|-------------|
| [Software 2000 — IT Strategy and Client-Server Transition](transcript-software-2000-f16f5b/README.md) | 1994 | high | high | high | 3 | 5 | 15 |
| [Sybase XI Launch — Kastner Analyst Endorsement](transcript-sybase-xi-launch-4b9753/README.md) | 1995 | medium | high | high | 3 | 6 | 8 |
| [Tandem Himalaya Server — Airport Dream Commercial](transcript-tandem-airport-commercial-9e163b/README.md) | 1995 | high | high | high | 13 | 6 | 17 |
| [Oracle Data Warehousing Launch](transcript-oracle-data-warehousing-launc-f4b560/README.md) | 1996 | medium | high | high | 3 | 6 | 15 |
| [Portal Software Inside Business](transcript-portal-software-inside-busine-f4aefd/README.md) | 1998 | medium | high | high | 5 | 5 | 16 |
| [SARS Impact on Electronics Industry — CNBC Morning Call (April 3, 2003)](transcript-sars-cnbc-4-3-2003-6325e7/README.md) | 2003 | high | high | high | 8 | 3 | 17 |
| [SARS Economic Impact — NBC Nightly News (April 3, 2003)](transcript-sars-nbc-nightly-news-segment-4e22a6/README.md) | 2003 | high | high | high | 7 | 2 | 15 |

## Collection Notes

- **SARS pair (2003)**: Two same-day appearances (CNBC and NBC Nightly News, April 3 2003) — Kastner commenting on SARS economic/business impact, not IT. Unique in the collection as non-IT subject matter.
- **Sybase XI clip**: Very short (1 min); 8 observations is the correct count, not padded.
- **Cache efficiency**: 10 of 28 entities and 4 of 10 technologies resolved directly from Archive-2 cache without additional web lookups.
- All `[DEFERRED]` fields resolved via Phase 3 web verification.

## Repository

`github.com/shorttack/aberdeen-group-archive`

## License

CC-BY-4.0 — Peter S. Kastner
