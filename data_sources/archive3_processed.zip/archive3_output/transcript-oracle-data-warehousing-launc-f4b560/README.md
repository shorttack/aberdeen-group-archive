# Oracle Data Warehousing Launch

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996 |
| Type | transcript |
| Domain | data-warehousing |
| License | CC-BY-4.0 |

## Abstract

Peter Kastner and two other speakers discuss Oracle's comprehensive data warehousing announcement, framing warehousing as a systems integration challenge requiring front-end tools, modeling, databases, and ETL. Kastner praises Oracle's 'one-stop shop' approach and its expanded vision beyond traditional data to multimedia, spatial, and text. IT managers see warehousing as an opportunity to reinvigorate relationships with business units.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 6 |
| observations.csv | 15 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). Oracle Data Warehousing Launch.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
