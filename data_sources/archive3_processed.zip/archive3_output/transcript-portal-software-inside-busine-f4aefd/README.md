# Portal Software Inside Business

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1998 |
| Type | transcript |
| Domain | internet-billing-infrastructure |
| License | CC-BY-4.0 |

## Abstract

A promotional/documentary video about Portal Software (Cupertino), featuring Peter Kastner of Aberdeen Group and a Juno Online Services representative. Kastner validates Portal's Infranet billing platform as the first architected for service-oriented internet, noting Aberdeen Group research shows success in 'second surgery' (companies rebuilding failed internet sites). Juno (6M free email accounts, 2nd largest dial-up ISP after AOL) deployed Infranet in H1 1998.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 5 |
| technologies.csv | 5 |
| observations.csv | 16 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1998). Portal Software Inside Business.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
