# Portal Software Inside Business

> Archived from: /home/user/workspace/archive3_raw/transcript-portal-software-inside-busine-f4aefd.txt
> Original publication date: 1998
> Author: Peter S. Kastner

---

## Original Document Text



Portal Software Inside Business

⏰Sat, 11/16 16:20PM · 8mins

AI Notes

 
 Summary
 The transcript discusses the evolution of online services and the challenges companies face in setting up infrastructure to offer, manage, and bill for these services. Portal Software, a company in Cupertino, is highlighted as providing software solutions to help businesses become an Internet presence and power. The discussion emphasizes the need for real-time, flexible customer management and billing systems in the fast-paced Internet environment. Portal's software, Infranet, is presented as a solution for real-time management of online services, offering features like complex pricing models and quick deployment. The transcript includes testimonials from industry experts and clients, emphasizing the importance of flexibility, time-to-market, and strategic advantage in the competitive online service landscape. The discussion concludes by highlighting Portal's vision of providing infrastructure for Internet business growth since 1985.
 Chapters
00:00:42 The shift to online services and infrastructure challenges
 Speaker0 introduces the shift in the communications industry towards online services based on Internet Protocol. They highlight the challenge for companies to set up infrastructure for offering, managing, and billing these diverse services.
00:01:07 Portal Software's solution for Internet businesses
 Speaker0 introduces Portal Software, a Cupertino-based company offering software solutions to help businesses become an Internet presence and power.
00:01:28 The need for real-time customer management and billing
 Speaker1 emphasizes the competitive nature of the Internet and the need for real-time, flexible customer management and billing systems. Speaker0 adds that companies unable to manage in real-time risk being overtaken by next-generation competitors.
00:02:17 Benefits of real-time customer management and billing
 Speaker0 explains how real-time customer management and billing infrastructure can improve customer satisfaction through immediate service availability, special offers, and up-to-date account information.
00:02:57 Portal's Infranet software for real-time management
 Speaker0 introduces Portal's Infranet software, designed for real-time management of online services. They highlight its ability to support strategic initiatives, new services, pricing, and target markets in real-time.
00:04:21 Flexible pricing and market responsiveness
 Speaker2 and Speaker0 discuss Infranet's powerful rating engine, which allows for complex pricing and discounting models. They emphasize the importance of quickly rolling out new pricing plans to attack new markets or react to competitive pressures.
00:04:48 Case study: Juno's implementation of Portal software
 Speaker2, representing Juno, shares their experience with Portal's software, highlighting the quick deployment and effective billing for their 6 million free email accounts.
00:05:39 Advantages of off-the-shelf solutions
 Speaker0 discusses the benefits of using flexible off-the-shelf solutions like Portal's software, allowing companies to focus on their core business instead of developing infrastructure systems from scratch.
00:07:00 Portal's vision and long-term focus
 Speaker0 concludes by sharing Portal's consistent vision since 1985 of providing infrastructure for Internet business growth, emphasizing their long-term focus and execution towards this goal.
 Action Items
00:01:59 Companies need to implement real-time, flexible customer management and billing systems to remain competitive in the fast-paced Internet environment.
00:03:13 Service providers should consider adopting software solutions like Portal's Infranet for real-time management of online services.
00:04:38 Businesses should leverage flexible pricing tools to quickly respond to market changes and competitive pressures.
00:05:57 Companies should evaluate off-the-shelf solutions for billing and infrastructure to focus on their core business.
00:05:14 Internet service providers need to ensure their systems can handle rapid deployment of new services and promotions.

Transcript

Speaker 1 
It's no secret anymore that online services are the next-generation business model, thanks to a huge shift in the communications industry from traditional circuit switch networks to amazing new IP or Internet protocol. 

Speaker 1 
Online games, web hosting and video conferencing and more are now available to Internet users. The problem is how do companies set up an infrastructure to offer, manage and bill for this wide variety of services. 

Speaker 1 
After all, it's one thing to come up with a business idea, it's another thing to get the business to actually work. Well, one company in Cupertino called Portal Software has software solutions to help these companies not only become an Internet presence, but also become an Internet power. 

Peter Kastner 
The internet is truly a dog eat dog competitive world. We just can't use the technology that we used to in the past. Because of that, all of our traditional infrastructure things like billing, they used to work fine on a 30 or 45 day cycle, don't work anymore. 

Peter Kastner 
We need to allow customers to turn on a dime, try new services right away. 

Speaker 1 
The internet changes so fast that companies are really forced to be able to be extremely flexible in terms of what the services that they are offering and how they offer those services. You can't manage things in real time. 

Speaker 1 
You're going to be washed away by the new wave of next generation competitors. Next generation competitors are all moving to real time, highly flexible customer management billing systems because that traditionally has been the single biggest constraint in satisfying your strategic needs for the services, the customers, and the revenues. 

Speaker 1 
Not just a simple back office function anymore, a real time customer management and billing infrastructure can help service providers improve customer satisfaction by providing immediate availability of new services, making special offers to customers while they are online or by having up to the minute account information available for customer review. 

Speaker 1 
Well the whole approach of billing has fundamentally changed from the old world, which you can see quite commonly in the telephony world. You make a telephone call, a month or two later, you get a bill. 

Speaker 1 
The new world is a complete customer interaction, signing the customer up, tracking everything he's doing, rolling out the new service, providing that service, figuring out what he's done, charging him money. 

Speaker 1 
So you're maintaining that whole customer interaction in one compact integrated package rather than all these disparate systems that are doing different parts of it. Portal, a Silicon Valley software company, provides software called Infranet for the real time management of an unlimited spectrum of online services. 

Speaker 1 
Portal markets customer management and billing software for IP or internet services providers. What we've got now is a billing system that can basically provide support for any strategic initiative. New services, new pricing, new target markets, and we can do it in real time. 

Speaker 1 
I'm not just talking about presenting a bill in real time, we're talking about interacting with the customer and managing them in real time so that while they're playing a game I can offer to sell them more ammunition. 

Speaker 1 
While they're in a video conference, they can increase the bandwidth if they want a higher resolution and if, for instance, I detect fraud, I can cut them off in real time. The power of the Portal software is that our customers know exactly what their customers are doing, who they are, what they're doing, what they like, how they can make more money from those customers, how they can maintain a long term profitable customer relationship. 

Speaker 1 
If it turns out that web based publishing models turn out to be the way that everybody is going to make money, infronets in a position to take care of that. If it turns out that different pricing plans for consumer internet access are the wave of the future, well then the software is capable of handling that. 

Speaker 3 
one of the unique features of our software is that we have a 

Speaker 1 
very powerful rating engine that provides a tremendous amount of functionality for building complex pricing and discounting models, yet a very easy to use graphical tool that allows just about anyone to set up those complex pricing models. 

Speaker 1 
The significance of being able to roll out new pricing plans quickly and easily is that our customers can attack new markets and create a competitive edge over their competition or react to competitive pressures. 

Speaker 3 
very, very quickly. Juneau's History is a dial-up free email provider. We have over six million free email accounts. That makes us the second largest provider of dial-up internet access in the country after America Online. 

Speaker 3 
The key benefit that we've derived from Portal is time to market. With Portal, we were able to buy a billing system in early 98 and we had it deployed by the middle of 98 and efficiently and effectively billing our customers when we launched the service in July. 

Speaker 1 
In a meeting this morning, we had about six different product managers that wanted to introduce 128 different promotions within a period of two weeks. You can imagine the impact that has on our customer care system and our billing systems. 

Speaker 1 
We have to have systems that help us strategically meet the needs of that marketplace, and they need to be flexible, and they need to be reliable, and they need to be in a position that we can modify the characteristics of as quickly as possible. 

Speaker 1 
So we scanned the environment for a flexible customer care and billing system and evaluated our various options and selected portal billing software as our solution. Having such a flexible off-the-shelf solution allows companies to do what they do best instead of spending valuable time developing software. 

Speaker 1 
We were to go off and begin to develop our billing and infrastructure systems from scratch, rebuild the architecture. It would literally be an unending process. We would never really finish the job. So going out and finding a third-party vendor that provides that service to us and they dedicate themselves to providing that capability gives us the ability to focus on what's important for our business, 

Speaker 1 
and that's providing internet service to our customers. 

Peter Kastner 
Aberdeen Group's research shows that Portal's software has been extremely successful in what we call second surgery. Companies that have put together internet sites and then found out they didn't do what they needed them to do, particularly in the billing and provisioning areas. 

Peter Kastner 
Portal's internet is the first product of its kind to be architected from the ground up with today's service-oriented internet in mind. 

Speaker 1 
Today's communications infrastructure revolution, with the advent of Internet Protocol, demands a revolution in the software infrastructure as well. Portal provides that software, offering service providers a business management solution that meets the real-time, no-limits needs of the Internet. 

Speaker 1 
The vision from the very beginning of the company has been a brave new world with millions and millions of new applications. Our vision was we provided the infrastructure for the growth of the network. 

Speaker 1 
We provide that foundation for business on the Internet. That's been a very consistent vision from day one of the company in 1985 till today. That's really given us major advantages in focusing the company's attention and consistently executing towards one long-term goal. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-portal-software-inside-busine-f4aefd |
| title | Portal Software Inside Business |
| author | Peter S. Kastner |
| date | 1998 |
| type | transcript |
| subject_domain | internet-billing-infrastructure |
| methodology | oral-history |
| source_file | /home/user/workspace/archive3_raw/transcript-portal-software-inside-busine-f4aefd.txt |
| license | CC-BY-4.0 |

### Abstract

A promotional/documentary video about Portal Software (Cupertino), featuring Peter Kastner of Aberdeen Group and a Juno Online Services representative. Kastner validates Portal's Infranet billing platform as the first architected for service-oriented internet, noting Aberdeen Group research shows success in 'second surgery' (companies rebuilding failed internet sites). Juno (6M free email accounts, 2nd largest dial-up ISP after AOL) deployed Infranet in H1 1998.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | medium | Captures Portal Software's mid-1990s market positioning and Kastner analyst endorsement; Portal's subscription billing model was prescient for the subscription economy. |
| **Relevance** | high | Direct Kastner appearance as named Aberdeen Group analyst providing market validation for Portal Software's Infranet platform. |
| **Prescience** | high | Kastner's prediction that real-time billing and flexible customer management would be essential proved accurate; subscription economy and usage-based billing now standard across all internet services. |

### Prescience Detail


**Prediction 1:** Portal Infranet market position
- **Claimed:** Portal's Infranet is the first product of its kind architected from the ground up with today's service-oriented internet in mind.
- **Year:** 1998
- **Confidence at time:** high

**Actual Outcome 1:** Juno deployment speed
- **Result:** Juno bought billing system in early 98, deployed by mid-98, effectively billing 6M free email accounts when service launched in July.
- **Confidence:** high
- **Notes:** Rapid ~6-month deployment from purchase to production; 6M accounts at launch

**Prediction 2:** Real-time billing as market requirement
- **Claimed:** Companies that cannot manage in real time will be washed away by next-generation competitors; traditional infrastructure is fundamentally inadequate.
- **Year:** 1998
- **Confidence at time:** high

**Actual Outcome 2:** Real-time billing as market requirement outcome
- **Result:** Real-time billing did become a market requirement for ISPs and telecoms, validating the prediction. Portal Infranet was adopted by major global carriers (Vodafone, Deutsche Telekom, China Mobile, Sprint). However, Portal Software itself was acquired by Oracle in 2006 for ~$220M, and Infranet was absorbed into Oracle's communications stack rather than becoming an independent industry standard.
- **Confidence:** verified
- **Notes:** Real-time converged billing became the telecom standard by 2000-2005. Portal's Infranet had 420+ customers at peak. The acquisition by Oracle in 2006 confirmed the market's validation of the technology, even if Portal did not remain independent.


### Entities Referenced (5)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Portal Software | company | acquired | Oracle |
| Juno Online Services | company | acquired | United Online / B. Riley Financial |
| America Online (AOL) | company | acquired | Bending Spoons |

### Technologies Referenced (5)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Portal Infranet | application | Portal Software | growth | acquired |
| Real-Time Customer Management and Billing | framework |  | emerging | mainstream |
| Subscription / Usage-Based Billing Infrastructure | application |  | emerging | mainstream |
| Internet Protocol (IP) / IP Networks | protocol |  | growth | mature |
| Dynamic Pricing and Rating Engine | application | Portal Software | emerging | evolved |

### Observation Summary

- Total observations: 16
- By type: technology-assessment: 7, expert-opinion: 3, actual-outcome: 2, market-data: 2, viability-prediction: 2
