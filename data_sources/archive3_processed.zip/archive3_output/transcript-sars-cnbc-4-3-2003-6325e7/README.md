# SARS Impact on Electronics Industry — CNBC Morning Call (April 3, 2003)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 2003-04-03 |
| Type | transcript |
| Domain | economic-impact-analysis |
| License | CC-BY-4.0 |

## Abstract

Peter Kastner, Chief Research Officer at Aberdeen Group, appears on CNBC Morning Call on April 3 2003 to discuss SARS impact on the global electronics industry. Kastner explains the trillion-dollar electronics industry's dependence on China/Asia supply chains (115M PCs assembled in Asia), the risk of quarantine-driven disruption, lists affected companies, notes Motorola's Singapore plant closure, Intel's developer forum postponement, and criticizes China's delayed information release. Host Martha interviews Kastner; Leslie provides context on RBC cutting PC/notebook demand forecasts.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 8 |
| technologies.csv | 3 |
| observations.csv | 17 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (2003). SARS Impact on Electronics Industry — CNBC Morning Call (April 3, 2003).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
