# SARS Impact on Electronics Industry — CNBC Morning Call (April 3, 2003)

> Archived from: /home/user/workspace/archive3_raw/transcript-sars-cnbc-4-3-2003-6325e7.txt
> Original publication date: 2003-04-03
> Author: Peter S. Kastner

---

## Original Document Text



CNBC 4_3_2003

⏰Sat, 11/16 13:19PM · 5mins

AI Notes

 
 Summary
 The meeting transcript discusses the potential impact of SARS (Severe Acute Respiratory Syndrome) on the global electronics industry, particularly focusing on the Asia-Pacific region. Leslie (Speaker0) introduces the topic, highlighting that half of all chips and most PCs and laptops are manufactured in Southeast Asia. She mentions that RBC has cut projections for PC and notebook demand due to the health crisis. Martha (Speaker1) then introduces Peter Kastner, Chief Research Officer at Aberdeen Group, to discuss the effects of SARS on the electronics industry. Kastner (Speaker3) explains that the electronics industry relies on low-cost, dependable supply chains, which China has provided in recent years. He expresses concern about potential supply chain disruptions if quarantines were to be implemented. Kastner notes that the global electronics industry is worth about a trillion dollars, with 115 million PCs assembled in Asia, many in China. He lists several major companies that could be affected, including semiconductor manufacturers, PC companies, and communications firms. Kastner also mentions that Motorola has already closed a cell phone plant in Singapore. The discussion touches on management changes, such as CEOs canceling trips and Intel postponing their developer forum. Kastner criticizes the Chinese government for initially withholding information about the outbreak, citing concerns from executives and Taiwan's president. The meeting concludes with a brief mention of upcoming segments on Iraq, oil and gold markets, and European trading.
 Chapters
00:00:22 Introduction to SARS impact on tech stocks
 Leslie introduces the topic of SARS and its potential impact on tech stocks. She highlights that half of all chips and most PCs and laptops are manufactured in Southeast Asia, raising concerns about possible manufacturing disruptions due to plant shutdowns. Leslie also mentions that RBC has cut projections for PC and notebook demand, citing the health crisis as a factor affecting demand from Asia.
00:01:05 Potential disruption in global commerce due to SARS
 Martha expands on the potential disruptions SARS could cause in various areas of global commerce. She specifically focuses on the global electronics industry, noting that the Asia-Pacific region, where SARS originated, is a significant source of both semiconductor production and consumption. Martha raises the question of whether the spread of SARS could lead to a breakdown in the global chip supply chain.
00:01:56 Interview with Peter Kastner on SARS impact
 Peter Kastner discusses the 'rules' upon which the electronics industry is built, emphasizing the industry's need for low-cost and dependable supply. He expresses concern about potential massive supply chain disruptions if quarantines were to be implemented due to SARS. Kastner provides context on the market share of the electronics industry, stating it's about a trillion dollars globally, with 115 million PCs assembled in Asia, many in China.
00:02:51 Companies potentially affected by SARS
 Kastner and Martha discuss various companies that could be impacted by the SARS outbreak. They mention major semiconductor manufacturers, PC companies, hard drive manufacturers, and communications firms. Specific companies named include Sony, NEC, Philips, Oki, Ellipta, Infineon, Broadcom, Sirius Logic, Connexant, and National Semiconductor. Kastner notes that virtually every semiconductor-related firm either manufactures in China or is considering doing so.
00:03:28 Management changes and travel restrictions
 The discussion turns to how companies are responding to the SARS outbreak. Kastner mentions that Motorola has already closed a cell phone plant in Singapore. He also notes that many executives are canceling trips, and Intel has postponed their developer forum. Kastner observes increasing government concern worldwide and the implementation of voluntary quarantines, which he believes should help reduce the spread of the disease.
00:04:07 Criticism of Chinese government's response
 Martha and Kastner discuss the potential commercial damage China may have caused by initially withholding information about the SARS outbreak. Kastner mentions that executives he's spoken to are concerned about the Chinese government's delayed response. He cites Taiwan's president, Chen Shui-bian, who criticized China's actions, stating that it threatens the whole world. Kastner notes the irony that China's attempt to protect business by withholding information may have ultimately had the opposite effect.
 Action Items
00:00:35 Leslie mentioned monitoring potential manufacturing disruptions in Southeast Asia due to SARS-related plant shutdowns.
00:00:57 Martha suggested further discussion on the effects of SARS, particularly in the Far East, with Peter Kastner.
00:02:09 Peter Kastner recommended closely watching for any quarantine measures in China that could lead to massive disruptions in the electronics supply chain.
00:03:04 Martha noted the need to track the impact on specific companies in the semiconductor and electronics industries, including Sony, NEC, Philips, and others.
00:03:39 Peter Kastner suggested monitoring management changes in tech companies, such as canceled trips and postponed events, in response to the SARS outbreak.
00:04:07 Martha proposed assessing the commercial damage to China resulting from their delayed response to the SARS outbreak.

Transcript

Speaker 1 
Let's finish out real quickly with a look at SARS and its impact on tech stocks. And we keep talking about this, but this is an important story. Half of all the chips are made in Southeast Asia. Almost all PC and laptops are made in the region. 

Speaker 1 
And the plant shutdowns could disrupt manufacturing. We are not getting reports of that now. But, of course, this market likes to get ahead of some of those moves. RBC, one of those getting ahead of it. 

Speaker 1 
And they have cut their projections for PC and notebook demand. And one of the things that they are citing is that health crisis could hurt demand coming out of Asia. So, Martha, that's a quick look. 

Speaker 1 
Martha and Ted, we're at 14.02. Back to you. 

Speaker 2 
All right, Leslie, thanks. And we'll be talking more about SARS in just a bit with Peter Kastner, Chief Research Officer at Aberdeen Group, about the effects it may be having already, at least in the Far East. 

Speaker 2 
Back to you. Thank you, folks. The respiratory disease SARS could disrupt many areas of global commerce. We'll talk about that when Morning Call comes right back. Gows down just a fraction. The recent outbreak of severe acute respiratory syndrome, also known as SARS, is affecting many industries worldwide, but the one that may be the most affected by this communicable disease is the global electronics industry. 

Speaker 2 
The Asia-Pacific region, where SARS originated, is a source of both semiconductor production and consumption. If this disease continues to spread, could there be a breakdown in the global chip supply chain, among other things? 

Speaker 2 
Joining us from New York, Peter Kastner, Chief Research Officer at Aberdeen Group. Thanks for being with us today. Thank you. You refer to the rules upon which the electronics industry is built. What are they, and how might this SARS outbreak break one of those rules? 

Peter Kastner 
Well, importantly, the electronics industry looks for low cost, of course, but they also look for a dependable supply of late, in the last few years, China, the People's Republic, has given them a high quality and low cost. 

Peter Kastner 
But now with the SARS outbreak, the concern is that if there were some sort of a quarantine, hypothetically, that that would lead to a massive disruption of the supply chain. 

Speaker 2 
What kind of market share does the People's Republic of China have at this point in terms of that? 

Peter Kastner 
Well, the global electronics industry is about a trillion dollars of which overall and there are 115 million PCs alone that are assembled in in Asia. Many of them are in China. So it would it is a critical building block manufacturing place in the global supply chain. 

Speaker 2 
What are some company names and product names that have been or might be affected here as a result? 

Peter Kastner 
Well, your major semiconductor manufacturers, major semiconductor equipment manufacturers, the PC companies, hard drives, communications as well. 

Speaker 2 
In the notes I got here, you're talking Sony, NEC, Philips, Oki, what is it, Ellipta, Infineon, Broadcom, Sirius Logic, Connexant, National Semiconductor, just to name a few, all of which could at some point be impacted. 

Peter Kastner 
There's not a semiconductor related firm in the world now, electronics firm that isn't either manufacturing in China or has plans or is thinking about manufacturing in the People's Republic. 

Speaker 2 
Motorola's already had to close the cell phone plant, you note, in Singapore? That's correct. All right. Are we starting to see management change the way it does things, CEOs canceling trips, for example? 

Peter Kastner 
Yeah, so far we've seen people canceling trips until postpone their developer forum, for instance. But I think what's happened in the last week since I began looking at this is that, number one, the governments of the world are more concerned. 

Peter Kastner 
Number two, we're seeing what amounts to voluntary quarantines, and that all should reduce the spread of the disease. But, as the head of the CDC said yesterday, it's too early to tell exactly what will happen. 

Speaker 2 
How much commercial damage has China done to itself for sitting on this problem for as long as it did? 

Peter Kastner 
That is unknown, but I can tell you the executives I've talked to are certainly concerned with the fact that the Chinese government for too long sat on this. The best comments I read were by Chen Shubian, the president of Taiwan yesterday, who lambasted the government of China for holding back on this, saying it really threatens the whole world. 

Speaker 2 
And here they held back hoping that it wouldn't affect business and in the end it very well may have the opposite effect. Thanks for sharing your thoughts Mr. Castner. You're welcome. Peter Castner, Chief Research Officer at the Aberdeen Group. 

Speaker 4 
coming up will bring you the latest developments in Iraq plus we'll get a report on the oil market and the gold market and we'll go live to Europe for a report on the trading day there. 

Speaker 2 
This is Morning Call on CNBC. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-sars-cnbc-4-3-2003-6325e7 |
| title | SARS Impact on Electronics Industry — CNBC Morning Call (April 3, 2003) |
| author | Peter S. Kastner |
| date | 2003-04-03 |
| type | transcript |
| subject_domain | economic-impact-analysis |
| methodology | oral-history |
| source_file | /home/user/workspace/archive3_raw/transcript-sars-cnbc-4-3-2003-6325e7.txt |
| license | CC-BY-4.0 |

### Abstract

Peter Kastner, Chief Research Officer at Aberdeen Group, appears on CNBC Morning Call on April 3 2003 to discuss SARS impact on the global electronics industry. Kastner explains the trillion-dollar electronics industry's dependence on China/Asia supply chains (115M PCs assembled in Asia), the risk of quarantine-driven disruption, lists affected companies, notes Motorola's Singapore plant closure, Intel's developer forum postponement, and criticizes China's delayed information release. Host Martha interviews Kastner; Leslie provides context on RBC cutting PC/notebook demand forecasts.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rare primary source capturing Kastner's expert analysis of SARS supply chain risk at onset of epidemic; provides data points on electronics industry China dependency in 2003. |
| **Relevance** | high | Named Kastner appearance on national TV as Chief Research Officer Aberdeen Group; documents his role as tech industry analyst for mainstream media during crisis events. |
| **Prescience** | high | Kastner's supply chain disruption warnings proved prescient for SARS 2003 and foreshadowed identical dynamics in COVID-19 2020; China information transparency concerns also proved durable. |

### Prescience Detail


**Prediction 1:** Quarantine disruption risk
- **Claimed:** If there were some sort of quarantine, hypothetically, that would lead to a massive disruption of the supply chain.
- **Year:** 2003
- **Confidence at time:** high

**Actual Outcome 1:** Motorola Singapore plant closure
- **Result:** Motorola has already had to close the cell phone plant in Singapore.
- **Confidence:** high
- **Notes:** First concrete example of SARS forcing manufacturing shutdown in electronics sector

**Prediction 2:** Supply chain disruption prediction
- **Claimed:** Massive supply chain disruption possible if quarantines implemented; critical that China is main low-cost high-quality manufacturing location for global electronics.
- **Year:** 2003
- **Confidence at time:** high

**Actual Outcome 2:** Motorola Singapore plant closure
- **Result:** Motorola has already had to close the cell phone plant in Singapore.
- **Confidence:** high
- **Notes:** First concrete example of SARS forcing manufacturing shutdown in electronics sector


### Entities Referenced (8)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Intel | company | public |  |
| Motorola | company | spun-off | Motorola Solutions / Motorola Mobility (Lenovo) |
| RBC Capital Markets | firm | active |  |
| China (People's Republic) | government | active |  |
| Taiwan Government (ROC) | government | active |  |
| US Centers for Disease Control (CDC) | government | active |  |

### Technologies Referenced (3)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Global Electronics Supply Chain (Asia-based) | framework |  | mature | under-geopolitical-pressure |
| Semiconductor Manufacturing (Southeast Asia) | hardware |  | mature | redistributing |
| PC and Laptop Manufacturing (Asia) | hardware |  | mature | mature |

### Observation Summary

- Total observations: 17
- By type: expert-opinion: 7, market-data: 4, actual-outcome: 3, viability-prediction: 2, technology-assessment: 1
