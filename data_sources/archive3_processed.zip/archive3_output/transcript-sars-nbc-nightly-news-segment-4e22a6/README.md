# SARS Economic Impact — NBC Nightly News (April 3, 2003)

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 2003-04-03 |
| Type | transcript |
| Domain | economic-impact-analysis |
| License | CC-BY-4.0 |

## Abstract

Peter Kastner appears as 'high-tech consultant' on NBC Nightly News (hosted by Tom Brokaw) on April 3 2003, the same day as his CNBC appearance. Ann Thompson reports on SARS economic impact: 90% decline in Asian travel bookings, Business Travel Coalition survey showing 27% of companies banning Asian travel ($22M monthly airline tickets affected), Intel canceling China/Taiwan roadshows, and Kastner's warning that factory closures would affect availability of TVs, toys, PCs, computers, and MP3 players in the US. Asian economies (ex-Japan) were growing at 5% before SARS.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 2 |
| observations.csv | 15 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (2003). SARS Economic Impact — NBC Nightly News (April 3, 2003).
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
