# SARS Economic Impact — NBC Nightly News (April 3, 2003)

> Archived from: /home/user/workspace/archive3_raw/transcript-sars-nbc-nightly-news-segment-4e22a6.txt
> Original publication date: 2003-04-03
> Author: Peter S. Kastner

---

## Original Document Text



NBC Nightly News segment (4_3_2003)

⏰Sat, 11/16 14:58PM · 3mins

AI Notes

 
 Summary
 This NBC Nightly News special edition, hosted by Tom Brokaw, focuses on the economic impact of SARS (Severe Acute Respiratory Syndrome) and the ongoing Iraq war. The report highlights a significant increase in first-time jobless claims and a sharp decline in the U.S. service sector activity. NBC's Ann Thompson reports on the global economic repercussions of SARS, particularly in Asia. The mystery illness is causing widespread fear, leading to reduced travel and business activities. Pat McCarrie, a businessman returning from Hong Kong, cut his trip short due to SARS concerns. The Business Travel Coalition survey reveals that 27% of companies are banning travel to Asian countries, potentially impacting $22 million in monthly airline ticket sales to Asia. The electronics industry is particularly vulnerable, with Intel canceling road shows in China and Taiwan. Peter Kastner, a high-tech consultant, warns of potential supply chain disruptions affecting consumer electronics availability. Prior to the SARS outbreak, Asian economies (excluding Japan) were growing at a 5% rate, but the current situation threatens U.S. exports and overall economic recovery. The report concludes by noting that some individuals are finding business opportunities in the crisis, such as mask sellers near the Vancouver airport.
 Chapters
 Economic concerns amid SARS outbreak and Iraq war
 Tom Brokaw reports on discouraging economic news, including a spike in first-time jobless claims and a significant drop in U.S. service sector activity. The report also mentions global economic issues related to war uncertainties and the SARS outbreak.
00:00:30 SARS impact on global travel and business
 Ann Thompson reports from Chicago on travelers returning from Hong Kong wearing masks as protection against SARS. Businessman Pat McCarrie cut his trip short due to the outbreak. The report highlights SARS as a threat to both public health and the global economy, with potential to cause a second recession in three years.
00:01:01 Travel industry disruptions
 Raymond Seuss, a San Francisco travel agent specializing in Asian trips, reports a 90% decrease in business, with only half his staff working. A Business Travel Coalition survey finds 27% of companies banning travel to Asian countries, potentially impacting $22 million in monthly airline ticket sales to Asia.
00:01:28 Impact on electronics industry
 The report discusses the potential impact on the electronics industry, with Intel canceling road shows in China and Taiwan. Peter Kastner, a high-tech consultant, warns of possible factory closures in Asia affecting the availability of consumer electronics products in the U.S.
00:02:00 Asian economic slowdown and its global implications
 The report notes that Asian economies, except Japan, had been growing at a 5% rate before the SARS scare. The current situation could hurt U.S. exports and hinder a key source of growth needed for U.S. economic recovery.
00:02:21 Opportunistic business ventures amid crisis
 The report concludes by showing salesmen selling masks near the Vancouver airport, highlighting how some individuals are finding business opportunities in the crisis.
 Action Items
 Tom Brokaw mentioned monitoring the spike in first-time jobless claims and the drop in U.S. service sector activity.
00:00:30 Ann Thompson suggested tracking the impact of SARS on global travel and business activities.
00:01:13 Business Travel Coalition recommended surveying companies' travel policies to Asian countries.
00:01:28 Intel decided to cancel road shows in China and Taiwan due to SARS concerns.
00:01:41 Peter Kastner advised monitoring potential factory closures in Asia and their impact on consumer electronics availability.
00:02:00 Economists suggested assessing the impact of weakened Asian economies on U.S. exports and overall economic recovery.

Transcript

Unknown speaker 
And spreading fast, that deadly mystery illness sars threatening businesses worldwide. Target Iraq, the battle for Baghdad. This is a special edition of NBC Nightly News with Tom Brokaw. Some discouraging economic news to report tonight, a big spike in first time jobless claims and a dramatic drop in activity in the huge service sector in this country. 

Unknown speaker 
And around the world, war uncertainties already causing economic problems. And now, the new fear of that mystery virus, sars. Here's NBC's Ann Thompson. Arriving in Chicago from Hong Kong, the must-have travel accessory, a mask. 

Unknown speaker 
An unproven defense worn by businessman Pat McCarrie and others against the mystery illness, sars. We cut our trip short and came home five days early. Sars, a threat to public health and now the global economy. 

Unknown speaker 
Sars could well be the tipping point that takes the world into its second recession in three years. Already the ripple effect hurting the San Francisco travel agency, Raymond Seuss specializes in trips to Asia. 

Unknown speaker 
His business now almost non-existent, off 90 percent. Only half his staff is working. And a nationwide survey of companies by the Business Travel Coalition finds 27 percent are banning travel to Asian countries. 

Unknown speaker 
Survey members alone spend a whopping $22 million a month on airline tickets to Asia. Racing for the impact? The electronics industry. Chipmaker Intel already calling off road shows in China and Taiwan this month. 

Unknown speaker 
If Sars forces factories to close over there, high-tech consultant Peter Kastner says consumers could feel it here, suddenly unable to buy. That's everything from TV sets, to electronic toys, to PCs, to high-tech computers, as well as all sorts of other MP3 companies. 

Unknown speaker 
players and everything in between. Until the SARS scare, the Asian economies, with the exception of Japan, had been a relative bright spot, growing at a 5 percent clip. Now weakened, that could hurt U.S. 

Unknown speaker 
exports. Stunting a key source of growth, economists say that the U.S. needs to recover. But even in trouble, some find opportunity, like these salesmen selling masks on the road to the Vancouver airport. 

Unknown speaker 
Are you flying off to Italy? A crisis with deadly consequences as the ills of SARS infect the economy. Ann Thompson, NBC News, New York. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-sars-nbc-nightly-news-segment-4e22a6 |
| title | SARS Economic Impact — NBC Nightly News (April 3, 2003) |
| author | Peter S. Kastner |
| date | 2003-04-03 |
| type | transcript |
| subject_domain | economic-impact-analysis |
| methodology | oral-history |
| source_file | /home/user/workspace/archive3_raw/transcript-sars-nbc-nightly-news-segment-4e22a6.txt |
| license | CC-BY-4.0 |

### Abstract

Peter Kastner appears as 'high-tech consultant' on NBC Nightly News (hosted by Tom Brokaw) on April 3 2003, the same day as his CNBC appearance. Ann Thompson reports on SARS economic impact: 90% decline in Asian travel bookings, Business Travel Coalition survey showing 27% of companies banning Asian travel ($22M monthly airline tickets affected), Intel canceling China/Taiwan roadshows, and Kastner's warning that factory closures would affect availability of TVs, toys, PCs, computers, and MP3 players in the US. Asian economies (ex-Japan) were growing at 5% before SARS.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | National TV appearance on NBC Nightly News with Tom Brokaw; rare Kastner appearance on non-specialist broadcast reaching mass audience; quantified travel and economic impact data. |
| **Relevance** | high | Kastner named on-screen as high-tech consultant; provides supply chain warning to mass consumer audience; complements same-day CNBC appearance with different data points. |
| **Prescience** | high | Consumer product availability risk from Asian factory closure predicted for SARS proved accurate in COVID-19; travel industry collapse pattern (90% decline) repeated exactly in 2020. |

### Prescience Detail


**Prediction 1:** Consumer electronics availability risk
- **Claimed:** If SARS forces factories to close in Asia, consumers in US could suddenly be unable to buy TVs, electronic toys, PCs, computers, MP3 players.
- **Year:** 2003
- **Confidence at time:** high

**Actual Outcome 1:** Intel roadshow cancellations
- **Result:** Intel called off roadshows in China and Taiwan in April 2003 due to SARS.
- **Confidence:** high
- **Notes:** First concrete corporate action in electronics: Intel pulling sales/marketing events from affected regions

**Prediction 2:** US exports threatened by Asian slowdown
- **Claimed:** Weakened Asian economies could hurt US exports and stunt a key source of growth the US needs to recover.
- **Year:** 2003
- **Confidence at time:** high


### Entities Referenced (7)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| Intel | company | public |  |
| Business Travel Coalition | organization | active |  |
| NBC News / NBC Nightly News | organization | active |  |
| Tom Brokaw | person | active |  |
| Ann Thompson | person | active |  |

### Technologies Referenced (2)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Global Electronics Supply Chain (Asia-based) | framework |  | mature | under-geopolitical-pressure |
| International Air Travel to Asia | framework |  | growth | recovered |

### Observation Summary

- Total observations: 15
- By type: market-data: 6, actual-outcome: 5, viability-prediction: 2, expert-opinion: 2
