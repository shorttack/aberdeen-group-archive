# Software 2000 — IT Strategy and Client-Server Transition

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1994 |
| Type | transcript |
| Domain | enterprise-IT-strategy |
| License | CC-BY-4.0 |

## Abstract

Peter Kastner delivers a keynote/presentation for Software 2000, using the metaphor of an exhausted fighter to frame IT organizations struggling with client-server transformation. He addresses paradigm shift requirements, the coexistence of mainframes in large company IT architectures, the importance of 3-year enterprise client-server vision, future MIS roles (security, infrastructure, networking, training), and the career choice MIS managers face between technological overlord and business-aligned roles.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 5 |
| observations.csv | 15 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1994). Software 2000 — IT Strategy and Client-Server Transition.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
