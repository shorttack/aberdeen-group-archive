# Software 2000 — IT Strategy and Client-Server Transition

> Archived from: /home/user/workspace/archive3_raw/transcript-software-2000-f16f5b.txt
> Original publication date: 1994
> Author: Peter S. Kastner

---

## Original Document Text



Software 2000

⏰Sat, 11/16 14:58PM · 7mins

AI Notes

 
 Summary
 The transcript discusses the challenges and future of information technology in business. It begins with a metaphor comparing the exhaustion of a fighter in early rounds to the challenges faced in IT projects. The speaker emphasizes the need for companies to reevaluate their approach to technology, suggesting a paradigm shift that requires starting over with some applications. The discussion then moves to the evolving role of mainframes in large companies, the importance of flexible access to information for end-users, and the need for a clear vision in transitioning to enterprise-wide client-server environments. The speaker highlights key roles for MIS (Management Information Systems) in the future, including security, maintaining corporate communications infrastructure, and training. The transcript concludes by addressing the career decisions facing MIS managers, whether to focus on technological infrastructure or business-oriented roles closer to competitive advantage.
 Chapters
00:00:02 The exhaustion metaphor in IT projects
 The speaker uses a metaphor of a tired fighter in early rounds of a match to illustrate the challenges faced in IT projects. This analogy emphasizes the need for endurance and perseverance in the face of exhaustion, as the 'fight' or project is far from over.
00:02:20 Paradigm shift in company applications
 The speaker emphasizes the need for companies to recognize a significant paradigm shift in technology. They suggest that some applications may require a complete restart, a process many companies have never undertaken before.
00:02:33 Multifaceted approach to business in the 90s
 The speaker outlines the complex challenges of the 1990s, including cost reduction, re-engineering business practices, and adopting new technologies such as LAN-based workgroup systems and client-server architectures.
00:03:01 Extending mainframe information to end-users
 The speaker suggests that companies with mainframes should focus on providing more flexible access to information for end-users, without increasing the load on the mainframe system.
00:03:18 The evolving role of mainframes
 The speaker predicts that mainframes will continue to play a crucial role in large companies, particularly in managing large-scale data networks, rather than being completely replaced.
00:03:42 The importance of long-term vision
 The speaker stresses the need for companies to have a clear long-term vision, warning that without it, transitioning to an enterprise-wide client-server environment will be extremely challenging.
00:04:29 Future roles of MIS
 The speaker outlines key future roles for Management Information Systems (MIS), including security, maintaining corporate communications infrastructure, networking, and training. They emphasize the potential benefits of centralized information control and distribution.
00:05:11 Career decisions for MIS managers
 The speaker discusses the career decisions facing MIS managers, presenting a choice between becoming a technological overlord focused on infrastructure or taking on a role closer to business operations and competitive advantage.
 Action Items
00:02:20 Companies need to reevaluate their approach to technology and consider starting over with some applications.
00:02:33 Businesses should focus on reducing costs while simultaneously re-engineering business practices and adopting new technologies.
00:03:01 Companies with mainframes should work on extending information access to end-users in a more flexible manner.
00:03:42 Organizations need to develop a clear long-term vision for transitioning to enterprise-wide client-server environments.
00:04:29 MIS departments should focus on key roles including security, maintaining corporate communications infrastructure, networking, and training.
00:05:11 MIS managers need to make a career decision between focusing on technological infrastructure or taking on more business-oriented roles.

Transcript

Thank you. There is an extortion of the will beyond any of our measure in the exhaustion which comes upon a fighter in early rounds when he's already too tired to lift his arms or take advantage of openings there before him. 

Yet the fight is not a third over. There are all those rounds to go. The fight is not a third over. There are all those rounds that come upon a fighter in early rounds when he's already too tired to lift his arms or take advantage of openings where he's already too tired to lift his arms or take advantage of openings where he's already too tired to lift his arms or take advantage of openings where he's already too tired to lift his arms or take advantage of openings where he's already too tired to lift his arms or take advantage of openings where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms or take advantage of links where he's already too tired to lift his arms. 

It's time for companies to take a step back and realize that the paradigm shift is so strong that they need to go back to square one with some applications and truly start over, which is something that many companies have never done. 

The play for the 90s is dealing with several different things at the same time. We're trying to reduce costs, but not just in IS. We should think about re-engineering and redoing our basic business practices as we move towards new technologies such as land-based work group systems, client server, downsizing, etc. 

It would make sense for companies with mainframes today that are gathering all of this information to begin to extend that to the end users in a way that users can have more flexible access to the information without more drain on the mainframe system. 

Mainframes aren't going away. They will continue to play an important part in every large company. Of course, there will be exceptions, but for most large companies, instead of ripping out all their mainframes and dumping them in the nearest lake, many mainframes will find a role in helping to manage a company's large-scale data network. 

So the mainframe isn't going away. There will just be particular roles where it has a strong purpose. If users don't figure out where they want to be in even, say, three years, they're in deep, deep trouble today because there's no way they're going to get from the environment that most companies are in today to the enterprise-wide client-server environment that they need to be in without some real vision and some real managerial strength behind it. 

The key roles of MIS in the future are security, maintaining the corporate communications infrastructure, the network, and teaching and training. Those should never go away. There's a lot of ions of information throughout organizations, and companies could really benefit if they could get their arms around it and centrally control that information, making it available to everybody. 

So the challenge of the information is to... professional goes beyond making the right technology decisions, it is also managing those technologies appropriately. The MIS managers of today are fundamentally faced with a career decision that they have to make. 

Do they want to be the technological overlord which would point them toward maintaining and developing the infrastructure long term, or do they want to be a role that's closer to the business, that's closer to... 

uh... a competitive advantage uh... uh... uh... 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-software-2000-f16f5b |
| title | Software 2000 — IT Strategy and Client-Server Transition |
| author | Peter S. Kastner |
| date | 1994 |
| type | transcript |
| subject_domain | enterprise-IT-strategy |
| methodology | oral-history |
| source_file | /home/user/workspace/archive3_raw/transcript-software-2000-f16f5b.txt |
| license | CC-BY-4.0 |

### Abstract

Peter Kastner delivers a keynote/presentation for Software 2000, using the metaphor of an exhausted fighter to frame IT organizations struggling with client-server transformation. He addresses paradigm shift requirements, the coexistence of mainframes in large company IT architectures, the importance of 3-year enterprise client-server vision, future MIS roles (security, infrastructure, networking, training), and the career choice MIS managers face between technological overlord and business-aligned roles.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Substantive Kastner strategic keynote capturing mid-1990s IT transformation thinking; covers mainframe coexistence, client-server vision, and MIS career evolution. |
| **Relevance** | high | Kastner as named speaker/presenter; content directly relevant to Aberdeen Group's research on client-server transition and enterprise IT strategy. |
| **Prescience** | high | Kastner's predictions about mainframe survival in network management proved accurate; MIS manager career bifurcation into technology vs. business roles proved accurate. 3-year vision requirement for client-server transition was directionally correct. |

### Prescience Detail


**Prediction 1:** Mainframe evolution to network management
- **Claimed:** Companies should extend mainframe data to end users more flexibly without more drain on the mainframe; mainframes will help manage company's large-scale data networks.
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 1:** Mainframe survival prediction outcome
- **Result:** Mainframes did survive and in fact experienced a renaissance through IBM's continued z-Series development. Geac (which acquired Dun & Bradstreet Software's mainframe ERP Millennium system) retained over 3,000 mainframe ERP customers in the late 1990s. The prediction of mainframe persistence proved correct; IBM's mainframe business remains active in 2025.
- **Confidence:** verified
- **Notes:** The mainframe survival prediction was accurate. Software 2000 itself (which focused on AS/400 mid-range, not mainframes) renamed to Infinium, was acquired by SSA Global (2002), then Infor (2006). IBM mainframe business remained active through the 2020s.

**Prediction 2:** Mainframe coexistence prediction
- **Claimed:** Mainframes aren't going away; will continue to play an important part in every large company — not ripped out and dumped in the nearest lake.
- **Year:** 1994
- **Confidence at time:** high

**Actual Outcome 2:** Mainframe survival prediction outcome
- **Result:** Mainframes did survive and in fact experienced a renaissance through IBM's continued z-Series development. Geac (which acquired Dun & Bradstreet Software's mainframe ERP Millennium system) retained over 3,000 mainframe ERP customers in the late 1990s. The prediction of mainframe persistence proved correct; IBM's mainframe business remains active in 2025.
- **Confidence:** verified
- **Notes:** The mainframe survival prediction was accurate. Software 2000 itself (which focused on AS/400 mid-range, not mainframes) renamed to Infinium, was acquired by SSA Global (2002), then Infor (2006). IBM mainframe business remained active through the 2020s.


### Entities Referenced (3)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Software 2000 | company | acquired | Infor (via SSA Global) |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |

### Technologies Referenced (5)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Client-Server Architecture | framework |  | growth | evolved |
| LAN-Based Workgroup Systems | platform |  | emerging | evolved |
| Mainframe Computing | hardware |  | declining | niche-mission-critical |
| MIS/IS Corporate Infrastructure | framework |  | transition | evolved |
| Enterprise-Wide Client-Server Environment | framework |  | emerging | evolved |

### Observation Summary

- Total observations: 15
- By type: expert-opinion: 5, framework-factor: 3, viability-prediction: 2, actual-outcome: 2, technology-assessment: 2, strategy-classification: 1
