# Sybase XI Launch — Kastner Analyst Endorsement

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995 |
| Type | transcript |
| Domain | database-software |
| License | CC-BY-4.0 |

## Abstract

A brief (~1 minute) clip featuring Peter Kastner from Aberdeen Group providing analyst endorsement for Sybase's multi-database strategy at a Sybase XI (Sybase IQ) launch event. Using a boat analogy, Kastner explains that Sybase's intelligent approach of offering different databases for different applications — OLTP, data warehousing, disconnected users, and mass distributed replicated systems — addresses what the market actually needs. Sybase XI refers to the Sybase IQ analytics/business intelligence database platform.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 3 |
| technologies.csv | 6 |
| observations.csv | 8 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Sybase XI Launch — Kastner Analyst Endorsement.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
