# Tandem Himalaya Server — Airport Dream Commercial

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995 |
| Type | transcript |
| Domain | enterprise-hardware |
| License | CC-BY-4.0 |

## Abstract

A Tandem Computers marketing video/commercial structured as a dream sequence at an airport, in which an IT decision-maker relives his research process for choosing the Tandem Himalaya K10,000 as the best open client-server platform. Includes customer testimonials from R.J. Montoro at UPS (tripling volume with K10,000 in mission-critical mobile messaging) and Linda Fuhrer at Diagnostic (VP of MIS, praising K10,000 parallelism for application development). Industry expert endorsements from Chris Christiansen (IDC) and Peter Kastner (Aberdeen Group) validate Tandem's TPC-C leadership, competitive pricing, scalability, and high availability without price premium.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 13 |
| technologies.csv | 6 |
| observations.csv | 17 |
| codes.csv | 23 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Tandem Himalaya Server — Airport Dream Commercial.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

oral-history
