# Tandem Himalaya Server — Airport Dream Commercial

> Archived from: /home/user/workspace/archive3_raw/transcript-tandem-airport-commercial-9e163b.txt
> Original publication date: 1995
> Author: Peter S. Kastner

---

## Original Document Text



Tandem airport commercial

⏰Transcribed Sat, 11/16/24 15:37PM · 7mins

AI Notes

 
 Summary
 The transcript describes a dream-like scenario where the speaker is reflecting on their decision to choose Tandem's Himalayan server as the best open client-server platform. The speaker recounts various encounters and information they've gathered about Tandem's performance, cost-effectiveness, and scalability. Key points include:
 1. The speaker recalls a visit to R.J. Montoro at United Parcel Service, who uses a Himalayan in their mobile messaging center. Montoro mentioned that the K-10,000 is crucial for their expanded volume processing, tripling their volume in the next three months.
 2. Linda Fuhrer, VP of MIS at Diagnostic, praised the parallelism of the K10,000 Himalaya system, noting its effectiveness in developing applications without concerns about response time.
 3. The speaker reviews TPCC audited results, showing Himalaya as the low-cost, high-performance, linearly scalable open champion with a database scaled up to 1.3 terabytes.
 4. Industry experts Chris Christiansen from International Data Corporation and Peter Kastner from Aberdeen Group provide positive feedback on Tandem's performance, cost-effectiveness, and competitiveness.
 5. The speaker emphasizes Tandem's linear scalability, noting that as the number of processors doubled, the transactions per minute also doubled.
 6. The UPS representative summarizes that the K10,000's price performance, nonstop capability, and scalability are now as good or better than any other platform in the market.
 The dream concludes with the speaker reaffirming their decision to choose Tandem, acknowledging that Tandem has transformed from a proprietary, expensive, niche system to an open system with excellent performance and price-performance ratio.
 Chapters
00:00:20 Introduction to the dream scenario
 The speaker begins by describing a strange dream where they find themselves at an airport, unsure of their destination. This dream appears to be a metaphor for their decision-making process regarding the choice of an open client-server platform, specifically Tandem's Himalayan server.
00:01:14 Recollection of customer testimonials
 The speaker recalls visits to two customers: R.J. Montoro at United Parcel Service and Linda Fuhrer at Diagnostic. Montoro emphasizes the importance of the K-10,000 for their expanded volume processing, stating they're tripling their volume in three months. Fuhrer praises the parallelism of the Himalaya system, noting its effectiveness in application development without concerns about response time.
00:03:03 Performance and cost analysis
 The speaker reviews TPCC audited results, which show Himalaya as the low-cost, high-performance, linearly scalable open champion. The results indicate a database scaled up to 1.3 terabytes. This section highlights Tandem's competitive edge in terms of performance and cost-effectiveness.
00:03:39 Expert opinions and industry validation
 The speaker recalls conversations with industry experts Chris Christiansen from International Data Corporation and Peter Kastner from Aberdeen Group. Both experts provide positive feedback on Tandem's performance, cost-effectiveness, and ability to compete with non-high availability systems. Kastner specifically mentions that Tandem offers scalability and high availability without a price premium.
00:05:03 Scalability and final decision
 The speaker emphasizes Tandem's linear scalability, noting that as the number of processors doubled, the transactions per minute also doubled. The UPS representative summarizes that the K10,000's price performance, nonstop capability, and scalability are now as good or better than any other platform in the market. The speaker concludes by reaffirming their decision to choose Tandem, acknowledging its transformation from a proprietary, expensive, niche system to an open system with excellent performance and price-performance ratio.
 Action Items
00:01:20 The speaker should follow up with R.J. Montoro at United Parcel Service to monitor the progress of their volume processing expansion using the K-10,000.
00:02:22 The speaker should request detailed performance metrics from Linda Fuhrer at Diagnostic to quantify the improvements in application development and response time with the Himalaya system.
00:03:18 The speaker should compile a comprehensive report comparing Tandem's performance and cost-effectiveness with other vendors based on the TPCC audited results.
00:04:35 The speaker should arrange follow-up interviews with Chris Christiansen and Peter Kastner to gather more in-depth analysis on Tandem's position in the market.
00:05:18 The speaker should create a case study on Tandem's linear scalability, using the data that shows how doubling the number of processors doubles the transactions per minute.
00:06:22 The speaker should develop a marketing strategy highlighting Tandem's transformation from a proprietary system to an open system with excellent performance and price-performance ratio.

Transcript

Thank you. 

Last night, I had the strangest dream. 

you 

I'm at the airport, but I don't know why. Where am I going? Then it hits me. This trip, this dream, must be about my decision to go with Tandem. Am I reliving my search for the best open client server platform? 

Didn't I already take the journey that led me to the new Himalayan server? What more is there to know? Didn't I already do my homework? Did I miss something? What? But let me check. I know. I'm supposed to fly to New Jersey to see that Tandem customer, R.J. 

Montoro, at United Parcel Service. They're using a Himalayan in their mobile messaging center. 

Similarly, a K-10,000 is the cornerstone for our expanded volume processing for this program. We're tripling our volume in the next three months, and the K-10,000 is the cornerstone of this. This is for us a truly mission-critical application. 

Montero already told me that. Weeks ago. So where am I going? What angle hadn't I checked? Best combination of parallel hardware and parallel software? I checked the departures. Hmm, a flight to Phoenix. 

That's it, I'm going to see Linda Fuhrer, the VP of MIS at diagnostic. They've got a Himalaya too. But no, I've already seen her. She's the one who told me. Parallelism has allowed us to develop an application and concentrate on the functionality and the features within that application without being overly concerned about the response time that we're going to get from the system. 

Parallelism is an inherent part of the K10,000 Himalaya system, provides us with the response time that we expect and its performance to date has been very effective. Right, the power of Tandem parallelism, commercial applications, MPP. 

I know all about that, sure. So where am I headed? Wait, cost. I've got to go somewhere to find out about cost comparisons. Oh, excuse me, can you help me? I need to go somewhere. The agent hands me a pile of reports. 

Oh, these are the official TPCC audited results. The client server environment, database scaled up to 1.3 terabytes, and how the Himalayas came out the low-cost high-performance linearly scalable open champion. 

I know this stuff. But maybe, the agent says, maybe you should talk to an industry expert. Listen to what international data corporations Chris Christiansen has to say. This benchmark essentially rebuts the idea that Tandem's fault tolerance carries an extreme level of premium pricing. 

It rebuts the idea that Tandem is not really as performance capable as some of the other machines out there from HP, NCR, Sun, IBM. It rebuts the idea that Tandem can not compete with non-high availability, non-FT systems. 

Thing is, I already talked to Christiansen. In fact, didn't I talk to a second expert, too, from the Aberdeen group, Peter Kastner. I'm sure that I... It's Kastner on the phone now. 

Peter Kastner: “One of the secrets of the new Tandem is, you can get the scalability, you can get the high availability, you can get the absolute levels of performance without paying a price premium. 

You ought to look at Tandem just on a dollars per transaction per second basis, and you'll find it's right up there with the leaders of the industry.” 

you 

I don't get it. I talk to customers. I talk to the experts. I checked on performance and cost. I picked the best application solution. What else do I have to do? 

What about scalability? 

What? What about scalability? But I know about scalability from the TPCC results. About how each time the number of Tandem processors doubled, the number of transactions per minute doubled, linear scalability. 

Tandem is the only vendor who has shown me proof over a wide performance range. In fact, I remember it all now. It was the fellow at UPS that summed it up. 

With the K10,000 price performance, the price of Tandem and the associated nonstop capability and the scalability that you get with it are now as good or better than any of the other applications in this type that are being sold, any of the platforms that are being sold. 

Right, that's exactly the conclusion I reached too. I've already made this trip. I've made my decision. I'm right where I need to be, with Tandem. Tandem has certainly changed its spots. Those people who remember Tandem as a proprietary, expensive, and niche type system should look again. 

Tandem now shows excellent performance, well beyond anything that we've seen before, but excellent price performance. While having the open systems capabilities that the world is asking for. I've arrived. 

The Tandem Himalayas. 


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | transcript-tandem-airport-commercial-9e163b |
| title | Tandem Himalaya Server — Airport Dream Commercial |
| author | Peter S. Kastner |
| date | 1995 |
| type | transcript |
| subject_domain | enterprise-hardware |
| methodology | oral-history |
| source_file | /home/user/workspace/archive3_raw/transcript-tandem-airport-commercial-9e163b.txt |
| license | CC-BY-4.0 |

### Abstract

A Tandem Computers marketing video/commercial structured as a dream sequence at an airport, in which an IT decision-maker relives his research process for choosing the Tandem Himalaya K10,000 as the best open client-server platform. Includes customer testimonials from R.J. Montoro at UPS (tripling volume with K10,000 in mission-critical mobile messaging) and Linda Fuhrer at Diagnostic (VP of MIS, praising K10,000 parallelism for application development). Industry expert endorsements from Chris Christiansen (IDC) and Peter Kastner (Aberdeen Group) validate Tandem's TPC-C leadership, competitive pricing, scalability, and high availability without price premium.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Documents Tandem Computers' strategic repositioning from proprietary expensive niche to open client-server platform; Kastner quoted on price-performance; TPC-C benchmarks cited with specific data. |
| **Relevance** | high | Kastner explicitly quoted by name; Aberdeen Group referenced; provides benchmark data and competitive positioning assessment for Tandem Himalaya. |
| **Prescience** | high | Kastner's validation of Tandem's transformation to open high-availability systems proved accurate; fault-tolerant computing for mission-critical workloads remains essential (HP NonStop). Price-performance competitive parity was achieved. |

### Prescience Detail


**Prediction 1:** Tandem scalability without price premium prediction
- **Claimed:** Scalability, high availability, and absolute performance without price premium; evaluate on $/TPS and find competitive with industry leaders.
- **Year:** 1995
- **Confidence at time:** high

**Actual Outcome 1:** Tandem competitive position outcome
- **Result:** Tandem's competitive position in fault-tolerant computing was validated by its acquisition by Compaq in 1997 for $3 billion, confirming its technology value. NonStop technology survived through Compaq (1997), HP (2002), and into HPE today as HPE NonStop. A 1999 study found NonStop ran 90% of securities trades, 80% of ATMs, and 66% of credit card transactions — confirming Tandem's dominance prediction.
- **Confidence:** verified
- **Notes:** Tandem's fault-tolerant computing leadership was fully vindicated. The technology is still deployed in mission-critical financial and telecom systems under HPE NonStop branding. Compaq paid a 20% premium to acquire the company, confirming market recognition of its value.


### Entities Referenced (13)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Tandem Computers | company | acquired | Hewlett Packard Enterprise |
| Aberdeen Group | firm | acquired | Spiceworks Ziff Davis |
| International Data Corporation (IDC) | firm | active |  |
| Chris Christiansen | person | deceased |  |
| United Parcel Service (UPS) | company | public |  |
| Diagnostic (Company) | company | active |  |
| R.J. Montoro | person | active |  |
| Linda Fuhrer | person | active |  |
| Hewlett-Packard (HP) | company | spun-off | HP Inc. / Hewlett Packard Enterprise |
| NCR Corporation | company | spun-off | NCR Voyix / NCR Atleos |
| Sun Microsystems | company | acquired | Oracle |
| IBM (International Business Machines) | company | public |  |

### Technologies Referenced (6)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Tandem Himalaya K10,000 Server | hardware | Tandem Computers | growth | obsolete |
| TPC-C Benchmark | framework | Transaction Processing Performance Council | growth | active |
| Fault-Tolerant / High-Availability Computing (NonStop) | framework | Tandem Computers | mature | niche-mission-critical |
| Massively Parallel Processing (MPP) / Commercial MPP | framework | Tandem Computers | growth | mainstream |
| Client-Server Architecture | framework |  | growth | evolved |
| Open Systems / UNIX | platform |  | growth | evolved |

### Observation Summary

- Total observations: 17
- By type: technology-assessment: 5, actual-outcome: 3, benchmark-result: 3, expert-opinion: 3, viability-prediction: 1, market-data: 1, strategy-classification: 1
