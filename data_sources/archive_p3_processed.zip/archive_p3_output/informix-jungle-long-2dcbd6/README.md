# Database Market Agenda

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995 |
| Type | employer-record |
| Domain | RDBMS market analysis, competitive intelligence, database technology, Unix server market, data warehousing, OLTP, parallel computing |
| License | CC-BY-4.0 |

## Abstract

A 58-slide Aberdeen Group briefing deck by Peter S. Kastner analyzing the 1995 database market. Covers the $20B overall DBMS market with the $5.5B RDBMS submarket as the primary focus. Profiles major suppliers—Oracle, Sybase, Informix, IBM DB2, Microsoft SQL Server, and CA-Ingres—with revenue data, market valuations, strategic themes, and competitive weaknesses. Evaluates vendors across six categories: Scalability, Distributed Technology, Open Technology, Development Tools, Other Technologies, and Supplier Solutions. Includes hardware-partner dynamics, a humorous user 'Top-10 Database Selection Outcomes' section, and IBM RS/6000+DB2 positioning guidance.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 20 |
| technologies.csv | 36 |
| observations.csv | 60 |
| codes.csv | 36 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Database Market Agenda.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Analyst briefing/presentation deck; Aberdeen Group primary research combined with vendor financial data from Software Magazine and Business Week; competitive product evaluation across six rating categories; buyer-needs synthesis from Aberdeen surveys
