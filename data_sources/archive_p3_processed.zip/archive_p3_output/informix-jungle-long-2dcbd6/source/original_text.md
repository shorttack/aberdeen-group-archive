# Database Market Agenda

> Archived from: source/_raw_text.txt
> Original publication date: 1995
> Author: Peter S. Kastner

---

## Original Document Text

                Database Market Agenda

  • Market Size
  • Market Characteristics
  • Suppliers
  • Buyer Needs




© AberdeenGroup 1995                     1
                       Database Market Size
• Overall WW market around $20 billion
• RDBMS market is largest segment at $5.5 billion
• Biggest market US, second Europe, fastest growing
  Japan (3rd largest) and Latin America
• Unix-server DBMS revenue now greater than
  mainframe revenues
• Major RDBMS suppliers are growing by 30-70% per
  year in revenue
• Pure decision support not yet over $2 billion. Bulk
  is OLTP and product query


© AberdeenGroup 1995                               2
                        Market Characteristics
• An increasing number of sales for application server or
  database server to carry out one competitive-advantage
  application, linked to other servers
   – Hardware used to drive the sale,
   – but increasingly DBMS or application drives the sale
• Focus on RDBMS submarket (where the action is)
   – RDBMS submarket is exceptionally fast-growing
     (50+% per year)
   – Desktop tools to access RDBMS are another attractive
     market
   – Significantly, Aberdeen research sees 9 RDBMS
     licenses for every 10 commercial multiuser servers
 © AberdeenGroup 1995                               3
                                                 Sybase Inc.
• Total 1994 corporate revenue $826 million, a 71%
  increase from 1993
• YTD Sales growth rate 51.9%
• Market Value $2.4 billion (July 28 1995)
• 41% Stock price drop -- first week April




                       (source: Software Magazine and Business Week)


© AberdeenGroup 1995                                                   4
                        Sybase
  • Key product -- SQL Server/System 10
  • Started with medium-scale & departmental, now
    scaling to enterprise
     – “Leading-edge” reputation
     – Good replication but lags in parallel-scalable,
       scalability poor beyond 4 processors
     – Strong fixation on competition with Oracle
        • New decision support, workgroup products
          positioned against Oracle
        • Advertising, sales force head-to-head focus


© AberdeenGroup 1995                                 5
                        Sybase

  • Second-largest RDBMS supplier
     – Past 60-80% growth rate
     – Powersoft acquisition beefs up tools
     – Mostly direct sales, few ISVs and apps
  • The future (System 11 is not just another release):
     – Add parallel-scalable technology, shared-less
     – “Leading-edge” distributed database
       management on Tivoli frameowrk
     – Merge Navigation Server data warehousing,
       sell IQ Accelerator for warehousing
© AberdeenGroup 1995                                  6
                       Sybase 1995 Themes

  • We will scale with System 11 enhancements
  • Fast growth, Wall Street superstar company -- down
    but not out
  • Replication -- we have it; you need it
  • Powersoft acquisition fills the tools gap
  • Navigation Server -- yes, we do parallel MPP
  • IQ Accelerator -- yes, we do complex decision
    support
  • System 11 will fix our performance problems

© AberdeenGroup 1995                               7
                       Computer Associates

  • Second largest software company behind Microsoft -- $2.74B
  • 22.2% net profit margin -- best in database industry
  • Primary segments are applications, system software, systems
    management
  • Client-server is now 30% of business; remainder is mainframe
  • Legent acquisition adds more systems management focus and
    pizazz to CA-Unicenter
  • Database products include IDMS, Datacom, and Ingres
  • More open, more innovative but still selling around negative
    customer perceptions



© AberdeenGroup 1995                                        8
                   CA-Ingres 1995 Themes

  • We haven't died! But we were acquired by Computer
    Associates
  • $30,000,000 marketing campaign to revitalize Ingres
  • OPENROAD -- New Windows 4GL version competes head on
    with Informix NewEra for best-in-class OO/GUI tool
  • Open Ingres: RDBMS engine update
  • Leader in Replication
  • Excellent connectivity into IBM MVS applications
  • Higher product quality, service offerings
  • Ingres should not be ignored, but CA with Ingres is not much
    of a market factor today outside the installed base


© AberdeenGroup 1995                                        9
                                 Informix
  • Total 1994 corporate revenue equals $469 million, up
    33% from 1993; last 12 months at $568 million
  • Market value $4.3 billion, up from $1.5B in 1994
  • Share prices up 207% in last 52 weeks!




                       (source: Software Magazine and Business Week)


© AberdeenGroup 1995   (share price as of 7/29/95)                     10
                       Informix
  • Key Product -- Informix-OnLine DSA 7.1
  • Started with medium-scale & departmental, now scaling
    to enterprise with version 8, XPS
     – Focus on Unix, indirect channels
     – Leader in parallel-scalable (Dynamic Server
        Architecture) but lags in replication
     – New toolset version (NewEra) with second-
        generation technology
  • Third-largest RDBMS supplier
     – Growth rate has accelerated in past year
     – Expanding high-end direct sales with success of DSA
        in Unix/OLTP and data warehousing as a hot-box
© AberdeenGroup 1995                                   11
                       Informix
  • Service and support receive good marks from users
    but is limited in scope
  • The future:
     – Improve parallel-scalable technology with
       clusters and MPP in just-announced Version 8
     – Add competitive replication technology
     – Achieve better sales for top-notch NewEra OO-
       GUI development tool




© AberdeenGroup 1995                              12
                       Informix 1995 Themes

  • OnLine 7.1 for mass-market SMP servers
  • OnLine 8.0 rollout for MPP, clusters
  • NewEra OO tool - Motif, Browser, Partitioning
  • Workgroup/OnLine for NT, Personal/SE
  • Replication
  • Systems Management
  • Gateways via DRDA




© AberdeenGroup 1995                                13
                                                             Oracle
   • 1994 total corporate revenue equals 2.4 billion, up 40%
     from 1993
   • Market value $18.7 billion, up 100% from 1994
   • Stock up 134% in last 52 weeks (as of July 29, 1995)




             (source: Software Magazine and Business Week)

© AberdeenGroup 1995                                                  14
                           Oracle
   • Key Product -- ORACLE 7.1
   • Focus on high end
      – Used to sell “runs on any platform”
      – Now sells “broadest functionality, one-stop
        shopping”
      – Supports both parallel-scalable and replication
        technology
      – New multimedia, text, desktop, and workgroup
        server products
   • Largest RDBMS supplier
      – On track for $3.6+ billion in revenues in fiscal 1996
      – Direct sales, but increasing indirect selling
© AberdeenGroup 1995                                       15
                        Oracle

• New focus on services
   – Vertical-industry services (telecomm, oil/gas, etc.)
   – Sales reps carry a consulting quota
• The future:
   – Object-oriented technology in Oracle 8
   – Competition with IBM, Microsoft and CA for
     overall IT market share
   – Multimedia set-top boxes and Hollywood


© AberdeenGroup 1995                                  16
                       Oracle 1995 Themes

  • Enterprise Scalability, one-stop-shopping
  • Applications business: turn a liability into an asset
  • You need consulting ... we have it
  • Workgroup 2000:
        – Personal, WG, wireless, easy to install/administer
  • Multimedia platform-of-choice (e.g., US West)
  • Oracle 8 -- Sorry, not until 1996...
        – but 7.2 and 7.3 offer better performance, scalability



© AberdeenGroup 1995                                              17
                           IBM
   • Key Product -- DB2
   • Largest overall DBMS supplier, but hard to tell revenues
      – Focus on mainframe, but increasingly on AS/400
        minicomputer, RS/6000 server platform, even
        DB2/6000 on HP & Sun
      – Invented relational technology but slow to get it out
        of labs
   • New-found competitiveness in DB2
      – Parallel/scalable PQS and SP2
      – Strong but proprietary replication technology
      – Lags in parallel-scalable but not by many months

© AberdeenGroup 1995                                     18
                        IBM
  • Typically a bundled sell with other IBM products,
    especially hardware and services
     – Extensive, worldwide service includes
       outsourcing and system integration
  • The future for DB2:
     – Add more non-IBM platforms
     – Match/surpass the independents in RDBMS
       technology
     – Scale from high-end SMP, clusters to MPP SP2
     – Better coordination between DB2 versions

© AberdeenGroup 1995                               19
                       IBM 1995 Themes

  • Continue roll-out of RS/6000 SMP servers “the
    second generation”
  • Build towards “best in class” image with best
    price/performance
  • Move the SP2 into general availability for mission-
    critical applications, particularly data warehousing
  • DB2/6000 version 2 brings new levels of
    functionality
  • Innovative query tools for data analysis and
    complex decision support

© AberdeenGroup 1995                                 20
                       Microsoft
  • Key Product -- SQL Server 6.0
  • Windows NT Server moves Microsoft into the
    department and enterprise
  • SQL Server 6.0
     – Highly aggressive pricing
     – Derived from Sybase but now diverged ...
     – All-Microsoft code developed by a world-class team
     – Tight integration between OS and RDBMS
     – Excellent performance on DEC Alpha @ 2,800 tpm_C
       with only 3 CPUs; leading price/performance



© AberdeenGroup 1995                                  21
                       Microsoft
  • Service and support less extensive than other
    suppliers. Few people & programs.
  • The future:
     – Scale towards the glass house
     – Catch up with RDBMS technology leaders
     – Grow market share
     – Add support channels, applications




© AberdeenGroup 1995                                22
      Partnering With an RDBMS Sales
       Rep: A View From a Hardware
           Supplier's Perspective


                 Which comes first? The hardware or the RDBMS?




© AberdeenGroup 1995                                             23
              Why Talk About Hardware
                     Partners?
  • They introduce you to new business
  • They can keep you away from new business
  • They have a different perspective on the sale
  • They have to eat too!




© AberdeenGroup 1995                                24
                       Rules of Thumb

  • Everybody is as nervous as a nineth grader at a school dance
  • Software Reps do not believe neutrality spiel either
  • Most reps will only wire an RDBMS if they have to, and late
    in the game at best
  • Hardware Rep thinks RDBMS rep will switch hardware on
    him/her
  • Hardware Rep will usually partner with a VAR Rep over
    Direct RDBMS Rep, believing they have more control
  • Account control perception is highly selective




© AberdeenGroup 1995                                          25
          Notes From a Hardware Rep --
               Informix Software
  • An easy-to-do-business-with company
  • Modest enterprise selling experience, but viewed by many as
    the hottest RDBMS on the street today
  • A good porting partner
  • One of the best comp plans on the street for OEM sales
  • Very little channel conflict except on biggest deals
  • Thousands of VAR resellers for solution sells
  • Little support/consulting/SI -- looks to 3rd parties or hardware
    supplier for this




© AberdeenGroup 1995                                            26
          Notes From a Hardware Rep --
                     Oracle
  • Hardware rep is typically pleased if Oracle wants to partner
  • Regardless of contract type, Oracle Rep always
    wants/takes/steals the deal ...
  • This can still be good for the hardware rep!
  • Large reference base
  • Very fast growing VAR base
  • A call-brand supplier to many large buying organizations




© AberdeenGroup 1995                                           27
          Notes From a Hardware Rep --
                   CA-Ingres
  • Sales usually result when customer specifies Ingres
  • Ingres' poor visibility in U.S. would stop most Hardware Reps
    from leading with Ingres
  • Ingres leans towards a technology-superiority sell
     – Excellent at complex applications
     – First rate development tool in OPENROAD
  • Partnering is highly deal-oriented
  • CA has made great strides in improving Ingres technology,
    quality
  • Large VAR base
  • What does the customer think about CA?

© AberdeenGroup 1995                                         28
          Notes From a Hardware Rep --
                    Sybase
  • Can you spell SUN MICROSYSTEMS? Sybase has blatantly
    proposed switching customers/prospects to Sun
  • Sun used to represent 40% of Sybase sales -- now about 25%
     – Best (only?) working version
     – Long-term local relationships with Sun reps
  • Sales of Sun now neck-and-neck with RS/6000 and HP 9000
  • Sybase is biased towards tier-1, top-5 hardware platforms,
    including RS/6000, HP 9000, Sun, Digital
  • Sybase is always focused on what Oracle is doing, never on
    the hardware platform



© AberdeenGroup 1995                                       29
          Notes From a Hardware Rep --
                 IBM DB2/6000
  • A Sun or HP hardware rep would never ever suggest IBM’s
    DB2/6000, even though it runs on their platforms
  • If you were in their shoes, would you?
  • Besides the account control issues
     – HP and Sun reps know nothing about DB2/6000 on their
        platforms -- unable to assist customer
     – Customers will drive DB2/6000 selection here, but
     – Aberdeen in unaware of any significant sales motions for
        DB2 off of IBM hardware platforms
  • An IBM rep selling DB2/6000 has a compelling story,
    particularly to a (largely) IBM installed-base account


© AberdeenGroup 1995                                         30
        Weighting RDBMS Technology

          • Not all features should be weighted the
            same
          • Every competitor touts their best features
          • Customers are different
          • Customers become confused

© AberdeenGroup 1995                                     31
              RDBMS Common Features

  An architecture                  4GL, report writer, DBA tools
  ANSI SQL                         Referential integrity
  20 GB-plus databases             Stored procedures & triggers
  Two-phase commit                 High-performance OLTP
  Multiprocessing                  Distributed query support
  Development tools                Object-oriented
  Special data types               Mission-critical customers
  Replication




  No competitive advantage here!
© AberdeenGroup 1995                                               32
                  User’s Top-10
           Database Selection Outcomes
  10. Your requirements today will not be your requirements
     tomorrow. You will be told about tomorrow’s requirements 5
     minutes before you report recommendations to the Board of
     Directors.
  9. Whichever database is chosen, the loser will take the CIO to
     lunch and convince him/her the selection was done by idiots.
  8. It is your personal fault every time there is a bug found in the
     chosen database.
  7. The database not selected is always the one that would have
     been faster for this application.
  6. The vendor who loses will never speak to you again,
     considering your decision a personal insult.

© AberdeenGroup 1995                                              33
                  User’s Top-10
           Database Selection Outcomes
  5. The tool you like the best and recommend is not the one
     chosen by management.
  4. As soon as you buy, 12 reviews will score your choice a 2 on a
     1-5 scale. You will spend your life defending your decision.
     Your best line is “wait until the next release.”
  3. A new benchmark will come out showing your database is
     half the speed of all others.
  2. As soon as you place your order, your second choice will
     announce a new release with all their deficiencies solved plus
     all your number 1 choice’s deficiencies solved.
  1. You’ll discover the perfect DBMS/development tool ... but you
     won’t be able to afford it.
  Attributed to Ken Leech

© AberdeenGroup 1995                                           34
     Aberdeen’s 1995 RDBMS Themes
                            Parallel processing
                            RDBMSs bring
     Middleware             scale-up or speed-up
     (gateways, open
                                                   Higher-powered
     clients, servers,
                                                   tools -- objects
     transparency)                                 everywhere
     drive enterprise
     connectivity
                                                   Personal/
           Enterprise                              workgroup
           administration    Replication for       databases
                             distributing data




© AberdeenGroup 1995                                                  35
       Aberdeen’s 1995 RDBMS Rating
                 Categories

• Scalability
• Distributed Data
• Open Data Access
• Development Tools
• Other Technology
• End-User Solutions




© AberdeenGroup 1995              36
                       Scalability

  Can I write an application once and have it grow or
    shrink to fit changing enterprise needs?
     – Non-parallel performance
     – Parallel performance
     – Large databases
     – High-availability features




© AberdeenGroup 1995                                    37
                       Scalability Notes
 • CA Ingres -- Modest scalability; no MPP
 • IBM DB2 for AIX
    – Competitive but not leading on SMP
    – Only compatible SMP and MPP story except AT&T
 • Informix
    – Good scalability to 8 processors on SMP. Many TPC-Cs.
    – Soon on SP2 and other loosely-coupled HW with version 8
 • Microsoft -- Modest scalability; no MPP; good on Alpha
 • Oracle
    – Good scalability story from desktop to SP2 & ES/9000
    – No TPC-C benchmarks until July 1995 -- Hot stuff
 • Sybase
    – Poor scalability beyond 4 processors. Good up to 4.
    – Navigation Server: Poor high-end MPP on AT&T 3600

© AberdeenGroup 1995                                      38
                  Distributed Technology

   Can I move computing and data out to workers and
     still be able to effectively administer it?

         – Tightly-coupled data -- two-phase commit
         – Loosely-coupled data -- replication
         – Simultaneous-update data -- peer-peer
         – Distributed administration




© AberdeenGroup 1995                                  39
          Distributed Technology Notes

  • CA Ingres: Best functionality
  • IBM DB2 for AIX: Good async replication in Data Propagator,
    but no peer-peer replication
  • Informix: Behind; better next year
  • Microsoft: Limited replication in new SQL Server 6 for NT
  • Oracle: Good replication including peer-peer
  • Sybase: OK asynchronous replication; no peer-peer




© AberdeenGroup 1995                                       40
                       Open Technology
  How will my applications work with other data
    sources?
     – Standards
     – Gateways, open clients
     – Open OLTP monitors
     – Access to other supplier’s RDBMSs




© AberdeenGroup 1995                              41
                  Open Technology Notes

  • CA Ingres: good mainframe gateways
  • IBM DB2 for AIX: full 2-way DRDA, ODBC; limited non-
    IBM gateways
  • Informix: DRDA client; limited gateways, but IBI ties.
    Improving APIs
  • Microsoft: great for PC apps; OLE; ODBC inventor
  • Oracle: DRDA client; broad gateways. Improving APIs.
  • Sybase: Open Client & Open Server appeal to 3GL bigots.
    Best gateway breadth. Overall, most flexible.




© AberdeenGroup 1995                                          42
           Distributed Tool Technology

  How can I efficiently develop, deploy and maintain
    distributed applications?
     – Distributed application support
     – Open technology
     – Programmer technology
     – Other development technology




© AberdeenGroup 1995                                   43
                 Development Tool Notes

  • CA Ingres: OpenROAD is most mature OO CADE
  • IBM DB2 for AIX: No comparable tools for OO CADE. More
    limited ISV selection than Informix, Oracle and Sybase
  • Informix: New Era is maturing as OO CADE
  • Microsoft: MFC as a 4GL is excellent for MS environment
  • Oracle: clunky tools only work on Oracle. Oracle Objects is
    interesting but low-end, incompatible with Developer/2000
  • Sybase: Powersoft & Watcom are among market leaders




© AberdeenGroup 1995                                        44
                       Other Technologies

  What other technologies are needed to develop superior
   distributed applications?
    – Business-rules processing
    – BLOBS, multimedia
    – Non-standard data types
    – Object extensions




© AberdeenGroup 1995                                 45
                 Other Technology Notes

  • CA Ingres: partnership with Fujitsu for 1st ORDBMS in ‘96
  • IBM DB2 for AIX: fast moving DB2 into searchable audio,
    video, user-defined data types. Hot stuff.
  • Informix: not much today. Practical BLOB support.
  • Microsoft: OLE, futures
  • Oracle: Most aggressive in multimedia marketing; objects by
    1997; serious about video on demand
  • Sybase: more multimedia/OO talk than action




© AberdeenGroup 1995                                        46
                       Supplier Solutions

      What else can my RDBMS supplier bring to the
      table?
       – Applications
       – Third-party support
       – Consulting & services




© AberdeenGroup 1995                                 47
           Supplier Added-Value Notes

  • CA Ingres: almost no services; many ISVs plus CA apps
  • IBM DB2 for AIX: world-class services; growing number of
      ISVs with many apps
  • Informix: almost no services; many ISV apps; never own apps
  • Microsoft: no services; most apps are for workgroups
  • Oracle: lots of services; many ISVs; Oracle applications
  • Sybase: fewer services; fewer ISVs; no applications




© AberdeenGroup 1995                                           48
                   CA-Ingres Weaknesses

  •   No Ingres people remain -- but no customers have defected
  •   CA sales force does not understand the Unix world
  •   Product quality was poor, getting better
  •   RDBMS architecture is at On-Line 6.0 level -- no parallel
  •   OPENROAD left customers with character 4GL behind --
      totally different, incompatible environment




© AberdeenGroup 1995                                          49
                       IBM Weaknesses

  • Essentially a new player with SMP RS/6000's and DB2/6000 v2
     – Old limits are still remembered.
     – Must shatter perceptions of limited scalability
  • Limited cross-platform, cross-OS
  • Still caution by "open" zealots




© AberdeenGroup 1995                                       50
                       Informix Weaknesses

  • Late with desktop & workgroup database/tools
  • Behind in replication and will remain so
  • NewEra 2.0 makes the product more useable
  • Slow to build direct sales force, marketing ... missed growth
    opportunities over past two years
  • No NetWare story
  • No-consulting policy slowed large enterprise growth




© AberdeenGroup 1995                                           51
                       Oracle Weaknesses

  • RDBMS engine looks dated -- where are the TPC-C's?
  • Informix can win on architecture and demonstrated
    performance
  • Deal-driven, not partnership driven
  • No 2nd generation client-server ala NewEra
  • Unfocused: Hollywood multimedia, applications, TV set-tops
  • Service/consulting drive makes ISV partnering tough
  • Informix is the RDBMS specialist to Oracle the generalist




© AberdeenGroup 1995                                       52
                       Sybase Weaknesses

  • 1980s architecture runs out of steam -- they need System 11
    now
     – Poor scalability in SMP, database size = departmental
       RDBMS
  • Poor GUI tools drove Powersoft acquisition
  • Navigation Server is platform-limited to the NCR 3600, an
    OLTP dog (but SP2 version is imminent)
  • Very few application solution partners & solutions
  • A North American phenomena, hardly seen elsewhere
  • Over-reaching sales tactics turn off customersmomentum



© AberdeenGroup 1995                                              53
          Where is IBM Best Positioned
                     Today?
  • Worldwide support and service ... the SAP R/3 story
  • Enterprises that commit to DB2 across IBM platforms
  • With mainframe ISVs who have ported to client-Unix-server
  • Departmental systems to 4-6 processors for OLTP
     – SMP is new for RS/6000, old for competition
  • Expandable workgroup-plus servers above/at OS/2 level
     – SMP & SP2 improve ability to do bigger systems
  • Modest data warehouses on SMP or SP2
     – Products now in place. Field experience will come over
       next year.



© AberdeenGroup 1995                                       54
                           Wrap-up

  • RDBMS on midrange server is the hot market
  • Technology is incredibably fast-moving
        – Deemphasize today’s product speeds and feeds
        – Emphasize long-term cost-of-ownership benefits
  • Users are emphasizing scalability and flexibility
    – Parallel-scalable technologies for multi-size
      OLTP and definitely for data warehousing
    – Replication technologies for managing the
      process of moving data around the enterprise


© AberdeenGroup 1995                                       55
        ISV Support for Unix Platforms
  • Application solutions pull through hardware/RDBMS
  • IBM gained market share in 1994, usually at the expense of HP
                        Platform Choices by Hardware Supplier
                        Source: Aberdeen Group and ISVs




© AberdeenGroup 1995                                            56
              Where RS/6000 with DB2 is
                     Best Suited
  • Product Strengths
     – DB2 for AIX 2 engine -- functionally much improved but
       nobody knows about it
     – Distributed technology using Data Propagator between
       mainframe and middle-server RS/6000s
     – Good performance and price-performance
     – Outstanding OLTP support with CICS, Ensina, & Tuxedo
     – Promising scalability with HACMP and SP2
  • Elevator Story




© AberdeenGroup 1995                                      57
             RS/6000 DB2 Elevator Story
                    CIO & CEO




© AberdeenGroup 1995                      58


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | informix-jungle-long-2dcbd6 |
| title | Database Market Agenda |
| author | Peter S. Kastner |
| date | 1995 |
| type | employer-record |
| subject_domain | RDBMS market analysis, competitive intelligence, database technology, Unix server market, data warehousing, OLTP, parallel computing |
| methodology | Analyst briefing/presentation deck; Aberdeen Group primary research combined with vendor financial data from Software Magazine and Business Week; competitive product evaluation across six rating categories; buyer-needs synthesis from Aberdeen surveys |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

A 58-slide Aberdeen Group briefing deck by Peter S. Kastner analyzing the 1995 database market. Covers the $20B overall DBMS market with the $5.5B RDBMS submarket as the primary focus. Profiles major suppliers—Oracle, Sybase, Informix, IBM DB2, Microsoft SQL Server, and CA-Ingres—with revenue data, market valuations, strategic themes, and competitive weaknesses. Evaluates vendors across six categories: Scalability, Distributed Technology, Open Technology, Development Tools, Other Technologies, and Supplier Solutions. Includes hardware-partner dynamics, a humorous user 'Top-10 Database Selection Outcomes' section, and IBM RS/6000+DB2 positioning guidance.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Detailed 1995 snapshot of the RDBMS competitive landscape at a pivotal moment—Unix server DBMS surpassing mainframe revenues, RDBMS growing 50%+ per year, parallel scalability emerging as the key differentiator. Rare primary-source vendor financials and analyst ratings from this era. |
| **Relevance** | 5 | Core Kastner expertise area: RDBMS competitive analysis, Aberdeen research methodology, Informix positioning. Kastner's multi-year engagement with Informix is directly evidenced; this deck informed the broader 'Database Market Agenda' canon he built. |
| **Prescience** | 4 | Highly accurate predictions: Oracle 8 OO features did arrive (1997), Informix lagged in replication (accurate), Sybase System 11 did fix some but not all scalability limits, MPP/cluster parallelism did become mainstream, Microsoft SQL Server did scale toward enterprise. Minor misses: Informix parallel story (XPS/Version 8) was weaker than expected. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (20)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |
| Oracle | organization | active |  |
| Sybase | organization | active |  |
| Informix Software | organization | active |  |
| IBM | organization | active |  |
| Microsoft | organization | active |  |
| Computer Associates | organization | active |  |
| Sun Microsystems | organization | active |  |
| Hewlett-Packard | organization | active |  |
| Digital Equipment Corporation | organization | acquired | compaq |
| NCR Corporation | organization | active |  |
| SAP | organization | active |  |
| Ken Leech | person | active |  |
| Powersoft Corporation | organization | acquired | sybase |
| Fujitsu | organization | active |  |
| Watcom International | organization | acquired | sybase |
| Information Builders Inc. (IBI) | organization | active |  |
| Tivoli Systems | organization | acquired | ibm |
| Legent Corporation | organization | acquired | computer-associates |

### Technologies Referenced (36)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Informix Dynamic Scalable Architecture (DSA) | framework | Informix | growth | legacy |
| Informix-OnLine DSA 7.1 | database | Informix | growth | legacy |
| TPC-C Benchmark | framework | Transaction Processing Performance Council | growth | legacy |
| Sybase System 10 / SQL Server | database | Sybase | mature | legacy |
| Sybase Navigation Server (MPP) | database | Sybase | emerging | legacy |
| Oracle 7.1 / ORACLE 7 | database | Oracle | mature | legacy |
| IBM DB2 (DB2/6000, DB2 for AIX) | database | IBM | growth | legacy |
| Microsoft Windows NT Server | platform | Microsoft | growth | legacy |
| ODBC (Open Database Connectivity) | protocol | Microsoft | growth | legacy |
| Symmetric Multiprocessing (SMP) | hardware |  | growth | mature |
| Massively Parallel Processing (MPP) | hardware |  | emerging | mainstream |
| Parallel-Scalable RDBMS | database |  | emerging | mainstream |
| Data Warehousing | framework |  | growth | evolved |
| Informix NewEra OO Development Tool | application | Informix | growth | legacy |
| Informix XPS / Version 8 (Extended Parallel Server) | database | Informix | emerging | legacy |
| Sybase System 11 | database | Sybase | emerging | legacy |
| Sybase IQ Accelerator | database | Sybase | emerging | legacy |
| Sybase Replication Server | middleware | Sybase | growth | legacy |
| CA OPENROAD (Open Ingres 4GL/OO) | application | Computer Associates | growth | legacy |
| Open Ingres RDBMS (CA-Ingres) | database | Computer Associates | declining | legacy |
| IBM SP2 (Scalable POWERparallel Systems) | hardware | IBM | emerging | legacy |
| IBM HACMP (High Availability Cluster Multi-Processing) | software | IBM | growth | legacy |
| DRDA (Distributed Relational Database Architecture) | protocol | IBM | growth | legacy |
| Microsoft SQL Server 6.0 | database | Microsoft | growth | legacy |
| IBM Data Propagator (DB2 Replication) | middleware | IBM | growth | legacy |
| IBM DB2 PQS (Parallel Query Server) | database | IBM | emerging | legacy |
| Oracle 8 (Object-Oriented Extensions) | database | Oracle | emerging | legacy |
| IBM CICS (Customer Information Control System) | middleware | IBM | mature | legacy |
| RDBMS Replication Technology | middleware |  | growth | legacy |
| Microsoft MFC as 4GL (Developer Tools) | application | Microsoft | growth | legacy |
| Oracle Developer/2000 | application | Oracle | growth | legacy |
| CA-Unicenter (Systems Management) | software | Computer Associates | growth | legacy |
| CA IDMS and Datacom Databases | database | Computer Associates | mature | legacy |
| IBM Encina and Tuxedo OLTP Monitors | middleware | IBM/Transarc | growth | legacy |
| OLE (Object Linking and Embedding) | framework | Microsoft | growth | legacy |
| Sybase Open Client / Open Server | middleware | Sybase | mature | legacy |

### Observation Summary

- Total observations: 60
- By type: market-share: 17, technical-claim: 17, competitive-analysis: 15, market-size: 4, prediction: 3, adoption: 2, strategic-recommendation: 2
