# Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1994-1995 |
| Type | employer-record |
| Domain | parallel-scalable RDBMS, downsizing, SMP architecture, MPP architecture, cluster computing, database performance, client-server computing, enterprise computing |
| License | CC-BY-4.0 |

## Abstract

An Aberdeen Group presentation deck by Peter S. Kastner arguing that parallel-scalable RDBMS technology can break the 'downsizing logjam'—the bottleneck preventing enterprises from migrating workloads from mainframes to midrange servers. Identifies three driving forces (global competition, technology innovation, social change) and four key problems with conventional RDBMSs (coarse-grain multiprocessing, administration bottlenecks, poor scale-up, slow response times). Proposes parallel-scalable RDBMS (fine-grain multiprocessing, parallel administration, dynamic resource scalability, batch speed-up via parallelization) as the solution. Recommends SMP now, with clusters and MPP as the evolutionary path. Concludes IS departments should take a hard look at parallel-scalable solutions immediately.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 2 |
| technologies.csv | 12 |
| observations.csv | 35 |
| codes.csv | 30 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1994). Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Analyst pitch/briefing deck; advocates for parallel-scalable RDBMS as solution to downsizing bottleneck; technology framework synthesis; buyer-needs analysis based on Aberdeen primary research; conceptual architecture diagrams
