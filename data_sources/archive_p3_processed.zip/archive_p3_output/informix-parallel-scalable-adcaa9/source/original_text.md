# Can Parallel-Scalable RDBMSs Break the Downsizing Logjam?

> Archived from: source/_raw_text.txt
> Original publication date: 1994-1995
> Author: Peter S. Kastner

---

## Original Document Text

Can Parallel-Scalable
 RDBMSs Break the
Downsizing Logjam?


                   AberdeenGroup
Agenda


  ä Facing
  ä Facing the
           the downsizing
               downsizing logjam
                          logjam
  ä Parallel-scalable
  ä Parallel-scalable relational
                      relational databases
                                 databases
  ä Benefits
  ä Benefits
  ä What
  ä What to
         to look
            look for
                 for
  ä Wrap-up
  ä Wrap-up




                                    AberdeenGroup
Downsizing Logjam


     ä Driving
     ä Driving forces
               forces
     ä Good
     ä Good old
            old days
                days are
                     are gone
                         gone
     ä Information
     ä Information logs
                   logs create
                        create aa jam
                                  jam
     ä Red
     ä Red summer
           summer dresses
                  dresses
     ä Why
     ä Why empower
           empower users?
                   users?




                                   AberdeenGroup
Driving Forces



 ä Global
 ä Global competition
          competition
 ä Technology
 ä Technology innovations
              innovations
 ä Social
 ä Social changes
          changes




                            AberdeenGroup
Good Old Days are Gone


   Capture


              Add It
              Store It

                          Sort It
                         Report It
  Customers

                                AberdeenGroup
Information
Information Demands
            Demands Go
                    Go Through
                       Through the
                               the Roof
                                   Roof



    ä Online
    ä Online transaction
             transaction processing
                         processing
    ä Production
    ä Production queries
                 queries
    ä New
    ä New client-server
          client-server applications
                        applications
    ä Desktop
    ä Desktop automation
              automation
    ä Ad
    ä Ad hoc
         hoc queries
             queries and
                     and decision
                         decision support
                                  support


    3-5x
    3-5x increase
         increase in
                  in information
                     information demand
                                 demand by
                                        by late
                                           late 1990s
                                                1990s


                                           AberdeenGroup
Red Summer Dresses


  ä It’s
  ä It’s May
         May in
             in Miami.
                Miami. Your
                       Your store
                            store manager
                                  manager
    has
    has 1,000
        1,000 red
              red summer
                   summer dresses
                           dresses that
                                   that
    have
    have not
         not sold.
             sold. Does
                    Does the
                         the company:
                             company:
     –– Put
        Put them
            them on
                  on sale?
                      sale?
     –– Ship
        Ship them
              them to
                   to Boston?
                      Boston?

  ä Be
  ä Be careful.
       careful. The
                The correct
                    correct decision
                            decision drops
                                     drops
    directly
    directly to
             to the
                the bottom
                    bottom line!
                           line!


                                   AberdeenGroup
Why Empower Users?

ä Personnel
ä Personnel downsizing
            downsizing
  is
  is aa reality
        reality
ä Computer
ä Computer literacy
                literacy
  improving
  improving
ä Increased
ä Increased job-level
                job-level
  productivity
  productivity
ä Users
ä Users are
          are decision
                decision
  makers
  makers
ä New
ä New decision-making
         decision-making
  cycle
  cycle
                            AberdeenGroup
Breaking the Logjam




                      AberdeenGroup
Technology Goals

ä Excellent
ä Excellent
  cost-performance
  cost-performance
ä Scalability
ä Scalability
ä Availability
ä Availability
ä Fast
ä Fast response
       response times
                 times
ä Open
ä Open infrastructure
        infrastructure
ä Development
ä Development tools
                tools
ä Ease
ä Ease of
        of administration
           administration

                            AberdeenGroup
Midrange Server Technology Ingredients


 Competitive Pressures Force Technology Excellence

  ä Lots
  ä Lots of
         of microprocessors
            microprocessors
  ä Lots
  ä Lots of
         of memory
            memory
  ä Fast
  ä Fast I/O
         I/O buses
             buses
  ä Intelligent
  ä Intelligent controllers
                controllers
  ä Unix-on-steroids
  ä Unix-on-steroids



                                        AberdeenGroup
Relational
Relational Databases
           Databases are
                     are the
                         the Biggest
                             Biggest Problem
                                     Problem

  ä Coarse-grain
  ä Coarse-grain multiprocessor
                 multiprocessor support
                                support
  ä Administration
  ä Administration bottlenecks
                   bottlenecks
  ä Poor
  ä Poor scaleup
         scaleup in
                 in database
                    database size
                             size
  ä Few
  ä Few ways
        ways to
             to speed
                speed up
                      up response
                         response times
                                  times




                                     AberdeenGroup
Parallelizing
Parallelizing the
              the RDBMS
                  RDBMS Solves
                        Solves the
                               the Problem
                                   Problem



 ä Fine-grain
 ä Fine-grain multiprocessor
              multiprocessor
   support
   support
 ä Parallel
 ä Parallel administration
            administration
 ä Dynamic
 ä Dynamic resource
             resource
   scalability
   scalability
 ä Speed-up
 ä Speed-up batch
               batch by
                     by
   parallelization
   parallelization



                                    AberdeenGroup
Fine-grain Multiprocessor Support


ä Harness
ä Harness available
          available CPUs
                    CPUs               Task
ä Sort,
ä Sort, index,
        index, aggregate,
               aggregate,
  scan,
  scan, merge
        merge operations
               operations    Subtask             Subtask
ä Application
ä Application scalability
              scalability
        SMP                            Subtask
   ––   SMP
   ––   Clusters
        Clusters
   ––   Massively
        Massively parallel
                  parallel
                              CPU       CPU       CPU




                                          AberdeenGroup
Parallel Administration


  ä Bulk
  ä Bulk loading/unloading
         loading/unloading
  ä Backup/recovery
  ä Backup/recovery
  ä Index
  ä Index building
          building
  ä Mass
  ä Mass updates/deletes
         updates/deletes
  ä Alter/reorganize
  ä Alter/reorganize




                             AberdeenGroup
Dynamic Resource Scalability


 ä Add processors ...
    •   Add users while response
        time remains constant
    •   Improve response time
        while users remain
        constant




                                   AberdeenGroup
Speed-up Batch by Parallelization

                  Batch
                  Batch Jobs
                        Jobs

                       Task
                       Task


                                 Subtask
             Subtask
             Subtask             Subtask
                                  Subtask

                       Subtask
                       Subtask




              CPU
              CPU       CPU
                        CPU        CPU
                                   CPU


                                            AberdeenGroup
Harnessing Today’s SMP Servers
Parallel-scalable RDBMS is like a free hardware upgrade

ä SMP
ä SMP is
      is today’s
         today’s most
                 most prevalent
                      prevalent
  hardware
  hardware architecture
           architecture
ä Hardware
ä Hardware needs
           needs change
                  change
  dynamically
  dynamically
ä Buyers
ä Buyers Get:
         Get:
    –– more
       more users
              users on
                    on same
                       same hardware
                             hardware
    –– faster
       faster response
              response times
                        times
    –– smaller,
       smaller, lower-cost
                lower-cost initial
                           initial
       hardware
       hardware investment
                  investment


                                            AberdeenGroup
Clusters and Massively-Parallel
Processors Tomorrow
                            Massively
                            Massively Parallel
                                      Parallel




                 Clusters
                 Clusters


   SMP
   SMP


          Time
          Time


                                       AberdeenGroup
What
What to
     to Look
        Look for
             for in
                 in Parallel-Scalable
                    Parallel-Scalable RDBMSs
                                      RDBMSs



   ä Hardware
   ä Hardware adaptation:
              adaptation:
     SMP,
     SMP, cluster,
           cluster, MPP
                     MPP
   ä Parallelization
   ä Parallelization breadth
                      breadth and
                                and depth
                                    depth
   ä Benchmarks
   ä Benchmarks
   ä Administration
   ä Administration
   ä Technology
   ä Technology invisibility
                   invisibility




                                        AberdeenGroup
Parallel-Scalable RDBMS Benefits


    ä Improved
    ä Improved performance
               performance can
                           can be
                               be aa
      hardware-upgrade
      hardware-upgrade equivalent
                          equivalent
    ä Increased
    ä Increased robustness,
                robustness, availability
                              availability
    ä Lower-cost
    ä Lower-cost configuration
                  configuration flexibility
                                 flexibility
    ä Improved
    ä Improved scalability
                scalability curve
                            curve




                                      AberdeenGroup
Aberdeen Conclusions

   ä Information-hungry
   ä Information-hungry users
                        users and
                              and
     applications
     applications demand
                   demand better
                            better data
                                    data
     management
     management approaches
                    approaches
   ä Technology
   ä Technology pieces
                  pieces now
                          now fit
                               fit together
                                   together
   ä Parallel-scalable
   ä Parallel-scalable RDBMS
                        RDBMS technology
                                 technology
   ä Solves
   ä Solves real-world
             real-world problems
                         problems
   ä Is
   ä Is now
        now being
             being rolled
                   rolled out
                          out by
                              by RDBMS
                                   RDBMS
     leaders
     leaders


                                    AberdeenGroup
Aberdeen Conclusions

    Parallel-Scalable
    Parallel-Scalable RDBMS
                      RDBMS technology
                            technology

    ä Smashing
    ä Smashing the
               the logjam,
                   logjam, empowering
                           empowering
      users
      users

    ä SMP
    ä SMP now,
          now, clusters
               clusters and
                        and MPP
                            MPP soon
                                soon

      IS
      IS should
         should take
                 take aa hard
                         hard look
                              look now
                                   now at
                                       at
          parallel-scalable
          parallel-scalable solutions
                             solutions


                                      AberdeenGroup


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | informix-parallel-scalable-adcaa9 |
| title | Can Parallel-Scalable RDBMSs Break the Downsizing Logjam? |
| author | Peter S. Kastner |
| date | 1994-1995 |
| type | employer-record |
| subject_domain | parallel-scalable RDBMS, downsizing, SMP architecture, MPP architecture, cluster computing, database performance, client-server computing, enterprise computing |
| methodology | Analyst pitch/briefing deck; advocates for parallel-scalable RDBMS as solution to downsizing bottleneck; technology framework synthesis; buyer-needs analysis based on Aberdeen primary research; conceptual architecture diagrams |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

An Aberdeen Group presentation deck by Peter S. Kastner arguing that parallel-scalable RDBMS technology can break the 'downsizing logjam'—the bottleneck preventing enterprises from migrating workloads from mainframes to midrange servers. Identifies three driving forces (global competition, technology innovation, social change) and four key problems with conventional RDBMSs (coarse-grain multiprocessing, administration bottlenecks, poor scale-up, slow response times). Proposes parallel-scalable RDBMS (fine-grain multiprocessing, parallel administration, dynamic resource scalability, batch speed-up via parallelization) as the solution. Recommends SMP now, with clusters and MPP as the evolutionary path. Concludes IS departments should take a hard look at parallel-scalable solutions immediately.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 3 | Important as an early Aberdeen advocacy piece for parallel-scalable RDBMSs, predating the mainstream adoption of this approach. Represents Kastner's foundational thinking that recurs across his Informix, Bank of America, and data warehousing presentations. Less granular than the jungle-long study but historically significant as a conceptual pitch. |
| **Relevance** | 5 | Directly reflects Kastner's signature thesis on parallel scalability and downsizing that he repeated across multiple client presentations. Shows foundational framework used throughout his 1994-1996 client work period. |
| **Prescience** | 5 | Highly accurate: SMP became dominant, clusters and MPP did follow, parallel-scalable RDBMS (as exemplified by Informix DSA, IBM DB2 SP2, Oracle Parallel Server) did break the logjam. The 3-5x information demand increase by late 1990s was validated. The hardware upgrade equivalence claim (parallel RDBMS = free hardware upgrade) became industry wisdom. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (2)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | active |  |

### Technologies Referenced (12)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Parallel-Scalable RDBMS | database |  | emerging | mainstream |
| Symmetric Multiprocessing (SMP) | hardware |  | growth | mature |
| Cluster Computing | hardware |  | emerging | mature |
| Massively Parallel Processing (MPP) | hardware |  | emerging | mainstream |
| Client-Server Architecture | framework |  | growth | evolved |
| OLTP Database Systems | database |  | mature | mature |
| Data Warehousing / Decision Support | framework |  | growth | evolved |
| Unix Midrange Server Platform | hardware |  | growth | legacy |
| Fine-Grain Multiprocessor Support (Parallel RDBMS) | framework |  | emerging | mainstream |
| Parallel Database Administration | framework |  | emerging | mainstream |
| Dynamic Resource Scalability | framework |  | emerging | mainstream |
| Parallel Batch Processing | framework |  | emerging | mainstream |

### Observation Summary

- Total observations: 35
- By type: technical-claim: 27, adoption: 3, prediction: 3, strategic-recommendation: 2
