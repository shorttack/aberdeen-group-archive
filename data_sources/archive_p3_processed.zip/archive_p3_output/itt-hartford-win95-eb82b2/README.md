# Making the Corporate Platform Decision

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-05 |
| Type | employer-record |
| Domain | desktop OS, platform strategy, Windows 95, Windows NT, NetWare, corporate IT |
| License | CC-BY-4.0 |

## Abstract

9-page executive summary presented to ITT Hartford covering Aberdeen Group's findings on the corporate platform decision. Evaluates desktop OS candidates (Windows 95, OS/2 Warp, NT Workstation), workgroup OS strategy (NT/AS + NetWare), network/system management, groupware, electronic mail, and other platform components. Concludes Windows 95 is the runaway choice as desktop OS; recommends dual workgroup-OS strategy; affirms ITT Hartford's planning process was professional and systematic.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 9 |
| observations.csv | 20 |
| codes.csv | 29 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Making the Corporate Platform Decision.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Client consulting engagement; Aberdeen RAMP analysis; advisory/executive briefing for ITT Hartford on corporate platform decision
