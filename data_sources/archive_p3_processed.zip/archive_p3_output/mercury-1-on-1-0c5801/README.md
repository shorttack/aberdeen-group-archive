# Aberdeen Group Critical Planning Insights — Dynamics of Change

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1995-1996 |
| Type | employer-record |
| Domain | market research, IT consulting, client-server, networking, ERP, workgroup computing, Aberdeen Group methodology |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group capabilities presentation prepared for Mercury One-2-One. Describes Aberdeen's charter (founded 1988, custom consulting focus), research methods (RAMP—Rapid Accurate Market Positioning, focus groups, surveys, ongoing consultation), technology coverage areas (hardware/systems software/networking/app development/system management), and customized research services for IT user and supplier clients. Includes a coverage map of topics where Aberdeen has focused research energy.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 10 |
| technologies.csv | 12 |
| observations.csv | 20 |
| codes.csv | 27 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1995). Aberdeen Group Critical Planning Insights — Dynamics of Change.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Sales/capabilities pitch; overview of Aberdeen research methods (RAMP, focus groups, surveys), custom consulting services; tailored for Mercury One-2-One
