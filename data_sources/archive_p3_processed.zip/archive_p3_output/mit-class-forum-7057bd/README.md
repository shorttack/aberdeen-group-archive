# Who Cares If The Computer Breaks?

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Vice President, Aberdeen Group |
| Date | 1995-10 |
| Type | employer-record |
| Domain | high availability, fault tolerance, downtime, failover architectures, Stratus, Tandem, DEC, application availability, distributed computing |
| License | CC-BY-4.0 |

## Abstract

MIT Forum presentation (October 1995) examining the business and technical dimensions of computer downtime. Covers evolution from batch/one-tier computing to complex multi-tier client-server environments, where failures are increasingly catastrophic. Analyzes application availability metrics (99.9% as floor, not ceiling), hardware/software/network failure modes, failover architectures (Stratus self-checking, Tandem N+1, DEC heartbeat-based), RAID storage, and planning strategies on a 'paranoia curve.' Concludes that future availability improvements depend on system software that assists application failover.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 14 |
| observations.csv | 28 |
| codes.csv | 28 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Vice President, Aberdeen Group (1995). Who Cares If The Computer Breaks?.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Conference presentation; market analysis; primary research on availability architectures; Aberdeen Group conclusions on high-availability computing
