# Who Cares If The Computer Breaks?

> Archived from: source/_raw_text.txt
> Original publication date: 1995-10
> Author: Peter S. Kastner, Vice President, Aberdeen Group

---

## Original Document Text

Who Cares If The Computer
        Breaks?
    MIT Forum  —Kastner
        Peter S. October 1995
         Vice President
      Aberdeen Group, Inc.
      Boston, Mass. 02108
        (617) 723-7890
                                     MIT Forum



Agenda

⬛Who cares if the computer breaks?

⬛Where computer systems fail

⬛Planning for the inevitable

⬛Approaches to minimizing downtime
Who Cares If the Computer
        Breaks?
                                            MIT Forum



Computer Industry
Ancient History
⬛One-tier computing
  –Jobs were batch-processed based on keypunched
     data entered on forms by people
  –Reports printed on paper

  –Virtually no one was on-line

⬛Commercial computers kept the books

⬛If the computer failed, jobs were restarted and
  run again
                                       MIT Forum



Fast Forward to the 1990s

⬛Complex computing environments
  –Multiple tiers of networks

  –Computer-to-computer transactions

  –On-line, real-time changes

  –Less paper, ad hoc queries

⬛Commercial computers make the money

⬛But computer systems still fail!
                                             MIT Forum



Who Cares If The Computer
Breaks?
⬛Public safety

⬛National security

⬛Banking and financial system

⬛Telecommunications industry

⬛Retailers

⬛45% of U.S. workers now using PCs

⬛And virtually every aspect of our society
Where Computer Systems Fail


 Hardware, Networks, & Software
                                                        MIT Forum



Hardware Always Breaks
                                        Reliability Trends
⬛Unit reliability improves
   over time due to fewer,
                                        System
   more robust components
⬛System reliability declines
                     Mean Time Between Failure
   over time due to more
   components                         Components

                                                 1995

                                                 Time



                                             1,000 x
                                                   MIT Forum



Software Usually Breaks

⬛Correct software will outlive its hardware and
  never fail
⬛But most software fails
  –Too many lines of code ... complexity exceeds
     human capacity
  –Poor or unsystematic design, review, testing

  –Poor choice of software development tools

  –Repeated re-work due to business logic changes

  –Trade-offs on quality vs. time-to-market
                                              MIT Forum



Networks Will Always Break

⬛Networks suffer all the inherent problems of
  computer hardware and software, plus the
  reliability problems of electrical/light cables
⬛Network availability is a key inhibitor to the
  growth of distributed computing

                     No
                   Digging
Planning for the Inevitable


     “A stitch in time saves nine”
                                              MIT Forum



Planning for Downtime
⬛Backup files early and often

⬛Keep backup copies off site

⬛Design computer-free business procedures

⬛Choose high-availability computing options

⬛Hot backup of applications

⬛Off-site disaster backup of applications
                                                                                     MIT Forum



  Application Availability
                                                            Downtime Per Year
⬛There are lots of ways to
                                        10000.00   5259.6

   measure availability                  1000.00               526.0

   –MTBSI
                                          100.00                          52.6

   –Hardware availability      Minutes/Year
                                         10.00                                       5.3
                                (log scale)
   –System availability                                                                         0.5
                                            1.00


⬛Application availability to                0.10
                                                   99.0000%   99.9000%   99.9900%   99.9990%
                                                                                               99.9999%



   users is the most useful
                                                                 Uptime Percent
   measure
⬛In today’s business world,
   99.9% is a floor, not the
   ceiling
                                                 MIT Forum



Planning for Downtime
                                ⬛Off-site disaster
                                backup of applications
                          ⬛Hot backup of applications


                      ⬛   High-availability
  Paranoia Curve           computing options

            ⬛Design computer-free business
            procedures

     ⬛Keep backup copies off
     site
 ⬛File backup early and often
                                   MIT Forum



Approaches to Minimizing
Downtime
⬛How paranoid are you?
⬛How much have you got to spend?
  –Hardware

  –Software

  –Networks

  –Other
                                              MIT Forum
Approaches to Minimizing Downtime

   Hardware

   ⬛Standard industry practices to catch errors

   ⬛Self-testing (including systems management
       software)
   ⬛Overcapacity by design

   ⬛Hot replacement of power, fan, disk
       components
   ⬛RAID disk storage options

   ⬛Redundant hardware with failover (N+1 or
       other)
                                                                     MIT Forum
Approaches to Minimizing Downtime

Classic Failover Architecture
⬛Primary Machine                       ⬛Secondary Machine
    –Runs critical application               –Listens for periodic

    –Saves key data periodically                heartbeat message
    –Sends periodic “heartbeat”              –Determines when Primary

       message to secondary                     has stopped executing
    –Eventually fails ...                    –Uses saved key data to
                                                restart/recover application


     Primary                                 Secondary

                  Heartbeat Messages
                  Critical Data Structures
                                                       MIT Forum
Approaches to Minimizing Downtime

Hardware Failover Variations
 Hardware Self-Checking
                                              N+1

       =             ?
      Stratus

                           Shared Disk        Tandem




                            Heartbeat
                            Messages


                          Digital Equipment
                                          MIT Forum
Approaches to Minimizing Downtime

Networks
⬛Redundant network
    interface hardware              WAN
⬛Bridge/routers follow
    computer hardware path
⬛Robust protocols

⬛Adaptive routing
    eliminates point-point
    failure                         LAN
⬛More options in high-end
    servers; few options in
    workgroup servers
                                              MIT Forum
Approaches to Minimizing Downtime

Software Availability
⬛Failover always involves software

⬛Failure prediction technology aims to catch
    hardware failures before they happen
⬛Operating system availability is directly related
    to age
⬛RDBMS & OLTP software ensures data
    recoverability
⬛Applications are poorly instrumented for
    failures, but will improve
⬛Desktop software is still prone to failure
                                                   MIT Forum



Opportunities

⬛Hardware and Networks
  –Note:buyers are contradictory. They want the
    highest availability levels but are unwilling to pay
    (much) more than commodity prices
  –Low/no-cost improvements in client-server
    application availability
  –Added value by improved failure prediction due to
    better error-recovery reporting
  –Self-repairing networks
                                                    MIT Forum




Software and Services
⬛Software
  –Systems management tools down to the application-
     object level
  –Adaptive routing to movable objects

  –Client-server application testing tools

  –Self-distributing databases

⬛Services
  –Disaster backup for client-server applications

  –Availability audits and testing
                                                      MIT Forum



Aberdeen Group Conclusions
⬛Computer failures are becoming more catastrophic
   because we depend so much on computers
⬛Reducing the cost and aggravation of downtime
   involves a spectrum of increasingly costly remedies
⬛Hardware and network availability improvements are
   offset by more computers/networks that will fail
⬛Most future improvements in availability will depend on
   system software that assists application failover
   without dramatically increasing development costs or
   complexity
⬛There are interesting opportunities for new businesses
MIT Forum


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | mit-class-forum-7057bd |
| title | Who Cares If The Computer Breaks? |
| author | Peter S. Kastner, Vice President, Aberdeen Group |
| date | 1995-10 |
| type | employer-record |
| subject_domain | high availability, fault tolerance, downtime, failover architectures, Stratus, Tandem, DEC, application availability, distributed computing |
| methodology | Conference presentation; market analysis; primary research on availability architectures; Aberdeen Group conclusions on high-availability computing |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

MIT Forum presentation (October 1995) examining the business and technical dimensions of computer downtime. Covers evolution from batch/one-tier computing to complex multi-tier client-server environments, where failures are increasingly catastrophic. Analyzes application availability metrics (99.9% as floor, not ceiling), hardware/software/network failure modes, failover architectures (Stratus self-checking, Tandem N+1, DEC heartbeat-based), RAID storage, and planning strategies on a 'paranoia curve.' Concludes that future availability improvements depend on system software that assists application failover.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Early articulation of the high-availability imperative for client-server era; pioneered the '99.9% is a floor not a ceiling' framing; presented at MIT Forum to technically sophisticated audience; historically significant for data center and cloud resilience discourse. |
| **Relevance** | 5 | Core Kastner expertise area; Aberdeen Group conclusions on high-availability computing; demonstrates Kastner's ability to translate complex HA architecture to business executives. |
| **Prescience** | 5 | Highly prescient: correctly predicted future HA improvements would depend on system software assisting application failover; this became the foundation of modern cloud and Kubernetes-era resilience. Correctly identified network availability as key inhibitor to distributed computing growth. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (7)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | acquired | Aberdeen (Harte-Hanks) |
| MIT Forum | event | active |  |
| Stratus Computer | organization | active | Stratus Technologies |
| Tandem Computers | organization | acquired | Compaq/HP |
| Digital Equipment Corporation (DEC) | organization | acquired | Compaq |
| Marathon Technologies | organization | acquired |  |

### Technologies Referenced (14)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| High-Availability Computing | framework | multiple | emerging | legacy |
| Stratus Hardware Self-Checking (Continuous Processing) | hardware | Stratus Computer | mature | legacy |
| Tandem N+1 Failover Architecture | hardware | Tandem Computers | mature | legacy |
| DEC Heartbeat Shared-Disk Failover | hardware | Digital Equipment Corporation | mature | legacy |
| RAID Disk Storage | hardware | multiple | growth | legacy |
| Classic Failover Architecture (Heartbeat) | framework | multiple | mature | legacy |
| Failure Prediction Technology | middleware | multiple | emerging | legacy |
| RDBMS & OLTP Recovery Software | database | multiple | mature | legacy |
| Adaptive Network Routing | protocol | multiple | emerging | legacy |
| Hot-Swap Components (Power, Fan, Disk) | hardware | multiple | emerging | legacy |
| Disaster Backup and Recovery Services | framework | multiple | emerging | legacy |
| Availability Audits and Testing Services | framework | multiple | emerging | legacy |
| Systems Management HA Software (Application-Object Level) | middleware | multiple | emerging | legacy |
| Self-Distributing Databases | database | multiple | emerging | legacy |

### Observation Summary

- Total observations: 28
- By type: technical-claim: 21, prediction: 4, strategic-recommendation: 2, adoption: 1
