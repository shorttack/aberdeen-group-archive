# Workgroup Collaboration and the Internet/Intranet

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Aberdeen Group |
| Date | 1996-09-25 |
| Type | employer-record |
| Domain | groupware, workgroup collaboration, Internet, Intranet, Oracle InterOffice, Lotus Notes, Microsoft Exchange, GroupWise, workflow, electronic mail, reengineering |
| License | CC-BY-4.0 |

## Abstract

Presentation at Oracle Netherlands event (25 September 1996) on workgroup collaboration and Internet/Intranet trends. Covers the decade-long deployment challenges of groupware (costs, security, manageability, interoperability), business drivers for collaboration (globalization, 24x7 operations, downsizing, cycle time reduction), collaboration technology types (email, conferencing, group decision support, documents, workflow), and the Internet/Intranet opportunity. Makes the case for Oracle InterOffice as an open, scalable, multi-tier collaboration platform with RDBMS integration. Addresses ROI challenges and reengineering imperatives. Cites examples from Cisco (25,000 support calls eliminated), Delta, Lufthansa, Harley Davidson, Arthur Andersen, Price Waterhouse, and HP Labs.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 21 |
| technologies.csv | 15 |
| observations.csv | 29 |
| codes.csv | 31 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Aberdeen Group (1996). Workgroup Collaboration and the Internet/Intranet.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Keynote/conference presentation; Aberdeen Group primary research on collaboration market; technology trend analysis; competitive analysis of groupware products
