# Workgroup Collaboration and the Internet/Intranet

> Archived from: source/_raw_text.txt
> Original publication date: 1996-09-25
> Author: Peter S. Kastner, Aberdeen Group

---

## Original Document Text

                                                                    Oracle Netherlands - 25 September 1996




                 It has taken most organizations at least a decade to deploy
                 workgroup collaboration systems (i.e., groupware), yet complaints
                 about costs, security, manageability, and interoperability are all too
                 common. And many suppliers (e.g., Novell) lack a clear vision of
                 the future.
                 Aberdeen Group’s research indicates workgroup collaboration will
                 quickly spread far beyond the workgroup’s cubicles -- across the
                 enterprise via Intranets and to customers and suppliers via the
                 Internet. This will create challenges an opportunities that IT
                 organizations should understand. Moreover, new approaches such
                 as Oracle’s InterOffice will play a pivotal role in the proliferation
                 of worldwide collaboration systems


                 - Bio and responsbilities
                 - Aberdeen Group Inc at www.aberdeen.com
                 - Oracle InterOffice -- Helping IS deploy solutions to business
                 partners and customers over the Internet -- ask for free copy



(c) Aberdeen Group, Inc., 1996                                                                          1
                                                                  Oracle Netherlands - 25 September 1996




                 This talk is aimed at IT executives who are thinking about new
                 ideas (hate the Paradigm word) for how to think about, plan, and
                 execute a successful reengineering strategy that opens up the
                 Enterprise to customers, supplioers, and other workers.
                 Workgroup and collaboration products have been aroud for almost
                 20 years. When did you first use e-mail?
                 But past experiences will not work in our fast changing world


                 We will look at the workgroup collaboration market
                 - Business, market, and technology trends that will change our
                 thinking
                 - Discuss how to set technology requirements for your Enterprise
                 - Look at Aberdeen’s research, recommendations, and conclusions




(c) Aberdeen Group, Inc., 1996                                                                        2
                                                                 Oracle Netherlands - 25 September 1996




                 Lots of definitions
                 Communication via electronics
                 Coleman: productivity and reengineered processes
                 Johansen: anytime, anywhere anticipated the Internet
                 Kastner: look outward. Avoid airplane trips. Meet new markets
                 and geographies.




(c) Aberdeen Group, Inc., 1996                                                                       3
                                                                 Oracle Netherlands - 25 September 1996




                 Large market attracts major product players
                 Fast growing with large installed base
                 Projected merger with Internet & Intranet technologies should
                 explode collaboration market over next five years




(c) Aberdeen Group, Inc., 1996                                                                       4
                                                                    Oracle Netherlands - 25 September 1996




                 e-mail -- ties WW companies together today. Proof Oracle etc.
                 Conferencing -- calendar & schedules today
                                  - discussion groups -> Internet newsgroups
                                  - viedo conferencing tomorrow
                 Group decision support
                                 - maybe Notes-like ‘cabinets’
                                 - Workgroup datamarts for complex DSS, OLAP
                 Documents -- most organization’s data is here
                 Workflow -- fewer secretaries; automatic; self-adapting process
                 saves unnecessary steps; re-engineering; e-mail as workflow
                 Development too -- workgroup duties vary. Need to marry
                 workgroup-specific applications with general-purpose collaboration




(c) Aberdeen Group, Inc., 1996                                                                          5
                                                                  Oracle Netherlands - 25 September 1996




                 Butterfly world hits the Web


                 Segue into Trends that are driving changes in the collaboration
                 market
                                 - business forces
                                 - Why people buy
                                 - Rapid changes in technology
                                 - Market maturation




(c) Aberdeen Group, Inc., 1996                                                                        6
                                                                  Oracle Netherlands - 25 September 1996




                 Business Competition is Global
                                 Phillips NV
                 - Dispersion: talent pools, cheaper manufacturing, supply chain
                 management
                 - Communicate: 24x7 operations x 365 days
                 - Cycle times: project teams. Global 24x7 development. India sw.
                 - Globalization: everywhere, competition
                 - Downsizing: business process efficiency. Now process
                 automation.
                                 + Parcel management system
                                 + Internet news groups
                 - Knowledge is power




(c) Aberdeen Group, Inc., 1996                                                                        7
                                                                 Oracle Netherlands - 25 September 1996




                 Motivations for Buying workgroup collaboration systems
                 Andy Grove of Intel says ...
                 Better customer support: Cisco 25,000 calls eliminated




(c) Aberdeen Group, Inc., 1996                                                                       8
                                 Oracle Netherlands - 25 September 1996




(c) Aberdeen Group, Inc., 1996                                       9
                                                                   Oracle Netherlands - 25 September 1996




                 PCs per person will prove to be a good indicator of the overall
                 competitiveness of a country in the global economy
                 The Netherlands is highly advanced




(c) Aberdeen Group, Inc., 1996                                                                        10
                                 Oracle Netherlands - 25 September 1996




(c) Aberdeen Group, Inc., 1996                                      11
                                                                       Oracle Netherlands - 25 September 1996




                 Groupware systems in the past helped workgroups collaborate.
                 Good for the workgroup but not necessarily good for the enterprise.


                 The globalization of the economy, coupled with the availability of
                 the Internet for transport creates a brand, new, once in a generation
                 opportunity
                                 - communicate with your customers
                                 - work more closely with suppliers on designs, supply
                                    chain management issues, quality
                                 - Competitors: if it leads to standards, or larger
                                   markets for all. Example: cable modems.




(c) Aberdeen Group, Inc., 1996                                                                            12
                                                                     Oracle Netherlands - 25 September 1996




                 But before you walk into the President’s office …
                 1. It takes senior management directives, not just technology from
                 the IT department, to effect sensible reengineering. Yes,
                 workgroup collaboration is an ideal technology to use as the
                 infrastructure for process reengineering.
                 2. Plan for the long term, think big
                 3. The first application to roll out is almost always electronic mail.
                 Make sure the top bosses start using it to direct their staff. Then,
                 the rst will naturally take care of itself. Example: IBM
                 4. Buying groupware software should be like buying programming
                 software: a tool and not an end point
                             - What applications should supplement the core mail,
                 scheduling and document management tools?




(c) Aberdeen Group, Inc., 1996                                                                          13
                                                                     Oracle Netherlands - 25 September 1996




                 When evaluating collaboration software:
                 - scalability: ability to grow (suppliers, customers, acquisitions)
                 - platforms
                 - standards: you will buy from lots of sources
                 - The Internet will absolutely play a large role in future
                 collaboration
                 - Application extensibility: to build/buy custom applications for
                 workgroups that leverages the productivity enhancers of
                 collaboration software. Example: tie Tax Department to tax
                 regulations on-line; project management tools; video training;
                 knowledge bases




(c) Aberdeen Group, Inc., 1996                                                                          14
                                                                    Oracle Netherlands - 25 September 1996




                 Technologically sophisticated organizations have grabbed
                 collaboration technology to seek/maintain competitive advantege
                                 - computer companies
                                 - Financial services & telecommunications


                 Organizationally sophisticated enterprises have used collaboration
                 software to
                                 extend management and control across widely
                                 separated sites (Delta, Lufthansa)


                                 Reengineer to survive (Harley Davidson)


                 Some are able to do both
                                 Arthur Andersen and Price Waterhouse
                                 Hewlet Packard (labs)



(c) Aberdeen Group, Inc., 1996                                                                         15
                                                                Oracle Netherlands - 25 September 1996




                 It is a mistake commonly made to push a collaboration system
                 request through a simple ROI spreadsheet model. You will usually
                 come out with a negative return on investment.


                 Why? Because if collaboration’s benefits typically allow
                 organizations to grow without adding (as many) people.
                 Productivity improvements partially brought about through
                 collaboration may be lost or difficult to measure


                 But look at the macro-economic evidence. Since 1985, many US
                 workers have lost their secretaries (or worse, their jobs) to
                 reengineering and downsizing. Yet productivity per worker is up
                 considerably (source: US Dept of Commerce).




(c) Aberdeen Group, Inc., 1996                                                                     16
                                                         Oracle Netherlands - 25 September 1996




                 Portable: cross-platform and wireless




(c) Aberdeen Group, Inc., 1996                                                              17
                                                                   Oracle Netherlands - 25 September 1996




                 Oracle: Fewer, bigger servers -- easier to administer. Others:
                 server per workgroup philosophy
                 Standards: Oracel InterOffice is open. See next slide.
                 With built-in Internet-awareness, it’s easy to envision widely
                 deployed applications at customers, suppliers and others
                 Adds collaboration capabilities to custom IT-built applications for
                 workflow, scheduling, etc.
                 Integration is excellent. Ties to RDBMS, ConText, video server,
                 on-line analytical processing (OLAP) add enormous value to base
                 collaboration capabilities.




(c) Aberdeen Group, Inc., 1996                                                                        18
                                                                 Oracle Netherlands - 25 September 1996




                 No detail here, but …
                 Full set of features for messaging, scheduling, document
                 management, workflow plus Internet enablement




(c) Aberdeen Group, Inc., 1996                                                                      19
                                                                    Oracle Netherlands - 25 September 1996




                 In order to isolate IT from the enormous changes in underlying
                 technology, Oracle has built InterOffice on a multi-tier architecture.
                 Standards such as MAPI allow InterOffice to work with other
                 vendors’ best-of-breed (or legacy) products.
                 Ultimately, data is managed by Oracle7, a robust, proven, scalable
                 data repository.




(c) Aberdeen Group, Inc., 1996                                                                         20
                                                                   Oracle Netherlands - 25 September 1996




                 Don’t buy collaboration software for a workgroup, think about the
                 whole enterprise and all of its constituencies.
                 The Internet is not just hype. It will become the backbone for
                 worldwide collaboration. It can be used to enormous competitive
                 advantage.
                 When evaluating workgroup collaboration software, Aberdeen
                 Group places high value on an extensible architecture that isolates
                 technology details from applications and programmers.
                 Oracle is one of the fastest growing large companies in the world.
                 Oracle runs on Oracle products, including InterOffice. That’s not
                 true with a Microsoft. For buyers, ask for customer references for
                 fast growing sites. How have they managed the growth. Would
                 they choose the same products again? Was the product over-
                 promised? Does the product have a future?




(c) Aberdeen Group, Inc., 1996                                                                        21
                                 Oracle Netherlands - 25 September 1996




(c) Aberdeen Group, Inc., 1996                                      22


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | oracle-office-1996-69e35d |
| title | Workgroup Collaboration and the Internet/Intranet |
| author | Peter S. Kastner, Aberdeen Group |
| date | 1996-09-25 |
| type | employer-record |
| subject_domain | groupware, workgroup collaboration, Internet, Intranet, Oracle InterOffice, Lotus Notes, Microsoft Exchange, GroupWise, workflow, electronic mail, reengineering |
| methodology | Keynote/conference presentation; Aberdeen Group primary research on collaboration market; technology trend analysis; competitive analysis of groupware products |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Presentation at Oracle Netherlands event (25 September 1996) on workgroup collaboration and Internet/Intranet trends. Covers the decade-long deployment challenges of groupware (costs, security, manageability, interoperability), business drivers for collaboration (globalization, 24x7 operations, downsizing, cycle time reduction), collaboration technology types (email, conferencing, group decision support, documents, workflow), and the Internet/Intranet opportunity. Makes the case for Oracle InterOffice as an open, scalable, multi-tier collaboration platform with RDBMS integration. Addresses ROI challenges and reengineering imperatives. Cites examples from Cisco (25,000 support calls eliminated), Delta, Lufthansa, Harley Davidson, Arthur Andersen, Price Waterhouse, and HP Labs.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Captures the pivotal 1996 moment when groupware was merging with Internet/Intranet; documents early vision of enterprise collaboration extending beyond workgroup to suppliers and customers; prescient framing of what became enterprise social networking and cloud collaboration. |
| **Relevance** | 5 | Client keynote for Oracle Netherlands; demonstrates Kastner's scope at Aberdeen (Group Vice President); shows how Aberdeen positioned Oracle InterOffice vs Lotus Notes/Exchange/GroupWise. |
| **Prescience** | 5 | Highly prescient: correctly predicted Internet would become backbone for worldwide collaboration; correctly identified email as critical first deployment step; correctly predicted collaboration extending to customers/suppliers (B2B collaboration, supply chain portals); correctly predicted scalability and open architecture as key buyer criteria. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (21)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | acquired | Aberdeen (Harte-Hanks) |
| Oracle | organization | active |  |
| Oracle Netherlands | organization | active |  |
| Lotus Development Corporation | organization | acquired | IBM |
| Microsoft | organization | active |  |
| Novell | organization | acquired | Micro Focus/OpenText |
| Cisco Systems | organization | active |  |
| Andy Grove | person | active |  |
| Philips NV | organization | active |  |
| Delta Air Lines | organization | active |  |
| Lufthansa | organization | active |  |
| Harley-Davidson | organization | active |  |
| Arthur Andersen | organization | defunct |  |
| Price Waterhouse | organization | merged | PricewaterhouseCoopers |
| Hewlett-Packard (HP) | organization | active |  |
| US Department of Commerce | organization | active |  |
| David Coleman (groupware analyst) | person | active |  |
| Robert Johansen (groupware analyst) | person | active |  |
| IBM | organization | active |  |
| MAPI Standard | standard | active |  |

### Technologies Referenced (15)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Oracle InterOffice | application | Oracle | emerging | legacy |
| Lotus Notes | middleware | Lotus/IBM | mature | legacy |
| Microsoft Exchange | application | Microsoft | growth | legacy |
| Novell GroupWise | application | Novell | mature | legacy |
| Oracle7 RDBMS | database | Oracle | mature | legacy |
| Internet/Intranet Collaboration Platform | framework | multiple | emerging | legacy |
| MAPI (Messaging Application Programming Interface) | protocol | Microsoft | emerging | legacy |
| Corporate Electronic Mail | application | multiple | mature | legacy |
| Workflow Automation Software | application | multiple | emerging | legacy |
| Oracle ConText (Text Retrieval) | database | Oracle | emerging | legacy |
| Oracle Video Server | application | Oracle | emerging | legacy |
| OLAP (Online Analytical Processing) Workgroup Datamarts | application | multiple | emerging | legacy |
| Multi-Tier Collaboration Architecture | framework | Oracle | emerging | legacy |
| Video Conferencing | application | multiple | emerging | legacy |
| Cable Modems | hardware | multiple | emerging | legacy |

### Observation Summary

- Total observations: 29
- By type: technical-claim: 15, adoption: 5, strategic-recommendation: 5, prediction: 2, competitive-analysis: 2
