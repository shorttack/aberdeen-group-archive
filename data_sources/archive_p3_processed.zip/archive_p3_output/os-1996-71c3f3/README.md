# An Uninhibited Look at Operating Systems 1996

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner |
| Date | 1996 |
| Type | employer-record |
| Domain | operating systems, IBM MVS, DOS/VSE, VM, AS/400, Unix, VAX VMS, OS/2 Warp, Windows 95, Windows NT, NetWare, competitive analysis, platform strategy |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group competitive OS analysis covering all major operating system categories in 1996. Evaluates mainframe OS (IBM MVS/OpenMVS, DOS/VSE, VM), midrange OS (proprietary: VAX VMS, Data General AOS, Wang VS; AS/400; Unix), and desktop/workgroup OS (OS/2 Warp Connect, Windows 95, Windows NT Server, Novell NetWare). Key thesis: 'Unix is a Trademark, Not an OS.' Evaluates OS requirements for 1996 against Aberdeen's four-tier distributed computing model. Provides prognoses for each OS: MVS evolutionary but slow; DOS/VSE look elsewhere; VM nearly dead; proprietary midrange dead; AS/400 growing 20%+; Unix fragmented but alive; OS/2 will never beat Windows on desktop; Windows NT the long-term mission-critical candidate; NetWare hurt by file/print-only limitations.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 9 |
| technologies.csv | 20 |
| observations.csv | 27 |
| codes.csv | 28 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner (1996). An Uninhibited Look at Operating Systems 1996.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Competitive platform analysis; Aberdeen Group market research; structured evaluation across mainframe, midrange, and desktop/workgroup OS tiers
