# An Uninhibited Look at Operating Systems 1996

> Archived from: source/_raw_text.txt
> Original publication date: 1996
> Author: Peter S. Kastner

---

## Original Document Text

 An Uninhibited Look at
   Operating Systems
Peter S. Kastner
Aberdeen Group, Inc.
One Boston Place
Boston, Mass. USA 02108
(617) 723-7890


                   (c) AberdeenGroup   1
Agenda
n OS Requirements Are Changing
n The Suppliers Respond to Change
  – Mainframe
  – Midrange
  – Desktop & Workgroup




                  (c) AberdeenGroup   2
Historical OS Functions
n Kernel
n Memory management
n Job & user management
n Task management
n Device management
n Security
n Utility functions




                    (c) AberdeenGroup   3
     Today’s Distributed Computing
     Reality
                                                                       Decision
                                                                       Support
Production                 Mainframe                                   System
System &
Administration                                        (Massively) Parallel

                                                                     OLTP at POS
  Division, Department,
  Replicated Branch, ...


                                                           PC, Workstation
                                                           PC LAN
                                                           PC LAN Server


                       User Desktops and Workgroups
                                  (c) AberdeenGroup                               4
OS Requirements for 1996
n Support the Aberdeen four-tier model
n Open means interoperable
n Data, application, security “repository”
n Client-server maturity and elegance
n Single-system image across enterprise distributed
  systems (e.g., ORB)

  Conclusion: Don’t bet on it!


                    (c) AberdeenGroup                 5
Where Are OS’s Really Going?
n Mainframe
  –   IBM MVS, DOS/VSE, VM
n Midrange
  –   AS/400, Unix, VAX VMS, etc.
n Desktop & Workgroup
  –   NetWare, OS/2, NT, Windows 95




                     (c) AberdeenGroup   6
IBM Mainframe Operating
Systems
n MVS is critical to IBM’s largest customers
   – Add SPEC 1170 standards to become OpenMVS
   – Five-year program to add clustering capability through
     Sysplex and in Parallel Servers
   – Supplant hierarchical SNA with better peer-peer
     through TCP/IP
n MVS is awfully hard for IBM to drag into the
  future due to complexity, compatibility issues
n Expect continued evolutionary growth, but slowly


                       (c) AberdeenGroup                      7
IBM DOS/VSE and VM
n IBM has functionally stabilized DOS/VSE & VM
n DOS/VSE users have nothing to cheer about.
  They should look elsewhere for long-term relief.
n VM is not quite as dead as DOS/VSE, but don’t
  expect much in new functionality
n Therefore, expect little further enhancement
n Neither are likely candidates as next-generation
  OS leaders. Poor technology base.


                    (c) AberdeenGroup                8
Midrange Operating Systems
n Proprietary minicomputers
n AS/400
n Unix




                   (c) AberdeenGroup   9
Proprietary Midrange OSs
n The midrange proprietary market is dead, so the
  proprietary OSs are dead too
   – Digital Equipment’s VAX VMS
   – Data General AOS
   – Wang VS

n The “open” trend strength means the prognosis for
  significant future proprietary OS enhancement is
  nil
n Expect end-of-life after the year 2000, not earlier


                     (c) AberdeenGroup                  10
IBM’s AS/400
n Ease of use and operations leader growing 20%+
n Version 3 Release 1 of OS/400 adds new, client-server
  functionality
    –   Support for Advanced Servers
    –   Support for PC-LAN I/O processors
    –   OptiConnect for clustering
    –   Much better PC client support
n DB2/400 adds advanced SQL capabilities
n New RISC machines as application servers creates future
  demand


                           (c) AberdeenGroup                11
Unix is a Trademark, Not an OS
n Unix is alive and very well but living in many
  houses
n The odds of a single “Unix operating environ-
  ment” providing complete interoperability is nil
n The flaws in Unix circa 1990 are long gone, and
  many trust their business to Unix (and RDBMS)
n “Every Unix vendor for themselves” situation
  dissipates and fragments collective efforts
n Microsoft NT starts dividing the Unix camp

                    (c) AberdeenGroup                12
Desktop & Workgroup
Operating Systems
n OS/2
n Windows 95 & NT
n NetWare
n NT Server




                    (c) AberdeenGroup   13
IBM OS/2 Warp Connect
n A great operating system ... for 1993
n Rock solid desktop and small server OS
   – Well suited for transaction processing
   – Integrated with LAN Manager
   – Limited scalability with multiprocessors

n Hurt by lack of apps, interest in PM
n Prognosis
   – Will never beat Microsoft Windows on the desktop
   – Worth keeping if you use it now on the desktop
   – Worth reconsidering for future server applications
                       (c) AberdeenGroup                  14
Windows 95 and NT Desktop
n Windows is a huge market-share winner
n Windows 95 adds
  – better networking
  – more solid code base = fewer crashes
  – excellent user interface

n Windows NT desktop
  – As transaction-solid as OS/2
  – Gains Windows 95 apps and GUI
  – Is the long-term candidate for mission-critical desktops


                      (c) AberdeenGroup                        15
Novell NetWare
n Market-share leading file & print network OS
n Version 4.1 gains slowly
   – New directory services
   – Relatively little other new functionality

n Issues
   – File- and print-serving is not enough today
   – NLM application-serving is too complex
   – Novell does not seem to care about Microsoft




                        (c) AberdeenGroup           16
Windows NT Server
n Most modern server OS
n Growing from the low-end upwards
n BackOffice adds database, workgroup capabilities
n Excellent OLTP performance should scare Unix (and
  mainframe) suppliers
n Issues
    –   Scalability: when not if
    –   Intel vs. RISC
    –   Application supplier support ala SAP
    –   Service, support, consulting and sales


                             (c) AberdeenGroup        17
What Else Should We Look For?
n Enterprise information system management
n A repository for distributed computing elements
n Unified security, but flexible trust
n More middleware like gateways, filters, workflow
n Network agents provide artificial intelligence
n Performance prediction tools to make better
  operators and DBAs



                     (c) AberdeenGroup               18


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | os-1996-71c3f3 |
| title | An Uninhibited Look at Operating Systems 1996 |
| author | Peter S. Kastner |
| date | 1996 |
| type | employer-record |
| subject_domain | operating systems, IBM MVS, DOS/VSE, VM, AS/400, Unix, VAX VMS, OS/2 Warp, Windows 95, Windows NT, NetWare, competitive analysis, platform strategy |
| methodology | Competitive platform analysis; Aberdeen Group market research; structured evaluation across mainframe, midrange, and desktop/workgroup OS tiers |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group competitive OS analysis covering all major operating system categories in 1996. Evaluates mainframe OS (IBM MVS/OpenMVS, DOS/VSE, VM), midrange OS (proprietary: VAX VMS, Data General AOS, Wang VS; AS/400; Unix), and desktop/workgroup OS (OS/2 Warp Connect, Windows 95, Windows NT Server, Novell NetWare). Key thesis: 'Unix is a Trademark, Not an OS.' Evaluates OS requirements for 1996 against Aberdeen's four-tier distributed computing model. Provides prognoses for each OS: MVS evolutionary but slow; DOS/VSE look elsewhere; VM nearly dead; proprietary midrange dead; AS/400 growing 20%+; Unix fragmented but alive; OS/2 will never beat Windows on desktop; Windows NT the long-term mission-critical candidate; NetWare hurt by file/print-only limitations.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Comprehensive 1996 OS competitive landscape from a leading analyst; captures the exact moment when Windows NT was emerging as the mission-critical platform and Unix was fragmenting; historically important primary source. |
| **Relevance** | 5 | Core Aberdeen OS competitive analysis by Kastner; showcases breadth of platform expertise across mainframe/midrange/desktop; central to his career work. |
| **Prescience** | 4 | Correctly predicted Windows NT as long-term mission-critical desktop; correctly assessed OS/2 as unable to beat Windows; correctly identified Unix fragmentation as weakness; correctly predicted AS/400 growth; DOS/VSE dead-end prognosis accurate. Slightly underestimated Linux which emerged not long after. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (9)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | acquired | Aberdeen (Harte-Hanks) |
| IBM | organization | active |  |
| Microsoft | organization | active |  |
| Novell | organization | acquired | Micro Focus/OpenText |
| Digital Equipment Corporation (DEC) | organization | acquired | Compaq |
| Data General Corporation | organization | acquired | EMC |
| Wang Laboratories | organization | defunct |  |
| SAP | organization | active |  |

### Technologies Referenced (20)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM MVS (Multiple Virtual Storage) | platform | IBM | mature | legacy |
| IBM DOS/VSE | platform | IBM | declining | legacy |
| IBM VM (Virtual Machine) | platform | IBM | declining | legacy |
| IBM AS/400 (OS/400) | platform | IBM | growth | legacy |
| VAX VMS / OpenVMS | platform | Digital Equipment Corporation | declining | legacy |
| Data General AOS | platform | Data General | declining | legacy |
| Wang VS Operating System | platform | Wang Laboratories | declining | legacy |
| Unix (Multiple Variants) | platform | multiple | mature | legacy |
| IBM OS/2 Warp Connect | platform | IBM | declining | legacy |
| Microsoft Windows 95 | platform | Microsoft | emerging | legacy |
| Microsoft Windows NT (Desktop & Server) | platform | Microsoft | growth | legacy |
| Novell NetWare 4.1 | platform | Novell | mature | legacy |
| Microsoft BackOffice | application | Microsoft | emerging | legacy |
| IBM Sysplex / Parallel Servers | hardware | IBM | emerging | legacy |
| IBM OptiConnect (AS/400) | hardware | IBM | emerging | legacy |
| IBM DB2/400 | database | IBM | mature | legacy |
| SPEC 1170 Standards (POSIX/Open Systems) | framework | Industry consortium | emerging | legacy |
| Object Request Broker (ORB) | middleware | multiple | emerging | legacy |
| Network Agents with Artificial Intelligence | middleware | multiple | emerging | legacy |
| Performance Prediction Tools | application | multiple | emerging | legacy |

### Observation Summary

- Total observations: 27
- By type: technical-claim: 13, competitive-analysis: 12, adoption: 1, prediction: 1
