# Pyramid/SNI OLTP Overview

| Field | Value |
|-------|-------|
| Author | Wayne T. Kernochan; Robert J. Sakakeeney |
| Date | 1996 |
| Type | employer-record |
| Domain | OLTP, midrange computing, RISC/Unix, SMP, clustering, IBM RS/6000, HP 9000, DEC Alpha, Sun SPARC, AT&T GIS/NCR, Pyramid Technology, Siemens Nixdorf, competitive analysis, midrange market share |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group competitive briefing prepared for Pyramid Technology/Siemens Nixdorf (SNI) covering the midrange OLTP market in 1996. Examines the worldwide $14B commercial multiuser RISC/Unix market, provides detailed competitive analysis of the five major midrange suppliers (IBM, HP, Digital, Sun, AT&T GIS/NCR), and benchmarks Pyramid/SNI against them. Uses Aberdeen's Three-Tier-Plus computing model. Covers market share data (HP 50%, IBM 19%, Sun 9%, DEC 3%), revenue data, strengths/challenges/key points for each supplier, and technology positioning. Discusses adoption trajectory from early adopter (NT, ORDBMS) to mainstream (multi-tier OLTP, warehousing) to trailing (RDBMS).

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 18 |
| technologies.csv | 24 |
| observations.csv | 35 |
| codes.csv | 31 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Wayne T. Kernochan; Robert J. Sakakeeney (1996). Pyramid/SNI OLTP Overview.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

Client-sponsored competitive briefing; Aberdeen Group primary market research; structured vendor competitive analysis for Pyramid/SNI customer audience; includes market share and revenue data from Aberdeen's February 1995 research
