# Pyramid/SNI OLTP Overview

> Archived from: source/_raw_text.txt
> Original publication date: 1996
> Author: Wayne T. Kernochan; Robert J. Sakakeeney

---

## Original Document Text

                                                   Pyramid/SNI




                         Pyramid
                      OLTP Overview

                           Wayne T. Kernochan
                            Robert J. Sakakeeney
                           Aberdeen Group, Inc.
                             One Boston Place
                            Boston, Mass. 02108
                               (617) 723-7890


©   AberdeenGroup 1996 1
                                                            Pyramid/SNI




                              Agenda

    •    Impact of Information Technology on Business
    •    Midrange Platform Technology & Leading Suppliers




©   AberdeenGroup 1996 2
                                                               Pyramid/SNI




                              Summary

    •    Business is continuously in a state of change
    •    Information technologies grow only when they solve real world
         business problems
    •    Many business executives have learned how to use IT for the
         benefit of their enterprises. Many have not and tend to blame
         their IS staffs
    •    The IS function within an enterprise is charged with evaluating
         new information technologies and implementing them as
         appropriate for the benefit of the entire enterprise
          – The technologies are changing too rapidly to keep abreast of
            all
          – Business goals and requirements are unclear and changing

©   AberdeenGroup 1996 3
                                                                                                 Pyramid/SNI




          Top Mgt Issues For IT Executives

                    '95  '94
                   Rank Rank                                              Issue
                        1               2            Aligning IT & corporate goals
                        2               4            Instituting cross-functional Information Systems
                        3               3            Organizing & utilizing data
                        4               1            Implementing business reengineering
                        5               9            Improving the IT human resource
                        6              NR            Enabling change and nimbleness
                        7              16            Connecting to customers or suppliers
                        8               5            Creating an information architecture
                        9               7            Updating obsolete systems
                       10               6            Improving the system development process
                   Source: Computer Sciences Corp.




©   AberdeenGroup 1996 4
                                                                    Pyramid/SNI




           Aberdeen Three Tier Plus Model
Production                                                         Decision
System                                                             Support
                            Mainframe                              System
                                                  (Massively) Parallel

                                                                 OLTP at POS
      Division, Department
      Replicated Branch


                                                       PC, Workstation
                                                       PC LAN
                                                       PC LAN Server


                            User Desktops and Workgroups
 ©   AberdeenGroup 1996 5
                                                 Pyramid/SNI




         Increase Line Access to Data
                                           Departmental/
Enterprise
                                           Other
Databases
                                           Workgroup
                                           Servers



                           Workgroup
                           Server
                           and/or Router

                                           Fat
                                           Clients
©   AberdeenGroup 1996 6
                                                                      Pyramid/SNI




                           Adopting Technology


                                         Mainstream


                                       Downsizing
                            Leading
                             Edge Multi-tier OLTP
                              Warehousing
                                                    Unix   Trailing
                  Early     NT
                 Adopters
                          ORDBMS                      RDBMS




©   AberdeenGroup 1996 7
                                           Pyramid/SNI




          Examining the Midrange Leaders

    •    IBM
    •    Hewlett-Packard
    •    Digital Equipment
    •    Sun Microsystems
    •    AT&T Global Information Systems




©   AberdeenGroup 1996 8
                                                                    Pyramid/SNI




          1995 Worldwide Commercial
         Multiuser Risc/Unix Market $14B




                                                     Market Share



            Source: Aberdeen Group, February, 1995
©   AberdeenGroup 1996 9
                                                             Pyramid/SNI




                       IBM Hardware Line-up
    •    RS/6000 Servers
          – Second largest supplier of multiuser RISC/UNIX systems --
            19% market share
          – 52% revenue increase ‘93/94
          – 1994 revenues = $2 billion
          – Product line is transitioning from uniprocessor, Power2
            (RIOS) systems to SMP, PowerPC 601 servers
          – Following an IBM-first strategy, will frequently offer
            DB2/6000 RDBMS at considerable cost savings with
            platform
          – Value Proposition: IBM’s professional services
            organizations will help our customers implement
            RISC/UNIX-based open, client-server computing with the
            RS/6000
©   AberdeenGroup 1996 10
                                                                       Pyramid/SNI




                       IBM Hardware Line-up
    •   SP2
         –    Up to 512 Power2 processors each running AIX 4.x for commercial
              and technical applications
         –    1995 revenues = $400 million
         –    Positioned as high-end of RS/6000 line and DB/2 offload for
              ES/9000
         –    Major commercial applications: Complex Decision Support, LAN
              server consolidation, OLTP
         –    Has generated 380 ISV promises to port RDBMSs and applications
         –    Futures: SMP Nodes and RIOS2 upgrades
         –    Value Proposition: IBM’s entry into very large scale, open systems
              computing. Hot new technology from IBM.




©   AberdeenGroup 1996 11
                                                                                 Pyramid/SNI




                                      IBM Strengths
    •    Size
          –     Global support
          –     Range of products
          –     Talent pool to draw upon
    •    Customer base and sales reps’ knowledge of customers
          –     Shared history, Customer Trust
          –     Former IBM employees working now as customers
    •    Services
          –     Planning, Implementation, Operations, Outsourcing, Financing
    •    Third-party support and competition
          –     ISVs by the 1,000’s
          –     PCM and peripheral suppliers
          –     Professional service organizations (e.g., Andersen Consulting)




©   AberdeenGroup 1996 12
                                                               Pyramid/SNI




                            IBM Challenges

    •    Processor technology -- PowerPC 600 will not be leading the
         industry for many years
    •    Re-energizing and focusing the field organization
    •    Gaining the trust of leading-edge, business line manager, and
         X-generation buyers
    •    Learning how to work with ISVs as allies -- not enemies
    •    Recognizing that its chief competition for IS executive
         allegiance is not other hardware suppliers such as HP but
         software solution suppliers such as Oracle, SAP, and Microsoft




©   AberdeenGroup 1996 13
                                                                 Pyramid/SNI




                   Points-You-Should Know:
                         IBM RS/6000
    •    Customers buy RS/6000 for support and historical relationship
         reasons and have replaced it until lately because of lack of high-
         end growth path.
    •    Platform-of-choice for VARs whose customers cannot afford
         AS/400 but want IBM platform
    •    RDBMS ISVs fear that if they recommend RS/6000 IBM will
         still switch customer to low priced DB2/6000
    •    Expect growth to continue in 1996 as datacenter managers
         experiment with RS/6000 Tier-2 surround strategies
    •    RS/6000 with DB2 is neither the fastest nor least expensive
         option
    •    Whole story includes NetView, Data Propagator, DataHub

©   AberdeenGroup 1996 14
                                                           Pyramid/SNI




                        HP Hardware Line-up

    Midrange:
    • HP 9000:
       – Multi-user RISC/UNIX industry leader -- 50% share
       – 57% revenue growth in 1995
       – 1995 revenues = $5 billion
       – Value Proposition: Leading platform for Unix applications
         in terms of technology and ISV application support
    • HP 3000:
       – Legacy MPE/IX system updated with HP’s PA-RISC
         technology. Same hardware as HP 9000 but with MPE/iX
         operating system

©   AberdeenGroup 1996 15
                                                             Pyramid/SNI




                            HP Strengths

    •    Trusted-supplier by IS decision makers for making the
         transition to high-performance UNIX systems
    •    Supports and is supported by ISVs and professional service
         organizations -- usually as a first among equals
    •    One of a handful of hardware suppliers that can support
         enterprises on a global basis
    •    Technology leadership perception
          –  RISC processors
          –  Complete Unix operating environment
          –  OpenView systems management framework
    •    HP Professional Service Organization knows Unix operating
         environment capabilities thoroughly
©   AberdeenGroup 1996 16
                                                              Pyramid/SNI




                            HP Challenges

    •    Running as a lean and mean organization means business
         opportunities often slip by
    •    Making the transformation from selling hot boxes on price and
         price/ performance to being seen as an incumbent supplier that
         can add value in additional ways
    •    Current generation of PA-RISC, PA-7200, is not the fastest chip
         in the market
    •    Does not have a very high-end RISC/UNIX product offering (i.e.
         clusters & MPP) and is being squeezed by Intel/NT at the low
         end
    •    After 3 years as Top Gun, HP is getting arrogant, sloppy


©   AberdeenGroup 1996 17
                                                              Pyramid/SNI




              Points-You-Should Know: HP

    •    Is considered the mainframe alternative leader
    •    In new sales deals, HP’s most common hardware competitors
         will be IBM and Sun
    •    HP’s Computer Systems Organization (HP 3000/9000,
         Workstations, PSO) has a separate sales force from its Computer
         Products Organization (Vectras, LaserJets, NetManagers)
         resulting in sales confusion and annoyance for customers and
         prospects
    •    Is consistently ranked as one of the computer industry’s most
         respected companies
    •    Should be respected but not feared. HP is not invincible.


©   AberdeenGroup 1996 18
                                                                     Pyramid/SNI




                   Digital Hardware Line-up
    Midrange:
    •   Digital ALPHAserver XX00:
         –   Multi-user RISC/UNIX 64 bit -- 3% market share
         –   75% revenue growth rate 1995
         –   Value Proposition: Faster processors capable of managing vast
             amounts of memory and disk -- VLM64
    •   Digital VAX:
         –   Legacy VMS system updated to OpenVMS
         –   VAX revenues declining 50% per annum
         –   1995 revenues = less than 10% of company revenues - with all add-
             ons
         –   Value Proposition: Hold base while selling evolution and
             migration (if possible) to OpenVMS and ALPHA AXP


©   AberdeenGroup 1996 19
                                                              Pyramid/SNI




                            Digital Strengths

    •    Alpha performance combined with aggressive pricing has
         created the best price/performance in the industry.
    •    Digital's UNIX (OSF/1) meets the specifications of more
         standards setting groups than any other Unix operating system.
    •    Digital will deliver enterprise-class open platforms with
         Microsoft NT on Alpha. Note recent TPC-C benchmarks.
    •    Digital is creating software frameworks for enterprise-wide
         open computing to meet customer needs for applications
         interoperability from the desktop to datacenter.




©   AberdeenGroup 1996 20
                                                               Pyramid/SNI




                            Digital Challenges

    •    Digital is finally emerging from the restructuring woods. As a
         result, customers and prospects remain concerned about:
          –  who will sell to them
          –  where support will come from
          –  which support people will continue to be there
          –  which promised products may be eliminated
    •    With the current neutral attitude of prospects to Digital's
         limited number of Alpha UNIX systems, Digital has yet to
         establish a critical mass for long-term viability.
    •    Alpha/NT looks like a rosy future, but lacks 1996 revenues to
         sustain the company alone


©   AberdeenGroup 1996 21
                                                              Pyramid/SNI




         Points-You-Should Know: Digital

    •    The company's diligence and resolve is regaining it respect
         from the industry and Wall Street. Prospects becoming more
         willing to entertain a Digital solution.
    •    Digital remains an excellent engineering company.
         Development of Large In-Memory Databases (LIMD) could
         revolutionize enterprise OLTP and complex DSS.
    •    Digital and Oracle have been increasing their strategic
         commitments
          – Oracle acquires RDB and installed base
          – Oracle is the LIMD database



©   AberdeenGroup 1996 22
                                                            Pyramid/SNI




                       Sun Hardware Line-up

    Midrange:
    • SPARCcenter 2000 and SPARCserver 1000 :
       – Multi-user RISC/UNIX - 9% market share
       – Revenues = ~ 20% of Sun / $1.3 Billion
       – SPARCcenter - 2 to 20 processors
       – SPARCserver - 2 to 8 processors
       – Challenging IBM for number 2 position with ISVs for
         application support
       – Value Proposition: The open systems, price leader for
         enterprises that want alternative high-risk, high-reward
         solutions

©   AberdeenGroup 1996 23
                                                              Pyramid/SNI




                            Sun Strengths

    •    Originator and still a leader in the open systems client-server
         computing marketplace. Customers and Prospects still may
         have Sun religion.
    •    Large number of software applications available - a pound-for-
         pound leader.
    •    Sun is regarded as an innovator in providing networked
         client/server solutions to the industry.
    •    Sun’s positive working relationships with value-added resellers
         and third party distributors can mean lower acquisition and
         maintenance costs.
    •    Strong ISV relationships. Most ISVs use Sun workstations to
         develop their client/server products and applications.

©   AberdeenGroup 1996 24
                                                                 Pyramid/SNI




                            Sun Challenges
    •    Sun direct field support is limited and is often contracted out to
         other firms.
    •    There are very few references for running SPARCcenter 2000s
         and SPARCserver 1000s for business critical production OLTP
         applications.
    •    Transitions between operating system releases has historically
         been problematic, compounded by minimal technical support
         from its corporate offices. Problems with Solaris in 1994.
    •    Real world scalability of applications appears to be very poor
         on all of Sun’s workstations and servers.
    •    Loss of influence. Sun does not appear to be a major player in
         the new generation of standards setting groups. Many Sun
         products, such as its critical OpenLook GUI, may be excluded
         from future standards.
©   AberdeenGroup 1996 25
                                                               Pyramid/SNI




             Points-You-Should Know: Sun

    •    Large number of applications.
    •    Champion of the “common” customer.
    •    Strong alternate channel presence - will sell through any
         distributor.
    •    1996 is an important product year with UltraSPARC 64-bit
         rollout
    •    Sun’s commercial client/server strategy is making inroads via
         Networking and application development.
    •    Sun maintains both the lowest entry price and best
         price/performance point for commercial servers.



©   AberdeenGroup 1996 26
                                                            Pyramid/SNI




     AT&T Global Information Solutions
               (i.e. NCR)
    •    1995 total revenues of approx. $7.0 Billion
    •    Revenues have been flat for several years -- with financial
         results running in the red
    •    Spin-out of AT&T has immediate implications to customers and
         prospects
          – Is the company viable?
          – Will the company play in my market?




©   AberdeenGroup 1996 27
                                                               Pyramid/SNI




     AT&T Global Information Solutions
               (i.e. NCR)
    •    Product strategy is to offer open systems based on midrange to
         massively parallel product lines -- Worldmark models from
         departmental to Teradata for decision support
    •    All servers based on Unix and Intel Pentium microprocessor --
         no RISC servers
    •    Unix System V.4 MP OS with Reliability, Availability,
         Serviceability enhancements
    •    Low-end servers also run OS/2, SCO Unix, NetWare, and
         Windows NT (an NT champion)
    •    Full line of peripherals, including RAID storage
    •    High availability clustering with LifeKeeper
    •    Open OLTP with TopEnd

©   AberdeenGroup 1996 28
                                                               Pyramid/SNI




                            NCR Strengths

    •    Breadth of compatible server products is excellent
    •    Good, often leading, TPC price/performance
    •    The backing of AT&T (for a few more months)
    •    Bullet-proof version of UNIX. Known for stability.
    •    The Intel multiprocessor market champion (vs. RISC) and
         leader -- ~$2.0 Billion in 199
    •    Market strength and broad solutions strength in retail and
         banking
          – Will mostly consolidate into above markets
          – Also Telecomm, Government, Transportation markets



©   AberdeenGroup 1996 29
                                                                Pyramid/SNI




                            NCR Challenges

    •    While the leader in Intel/Unix servers, losing ground to leading
         RISC providers, not to mention Compaq
    •    Never the leader in OLTP high-end performance
    •    Intel is depending on NCR to be premier supplier of P6-based
         servers for enterprise computing
    •    Organization seems to lack the fire required to gain market
         share
    •    Customer base may erode due to financial uncertainties and
         pull-out from general market distribution
    •    Failure to properly manage Teradata for big customers has
         resulted in unexpected backlash and opened up new
         opportunities for data warehousing/complex DSS.

©   AberdeenGroup 1996 30


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | pyramid-d50111 |
| title | Pyramid/SNI OLTP Overview |
| author | Wayne T. Kernochan; Robert J. Sakakeeney |
| date | 1996 |
| type | employer-record |
| subject_domain | OLTP, midrange computing, RISC/Unix, SMP, clustering, IBM RS/6000, HP 9000, DEC Alpha, Sun SPARC, AT&T GIS/NCR, Pyramid Technology, Siemens Nixdorf, competitive analysis, midrange market share |
| methodology | Client-sponsored competitive briefing; Aberdeen Group primary market research; structured vendor competitive analysis for Pyramid/SNI customer audience; includes market share and revenue data from Aberdeen's February 1995 research |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group competitive briefing prepared for Pyramid Technology/Siemens Nixdorf (SNI) covering the midrange OLTP market in 1996. Examines the worldwide $14B commercial multiuser RISC/Unix market, provides detailed competitive analysis of the five major midrange suppliers (IBM, HP, Digital, Sun, AT&T GIS/NCR), and benchmarks Pyramid/SNI against them. Uses Aberdeen's Three-Tier-Plus computing model. Covers market share data (HP 50%, IBM 19%, Sun 9%, DEC 3%), revenue data, strengths/challenges/key points for each supplier, and technology positioning. Discusses adoption trajectory from early adopter (NT, ORDBMS) to mainstream (multi-tier OLTP, warehousing) to trailing (RDBMS).

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Rich primary data on 1995-1996 midrange RISC/Unix market with specific market share and revenue figures from Aberdeen's own research; documents the competitive landscape at the exact moment HP dominated RISC/Unix and NCR was spinning out from AT&T. |
| **Relevance** | 3 | Not authored by Kastner; Wayne Kernochan and Robert Sakakeeney are the authors; demonstrates Aberdeen's breadth of expertise across multiple analysts; Pyramid/SNI was a midrange OLTP niche player. |
| **Prescience** | 4 | Correctly identified IBM's challenges with ISVs; correctly predicted HP's arrogance would create openings; correctly assessed DEC's recovery; correctly identified NCR's financial uncertainty as customer risk; correctly identified Intel/NT threat to RISC vendors. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (18)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Wayne T. Kernochan | person | active |  |
| Robert J. Sakakeeney | person | active |  |
| Aberdeen Group | organization | acquired | Aberdeen (Harte-Hanks) |
| Pyramid Technology Corporation | organization | acquired | Siemens Nixdorf (SNI) |
| Siemens Nixdorf Informationssysteme (SNI) | organization | renamed | Fujitsu Siemens Computers |
| IBM | organization | active |  |
| Hewlett-Packard (HP) | organization | active |  |
| Digital Equipment Corporation (DEC) | organization | acquired | Compaq |
| Sun Microsystems | organization | acquired | Oracle |
| AT&T Global Information Solutions (GIS) / NCR | organization | renamed | NCR Corporation |
| NCR Corporation | organization | active |  |
| Oracle | organization | active |  |
| SAP | organization | active |  |
| Microsoft | organization | active |  |
| Compaq Computer | organization | acquired | HP |
| Computer Sciences Corporation (CSC) | organization | active |  |
| Andersen Consulting | organization | renamed | Accenture |
| Intel | organization | active |  |

### Technologies Referenced (24)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 (SMP, PowerPC 601) | hardware | IBM | growth | legacy |
| IBM SP2 (Massively Parallel Processor) | hardware | IBM | emerging | legacy |
| HP 9000 (PA-RISC) | hardware | Hewlett-Packard | mature | legacy |
| HP 3000 (MPE/iX) | hardware | Hewlett-Packard | mature | legacy |
| HP PA-RISC PA-7200 | hardware | Hewlett-Packard | mature | legacy |
| HP OpenView | application | Hewlett-Packard | mature | legacy |
| DEC ALPHAserver (64-bit) | hardware | Digital Equipment Corporation | emerging | legacy |
| Digital LIMD (Large In-Memory Database) | database | Digital Equipment Corporation | emerging | legacy |
| Sun SPARCcenter 2000 / SPARCserver 1000 | hardware | Sun Microsystems | mature | legacy |
| Sun UltraSPARC (64-bit) | hardware | Sun Microsystems | emerging | legacy |
| Sun Solaris | platform | Sun Microsystems | mature | legacy |
| NCR Worldmark Servers | hardware | NCR/AT&T GIS | mature | legacy |
| Teradata Decision Support System | platform | NCR/AT&T GIS | mature | legacy |
| NCR LifeKeeper High-Availability Clustering | middleware | NCR/AT&T GIS | mature | legacy |
| NCR TopEnd Open OLTP | middleware | NCR/AT&T GIS | mature | legacy |
| Unix System V.4 MP (NCR) | platform | NCR/AT&T | mature | legacy |
| IBM DB2/6000 | database | IBM | mature | legacy |
| DEC OSF/1 Unix | platform | Digital Equipment Corporation | mature | legacy |
| SMP (Symmetric Multiprocessing) | hardware | multiple | growth | legacy |
| Aberdeen Three-Tier-Plus Architecture Model | methodology | Aberdeen Group | active | legacy |
| ORDBMS (Object-Relational DBMS) | database | multiple | emerging | legacy |
| RAID Storage | hardware | multiple | growth | legacy |
| Intel P6 Processor (Pentium Pro) | hardware | Intel | emerging | legacy |
| DEC VAX/VMS | operating-system | digital-equipment-corporation | mature | legacy |

### Observation Summary

- Total observations: 35
- By type: technical-claim: 10, market-size: 8, competitive-analysis: 7, adoption: 5, market-share: 4, prediction: 1
