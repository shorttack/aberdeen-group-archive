# October 4, 1994 RS/6000 Announcement — Aberdeen Conclusions

> Archived from: source/_raw_text.txt
> Original publication date: 1994-10-04
> Author: Aberdeen Group (Peter S. Kastner, likely)

---

## Original Document Text

                                                                                October 4, 1994 RS/6000 Announcement




                  Aberdeen Conclusions
•   IBM is back on track for providing enterprises with those production quality
    Risc/Unix platforms that they require for running business-critical, client-server
    applications. While the RS/6000 product line is now in the last phases of
    transitioning from Power2 to PowerPC 604 processors and from AIX 3.2 to AIX
    4.1, the new, revitalized product set is more than robust enough for both
    prototyping new applications and placing them into production.
•   But just as important as the specific products introduced on October 4th is the
    serious and mature approach IBM is now taking to the commercial Risc/Unix
    marketplace. Rather than constrain the capabilities of the RS/6000 multiuser
    systems and limiting the range of the workstation line, IBM is now willing and able
    to expand both product lines to meet the needs of sophisticated commercial Unix
    practitioners. The following actions are strong evidence of this new
    aggressiveness:
      –   Early release of AIX 4.1 to ISVs and developers;
      –   Introduction of an under $4,000 commercial workstation;
      –   No-charge upgrades from a perfectly good PowerPC 601 processor to an even better 604;
      –   Successful technology transfers between IBM and its partner Bull;
      –   Vigorous inclusion of the SP2 into the RS/6000 line for data mining.
•   As a result, Aberdeen believes that the new PowerPC-AIX 4.1 RS/6000 product
    line will represent a good long-term investment for forward thinking IS decision
    makers.

                                                                          Source: Aberdeen Group, Inc.
                                                             October 4, 1994 RS/6000 Announcement




                              Strengths

•   Upgradeable with higher performance processors (all to PowerPC 604, J30 and
    R30 to PowerPC 620) and (for J30 and R30) more processors (up to 8). Result
    will be the ability to upgrade in-box throughput 10X from entry level 2-
    processor J30 and R30
•   Industry-leading reliability, availability and serviceability implemented through
    dedicated IBM SystemGuard processor
•   Immediate investment protection by including free upgrade from PowerPC 601
    processor to PowerPC 604
•   Future investment protection through bandwidth of data crossbar technology,
    PowerPC roadmap to PowerPC 630, and mid-1995 availability of HACMP
•   Anchor point for broadest binary compatible commercial Unix product offering
    in industry -- from under $4,000 40P workstation to 512-node parallel-scalable
    SP2
•   All major independent software applications available -- 10,000 applications in
    total
•   IBM comprehensive, global support for large multinational customers




                                                        Source: Aberdeen Group, Inc.
                                                           October 4, 1994 RS/6000 Announcement




                Customer Concerns

•   Lack of audited TPC-C performance results at announcement
•   Compatibility of applications and third-party software between AIX 3.2 and AIX
    4.1 as highlighted by lack of HACMP availability on AIX 4.1 at October
    announcement
•   Short projected life of PowerPC 601 processor (12/94 to 6/95) combined with
    concern about ability of IBM to produce PowerPC 604 and PowerPC 620
    processors
•   IBM's serious commitment to RS/6000 for commercial applications (compared
    to AS/400)
•   Much of upgrade story is futures oriented (6- and 8-processor support,
    PowerPC 604 and 620 availability, applications software testing, and TPC-C
    performance benchmarking)




                                                      Source: Aberdeen Group, Inc.
                                                           October 4, 1994 RS/6000 Announcement




                     Sales Messages

•   The new generation of RS/6000 products based on the PowerPC 600
    processors and AIX 4.1 operating systems represent the full Unix platform
    solution enterprise IS decision makers are asking for to meet all their new
    commercial application solutions
•   IBM has the worldwide sales and service support capability and capacity to
    most effectively help its customers transition to open systems
•   No application or database is so big that it cannot be handled by the RS/6000
    SMP systems or the binary-compatible SP2
•   Commitment of all major independent RDBMS application suppliers to the
    success of the full RS/6000 and SP2 products




                                                      Source: Aberdeen Group, Inc.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | rs6000-1994-announcement-c1cb6a |
| title | October 4, 1994 RS/6000 Announcement — Aberdeen Conclusions |
| author | Aberdeen Group (Peter S. Kastner, likely) |
| date | 1994-10-04 |
| type | employer-record |
| subject_domain | Unix servers; RISC processors; IBM hardware strategy; business-critical client-server |
| methodology | analyst-briefing; event-response |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group's same-day conclusions on IBM's October 4, 1994 RS/6000 announcement. Covers IBM's transition from Power2 to PowerPC 604 processors and AIX 3.2 to AIX 4.1, evaluating strengths, customer concerns, and sales messages for the revitalized product line. Recommends the new PowerPC-AIX 4.1 RS/6000 as a good long-term investment for IS decision makers.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Primary source capturing Aberdeen's real-time analysis of a major IBM platform transition. Documents the competitive Unix/RISC server landscape and IBM's commercial strategy at a critical juncture. |
| **Relevance** | high | Peter Kastner's key analyst voice on IBM RS/6000 platform transitions; directly relevant to the IBM/RISC/Unix server segment of the archive. |
| **Prescience** | high | Accurately forecast that PowerPC/AIX 4.1 RS/6000 would be IBM's competitive platform; the HACMP/software compatibility concerns proved prescient; IBM's RS/6000 did become the primary commercial Unix platform for IBM. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (4)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| IBM (International Business Machines) | company | [DEFERRED] | [DEFERRED] |
| Aberdeen Group | firm | [DEFERRED] | [DEFERRED] |
| Peter S. Kastner | person | active |  |
| Bull Group (Groupe Bull) | company | [DEFERRED] | [DEFERRED] |

### Technologies Referenced (12)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 | hardware | IBM | growth | legacy |
| PowerPC 604 | hardware | IBM/Motorola/Apple | emerging | legacy |
| PowerPC 601 | hardware | IBM/Motorola/Apple | declining | legacy |
| PowerPC 620 | hardware | IBM/Motorola/Apple | emerging | legacy |
| IBM Power2 (RIOS) | hardware | IBM | declining | legacy |
| IBM AIX 4.1 | platform | IBM | emerging | legacy |
| IBM AIX 3.2 | platform | IBM | declining | legacy |
| IBM SP2 | hardware | IBM | emerging | legacy |
| IBM HACMP (High Availability Cluster Multi-Processing) | middleware | IBM | emerging | legacy |
| IBM SystemGuard | hardware | IBM | mature | legacy |
| Data Crossbar Technology | hardware | IBM | emerging | legacy |
| TPC-C Benchmark | framework | Transaction Processing Performance Council | growth | legacy |

### Observation Summary

- Total observations: 20
- By type: customer-concern: 4, product-transition: 2, product-capability: 2, sales-message: 2, strategic-assessment: 1, competitive-positioning: 1, price-data: 1, product-policy: 1, partnership: 1, strategic-positioning: 1, product-roadmap: 1, market-scope: 1, geographic-presence: 1, market-assessment: 1
