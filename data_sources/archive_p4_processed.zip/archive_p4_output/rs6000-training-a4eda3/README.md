# RS/6000 RDBMS Sales Training

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Group Vice President, Aberdeen Group |
| Date | 1995 |
| Type | employer-record |
| Domain | RDBMS market; Unix server competitive landscape; IBM RS/6000; midrange hardware; client-server computing |
| License | CC-BY-4.0 |

## Abstract

65-page IBM sales training deck authored by Peter S. Kastner of Aberdeen Group. Covers: (1) IT impact on business, (2) midrange platform technology and leading suppliers, (3) decision support and data mining, (4) open OLTP opportunities, (5) RDBMS player analysis (Oracle, Sybase, Informix, etc.), (6) RDBMS sales rep partnering, (7) RDBMS supplier positioning, (8) RS/6000 with DB2/6000. Provides financial data for IBM, HP, DEC, Sun, and AT&T GIS circa 1994-1995. Preserved raw text covers pages 1-64; RDBMS-specific positioning sections (pp. 65+) appear truncated in OCR.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 20 |
| technologies.csv | 35 |
| observations.csv | 50 |
| codes.csv | 35 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Group Vice President, Aberdeen Group (1995). RS/6000 RDBMS Sales Training.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

sales-training-deck; analyst-briefing; competitive-analysis
