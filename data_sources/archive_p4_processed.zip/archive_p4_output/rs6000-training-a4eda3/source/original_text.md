# RS/6000 RDBMS Sales Training

> Archived from: source/_raw_text.txt
> Original publication date: 1995
> Author: Peter S. Kastner, Group Vice President, Aberdeen Group

---

## Original Document Text

                                                IBM Sales Training




      RS/6000 RDBMS Sales
            Training

                          Peter S. Kastner
                         Group Vice President
                         Aberdeen Group, Inc.
                           One Boston Place
                          Boston, Mass. 02108
                            (617) 723-7890


© AberdeenGroup 1995 1
                                                         IBM Sales Training




                          Agenda

  •   Impact of Information Technology on Business
  •   Midrange Platform Technology & Leading Suppliers
  •   Decision Support: Mining Data for Information
  •   Opportunities for Open OLTP
  •   Introducing the RDBMS Players
  •   Partnering with an RDBMS Sales Rep
  •   Positioning the RDBMS Suppliers
  •   The RS/6000 with DB2/6000




© AberdeenGroup 1995 2
                                                IBM Sales Training




                      Business and
                 Information Technology
                         The Impact of Change




© AberdeenGroup 1995 3
                                              IBM Sales Training




                   Major Industry Trends

  • Open Systems
  • Increased LOB influence on Information Systems
  • Quantum Leaps in Semiconductors
  • Rapid Application Development (RAD)
  • Distributed Computing
  • Client-Server Feeding Frenzy




© AberdeenGroup 1995 4
                                                       IBM Sales Training




       IT Is A CEO/BOD Concern --
       Enterprise Core Competency
  • Cannot allow direct competitors to gain a significant advantage
     – Non-competitors can use to enter new marketplaces
     – Can be used to strengthen ties with customers and suppliers
     – Must not allow costs for back-office applications as a
        percentage of budget to be more than competitors/similar
        operations
  • Strategic IT questions remain the same but the answers change
    every year
  • IT is viewed as a combination of technology and staff issues
  • When making major IT investment changes, CEO/BOD will invest
    2%-3% of enterprise revenue during a 3 year period


© AberdeenGroup 1995 5
                                               IBM Sales Training




                Lower Enterprise
                 Overhead Costs
     Bigco LTD Income Statement:
     100% Total Revenue
      55% Cost of Goods Sold
      35% Selling, General, & Administrative
       3% MIS (part of SG&A)
      10% Profit Before Tax (PBT)


     Direct IS to lower:
     • SG&A by 20% -- 70% PBT improvement
     • COGS by 5% -- 27% PBT improvement
     • MIS by 50% -- 15% PBT improvement


© AberdeenGroup 1995 6
                                                             IBM Sales Training




                 Increase Customer
                    Satisfaction
 • Fewer customer-supplier relationships
      – Customer delight is critical
      – Trusted-supplier partnerships
      – Virtual company basis
 • More revenues from existing customers
      – Data mining
      – Leverage existing relationships with new, often
        opportunistic products and services
 • New customer capture tactics
      – Target high probability prospects
      – Add information value to differentiate product and
        service
© AberdeenGroup 1995 7
                                                          IBM Sales Training




                    Empower Fewer Users

  • Make data accessible to both line managers and staff
  • Fewer managers and staff will be directly responsible for
    more of the financial results of the enterprise
  • Non-programmatic problems must be solved relying on
    information that may reside anywhere in the enterprise
  • Empowered end user model:
     – Review
     – Analyze
     – Decide
     – Report



© AberdeenGroup 1995 8
                                                                  IBM Sales Training




       Aberdeen Three Tier Plus Model
Production                                                       Decision
System                                                           Support
                          Mainframe                              System
                                                (Massively) Parallel

                                                               OLTP at POS
   Division, Department
   Replicated Branch


                                                     PC, Workstation
                                                     PC LAN
                                                     PC LAN Server


                          User Desktops and Workgroups
 © AberdeenGroup 1995 9
                                                IBM Sales Training




     Increase Line Access to Data
                                          Departmental/
Enterprise
                                          Other
Databases
                                          Workgroup
                                          Servers



                          Workgroup
                          Server
                          and/or Router

                                          Fat
                                          Clients
© AberdeenGroup 1995 10
                                                         IBM Sales Training




    Shorten Application Development
              Cycle Time
  • Quick moving enterprises must have IS development tools
    that facilitates change -- not delay it
  • Multi-year, only 20% effective application, custom develop-
    ment efforts are not acceptable
  • RAD means now for minor modifications -- nine months for
    major applications
     – SAD is opposite of RAD
  • License the core multiuser ISV solution ASAP -- modify the
    fat client when convenient




© AberdeenGroup 1995 11
                                                                IBM Sales Training




        Increase Operational Flexibility

  • IT must facilitate -- not constrain -- the enterprise’s ability to
    function and transform itself
  • New strategy, tactics, business policy implementations
  • Acquisitions, divestitures, mergers -- information is key
    component
  • Business process reengineering
  • Financial planning including items such as interest rate
    changes and derivative risks
  • Government mandates
  • ETC.



© AberdeenGroup 1995 12
                                                           IBM Sales Training




                          Database

  • Gathering and storing data for the purpose of retrieving
    information to make decisions
  • Has evolved from high speed account management to decision
    support to online transaction processing to application
    portability to the key technology for enterprise-IS success
  • Revenues for databases, database-centric applications, tools to
    build database-centric applications, end-user query tools,
    database-oriented services, and hardware platforms to run
    databases grew at ~50% in 1994
  • Interoperability with other software and standard interfaces
    are key requirements


© AberdeenGroup 1995 13
                                                          IBM Sales Training




  Enterprises’ Critical Business Issues
    Solved By new IT Technology
  •   Online management reporting for decision support
  •   Increasing customer services
  •   Expanding order fulfillment
  •   Business process re-engineering -- green field approach to
      strategy and/or operations
  •   Data mining
  •   Acquisition and divestiture needed and required information
      and data
  •   Lower IS costs
  •   Enterprise-wide messaging with interfaces for customers and
      suppliers
  •   And anything else
© AberdeenGroup 1995 14
                                                                IBM Sales Training




                     Adopting Technology

                                    Mainstream


                                    Downsizing
                          Leading
                           Edge
                          Warehousing
                                                     Trailing
              Early     NT                   Unix
             Adopters
                      ORDBMS                     RDBMS




© AberdeenGroup 1995 15
                                                                                              IBM Sales Training




      Top Mgt Issues For IT Executives
                '95  '94
               Rank Rank                                              Issue
                    1               2            Aligning IT & corporate goals
                    2               4            Instituting cross-functional Information Systems
                    3               3            Organizing & utilizing data
                    4               1            Implementing business reengineering
                    5               9            Improving the IT human resource
                    6              NR            Enabling change and nimbleness
                    7              16            Connecting to customers or suppliers
                    8               5            Creating an information architecture
                    9               7            Updating obsolete systems
                   10               6            Improving the system development process
               Source: Computer Sciences Corp.




© AberdeenGroup 1995 16
                                                         IBM Sales Training




                          Summary

  • Business is continuously in a state of change
  • Information technologies grow only when they solve real
    world business problems
  • Many business executives have learned how to use IT for the
    benefit of their enterprises. Many have not and tend to blame
    their IS staffs
  • The IS function within an enterprise is charged with
    evaluating new information technologies and implementing
    them as appropriate for the benefit of the entire enterprise
     – The technologies are changing too rapidly to keep abreast
       of all
     – Business goals and requirements are unclear and changing

© AberdeenGroup 1995 17
                                                            IBM Sales Training




        Midrange Platform Technology

                          The basis for RISC-Unix systems




© AberdeenGroup 1995 18
                                                         IBM Sales Training




           Schematic of Basic SMP
             Multi-User System
           CPU              CPU         CPU        CPU

                          Internal Bus/Backplane

             Memory                  IOP           IOP


                               Disk tape and   Terminals, PCs,
                               tape storage       Printers

© AberdeenGroup 1995 19
                                                     IBM Sales Training




              Symmetric Multiprocessors
                                       Software      Hardware
• Examples: Tandem Integrity NR,
  HP 9000, IBM ES/9000, many            Operating
  more                                  System
• Multiple CPUs share common                         Processors

  data highway (bus), memory and
  operating system                      Task1
                                        Task2
• Well understood technology.           Task3
  New chip set accelerators.            Task4
  Inexpensive engineering.              Task n ...
• Scalability: Good to 4 processors;                 Memory access is
  fair to 8; few do more than 10                      a big problem
                                                      getting worse


                                                     Memory & I/O

 © AberdeenGroup 1995 20
                                                          IBM Sales Training




          Component-to-System Design
                 Trade-offs
  • What is the system intended to do?
  • Batch processing -- needs greatest I/O capability to disks
  • Online transaction processing (OLTP) -- needs I/O processors,
    fast CPU, and large memory
  • Decision support -- needs large number of fast processors and
    as much disk storage as possible
  • Desktop PC -- inexpensive but reliable
  • Technical -- fast floating point processing and excellent
    graphics
  • Commercial -- fast integer processing
  • Trade-offs are continuously made by the systems architect


© AberdeenGroup 1995 21
                                                          IBM Sales Training




               Major Systems Categories

  • Uniprocessor -- one processor -- the majority of systems
    installed and sold
  • Symmetric Multi-Processing (SMP) -- multiple processors but
    only one global memory and one copy of the operating system
    running. Internal bus with operating system allocates tasks to
    individual processors
  • Massively Parallel Processing (MPP) -- each node has its own
    processor, memory and copy of the operating system. All
    nodes can process the same problem, if directed to do so
  • Clustering -- loosely coupling more than one of the above
    systems with systems software that allows for a single image
    view of the multiple systems

© AberdeenGroup 1995 22
                                                          IBM Sales Training




               Major Systems Categories

  • Commercial versus technical: Database oriented for
    commercial applications compared to number crunching for
    technical applications
  • Multi-user versus single user: Effects how many users and
    what types of applications are supported
  • Open versus Proprietary: Primarily refers to the operating
    system but also to the ability to connect peripheral devices
  • Enterprise -- supports several hundred to several thousand
    users
  • Departmental -- supports 50 to 500 users
  • Workgroup -- 2 to 200 users
  • Desktop -- single user

© AberdeenGroup 1995 23
                                                              IBM Sales Training




                           Midrange

  • Designed in 1970’s for technical, office automation, small
    business and decision support application. Major commercial
    use today is as platform engine for RDBMS-based apps
  • Primary operating system is Unix. However, proprietary
    operating systems such as OS/400, VMS, and MPE/iX are
    prevalent in installed bases
  • Major U.S. Suppliers
       – IBM -- AS/400 and RS/6000
       – Hewlett-Packard -- HP 9000 and HP 3000
       – Sun Microsystems -- SPARCcenter 2000 and SPARCserver 1000
       – Digital Equipment Corporation -- DECsystems and VAX
       – AT&T GIS -- Model 3X00
       – Others include Tandem, Data General, Unisys, and Sequent
© AberdeenGroup 1995 24
                                                         IBM Sales Training




                          Midrange

  • Midrange technology battle has been CISC processors
    (primarily Intel X86) versus RISC (HP PA-RISC, Sun SPARC,
    and IBM/Motorola PowerPC). RISC is winner at this time
  • Midrange systems are used primarily for decision support,
    OLTP, departmental data repository, and small-to-medium
    business applications
  • Uniprocessors for low-end -- SMP for high-end. Clustering is
    an increasingly important technology
  • Platform-of-choice for changing enterprise applications --
    reengineering business processes or lowering computing costs
  • Servers -- a marketing term to differentiate midrange systems
    from mainframes

© AberdeenGroup 1995 25
                                                        IBM Sales Training




                          Midrange

  • Best Uses:
  • Creating multi-user RDBMS-based applications or running
    ISV applications targeted for a RDBMS
  • Distributed, local processing nodes in an enterprise-wide
    network
  • Leveraging existing mainframe applications and databases by
    adding new functionality and offloading mainframe
    requirements
  • OLTP for applications that require less than 10 real-world
    transactions per second (600 transactions per minute)



© AberdeenGroup 1995 26
                                                         IBM Sales Training




                          Midrange

  Challenges:
  • Building enterprise-wide systems with midrange systems
    requires a component approach -- not enough IT professionals
    can do it [So IBM services are invaluable]
  • Network and systems management
  • Scalability to support large numbers of users at the high-end
  • Position and use of midrange servers compared to PC for
    client-server applications is still evolving
  • Being challenged by NT and PC LANs on workgroup servers
    at the low-end



© AberdeenGroup 1995 27
                                                         IBM Sales Training




                          Workstations

  • Defined by high performance graphics, RISC-based
    computing, superior floating-point processing, plug-and-play
    networking, multi-tasking Unix operating system, and O/S
    compatibility with workgroup server
  • Sold as networks rather than individual desktop devices
  • Major U.S. suppliers
     – Sun Microsystems -- SPARC stations
     – Hewlett-Packard -- Series 700
     – Silicon Graphics -- Iris and Indigo
     – IBM -- RS/6000
     – DEC -- AlphaStation


© AberdeenGroup 1995 28
                                                         IBM Sales Training




                          Workstations

  Best Uses:
  • Application development
  • Computer aided design (CAD) and Computer aided
     engineering (CAE)
  • Computational finance, such as trading room functions
  • Accessing data from multiple, remote, incompatible databases
  • Collaborative computing




© AberdeenGroup 1995 29
                                                         IBM Sales Training




            Terminals and Workstations
   Terminals:
   • For low-cost character-based computing or high-security
   • Block mode IBM 3270
   • ASCII standard - VT 100 equivalent
   • Best use -- heads-down data entry
   • Challenge -- PCs
   X-Stations:
   • For low-cost graphics-based client applications
   • Used where IT decision maker does not want to commit to
      PCs as desktop clients or needs security
   • Best use -- complex data retrieval
   • Challenge -- workstations, diskless PCs and PCs with OS/2 or
      Windows 95
© AberdeenGroup 1995 30
                                                     IBM Sales Training




                             Clusters
• Examples: Tandem               Node 1     Node 2   Node 4
  Himalaya, Digital              OS
                                 Tasks...
  VAXcluster, IBM SP2 &
  ES/9000 Sysplex
• Each node can be a                                          Message Bus
  uniprocessor or SMP
• Multiple, independent
  computing nodes cooperate
  via messages
• Most common use is for
  high availability; second is
  resource sharing
• Issue: Message-passing
  resource expense

© AberdeenGroup 1995 31
                                                        IBM Sales Training




                Massively Parallel
 • Developed in the 1990s for very high-end commercial decision
     support, OLTP, server consolidation applications and for
     technical/ scientific simulations and analysis
 • Major U.S. suppliers:
       – Tandem -- Himalaya
       – ATT GIS -- Teradata, 3600 and follow-on
       – IBM -- SP2
       – NCube -- NCube 2/3
       – Cray Research -- T3D
       – Intel -- Paragon
 Challenges:
 • Getting them to work as envisioned
 • Programming tools
 • ISV applications
© AberdeenGroup 1995 32
                                                          IBM Sales Training




                          Performance

  • For commercial, multi-user applications, Transaction
    Processing Council benchmarks are the standard
     – TPC-A: single application, OLTP test -- out of date (TPS-A)
     – TPC-B: ability to handle data calls to CPU -- irrelevant
       (TPS-B)
     – TPC-C: Most viable and commonly used for OLTP
       applications simulating real-world environment (tpmC)
     – Need decision support and workgroup benchmarks
  • For PCs, various magazine test suites
  • For technical applications
     – SPECint92 and SPECfp92 for workstation performance
     – LADDIS for file serving capability
© AberdeenGroup 1995 33
                                                IBM Sales Training




                  Closing Observations
• IS decision makers have a wide choice of hardware
  platforms -- and these platforms keeping getting more
  powerful, more reliable and cheaper

• The single-user and multi-user designs and operating
  systems environments are very different

• Multi-user hardware is viewed more and more as a
  commodity on which to run RDBMS base
  applications

© AberdeenGroup 1995 34
                                                  IBM Sales Training




                  Closing Observations
  • Managing distributed systems is a software issue

  • SMP and massively parallel systems are means to
    achieve high-end performance -- but users would
    prefer uniprocessors if possible

  • Systems design and complementary acquisition
    decisions are made through a series of trade-offs



© AberdeenGroup 1995 35
                                                                  IBM Sales Training




      Midrange Market & Competition

              Sizing up the RS/6000 versus the rest of the pack




© AberdeenGroup 1995 36
                                                       IBM Sales Training




      Midrange/Distributed Multiuser
              Servers: $25 B
  • Proprietary operating systems vs Unix-derivatives
  • RISC vs CISC processors
     – Intel is leading CISC processor
     – AS/400 will use RISC processors ASAP
     – Suppliers are waging a processor techno-babble war
       against each other
  • 32-bit vs 64-bit battles
     – Do not forget the software -- must be written for the
       hardware
  • Uniprocessors vs SMP
  • Transaction Processing Council (TPC) benchmarks are major
    performance battleground
© AberdeenGroup 1995 37
                                                           IBM Sales Training




      Midrange/Distributed Multiuser
              Servers: $25 B
  • Anticipate continued strong growth as a new generation of
    enterprise-wide, client-server, production applications are
    being rolled out
  • Suppliers’ middleware, application availability, professional
    services capability, and networking support are key factors in
    selection criteria
  • Competition will remain intense -- none of the current major
    suppliers can afford to lose volume or market share and
    newcomers want more
  • Will maintain price points and increase functionality and
    performance


© AberdeenGroup 1995 38
                                        IBM Sales Training




      Examining the Midrange Leaders

  •   IBM
  •   Hewlett-Packard
  •   Digital Equipment
  •   Sun Microsystems
  •   AT&T Global Information Systems




© AberdeenGroup 1995 39
                                                       IBM Sales Training




                          IBM Financials

  •   1994 Revenues = $64.0 Billion
  •   93/94 Revenue Growth Rate = +2%
  •   1994 Profitability = $3 B   (5% of revenue)
  •   Employees = 223,000
  •   Stock Price Trend = 50% increase in last year:
       – 3/94 = $55
       – 3/95 = $83




© AberdeenGroup 1995 40
                                                        IBM Sales Training




                   IBM Hardware Line-up
  • RS/6000 Servers
     – Second largest supplier of multiuser RISC/UNIX systems -
       - 19% market share
     – 52% revenue increase 93/94
     – 1994 revenues = $2 billion
     – Product line is transitioning from uniprocessor, Power2
       (RIOS) systems to SMP, PowerPC 601 servers
     – Following an IBM-first strategy, will frequently offer
       DB2/6000 RDBMS at considerable cost savings with
       platform
     – Value Proposition: IBM’s professional services
       organizations will help our customers implement
       RISC/UNIX-based open, client-server computing with the
       RS/6000
© AberdeenGroup 1995 41
                                                             IBM Sales Training




                   IBM Hardware Line-up
 • SP2
    – Up to 512 Power2 processors each running AIX 4.x for commercial
       and technical applications
    – 1994 revenues = $200 million
    – 370 SP1 and 2 systems installed;
       70 SP2s for commercial applications
    – Positioned as high-end of RS/6000 line and DB/2 offload for
       ES/9000
    – Major commercial applications: Complex Decision Support, LAN
       server consolidation, OLTP
    – Has generated 380 ISV promises to port RDBMSs and
       applications
    – Futures: SMP Nodes and RIOS2 upgrades
    – Value Proposition: IBM’s entry into very large scale, open
       systems computing. Hot new technology from IBM.
© AberdeenGroup 1995 42
                                                                          IBM Sales Training




                            IBM Strengths
  •   Size
       – Global support
       – Range of products
       – Talent pool to draw upon
  •   Customer base and sales reps’ knowledge of customers
       – Shared history, Customer Trust
       – Former IBM employees working now as customers
  •   Services
       – Planning, Implementation, Operations, Outsourcing, Financing
  •   Third-party support and competition
       – ISVs by the 1,000’s
       – PCM and peripheral suppliers
       – Professional service organizations (e.g., Andersen Consulting)




© AberdeenGroup 1995 43
                                                          IBM Sales Training




                          IBM Challenges

  • Processor technology -- PowerPC 600 will not be leading the
    industry for many years
  • Re-energizing and focusing the field organization
  • Gaining the trust of leading-edge, business line manager, and
    X-generation buyers
  • Learning how to work with ISVs as allies -- not enemies
  • Recognizing that its chief competition for IS executive
    allegiance is not other hardware suppliers such as HP but
    software solution suppliers such as Oracle, SAP, and
    Microsoft



© AberdeenGroup 1995 44
                                                         IBM Sales Training




               Points-You-Should Know:
                     IBM RS/6000
  • Customers buy RS/6000 for support and historical relationship
    reasons and have replaced it until lately because of lack of
    high-end growth path. Sell SMP scalability to SP2.
  • Platform-of-choice for VARs whose customers cannot afford
    AS/400 but want IBM platform
  • RDBMS ISVs fear that if they recommend RS/6000 IBM will
    still switch customer to low priced DB2/6000
  • Expect growth to continue in 1995 as datacenter managers
    experiment with RS/6000 Tier-2 surround strategies
  • RS/6000 with DB2 is neither the fastest nor least expensive
    option
  • Whole story includes NetView, Data Propagator, DataHub

© AberdeenGroup 1995 45
                                                       IBM Sales Training




                          HP Financials

  •   1994 Revenues = $26.6 Billion
  •   93/94 Revenue Growth Rate = +23%
  •   1994 Profitability = $1.6 B   (6% of revenue)
  •   Employees = 98,000
  •   Stock Price Trend = 51% increase in last year:
       – 3/94 = $82
       – 3/95 = $124




© AberdeenGroup 1995 46
                                                         IBM Sales Training




                    HP Hardware Line-up

  Midrange:
  • HP 9000:
     – Multi-user RISC/UNIX industry leader -- 45% share
     – 60% revenue growth rate last 3 quarters
     – 1994 revenues = $4.5 billion
     – Value Proposition: Leading platform for Unix applications
       in terms of technology and ISV application support
  • HP 3000:
     – Legacy MPE/IX system updated with HP’s PA-RISC
       technology. Same hardware as HP 9000 but with MPE/iX
       operating system


© AberdeenGroup 1995 47
                                                        IBM Sales Training




                          HP Strengths

  • Trusted-supplier by IS decision makers for making the
    transition to high-performance UNIX systems
  • Supports and is supported by ISVs and professional service
    organizations -- usually as a first among equals
  • One of a handful of hardware suppliers that can support
    enterprises on a global basis
  • Technology leadership perception
     – RISC processors
     – Complete Unix operating environment
     – OpenView systems management framework
  • HP Professional Service Organization knows Unix operating
    environment capabilities thoroughly
© AberdeenGroup 1995 48
                                                           IBM Sales Training




                          HP Challenges

  • Running as a lean and mean organization means business
    opportunities often slip by
  • Making the transformation from selling hot boxes on price
    and price/ performance to being seen as an incumbent
    supplier that can add value in additional ways
  • Current generation of PA-RISC, PA-7200, is not the fastest
    chip in the market
  • Does not have a very high-end RISC/UNIX product offering
    (i.e. clusters & MPP) and is being squeezed by Intel/NT at the
    low end
  • After 3 years as Top Gun, HP is getting arrogant, sloppy


© AberdeenGroup 1995 49
                                                          IBM Sales Training




          Points-You-Should Know: HP

  • Is considered the mainframe alternative leader
  • In new sales deals, HP’s most common hardware competitors
    will be IBM and Sun
  • HP’s Computer Systems Organization (HP 3000/9000,
    Workstations, PSO) has a separate sales force from its
    Computer Products Organization (Vectras, LaserJets,
    NetManagers) resulting in sales confusion and annoyance for
    customers and prospects
  • Is consistently ranked as one of the computer industry’s most
    respected companies
  • Should be respected but not feared. HP is not invincible.


© AberdeenGroup 1995 50
                                                         IBM Sales Training




                          Digital Financials

  •   1994 Calendar Revenues = $13 Billion
  •   93/94 Revenue Growth Rate = +5%
  •   1994 FY Loss = ($2.5 Billion)
  •   Employees = 65,600
  •   Stock Price Trend = 27.5% increase in last year:
       – 3/94 = $29.625
       – 3/95 = $37.875




© AberdeenGroup 1995 51
                                                                IBM Sales Training




               Digital Hardware Line-up
 Midrange:
 • Digital ALPHAserver XX00:
    – Multi-user RISC/UNIX 64 bit -- 3% market share
    – 150% revenue growth rate 1994
    – 1994 revenues = ~ 20% revenues or $2.5 billion - with all add-ons
    – Value Proposition: Faster processors capable of managing vast
      amounts of memory and disk
 • Digital VAX:
    – Legacy VMS system updated to OpenVMS
    – VAX revenues declining 35% to 50% per annum
    – 1994 revenues = less than 10% of company revenues - with all
      add-ons
    – Value Proposition: Hold base while selling evolution and
      migration (if possible) to OpenVMS and ALPHA AXP

© AberdeenGroup 1995 52
                                                          IBM Sales Training




                          Digital Strengths

  • Alpha performance combined with aggressive pricing has
    created the best price/performance in the industry.
  • Digital's UNIX (OSF/1) meets the specifications of more
    standards setting groups than any other Unix operating
    system.
  • Digital will deliver enterprise-class open platforms with
    Microsoft NT on Alpha. Note recent TPC-C benchmarks.
  • Digital is creating software frameworks for enterprise-wide
    open computing to meet customer needs for applications
    interoperability from the desktop to datacenter.




© AberdeenGroup 1995 53
                                                            IBM Sales Training




                          Digital Challenges

  • Digital is not yet out of the restructuring woods. As a result,
    customers and prospects remain concerned about:
     – who will sell to them
     – where support will come from
     – which support people will continue to be there
     – which promised products may be eliminated
  • With the current neutral attitude of prospects to Digital's
    limited number of Alpha UNIX systems, Digital has yet to
    establish a critical mass for long-term viability.
  • Alpha/NT looks like a rosy future, but lacks 1995 revenues to
    sustain the company


© AberdeenGroup 1995 54
                                                         IBM Sales Training




     Points-You-Should Know: Digital

  • The company's diligence and resolve is regaining it respect
    from the industry and Wall Street. Prospects becoming more
    willing to entertain a Digital solution.
  • Digital remains an excellent engineering company.
    Development of Large In-Memory Databases (LIMD) could
    revolutionize enterprise OLTP and complex DSS.
  • Digital and Oracle have been increasing their strategic
    commitments
     – Oracle acquires RDB and installed base
     – Oracle is the LIMD database



© AberdeenGroup 1995 55
                                                            IBM Sales Training




                          Sun Financials

  •   1994 Revenues = $5.6 Billion
  •   93/94 Revenue Growth Rate = +31%
  •   1994 Profitability = $22.4 million (4% of revenues)
  •   Employees = 13,500
  •   Stock Price Trend = 39% increase in last year:
       – 3/94 = $27.375
       – 3/95 = $36




© AberdeenGroup 1995 56
                                                          IBM Sales Training




                   Sun Hardware Line-up

  Midrange:
  • SPARCcenter 2000 and SPARCserver 1000 :
     – Multi-user RISC/UNIX - 10% market share
     – Revenues = ~ 20% of Sun / $1.1 Billion
     – SPARCcenter - 2 to 20 processors
     – SPARCserver - 2 to 8 processors
     – Challenging IBM for number 2 position with ISVs for
       application support
     – Value Proposition: The open systems, price leader for
       enterprises that want alternative high-risk, high-reward
       solutions


© AberdeenGroup 1995 57
                                                            IBM Sales Training




                          Sun Strengths

  • Originator and still a leader in the open systems client-server
    computing marketplace. Customers and Prospects still may
    have Sun religion.
  • Large number of software applications available - a pound-
    for-pound leader.
  • Sun is regarded as an innovator in providing networked
    client/server solutions to the industry.
  • Sun’s positive working relationships with value-added
    resellers and third party distributors can mean lower
    acquisition and maintenance costs.
  • Strong ISV relationships. Most ISVs use Sun workstations to
    develop their client/server products and applications.

© AberdeenGroup 1995 58
                                                           IBM Sales Training




                          Sun Challenges
  • Sun direct field support is limited and is often contracted out
    to other firms.
  • There are very few references for running SPARCcenter 2000s
    and SPARCserver 1000s for business critical production OLTP
    applications.
  • Transitions between operating system releases has historically
    been problematic, compounded by minimal technical support
    from its corporate offices. Problems with Solaris in 1994.
  • Real world scalability of applications appears to be very poor
    on all of Sun’s workstations and servers.
  • Loss of influence. Sun does not appear to be a major player in
    the new generation of standards setting groups. Many Sun
    products, such as its critical OpenLook GUI, may be excluded
    from future standards.
© AberdeenGroup 1995 59
                                                          IBM Sales Training




         Points-You-Should Know: Sun

  • Large number of applications.
  • Champion of the “common” customer.
  • Strong alternate channel presence - will sell through any
    distributor.
  • Sun’s commercial client/server strategy is making inroads via
    Networking and application development.
  • Sun maintains both the lowest entry price and best
    price/performance point for commercial servers.




© AberdeenGroup 1995 60
                                                            IBM Sales Training




              AT&T Global Information
                Solutions (i.e. NCR)
  • 1994 total revenues of approx. $4.2 Billion
  • Revenues have been flat for several years -- with financial
    results running at break-even (1% profit for 1994)
  • Continues to have financial backing of parent AT&T (1994
    revenues = $75 Billion) -- but could also be spun out or sold at
    any time




© AberdeenGroup 1995 61
                                                          IBM Sales Training




              AT&T Global Information
                Solutions (i.e. NCR)
  • Product strategy is to offer open systems based on desktop to
    massively parallel product lines -- Globalyst models from PC
    to departmental and Teradata for decision support
  • All servers based on Unix and Intel 486/ Pentium
    microprocessor -- no RISC server
  • Unix System V.4 MP OS with Reliability, Availability,
    Serviceability enhancements
  • Low-end servers also run OS/2, SCO Unix, NetWare, and
    Windows NT
  • Microchannel peripheral bus adapters migrates to PCI
  • Full line of peripherals, including RAID storage
  • High availability clustering with LifeKeeper

© AberdeenGroup 1995 62
                                                          IBM Sales Training




                      AT&T GIS Strengths

  • Breadth of compatible server products is excellent
  • Good, often leading, TPC price/performance
  • The backing of AT&T
  • Bullet-proof version of UNIX. Known for stability.
  • The Intel multiprocessor market champion (vs. RISC) and
    leader -- $1.2 Billion in 1994
  • Market strength and broad solutions strength in retail and
    banking
     – Also Telecomm, Government, Transportation markets




© AberdeenGroup 1995 63
                                                         IBM Sales Training




                    AT&T GIS Challenges

  • While the leader in Intel/Unix servers, losing ground to
    leading RISC providers, not to mention Compaq
  • Intel is depending on AT&T GIS to be premier supplier of P6-
    based servers for enterprise computing
  • Organization seems to lack the fire required to gain market
    share
  • Customer base is loyal due to product reliability and service
    orientation
  • Failure to properly manage Teradata for big customers has
    resulted in unexpected backlash and opened up new
    opportunities for data warehousing/complex DSS.


© AberdeenGroup 1995 64


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | rs6000-training-a4eda3 |
| title | RS/6000 RDBMS Sales Training |
| author | Peter S. Kastner, Group Vice President, Aberdeen Group |
| date | 1995 |
| type | employer-record |
| subject_domain | RDBMS market; Unix server competitive landscape; IBM RS/6000; midrange hardware; client-server computing |
| methodology | sales-training-deck; analyst-briefing; competitive-analysis |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

65-page IBM sales training deck authored by Peter S. Kastner of Aberdeen Group. Covers: (1) IT impact on business, (2) midrange platform technology and leading suppliers, (3) decision support and data mining, (4) open OLTP opportunities, (5) RDBMS player analysis (Oracle, Sybase, Informix, etc.), (6) RDBMS sales rep partnering, (7) RDBMS supplier positioning, (8) RS/6000 with DB2/6000. Provides financial data for IBM, HP, DEC, Sun, and AT&T GIS circa 1994-1995. Preserved raw text covers pages 1-64; RDBMS-specific positioning sections (pp. 65+) appear truncated in OCR.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rare primary source: paid analyst content created for IBM sales force. Contains Aberdeen's proprietary frameworks (Three Tier Plus Model, technology adoption curve), competitive scorecards, and financial data for all major midrange vendors. A comprehensive snapshot of the 1995 Unix/RDBMS commercial server market. |
| **Relevance** | high | Kastner's most comprehensive known training document; covers full RS/6000 competitive landscape against HP, DEC, Sun, AT&T GIS with quantitative financial data. |
| **Prescience** | high | Correctly identified: RISC winning over CISC in midrange; HP's arrogance problem; Digital's recovery struggle; Sun's ISV leader position; IBM's chief competition shifting from HP to Oracle/SAP/Microsoft; NT challenging Unix at workgroup low end. All proved accurate by 1997-1999. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (20)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| IBM (International Business Machines) | company | [DEFERRED] | [DEFERRED] |
| Hewlett-Packard (HP) | company | [DEFERRED] | [DEFERRED] |
| Digital Equipment Corporation (DEC) | company | [DEFERRED] | [DEFERRED] |
| Sun Microsystems | company | [DEFERRED] | [DEFERRED] |
| AT&T Global Information Solutions (GIS) | company | [DEFERRED] | ncr |
| Aberdeen Group | firm | [DEFERRED] | [DEFERRED] |
| Peter S. Kastner | person | active |  |
| Oracle | company | [DEFERRED] | [DEFERRED] |
| Microsoft | company | [DEFERRED] | [DEFERRED] |
| SAP | company | [DEFERRED] | [DEFERRED] |
| Tandem Computers | company | [DEFERRED] | [DEFERRED] |
| Data General Corporation | company | [DEFERRED] | [DEFERRED] |
| Unisys | company | [DEFERRED] | [DEFERRED] |
| Sequent Computer Systems | company | [DEFERRED] | [DEFERRED] |
| NCR Corporation | company | [DEFERRED] | [DEFERRED] |
| Compaq Computer | company | [DEFERRED] | [DEFERRED] |
| Cray Research | company | [DEFERRED] | [DEFERRED] |
| Silicon Graphics (SGI) | company | [DEFERRED] | [DEFERRED] |
| Andersen Consulting | company | [DEFERRED] | [DEFERRED] |
| Computer Sciences Corporation (CSC) | company | [DEFERRED] | [DEFERRED] |

### Technologies Referenced (35)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| IBM RS/6000 | hardware | IBM | growth | legacy |
| IBM SP2 | hardware | IBM | emerging | legacy |
| PowerPC (601/604) | hardware | IBM/Apple/Motorola | emerging | legacy |
| IBM AIX 4.x | platform | IBM | emerging | legacy |
| IBM DB2/6000 | database | IBM | growth | legacy |
| IBM AS/400 | hardware | IBM | mature | evolved |
| IBM ES/9000 (Sysplex) | hardware | IBM | mature | legacy |
| HP 9000 | hardware | Hewlett-Packard | growth | legacy |
| HP 3000 (MPE/iX) | hardware | Hewlett-Packard | mature | legacy |
| HP PA-RISC (PA-7200) | hardware | Hewlett-Packard | mature | legacy |
| HP OpenView | middleware | Hewlett-Packard | mature | legacy |
| Digital ALPHAserver | hardware | Digital Equipment Corporation | emerging | legacy |
| DEC VAX/OpenVMS | hardware | Digital Equipment Corporation | declining | legacy |
| Digital OSF/1 (Unix) | platform | Digital Equipment Corporation | emerging | legacy |
| Sun SPARCcenter 2000 / SPARCserver 1000 | hardware | Sun Microsystems | growth | legacy |
| Sun SPARC | hardware | Sun Microsystems | growth | legacy |
| AT&T GIS Teradata / NCR 3600 | hardware | AT&T GIS/NCR | mature | legacy |
| AT&T GIS Globalyst | hardware | AT&T GIS/NCR | mature | legacy |
| Intel x86 (486/Pentium) | hardware | Intel | growth | legacy |
| Microsoft Windows NT | platform | Microsoft | emerging | evolved |
| Microsoft Windows 95 | platform | Microsoft | emerging | legacy |
| IBM OS/2 | platform | IBM | declining | legacy |
| Symmetric Multi-Processing (SMP) | framework |  | growth | evolved |
| Massively Parallel Processing (MPP) | framework |  | emerging | mainstream |
| Clustering (High Availability) | framework |  | emerging | mainstream |
| TPC-C Benchmark (tpmC) | framework | Transaction Processing Performance Council | growth | legacy |
| SPECint92 / SPECfp92 | framework | SPEC Consortium | mature | legacy |
| Unix (variants) | platform |  | mature | evolved |
| RISC Architecture | hardware |  | growth | evolved |
| IBM Data Propagator / DataHub / NetView | middleware | IBM | emerging | legacy |
| Large In-Memory Databases (LIMD) | database | Digital Equipment Corporation | emerging | legacy |
| Novell NetWare | platform | Novell | declining | legacy |
| IBM Power2 / RIOS | hardware | IBM | declining | legacy |
| LifeKeeper (AT&T GIS) | middleware | AT&T GIS | mature | legacy |
| Aberdeen Three Tier Plus Model | framework | Aberdeen Group | emerging | legacy |

### Observation Summary

- Total observations: 50
- By type: financial-data: 19, competitive-assessment: 8, framework: 5, market-share: 5, market-data: 4, technical-assessment: 2, strategic-assessment: 2, survey-data: 2, market-sizing: 1, competitive-risk: 1, strategic-move: 1
