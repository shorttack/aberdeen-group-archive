# Software Market Dynamics

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Vice President, Aberdeen Group |
| Date | ~1995 |
| Type | employer-record |
| Domain | Software market overview; operating systems; RDBMS; client-server development; enterprise systems management |
| License | CC-BY-4.0 |

## Abstract

9-page Aberdeen Group overview of software market dynamics authored by Peter S. Kastner. Covers: (1) Operating systems landscape (Windows 95 gaining acceptance by 1996, NT sweeping toward enterprise, IBM OS/2 Warp missed window, Unix variants mature), (2) RDBMS market (relational hot; ODBMS a niche; object-relational emerging; data warehousing reaching mainstream), (3) Client-server application development (distributed model by 2000; object-oriented next move; ORBs needed), (4) Client-server application solutions (SAP barriers huge; Windows NT as common option; emerging verticals), (5) Enterprise Information Systems Management (EISM model; distributed chaos; consolidation), (6) Software opportunities (integration services; object-transitional aids; NT robustness; SAP R3 distribution). OCR quality poor — garbled characters normalized.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 21 |
| observations.csv | 30 |
| codes.csv | 32 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Vice President, Aberdeen Group (~199). Software Market Dynamics.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

analyst-briefing; market-overview
