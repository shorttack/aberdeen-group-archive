# Enterprise Superservers and Sequent's NUMA Architecture

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Aberdeen Group |
| Date | 1996 |
| Type | employer-record |
| Domain | enterprise-servers; parallel-computing; NUMA-architecture; SMP; clustering |
| License | CC-BY-4.0 |

## Abstract

Aberdeen Group presentation arguing that competitive-advantage business pressures are forcing enterprises to rethink computer architectures. Bottlenecks in traditional SMP and cluster architectures preclude true enterprise superservers. Sequent's NUMA architecture, built on Intel building blocks, solves these bottleneck problems and is positioned as a leader in next-generation enterprise servers. Includes an insurance company case study: 5,000 remote + 3,500 HQ users, 15% annual growth projection. Predicts 3x-5x increase in user-driven compute demand by year 2000.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 4 |
| technologies.csv | 10 |
| observations.csv | 17 |
| codes.csv | 38 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Aberdeen Group (1996). Enterprise Superservers and Sequent's NUMA Architecture.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

analyst-presentation; architecture-analysis; case-study
