# Enterprise Superservers and Sequent's NUMA Architecture

> Archived from: source/_raw_text.txt
> Original publication date: 1996
> Author: Peter S. Kastner, Aberdeen Group

---

## Original Document Text

Aberdeen Group Copyright 1996
                                1
        Business is market-driven to become more productive, and
        technology is the means.


        The competitive-advantage business process is causing large
        enterprises to re-think their computer architectures. But
        bottlenecks in traditional architectures won’t allow the kinds of
        enterprise superservers that many need today -- and more
        tomorrow. Sequent’s NUMA architecture -- built on Intel
        building-blocks -- solves real bottleneck problems and is likely
        to be one of the leaders in next-generation enterprise servers.




Aberdeen Group Copyright 1996
                                                                            2
        The cliché about competitive advantage is true. Strong,
        worldwide and cross-industry pressures are driving business -
        - and government -- to become more competitive.
        Technology is the hands-down favorite means to improve
        productivity and to do more with less.




Aberdeen Group Copyright 1996
        Improving the bottom line can be accomplished by three
        means:
                          - Cut IS costs
                          - Reduce already optimized COGS
        or, the best choice for many, focus on reducing the SG&A
        overhead.




Aberdeen Group Copyright 1996
        Reducing SG&A becomes a never-stopping process of
        constant improvement ...
        Fewer relationships ... but better supply-chain management
        More revenues (and profits) due to better customer targeting
        and better sales management systems
        New customer capture techniques such as the Internet and
        data mining to develop a “market of one”.




Aberdeen Group Copyright 1996
        Business-driven pressures and new technology are radically
        changing the way many enterprise workers conduct their
        jobs.
        1. Use sophisticated decision support tools and mange-by-
        exception applications to identify job problems and potential
        solutions.
        2. Humans still need to analyze and decide, but increasingly
        smart applications can give prioritized recommendations.
        3. User issues transactions to effect the solution. Workflow
        may message the job to the next step.
        4. Reporting, often by e-mail, completes the cycle.
        unfortunately, this new user job cycle has huge implications
        on the IS infrastructure.




Aberdeen Group Copyright 1996
Aberdeen Group Copyright 1996
        The end user wants and needs a SINGLE view of the
        enterprise IT resources needed for OLTP, DSS, messaging,
        even the Web. But the user needs to be isolated behind the
        User Curtain -- remember the wizard of OZ? -- hidden from
        the complexity of servers, WANs and distributed applications.
        The user can’t handle the complexity of today’s IT
        infrastructure (i.e.., 15 different application login sequences).
        However, IT is hard pressed to hide the complexity .. and to
        deliver the services for the decide/analyze/transact/report
        model.




Aberdeen Group Copyright 1996
        Aberdeen’s enterprise architecture model has four levels or
        tiers.




Aberdeen Group Copyright 1996
        A real-world insurance company and Aberdeen client is
        planning a next generation claims processing system. Any
        customer can stop in any office for complete support. Claims
        can be updated from any local office.
        A server at HQ will manage HQ users, systems management,
        and batch.
        .




Aberdeen Group Copyright 1996
        Local servers in 50 offices are desired for fast, local response
        time. Each office will have a complete copy of the active
        claims database. Replication or transaction queuing will be
        used to pull every transaction from the local office to an
        “enterprise superserver” at headquarters which will serve as
        the database of record. This superserver will service 3,500
        HQ users, replicate (“push”) all transactions out to all offices,
        and drive data transformation onto a data warehouse server.
        Supporting transactions from 5,000 remote users and 3,500
        local users as well as push replication, batch, and data
        warehouse transformation duties demands considerable
        computing capacity -- beyond traditional SMP architectures
        and even many clusters.
        What computing platform can handle this workload and still
        be able to grow with the projected 15% annual business
        volume?




Aberdeen Group Copyright 1996
        As the insurance example shows, business change-driven
        applications have enormous implications on computing
        decisions:
        1. user-driven demand for computing resources will increase
        3x-5x by year 2000
        2. Availability at or near 24x365 becomes mandatory
        3. Traditional computer capacity such as mainframes just
        won’t handle the projected workload
        4. IS organizations can Make their own solutions through
        complex and risky integration, or Buy an integrated, scaleable
        computing platform.




Aberdeen Group Copyright 1996
        Let’s discuss the issues needed to build an efficient
        Enterprise Superserver




Aberdeen Group Copyright 1996
        We can expect the usual better, faster, cheaper, smaller
        microprocessor by following Moore’s law
        And network bandwidth is finally starting to skyrocket --
        thanks in part to Internet demand and the infrastructure
        investments made in laying fiber
        While disk storage prices (and memory) drop -- allowing us to
        buy more for less
        Meanwhile, new technology-enabled applications such as
        voice user interfaces will arrive, as will practical artificial
        intelligence in areas such as system software
        But the ‘Net will still be the wild frontier.




Aberdeen Group Copyright 1996
        As more CPUs are added to an SMP, memory contention for
        critical structures (as well as overall memory bandwidth)
        becomes a show-stopper issue in most SMP
        implementations.
        So growing an enterprise superserver as an SMP is not
        practical.




Aberdeen Group Copyright 1996
        Clusters scale horizontally, and can be made up of SMP
        nodes. But the messaging software, interrupts and parasitic
        effects on the operating system, memory bus, and CPU limit
        the effectiveness of most cluster implementations.




Aberdeen Group Copyright 1996
        Most applications (or layered software such as an RDBMS)
        must be tailored specifically to run efficiently -- if at all -- on a
        cluster. This limits IS choices in buying applications and
        certainly complicates making applications.




Aberdeen Group Copyright 1996
Aberdeen Group Copyright 1996
Aberdeen Group Copyright 1996
Aberdeen Group Copyright 1996


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | sequent-1996-9ce892 |
| title | Enterprise Superservers and Sequent's NUMA Architecture |
| author | Peter S. Kastner, Aberdeen Group |
| date | 1996 |
| type | employer-record |
| subject_domain | enterprise-servers; parallel-computing; NUMA-architecture; SMP; clustering |
| methodology | analyst-presentation; architecture-analysis; case-study |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Aberdeen Group presentation arguing that competitive-advantage business pressures are forcing enterprises to rethink computer architectures. Bottlenecks in traditional SMP and cluster architectures preclude true enterprise superservers. Sequent's NUMA architecture, built on Intel building blocks, solves these bottleneck problems and is positioned as a leader in next-generation enterprise servers. Includes an insurance company case study: 5,000 remote + 3,500 HQ users, 15% annual growth projection. Predicts 3x-5x increase in user-driven compute demand by year 2000.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Primary Aberdeen analyst document authored by Kastner for Sequent client; articulates key architectural argument (SMP bottlenecks -> NUMA solution) that shaped 1990s enterprise server market thinking. |
| **Relevance** | high | Direct Aberdeen Group employer-record; Kastner's own analysis and market predictions; enterprise computing architecture taxonomy used as intellectual framework. |
| **Prescience** | high | 3x-5x compute demand prediction by 2000 proved accurate; NUMA became mainstream in modern servers; identification of SMP memory bus as ceiling was technically correct. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (4)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | [DEFERRED] |  |
| Sequent Computer Systems | company | [DEFERRED] |  |
| Intel | company | [DEFERRED] |  |

### Technologies Referenced (10)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Sequent NUMA-Q Architecture | hardware-architecture | Sequent Computer Systems | emerging | legacy |
| Symmetric Multiprocessing (SMP) | hardware-architecture | multiple | mature | legacy |
| Server Clustering (Loosely Coupled) | hardware-architecture | multiple | growth | legacy |
| Enterprise Superserver | server-concept | multiple | emerging | evolved |
| Online Transaction Processing (OLTP) | workload-type | multiple | mature | evolved |
| Decision Support Systems (DSS) / Data Warehouse | workload-type | multiple | emerging | evolved |
| Moore's Law (CPU improvement trajectory) | technology-principle | Intel | active | evolved |
| Database Replication / Transaction Queuing | middleware | multiple | emerging | evolved |
| Internet / World Wide Web | network-platform | multiple | emerging | evolved |
| Data Mining | analytics | multiple | emerging | evolved |

### Observation Summary

- Total observations: 17
- By type: technology-limitation: 3, case-study-metric: 3, technology-trend: 3, product-positioning: 1, demand-forecast: 1, availability-requirement: 1, growth-projection: 1, market-driver: 1, framework: 1, business-driver: 1, workflow-pattern: 1
