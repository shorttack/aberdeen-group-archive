# Sequent Servers and Data General Servers Competitive Brief

| Field | Value |
|-------|-------|
| Author | Aberdeen Group |
| Date | ~1994-1995 |
| Type | employer-record |
| Domain | competitive-intelligence; enterprise-servers; SMP; UNIX; Windows-NT; benchmarks |
| License | CC-BY-4.0 |

## Abstract

Aberdeen competitive intelligence brief on Sequent (Symmetry, WinServer) and Data General (Aviion) servers prepared for IBM sales representatives. IBM Confidential. Covers product lines, pricing, benchmark results (tps-A), strengths and concerns, and IBM sales messages. Sequent Symmetry 2000/250: $85,000 entry, 183.34 tps-A; 2000/750 2-cluster: 1002.37 tps-A. Sequent 5000 SE20 entry $171,100, SE60 entry $469,800. WinServer 500-5000 for Windows NT ($13,200-$246,900). Data General Aviion 5500: $14,490 entry, 130.9 tps-A; 9500: $79,995 entry, 523.64 tps-A. DG annual sales ~$1B fiscal '93; Sequent $354M fiscal '93.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 12 |
| observations.csv | 28 |
| codes.csv | 39 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Aberdeen Group (~199). Sequent Servers and Data General Servers Competitive Brief.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

competitive-brief; product-analysis; benchmark-compilation
