# Sequent 1996 Organization and Direction

| Field | Value |
|-------|-------|
| Author | Sequent Computer Systems |
| Date | 1996 |
| Type | employer-record |
| Domain | enterprise-servers; NUMA-Q-architecture; SMP; parallel-computing; company-strategy |
| License | CC-BY-4.0 |

## Abstract

Sequent internal pitch deck covering company changes and strategic direction. Positions Sequent as 'leading architect of open, client/server solutions' with a goal to become leading architect of enterprise-wide solutions. Key content includes detailed technical explanation of the transition from SMP to NUMA-Q architecture: NUMA-Q removes SMP single-bus limitation while preserving SMP programming model. IQ-LINK interconnect using SCI (Scalable Coherent Interconnect) with Vitesse GaAs DataPump chip at 1GB/sec. QUAD building blocks; Fibre Channel for I/O; support for up to 256 processors (8 nodes x 32 processors). Business philosophy: Buy vs. Build, leverage commodity, adherence to standards. Intel P6 chosen for SMP readiness.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 6 |
| technologies.csv | 11 |
| observations.csv | 16 |
| codes.csv | 38 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Sequent Computer Systems (1996). Sequent 1996 Organization and Direction.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

internal-pitch-deck; architecture-briefing
