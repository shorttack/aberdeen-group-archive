# Sequent 1996 Organization and Direction

> Archived from: source/_raw_text.txt
> Original publication date: 1996
> Author: Sequent Computer Systems

---

## Original Document Text

Page 1
         1
Introductory Remarks:
•               •

                Many changes in Sequent
                organization and direction
                since then
•               Net effect of those changes
                has been to position Sequent
                as a leading architect of
                open, client/server
                solutions
•               Our goal is to become the
                leading architect of
                enterprise-wide solutions
                for the world’s largest
                organizations


                    Page 2
                                               2
Page 3
         738
Page 4
         4
By taking the process centric view (requiring
business process engineering to have taken
place), the IT systems achieve the necessary
integration to manage commitments to
customers, suppliers and regulators of the
enterprise.




                    Page 5
                                                59
Page 6
         6
Page 7
         7
Page 8
         8
Page 9
         9
Page 10
          10
Page 11
          11
Page 12
          12
Page 13
          13
Page 14
          14
Page 15
          15
Page 16
          16
Page 17
          17
Page 18
          18
So what has the change to NUMA-Q meant. We are coming from
an SMP world where all of the bus traffic, I/O, Memory to CPU,
and Coherency traffic, all goes over one bus. The latencies from
any processor to any piece of memory are uniform. The latencies
from any disk to any piece of memory are uniform. So the
applications programmers don’t have to worry about data skew as
they do in MPP programming. At run time the number of CPUs
used are allocated dynamically. Since most of the SMP vendors
have similar architectures, the Applications companies can port
their software with relative ease, excluding making changes unique
to the OS. There will always be some tuning unique to each
platform, to squeeze out those last few single digit percentage
improvements, but fundamentally the applications do not have to
be re-architected as they are moved from one SMP platform to the
next. This is why SMP became so popular.
Of course this one backplane is also the limiting factor in how big a
single SMP system can be, until now. NUMA-Q removes that
limitation, while keeping the SMP programming model.




                           Page 19
                                                                        23
                                                                        19
                                                                        18
                                                                        46
So what is so tough about using these LYNX for
implementing large coherent memory systems? Do we
need to move from the big bus model other than to try and
leverage the QUAD building block ?
We have had the luxury of retaining the same architecture
for 11 years. We have changed the bus speed 3 times, and
had numerous processor, memory, and I/O changes, but
the fundamental shared memory architecture has not
changed. Indeed, a single shared memory, accessed by a
single shared bus is the “purest” form of SMP as long as it
meets your computing needs. This architecture is very easy
to program (SMP programming model) and port
applications to it.
But, as we look out into the future we realize that DSS
applications demand an increasing amount of I/O. There
is a strong desire to make a bigger and faster system bus,
and indeed it is feasible to design a 1GB/S single shared
bus. The drawback is that as the bus speed increases, the
bus length must necessarily shrink (physics you know,
Electrons travel at 2ns/ft and all that). Well having less bus
slots and therefore less processors etc. is not very desirable
to us. We might end up looking like an HP T500 or DEC
Turbolaser (9 slots). Caches do reduce bus traffic, but all
I/O and all memory traffic still goes over the one bus.
So we figured out a better way. We are not leaving the
current systems hanging though; we are designing new
processors, memory, and I/O for the S5000, but we have
recognized that in late ‘96 it would be very advantageous
                          Page 20
to make a major shift in architecture.
                                                                 20
So what has the change to NUMA-Q meant. We are coming from
an SMP world where all of the bus traffic, I/O, Memory to CPU,
and Coherency traffic, all goes over one bus. The latencies from
any processor to any piece of memory are uniform. The latencies
from any disk to any piece of memory are uniform. So the
applications programmers don’t have to worry about data skew as
they do in MPP programming. At run time the number of CPUs
used are allocated dynamically. Since most of the SMP vendors
have similar architectures, the Applications companies can port
their software with relative ease, excluding making changes unique
to the OS. There will always be some tuning unique to each
platform, to squeeze out those last few single digit percentage
improvements, but fundamentally the applications do not have to
be re-architected as they are moved from one SMP platform to the
next. This is why SMP became so popular.
Of course this one backplane is also the limiting factor in how big a
single SMP system can be, until now. NUMA-Q removes that
limitation, while keeping the SMP programming model.




                           Page 21
                                                                        23
                                                                        21
                                                                        18
                                                                        46
There are three guiding premises for hardware and software decisions within Sequent.
“Buy Vs. Build” ensures that we don’t get the NIH (Not Invented Here) syndrome. We
take the commodity if it has equal or better performance, equal or lower cost, and equal
or better quality. Leveraging the commodity is similar but we usually add something to
the product. Finally, adherence to standards takes precedence over “performance” as a
selection criteria for many products. Our choice of Intel is a good example. The
performance is not leadership (lags by 6months - a year), but it is clearly the
standards/safe choice.
Using these guidelines, Sequent has leveraged some key developing technologies. SCI,
the Scalable Coherent Interconnect enabled us to develop the IQ-LINK interconnect. SCI
products are being produced by two companies, Vitesse and Dolphin. We have
partnered with Vitesse to develop a 1GB/Sec DataPump chip based on GaAs. This
component is integral to the implementation and design of the IQ-LINK.
PCI is evolving as the standard for communications products in 1996. Fibre Channel will
be the I/O standard for disks and tapes also in 1996 and provide the RAS we need. The
router companies are integrating more functions and will take on some of the comms
role with LAN switches, ATM Switches, and Routers.
The P6 is SMP ready, or put another way, the P6 bus is actually an SMP bus.




                                  Page 22
                                                                                           22
                                                                                           17
                                                                                           18
                                                                                           28
Page 23
          236
Page 24
          246
The Fibre Channel technology and
the Fibre Channel switches provide
the means to cluster together
multiple STiNG nodes. We will
support up to 8 nodes.


A 256 processor system can
therefore be achieved by clustering
8 nodes, each with 32 processors.
This would have the added
advantage of providing much
higher availability than a single 256
SMP system. In addition its
performance for large DSS
problems will be quite similar.

               Page 25
                                        25
Page 26
          26
Page 27
          27
Page 28
          28
Page 29
          29
In selecting Quads as the building blocks for a NUMA-Q system,
one essentially started by distributing the Memory, Disk I/O, and
communications, because portions of these now reside in each
Quad. We returned to a single image of memory with the IQ-Link,
and despite the fact that the memory latency is no longer uniform
(it’s NUMA), the latency for remote accesses is so small, and the
accesses to rare, that the applications companies can effectively
ignore the effects and still achieve most of the potential
performance of the system.
Instead of attaching disks to individual QUADs, we can put PCI-
FC cards in each quad, and get back to the view of a common pool
of Disk, with equal latency from all processors and memory.
Additionally this “multipath” capability now gives us higher
availability, and load balancing. i.e. I/O bottlenecks can be
avoided.
The communications were similarly distributed in that one could
put unique comms ports in each quad. However, to achieve
maximum redundancy we have provided Lan Switches which not
only increase the fanout of the communications ports, but also
allow multiple quads direct access to shared communications
ports. The software is being developed to take advantage of this
redundancy.
So, we are back to having a shared pool of Memory, I/O, and
Comms once again. This is great news for the SMP applications
programmers, and also good news for the system availability,
because the NUMA-Q architecture brings with it a quantum leap in
availability characteristics and redundancy.




                          Page 30
                                                                    24
                                                                    30
                                                                    19
                                                                    47


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | sequent-pitch-1996-2e70e9 |
| title | Sequent 1996 Organization and Direction |
| author | Sequent Computer Systems |
| date | 1996 |
| type | employer-record |
| subject_domain | enterprise-servers; NUMA-Q-architecture; SMP; parallel-computing; company-strategy |
| methodology | internal-pitch-deck; architecture-briefing |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Sequent internal pitch deck covering company changes and strategic direction. Positions Sequent as 'leading architect of open, client/server solutions' with a goal to become leading architect of enterprise-wide solutions. Key content includes detailed technical explanation of the transition from SMP to NUMA-Q architecture: NUMA-Q removes SMP single-bus limitation while preserving SMP programming model. IQ-LINK interconnect using SCI (Scalable Coherent Interconnect) with Vitesse GaAs DataPump chip at 1GB/sec. QUAD building blocks; Fibre Channel for I/O; support for up to 256 processors (8 nodes x 32 processors). Business philosophy: Buy vs. Build, leverage commodity, adherence to standards. Intel P6 chosen for SMP readiness.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Rich internal technical briefing with detailed NUMA-Q architecture specifications; reveals Sequent's 11-year architectural history and the rationale for the NUMA-Q transition. Business guiding principles articulated explicitly. |
| **Relevance** | high | Employer-record from Sequent engagement; directly documents the platform transition being discussed in contemporaneous Aberdeen analyses. |
| **Prescience** | medium | NUMA-Q direction proved correct; PCI and Fibre Channel predictions accurate; Intel P6 (Pentium Pro) did succeed as SMP platform. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (6)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Sequent Computer Systems | company | [DEFERRED] |  |
| Intel | company | [DEFERRED] |  |
| Hewlett-Packard (HP) | company | [DEFERRED] |  |
| Digital Equipment Corporation (DEC) | company | [DEFERRED] |  |
| Vitesse Semiconductor | company | [DEFERRED] |  |
| Dolphin Interconnect Solutions | company | [DEFERRED] |  |

### Technologies Referenced (11)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Sequent NUMA-Q Architecture | hardware-architecture | Sequent Computer Systems | emerging | legacy |
| IQ-LINK Interconnect | interconnect | Sequent Computer Systems | emerging | legacy |
| SCI (Scalable Coherent Interconnect) | interconnect-standard | IEEE | emerging | legacy |
| QUAD Building Block | hardware-component | Sequent Computer Systems | emerging | legacy |
| Fibre Channel | storage-interconnect | multiple | emerging | evolved |
| PCI Bus | bus-standard | Intel | growth | evolved |
| Intel P6 (Pentium Pro) | processor | Intel | emerging | legacy |
| STiNG (Sequent NUMA-Q Platform) | server-platform | Sequent Computer Systems | emerging | legacy |
| Sequent S5000 | server-platform | Sequent Computer Systems | current | legacy |
| ATM Switches / LAN Switches | network | multiple | emerging | legacy |
| SMP Architecture | server-architecture |  | mainstream | evolved |

### Observation Summary

- Total observations: 16
- By type: technology-adoption: 3, company-positioning: 1, architectural-history: 1, architectural-transition: 1, technology-spec: 1, scale-spec: 1, availability-spec: 1, technology-decision: 1, technical-analysis: 1, programming-model: 1, architecture-design: 1, business-principle: 1, node-support: 1, dss-capability: 1
