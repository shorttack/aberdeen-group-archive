# The Strategic R/3 Solution for the Enterprise

| Field | Value |
|-------|-------|
| Author | Sequent Computer Systems |
| Date | ~1995-1996 |
| Type | employer-record |
| Domain | SAP-R/3; ERP-benchmarks; enterprise-servers; SMP-performance |
| License | CC-BY-4.0 |

## Abstract

Sequent benchmark document presenting SAP R/3 SD benchmark results on the Symmetry SE70 platform. Benchmark independently audited and certified by iXOS Software (SAP Strategic Partner). Results show 800 users, 20 application servers, 51% CPU utilization on Windows NT & UNIX. Compares favorably to HP (900 users, not certified), Sun/Cray (800 users, not certified), and IBM (1000 users, not certified). Benchmark configuration uses FDDI rings and Compaq ProLiant 4000s as client drivers.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 7 |
| technologies.csv | 5 |
| observations.csv | 12 |
| codes.csv | 32 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Sequent Computer Systems (~199). The Strategic R/3 Solution for the Enterprise.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

benchmark-results; competitive-comparison
