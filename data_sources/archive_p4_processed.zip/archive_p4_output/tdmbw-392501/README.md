# Surfing the Parallel Architectures

| Field | Value |
|-------|-------|
| Author | Peter S. Kastner, Vice President, Aberdeen Group |
| Date | September 27, 1994 |
| Type | employer-record |
| Domain | parallel-computing; SMP; MPP; clustering; NUMA; enterprise-servers; data-warehousing; RDBMS |
| License | CC-BY-4.0 |

## Abstract

Presentation by Peter S. Kastner (Aberdeen Group VP) to Tandem Computers' Board of Directors and Industry Advisory Panel on September 27, 1994. Covers parallel computing architectures (uniprocessor, SMP, cluster, MPP), market share estimates, parallel software including RDBMS, and Aberdeen's strategic assessment of Tandem's position. Key data: uniprocessor 72% market share; SMP 22%; clusters and MPP 5% and 1%. Aberdeen conclusion: MPP will remain a sideshow to SMP and cluster markets. Identifies data warehousing as Tandem's best near-term opportunity. Assesses IBM, HP, DEC, Unisys, Compaq, AT&T as competitors. SAP needs 300 SQL statements/second today, 3,000/second in two years. Aberdeen projects 3x-5x information demand increase by late 1990s.

## Data Tables

| Table | Rows |
|-------|------|
| studies.csv | 1 |
| entities.csv | 24 |
| technologies.csv | 16 |
| observations.csv | 30 |
| codes.csv | 47 |

## Load with Python

```python
import pandas as pd
studies = pd.read_csv('data/studies.csv')
observations = pd.read_csv('data/observations.csv')
```

## Validate

```bash
frictionless validate datapackage.json
```

## Citation

Peter S. Kastner, Vice President, Aberdeen Group (Sept). Surfing the Parallel Architectures.
Archived in Kastner Research Archive. DOI: [pending]

## Methodology

analyst-presentation; market-sizing; competitive-analysis; technology-assessment
