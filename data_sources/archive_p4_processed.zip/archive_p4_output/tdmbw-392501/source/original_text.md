# Surfing the Parallel Architectures

> Archived from: source/_raw_text.txt
> Original publication date: September 27, 1994
> Author: Peter S. Kastner, Vice President, Aberdeen Group

---

## Original Document Text

Surfing the Parallel Architectures


   A Presentation to Tandem Computers’
           Board of Directors and
          Industry Advisory Panel
            September 27, 1994



                 Peter S. Kastner
                    Vice President
                Aberdeen Group, Inc.
                  One Boston Place
                Boston, Mass. 02108
                   (617) 723-7890




                                       ©Aberdeen Group,
                                        1994
                     Agenda


●Why Parallel?
●Review of Parallel Architectures
●Review of Parallel Software
●Parallelism in Applications
●Supplier Approaches to Parallelism
●Aberdeen's Viewpoint on Tandem in a Parallel
  World




                                      ©Aberdeen Group,
                                       1994
          Why Parallel Processing?


●Technology is an enabler
   ❻Parallel hardware is widely available, inexpensive
   ❻Parallel software (i.e., RDBMS)
   ❻$2M per terabyte disk storage
   ❻Scalability beyond traditional (mainframe) architectures ...
●Demand is price elastic, business driven
   ❻Replace people with technology
   ❻Time really is money
   ❻“I can answer questions we never could before.”
   ❻"I'm running out of night!"
   ❻"I'm looking for a sustainable competitive advantage with IT."



                                                   ©Aberdeen Group,
                                                    1994
    Very Quick Review of Parallel
           Architectures

●Uniprocessor
●Symmetric Multiprocessor (SMP)
●Cluster (Loosely-coupled)
●Massively Parallel (MPP/SPP)




                                  ©Aberdeen Group,
                                   1994
  Estimated Market Share by
         Architecture


                                                  Symmetric       Tandem’s architectures:
                                                 Multiprocessor   Enterprise Computing
                                                      22%
                                                                                 Clusters
                                                                              Massively   5% 1%
                                                                                        Parallel




                      Uniprocessor
                          72%
                                                                              Uniprocessor
Uniprocessor has the largest share but the lowest profits                     Symmetric Multiprocessor
                                                                              Massively Parallel
                                                                              Clusters




                                                                  ©Aberdeen Group,
                                                                   1994
                         Uniprocessor


●Examples: Compaq PC servers, IBM     Software              Hardware
   RS/6000's to date, Integrity NR
   entry, each Himalaya node           Operating
●No hardware parallelism               System
●Useful as a software parallelism
   platform
                                       Task1
●Easy to design, manufacture, low
                                       Task2
   selling price                       Task3...
●Potential entry point for SMP
●Benefits from 75% CAGR in
   processor/system performance
●Problems: No scalability except to
   upgrade CPU.




                                                  ©Aberdeen Group,
                                                   1994
          Symmetric Multiprocessors


●Examples: Tandem Integrity NR, HP    Software             Hardware
   9000, IBM ES/9000, many more
                                       Operating
●Multiple CPUs share common data
                                       System
   highway (bus), memory and                               Processors
   operating system
●Well understood technology. New       Task1
   chip set accelerators.              Task2
   Inexpensive engineering.            Task3
●Scalability: Good to 4 processors;    Task4
   fair to 8; few do more than 10      Task n ...
                                                             Memory access is
                                                              a big problem
                                                              getting worse



                                                           Memory & I/O

                                                 ©Aberdeen Group,
                                                  1994
                             Clusters


●Examples: Tandem Himalaya,       Node 1     Node 2             Node 4
    Digital VAXcluster, IBM SP2   OS
    & ES/9000 Sysplex             Tasks...
●Each node can be a
    uniprocessor or SMP
                                                                         Message Bus
●Multiple, independent
    computing nodes
    cooperate via messages
●Most common use is for high
    availability; second is
    resource sharing
●Issue: Message-passing
    resource expense




                                                      ©Aberdeen Group,
                                                       1994
                   Cluster Reality


●Problems lie in software
   ❻Messaging between nodes is a very complex technology.
     Requires time to mature. Example: Tandem's 20 years of
     experience.
   ❻Today's system software and customer applications are not
     cluster-enabled. Require re-engineering to work in a cluster
     and may not scale well unless carefully architected
      • Example: Oracle Parallel Server, IBM ES/9000 Sysplex
●Trend
   ❻Distributed operating systems will evolve from a cluster
     technology base




                                                  ©Aberdeen Group,
                                                   1994
      Massively Parallel (MPP or SPP)


●Examples: nCube, Kendall
   Square, large Tandem
   Himalaya, large IBM SP2,
   Teradata, AT&T 3600
●No industry-accepted
   definition. Aberdeen says
   any system with more than
   100 nodes is massive.
●“Shared nothing” is required.
●Differentiators
   ❻Merchant vs. custom micro-
      processor
   ❻Standard (e.g., Unix) vs.
      proprietary architecture
   ❻Interconnect technology


                                 ©Aberdeen Group,
                                  1994
                     MPP Markets


●Used today by bleeding-edge adopters in highly
  competitive markets
   ❻Dow Jones text retrieval (Thinking Machines)
   ❻Prudential Securities (derivatives)
   ❻American Express (mailing lists)
   ❻Retail industry (Teradata for data warehousing)
●Market is most likely to evolve with existing large-
  computer suppliers rather than MPP new-starts
   ❻Scale up from clusters: Tandem, IBM SP2, AT&T 3600
   ❻Possible exception: MPP as pure database platform (not a
     general purpose computer) -- for example, Teradata



                                                 ©Aberdeen Group,
                                                  1994
                      MPP Reality


●Problems
   ❻Scalability in the real world
   ❻Systems management software is lacking
   ❻Writing parallel commercial applications without tools
   ❻Lack of support by small MPP companies
●Aberdeen conclusion is that MPP will remain a side
  show to the SMP and cluster markets, but that
  MPP buyers will come from the attractive World-
  1000 base




                                                  ©Aberdeen Group,
                                                   1994
  Hardware Supplier Approaches to
            Parallelism

●IBM ES/9000, PTS, SP2
●Hewlett-Packard
●Digital Equipment
●Unisys
●Compaq
●AT&T Global Information Solutions
●Others




                                     ©Aberdeen Group,
                                      1994
                                IBM


●Mainframe markets are driven by largest customers.      Sysplex clusters
    will only appeal to existing customers, lack overall price-
    performance value.
●Parallel Query and Transaction mainframe products are a premature
    product reaction to market share losses to non-mainframe
    competition (i.e., Tandem, HP). IBM microprocessors are too slow,
    software too limited, prices too high to be effective before 1997.
●SP2 cluster/SPP is all talk, no commercial product. Awaits parallel
    database software, tools, applications. Shows great promise in
    markets Tandem seeks.
●DB2 has four different variations under common product name.
    Technology is not competitive but is getting better.
●Strategically, IBM cannot concede the parallel market. Will they be
    the Russian army or the mouse that roared? Mostly hot air for next
    two years.


                                                     ©Aberdeen Group,
                                                      1994
              Hewlett-Packard


●Mediocre in SMP due to focus on ultra-fast RISC
  microprocessors. "Fewer is better" approach.
●Has next-century microprocessor deal in place with
  Intel
●Surprisingly weak in clusters, even for high
  availability
●Appreciates distributed systems management
●Expect better clusters and marketing heat by mid-
  1995
●HP MPP vague, driven by customers, expected in
  1997 or later. Ignore Convex.

                                     ©Aberdeen Group,
                                      1994
             Digital Equipment


●Good job on low-end SMP.    Fair scalability on high
  end.
●VAXclusters the original shared-resource facility.
  Slowly migrates to Alpha.
●Encore reflected memory technology under-
  appreciated
●New focus on alternate distribution/box volume
  mentality will likely hurt high end R&D efforts
●Aberdeen is negative on Digital’s long term
  prospects


                                       ©Aberdeen Group,
                                        1994
                     Unisys


●Focus is on maintaining Burroughs and Sperry
  installed bases
●Adequate clustered OLTP today
●Recent MPP plans lack credibility, investment
●Unix is not strategic to Unisys, so Intel/SMP will
  progress with market
●Conclusion: Unisys will be a minor competitor, and
  a potential roll-over sale target for Tandem




                                     ©Aberdeen Group,
                                      1994
                    Compaq


●Climbing up the enterprise food-chain from
  desktop/workgroup base
●Next year's Intel P6-based 4/8-way SMP will beat
  IBM mainframe ES/9000s in OLTP with RDBMS
●"Good enough" for many OLTP & moderate DSS
  applications
●The horse that Microsoft’s NT operating system will
  ride




                                      ©Aberdeen Group,
                                       1994
       AT&T Global Information
             Solutions

●#2 Unix server player with Intel-based line
●Owns the Teradata base of 400 large sites
●SMPs and 3600 cluster that grows to MPP
●Best company-wide at understanding complex DSS
  issues and experience
●Retail and banking powerhouse. Weak elsewhere.
●Often the bridesmaid. Will they ever get on track?




                                       ©Aberdeen Group,
                                        1994
       Other Hardware Suppliers


●SMP specialists Sequent and Pyramid
●ICL Goldrush query parallelization OS features
●nCube's fate rests with Oracle push
●Cray Research invades Wall Street with ex-Tandem
  sales rep
●Kendall Square Research is dead




                                       ©Aberdeen Group,
                                        1994
      Review of Parallel Software


●SAP says "I need 300 SQL statements/second
  today, 3,000 per second in two years."
●Relational databases are the most important
  commercial technology
●Operating systems become more parallel to evolve
  to distributed computing/object world of 1998
●Applications evolve towards distributed computing
  with partitioning and objects




                                     ©Aberdeen Group,
                                      1994
    Relational Databases (RDBMS)


●New software versions unleash the power of
  parallel hardware
●Complex decision support is the killer application
●Major suppliers are participating
   ❻Oracle
   ❻Sybase
   ❻Informix
   ❻IBM DB2




                                       ©Aberdeen Group,
                                        1994
   Independent Software Supplier
         Parallel Strategies

●Trend: Aberdeen sees a 3x-5x increase in
   information demand by the late 1990s. Complex
   DSS is the next major hurdle for commercial
   computing.
●Oracle: “Beat IBM mainframes. Protect Ellison's
   nCube investment.” Technology is behind.
●Sybase: talks enterprise, does departmental.
   Navigation Server an embarrassment.
●Informix: Bets the ranch on parallel RDBMS.
   Technology good but company lacks board-room
   visibility.


                                     ©Aberdeen Group,
                                      1994
       Aberdeen's Viewpoint on
      Tandem in a Parallel World

●Architecture
●Technology
●Markets




                          ©Aberdeen Group,
                           1994
                  Architecture


●Tandem ought to be a leader in distributed, object-
  based computing
●Tandem understands parallel issues in depth, with
  experience
●Market is recognizing that clustering (loose-
  coupling) is required for high-end applications
●Objects communicate via messages. Tandem does
  this better than others. The late 1990s will be
  dominated by object-oriented software issues.




                                       ©Aberdeen Group,
                                        1994
                  Technology


●Himalaya is at the enterprise-server market sweet-
   spot
●Integrity NR/FT cover mass-markets for commercial
   servers. High availability story great.
●“Open” Tandem will require by 1996 a better DCE
   and distributed-object technology roadmap.
●SGI/MIPS microprocessor faces enormous
   competition from Intel. Be prepared to switch.




                                      ©Aberdeen Group,
                                       1994
                         Markets


●Parallel computing profits are being made now in competitive-
   advantage markets (i.e., retail, telecomm, transportation,
   finance) where Tandem is already focused
●Tandem momentum has changed for the positive. Company
   has a wonderful opportunity to re-establish itself in existing
   markets for new applications
●Best near-term, cross-market opportunity is data warehousing
   (complex decision support). Tandem has the right-stuff
   technology, but needs partners in teaching buyers how to
   maximize their warehouse investments.
●Dual product strategy (Integrity & Himalaya) makes sense,
   recognizes that one-size-fits-all approach is unrealistic.




                                               ©Aberdeen Group,
                                                1994
           Backup Information


●The following material supplements the main
  presentation
●See also Aberdeen Group Viewpoints on Tandem,
  Digital Equipment, Parallel-Scalable Databases




                                     ©Aberdeen Group,
                                      1994


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | tdmbw-392501 |
| title | Surfing the Parallel Architectures |
| author | Peter S. Kastner, Vice President, Aberdeen Group |
| date | September 27, 1994 |
| type | employer-record |
| subject_domain | parallel-computing; SMP; MPP; clustering; NUMA; enterprise-servers; data-warehousing; RDBMS |
| methodology | analyst-presentation; market-sizing; competitive-analysis; technology-assessment |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Presentation by Peter S. Kastner (Aberdeen Group VP) to Tandem Computers' Board of Directors and Industry Advisory Panel on September 27, 1994. Covers parallel computing architectures (uniprocessor, SMP, cluster, MPP), market share estimates, parallel software including RDBMS, and Aberdeen's strategic assessment of Tandem's position. Key data: uniprocessor 72% market share; SMP 22%; clusters and MPP 5% and 1%. Aberdeen conclusion: MPP will remain a sideshow to SMP and cluster markets. Identifies data warehousing as Tandem's best near-term opportunity. Assesses IBM, HP, DEC, Unisys, Compaq, AT&T as competitors. SAP needs 300 SQL statements/second today, 3,000/second in two years. Aberdeen projects 3x-5x information demand increase by late 1990s.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | high | Board-level strategic briefing to Tandem by Aberdeen VP Kastner; rare primary document showing Aberdeen's market framework and forecasts in 1994; rich competitive assessments of all major parallel computing vendors. |
| **Relevance** | high | Direct employer-record; Kastner presenting as Aberdeen VP; comprehensive market analysis with quantified market share data and vendor-by-vendor competitive assessments. |
| **Prescience** | high | MPP as sideshow prediction largely correct (Teradata exception noted). Tandem data warehousing opportunity correct. Compaq P6-based SMP beating IBM mainframe OLTP — broadly accurate by 1996. DEC negative long-term — acquired by Compaq 1998. IBM SP2 'all talk' assessment — SP2 took years to gain commercial traction. SAP SQL demand forecast roughly accurate. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (24)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | [DEFERRED] |  |
| Tandem Computers | company | [DEFERRED] | Compaq |
| IBM | company | [DEFERRED] |  |
| Hewlett-Packard (HP) | company | [DEFERRED] |  |
| Digital Equipment Corporation (DEC) | company | [DEFERRED] | Compaq |
| Unisys | company | [DEFERRED] |  |
| Compaq | company | [DEFERRED] | Hewlett-Packard |
| AT&T (AT&T Global Information Solutions) | company | [DEFERRED] |  |
| Oracle | company | [DEFERRED] |  |
| Sybase | company | [DEFERRED] |  |
| Informix Software | company | [DEFERRED] |  |
| SAP | company | [DEFERRED] |  |
| Sequent Computer Systems | company | [DEFERRED] |  |
| Teradata (NCR Teradata) | company | [DEFERRED] | Teradata Corporation |
| nCube | company | [DEFERRED] |  |
| Kendall Square Research | company | defunct |  |
| Thinking Machines | company | [DEFERRED] |  |
| Pyramid Technology | company | [DEFERRED] | Siemens Nixdorf |
| Cray Research | company | [DEFERRED] | Silicon Graphics |
| Dow Jones | company | [DEFERRED] |  |
| Prudential Securities | company | [DEFERRED] |  |
| American Express | company | [DEFERRED] |  |
| ICL (International Computers Limited) | company | [DEFERRED] | Fujitsu |

### Technologies Referenced (16)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Symmetric Multiprocessing (SMP) | hardware-architecture | multiple | mature | legacy |
| Server Clustering (Loosely Coupled) | hardware-architecture | multiple | growth | legacy |
| Massively Parallel Processing (MPP/SPP) | hardware-architecture | multiple | emerging | legacy |
| Uniprocessor Servers | hardware-architecture | multiple | dominant | legacy |
| Tandem Himalaya | server-platform | Tandem Computers | current | legacy |
| Tandem Integrity NR/FT | server-platform | Tandem Computers | current | legacy |
| Oracle Parallel Server | database | Oracle | emerging | evolved |
| IBM SP2 (Scalable POWERparallel Systems) | server-platform | IBM | emerging | legacy |
| IBM DB2 | database | IBM | mature | evolved |
| IBM ES/9000 Sysplex | server-platform | IBM | mature | legacy |
| Digital VAXcluster | server-platform | Digital Equipment Corporation | mature | legacy |
| Intel P6 (Pentium Pro) | processor | Intel | emerging | legacy |
| Windows NT Server | operating-system | Microsoft | emerging | legacy |
| Data Warehousing / Complex DSS | workload-type | multiple | emerging | evolved |
| Distributed Object Computing / DCE | framework | multiple | emerging | evolved |
| SGI/MIPS Microprocessor | processor | Silicon Graphics/MIPS | mature | legacy |

### Observation Summary

- Total observations: 30
- By type: competitive-assessment: 8, market-share: 4, demand-forecast: 2, strategic-recommendation: 2, technology-assessment: 1, definition: 1, demand-data: 1, technology-trend: 1, pricing: 1, technology-forecast: 1, market-position: 1, technology-risk: 1, market-assessment: 1, market-momentum: 1, market-application: 1, market-prediction: 1, company-status: 1, strategic-assessment: 1
