# Aligning IT to Business Processes: How BPM is Complementing ERP and Custom Applications

> Archived from: source/_raw_text.txt
> Original publication date: 2007-05
> Author: Aberdeen Group

---

## Original Document Text

                                       Aligning IT to Business Processes




  Aligning IT to Business Processes: How
      BPM is Complementing ERP and
            Custom Applications
    Implementing BPM now to ensure your ROI



                           May 2007




                      ~ Underwritten, in Part, by ~




All print and electronic rights are the property of Aberdeen Group © 2007.
                                                         Aberdeen Group • i
                                                           Aligning IT to Business Processes



                           Executive Summary



T
       he need to support new, agile business processes is the top pressure driving
       enterprise organizations, according to the latest results from Aberdeen’s Business
       Process Management Benchmark. The overwhelming concern from line of business
       executives and top management surrounds the lack of ROI in their ERP
investments. Over half of the respondents (51%) – mostly from small and mid-size
organizations ─ say their companies’ ERP systems or best-of-breed supply chain
solutions don’t provide adequate functionality! Some application software,
particularly custom applications common in the supply chain, retail areas, and on shop
floors are not designed to adapt or react to the rapid business process change and
distributed enterprise models on which enterprises operate today.
An overwhelming majority of organizations represented in the survey feel constrained in
their applications’ ability to meet business requirements. Here’s what they say about
their current application portfolios:
   • Only 15% believe their applications afford them the desired flexibility they
     need today.
   • Over 51% say they employ manual processes to get the job done, driving up
     G&A costs, delaying decisions, and impacting productivity.
   • Thirteen percent (13%) believe their applications offer little or no flexibility
     in meeting individual customer service requirements, and 21%, say their
     applications force them to limit service offerings.
As a result, more than 50% of those surveyed are turning to business process
management (BPM) in 2007 to help get the process right at the line-of-
business level. This move serves to blend and extend the value of the IT investments
already made (e.g. ERP). SOA technology and web services is the glue that 67%%
indicate they will use to tie BPM to ERP and other enterprise applications.”
Key Business Value Findings
   • There is a wider interest in BPM and
                                                       “Replacing our green-screen applications
     business intelligence tools than in SOA
     middleware software, especially in larger         with user-driven BPM front ends is
     companies.                                        something we should have done years
                                                       ago. It really works well for the business
   • More than two-thirds of supply chain-
                                                       and for IT.”
     intensive    industries,  such     as
     manufacturing, say their ERP systems
                                                                    ~ Retail company executive
     impede visibility since they require
     customized workarounds.
   • When IT does not align with business applications, users resort to labor-
     consuming spreadsheets and manual processes, visibly raising the cost of goods
     sold and inherently lowering productivity due to non-strategic work.




                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                        Aberdeen Group • iii
                                                           Aligning IT to Business Processes


Implications & Analysis
  • Large organizations are 50% more likely to have invested in BPM tools and
    strategies over small and mid-size enterprises.
  • Mid-size organizations are more likely than small and large companies to cite
    organizational and technical impediments to progress.
  • Most supply chain-intensive industries such as manufacturing, retail, and
    distribution/logistics say their ERP or best-of-breed supply chain solutions don’t
    provide the functionality they want and need.
  • Best in Class organizations are far ahead of Industry Average and Laggard
    companies in adaptability of applications and ROI from their SOA investments.

Required Actions
  • Best in Class companies have the most experience with SOA and should rely on
    it to drive higher ROI from their investments in BPM, especially in process
    transformation projects that harness BPM, SOA, and other technologies (e.g.,
    mobile devices) to capture and manage cost-critical processes unique to the
    business, and in driving lower application lifecycle costs.
  • Industry Average organizations must focus on modernizing their application
    approaches to business process management, eschewing legacy mainframe
    applications (37% report still having mission critical apps on this platform) in favor
    of composite (e.g. ERP) or best-of-breed tools, with a special focus on PC- or
    browser-based user interfaces.
  • Laggard companies must investigate means to improve their business processes.
    First, they must have the right ERP or custom application instead of wasting IT to
    make the wrong application work the way the business needs it to work. They
    need to investigate and deploy BPM technologies which enable process discovery.
    Get outside consulting expertise to discover the potential of SOA and manually
    mapping your business processes would be a good start of a long-term plan to
    integrate BPM with back-end applications.




               All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • iv
                                                                                            Aligning IT to Business Processes




                                                Table of Contents
Aligning IT to Business Processes: How BPM is Complementing ERP and Custom Applications                                         i
Executive Summary ......................................................................................................iii
Key Business Value Findings.......................................................................................iii
Implications & Analysis ................................................................................................iv
Required Actions ..........................................................................................................iv
Chapter One: Benchmarking the Best in Class........................................................ 1
The Constraints of Older Applications ................................................................... 2
The Year of BPM and SOA Technology Marriage ................................................ 4
Chapter Two: Key Business Value Findings .............................................................. 6
BPM Technologies Lead the Way............................................................................. 7
Roadblocks to Process Improvement...................................................................... 8
Payback is Starting to Ramp ....................................................................................... 9
Chapter Three: Implications & Analysis.................................................................. 11
Process and Organization ......................................................................................... 12
Kinks in the SOA Supply Chain............................................................................... 12
Large Companies Show the Way in Technology Investments......................... 13
Organizational Impediments .................................................................................... 13
Chapter Four: Recommendations for Action......................................................... 15
Best in Class Next Steps........................................................................................... 15
Industry Average Steps to Success ......................................................................... 15
Laggard Steps to Success .......................................................................................... 16
Appendix A: Research Methodology........................................................................ 20
Appendix B: Related Aberdeen Research & Tools............................................... 22




                         All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                    Aberdeen Group
                                                                                                      Aligning IT to Business Processes



                                                    Figures
Figure 1: Top Pressures Driving Service-Oriented Architectures.................... 2
Figure 2: Ability of Software Applications to Meet Business Requirements .. 3
Figure 3: Importance of IT Capabilities in Critical Business Process Performance 7
Figure 4: Infrastructure Middleware Tools Drawing Investment ...................... 7
Figure 5: Challenges with Applications for Key Business Processes ................ 9
Figure 6: Challenges in Starting or Implementing BPM/SOA............................ 10
Figure 7: Factors Resulting in Data Management Complexity ......................... 10



                                                      Tables
Table 1: Prioritized Pressures and Enablers ........................................................... 8
Table 4: PACE Framework....................................................................................... 21
Table 5: Relationship between PACE and Competitive Framework ............. 21




                            All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                       Aberdeen Group
                                                                          Aligning IT to Business Processes

                                  Chapter One:
                           Benchmarking the Best in Class

                • Companies are discovering how BPM, combined with SOA, is helping provide the
Key Takeaways


                  flexibility and process control needed in business today.
                • ERP systems don’t provide adequate functionality and are driving companies to integrate
                  costly workarounds to support business.
                • An overwhelming majority of organizations surveyed feel constrained in their
                  applications’ ability to meet customers’ individual business requirements.




A
        s corporations face the pressures of global supply chains, shrinking profit
        margins, and the need to deliver tailored solutions and consistent service to
        customers, they need technology infrastructures that are more flexible and
        provide end-to-end process control. That’s why these corporations are
investing heavily in IT infrastructure middleware to link their fragmented infrastructures
and applications of the past in order to improve the business processes they need to
meet the pressures of the present.
Aberdeen research has found that business process management (BPM) and
service-oriented architecture (SOA) are key infrastructure areas that can improve
business processes by allowing a company to become more agile, decentralize critical
decision making, boost management visibility, and reduce costs.
.The following table reflects Aberdeen’s classification of companies that are meeting the
challenges head-on of supporting speed and agility through the use of technology
enablers and process improvements (Table 1).

Table 1: Best in Class PACE Framework

        Pressures              Actions               Capabilities                         Enablers
       • The need to         • Improve line of     • Providing one common view of        • Standalone BPM suite plus
         support new,          business chain        data and information for              SOA
         agile business        agility               enterprise users and partners       • BPM from SOA
         processes           • Improve speed of • User capability to configure             middleware vendor
                               IT                 process workflows that meet            • BPM from ERP vendor
                               implementations    unique requirements
                                                                                       • Realtime Business Process
                             • Give line of        • Access to applications that offer   Monitoring
                               business greater      a wider range of functions or
                                                                                       • Business activity
                               direct control        features than we know have
                                                                                         monitoring
                               over their IT       • Use applications that are more
                                                                                       • Business Process
                                                     intuitive and easier to learn
                                                                                         Monitoring
                                                   • Better integration with desktop
                                                     applications




                           All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                   Aberdeen Group • 1
                                                                            Aligning IT to Business Processes

The need to support new, agile business processes is the chief pressure driving
organizations to start or implement an SOA-based system (Figure 1)

Figure 1: Top Pressures Driving Service-Oriented Architectures


       The need to support new, agile business processes                                           62%


         Current ERP system or best-of-breed supply chain
           solution does not provide desired functionality                             44%



           Lower cost integration and application upgrades                             43%


  There are critical user functions stored in legacy systems
  and composite applications are able to provide workflows                       34%
      that span legacy and ERP/supply chain systems


                                                               0%   10% 20% 30% 40% 50% 60% 70%

                                                                          Source: Aberdeen Group, May 2007

Tthe second pressure from nearly half of the respondents - mostly small and mid-size
organizations - say their companies’ ERP systems or best-of-breed supply chain
solutions don’t provide adequate functionality. Some application software,
particularly custom applications common in the supply chain, retail areas, and on the
manufacturing shop floor are not designed to handle the rapid business process change
and distributed enterprise models on which businesses operate today. This inability of
large expensive IT investments, such as ERP, to get real-time visibility down into
the factory floor is handicapping enterprises from being able to move as the
market shifts and demand changes.
The Constraints of Older Applications
An overwhelming majority of organizations represented in the Aberdeen survey feel
constrained in their applications’ ability to meet customers’ individual business
requirements (Figure 2).




                     All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                             Aberdeen Group • 2
                                                         Aligning IT to Business Processes




Figure 2: Ability of Software Applications to Meet Business Requirements


                                              My software applications
                                              allow me to quickly adapt
                                              to most customer
                                              requirements.
                13%
                            15%               My software applications
                                              force me to put limits on
                                              services I can offer.


                                              My software applications
                                              force me to employ some
                                21%           manual processes to
                                              meet customer
                                              requirements.
             51%
                                              My software applications
                                              offer little or no flexibility to
                                              meet individual customer
                                              service requirements.




Based on the Maturity Class Framework, Aberdeen established Best-in-Class
characteristics in four key categories: (1) process; (2) organization; (3)
performance management; and (4) technology.




             All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                     Aberdeen Group • 3
                                                                Aligning IT to Business Processes

Table 2: Competitive Framework

                                                    Best in      Industry
                        Characteristics                                           Laggard
                                                     class       average

                   Ability to integrate into any
Process            system possessing critical        70%           69%              51%
                   data or information

                   IT organization has or will
Organization       be using SOA or web
                   services to improve               67%           54%              55%
                   business processes
Performance
Measurement        Satisfaction of BPM tools         17%           6%               3%

                   SOA projects underway              54%           33%              32%
                   Standalone BPM suite with
Technology                                           66%            25%              50%
                   no SOA
                   BPM suite with SOA (plan
                                                     67%            25%              50%
                   to use)

The Year of BPM and SOA Technology Marriage
Aberdeen’s prior research indicated that 41% of all companies were to at least have
SOA strategies in place by the end of 2006, if they had not implemented them already.
The main factors driving the implementations were:
   •      A desire for new capabilities like cross-application process integration;
   •      Re-use of applications via web services; and
   •      Better management of IT complexity.
The 51% of companies whose applications force them to resort to manual processes to
meet customer requirements would be best served looking for vendors to provide
composite applications that tie together point solutions to enable a flexible industry-
or company-specific business process (One example: an integrated business planning
solution that can enable the balancing of supply and demand to maximize profit by
bridging sales and operations forecasting tools, constraint-based supply chain
applications, and financial systems) or in the case of small-to-medium size businesses
(SMB) to utilize vendors who can extend their existing core investments in office
tools, communication and document management systems.
Leading companies are looking to leverage BPM tools to build out front-end applications
that should be:
   •      Flexible from an end-user perspective;
   •      Equipped with a rich user interface that promotes productivity;
   •      Able to map well to line-of-business process requirements;
   •      Capable of integrating with their investments in back-end ERP and best-of-breed
          business process solutions.



                  All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                          Aberdeen Group • 4
                                                        Aligning IT to Business Processes

Over an application’s lifecycle, BPM can deliver dramatically lower software
maintenance costs due to the ease with which business units can change the process
and key process parameters without massive IT reprogramming and testing.
According to the 2007 Aberdeen Benchmark Report results, 2007 is shaping up
to be the year of BPM.




               All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 5
                                                                            Aligning IT to Business Processes

                                       Chapter Two:
                                Key Business Value Findings

                  • When IT does not align with business applications, users resort to labor-consuming
Key Takeaways


                    spreadsheets and manual processes, invisibly raising the cost of goods sold.
                  • There is a wider interest in BPM and business intelligence tools than in SOA middleware
                    software, Enterprise Application Integration (EAI) and Master Data Management (MDM).
                  • More than two-thirds of supply chain-intensive industries, such as manufacturing, say
                    their ERP systems impede better visibility since they require customized workarounds.



A
       fter seeing several years of a recession-fueled lockdown in technology
       investment, Aberdeen is witnessing a renaissance in IT spending around core
       infrastructure middleware. From our 2006 and 2007 research, the key drivers
       for these investments - especially SOA and BPM - are that the underlying
technologies must deliver prompt and demonstrable business value, can be developed in
controllable projects, and will incrementally lower long-term maintenance costs.
That’s why we’re witnessing the following, taken from our research for this report:
                • 38% of companies surveyed have current SOA projects, another 29% say their IT
                  organizations are planning to start at least one project within the next 12 months.
                • 41% have SOA-based solutions already in place, with another 27% budgeted to
                  start building them within the next 12 months.
                • 63% believe it’s very important that their technologies, such as BPM, be able to
                  integrate into any system that provides critical data or information, which is what
                  an SOA can deliver (Figure 3).
But our survey also found that change comes
slowly. Some 63% of surveyed companies use
spreadsheets and 37% use legacy mainframe                              Change comes slowly. Two-
applications to manage critical business process                       thirds of surveyed companies
functions. This is a clear reflection of the half of                   use spreadsheets and 37% use
the companies in the survey whose software
                                                                       legacy mainframe applications
applications force them to employ manual
processes to meet customer requirements.                               to manage critical business
                                                                       process functions.
However, 54% of Best in Class companies
Aberdeen surveyed recognize this and are
investing in technologies that can improve
nimble processes.




                             All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                     Aberdeen Group • 6
                                                                                Aligning IT to Business Processes

Figure 3: Importance of IT Capabilities in Critical Business Process
Performance


 Providing common view of
  data and information for
   enterprise users and                     32%                                66%
          partners


Ability to integrate into any
system with critical data or                  31%                               63%
         information



    Access to applications
    offering wider range of                                63%                              30%
    functions and features



                            0%               20%            40%           60%             80%        100%

                                Not Important      Somewhat Important    Very Important


                                                                               Source: Aberdeen Group, May 2007


BPM Technologies Lead the Way
Figure 4 shows the infrastructure middleware technologies in which the surveyed
companies are investing. There is an overwhelming preference for BPM technologies to
create and monitor business workflows, followed by the chief tools that assist with IT
integration: ESB, SOA middleware, and enterprise application integration (EAI).

Figure 4: Infrastructure Middleware Tools Drawing Investment

  60%             57%                    55%
  50%                                                         45%               45%
  40%

  30%                                                                                              25%
  20%
  10%
   0%
            Business process    Business intelligence or   ESB and SOA           EAI               MDM
            management (BPM)    business performance
                  tools         management/monitoring
                                        tools



                                                                         Source: Aberdeen Group, December 2006

Table 1 shows how these technologies map to the pressures driving SOA that were
listed in Chapter One. These findings highlight issues cited in the Aberdeen Composite
Applications Benchmark report:



                     All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                             Aberdeen Group • 7
                                                                 Aligning IT to Business Processes

    •    The biggest challenge in corporate IT organizations is improving real-time
         visibility into business operations;
    •    Business is discovering the SOA as a technological foundation that can make
         businesses more nimble and business processes more flexible with minimal IT
         intervention; and
    •    Sharing information with other parts of the organization, a key by-product of
         better business process management, is more reachable.

Table 1: Prioritized Pressures and Enablers

Priorities   Prioritized Pressures                  Prioritized Enablers

     1        The need to support new, agile        Æ Business process management (BPM)
              business processes                        tools for creating business
                                                        workflows
                                                    Æ Business intelligence or business
                                                        performance
                                                        management/monitoring tools

     2        Current ERP systems or supply         Æ BPM front-end to ERP or back-end
              chain best-of-breed solutions do          apps
              not provide the desired
              functionality.                        Æ Enterprise service bus (ESB) and
                                                        SOA middleware software with
                                                        composite applications
                                                    Æ Enterprise application integration
                                                        (EAI) middleware software

     3        Lower cost integration and            Æ Enterprise service bus (ESB) and
              application upgrades                      SOA middleware software
                                                    Æ Enterprise application integration
                                                        (EAI) middleware software with
                                                        composite applications

     4        There are critical user functions     Æ Composite applications that span at
              stored in legacy systems that users       least some of the following:
              need; composite applications are          spreadsheets, legacy applications,
              able to provide workflows that            ERP, best-of-breed applications,
              span legacy and ERP/supply chain          desktop applications, web-hosted/On
              systems;                                  Demand applications, customers’ or
                                                        suppliers’ applications
                                                               Source: Aberdeen Group, May 2007

Roadblocks to
Process Improvement
Still, improving business process visibility and integration capabilities doesn’t come
without its challenges (Figure 5). Companies surveyed indicate:




                  All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                          Aberdeen Group • 8
                                                                       Aligning IT to Business Processes

   •     ERP systems don’t provide the needed flexibility. Alarmingly, 75% of companies
         that are the biggest users of ERP systems cite this issue. Yet, only 33% of Best
         in Class companies are constrained by their ERP systems;
   •     Key application parameters and rules are locked inside program source code;
   •     A lack of centralized workflows associated with management life-cycles; and
   •     A lack of IT agility that forces interim paper workarounds to change business
         processes, with a resulting increase in labor and loss of management visibility.

Figure 5: Challenges with Applications for Key Business Processes


  ERP systems are unable to do what we want without
                   customization                                                      57%


   Key application parameters and rules are locked in
    program source code, making changes difficult
                                                                                    53%


       Many organizations and systems own workflows
          associated with life-cycle management                                     54%


     Business process changes result in interim paper
             workarounds until IT catches up                                    46%


                                                        0%     20%        40%         60%        80%

                                                               Source: Aberdeen Group, December 2006
Breaking technological and organizational
logjams can go a long way toward
improving business processes to meet                         “Once we realized how much effort was
today’s business demands. These issues                       going into doing things our ERP’s way,
also come up when we asked
                                                             the BPM solution to doing things our
respondents to cite the challenges they
face or will face in implementing an SOA-                    ‘own business’ way became obvious.”
based system (Figure 6), as well as the
                                                                     ~ Insurance company executive
factors that result in data management
complexity (Figure 7).

Payback is Starting to Ramp
These challenges may be preventing companies from realizing the full potential return
on investment (ROI) from SOA and BPM. Of course, these solutions are relatively new
on the IT scene and require much effort and a steep learning curve. For instance, only
19% of companies represented in Aberdeen’s Composite Applications Benchmark report
have had SOA-based solutions in place for more than a year, while another 22% were
implemented only within the last 12 months.
Already companies have shown an average return of about 9% based on an average
investment in SOA at around $730,000 while the mean payback to date is $798,000.


                   All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                           Aberdeen Group • 9
                                                                  Aligning IT to Business Processes

Figure 6: Challenges in Starting or Implementing BPM/SOA



                   Limited in-house IT skills                                          51%



  Limited vision/support or understanding
                                                                                       50%
    from the business side or leadership



       Data resides in too many places to
                                                                                 42%
              consolidate rapidly


                                                0%   10%    20%    30%     40%     50%    60%

                                                       Source: Aberdeen Group, December 2007

Figure 7: Factors Resulting in Data Management Complexity


     Proliferation of
   application-specific                                                           67%
       databases

    Interspersed data
      and business                                                               66%
        processes

   Legacy systems
    have inflexible,                                                       59%
  obsolete databases

                          0%         20%              40%                60%              80%


                                                       Source: Aberdeen Group, December 2006
When we separated the Best in Class
organizations from the rest of the survey
pool, the Best in Class are recouping                 “We missed some long-term recurring
averaging a return of more than twice                 cost savings in software maintenance by
their investment, while Industry Average              trying to get by with old development
and Laggard companies - have yet to                   tools.”
recover all they have invested. In spite of
these work-in-progress ROI results,                        ~ Petrochemical company executive
companies are continuing to invest
aggressively in these technologies.




                 All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                        Aberdeen Group • 10
                                                                                    Aligning IT to Business Processes

                                               Chapter Three:
                                          Implications & Analysis

                    •     Best in Class organizations are far ahead of Industry Average and Laggard companies
                          in their adaptability of applications and in their ROI from BPM and SOA investments.
Key Takeaways




                    •     Most supply chain-intensive industries such as manufacturing, retail, and
                          distribution/logistics say their ERP or best-of-breed supply chain solutions don’t provide
                          the functionality they want and need.
                    •     Large organizations are twice as likely to invest in data quality tools as small and mid-
                          size enterprises are.
                    •     Mid-size organizations are more likely than small and large companies to cite
                          organizational and technical impediments to progress.




H
         ow can an organization succeed in improving business processes? According to
         our survey results, success begins with knowledge and extends into
         implementation of BPM, SOA and master data management (MDM) tools. Table
         2 shows Aberdeen’s Competitive Framework for this report to distinguish
leading, or Best in Class, companies, from Industry Average and Laggard organizations.
We determined that:
                •       Best in Class organizations have
                        software applications that can allow                 Competitive Framework Key
                        them to adapt quickly to most                 The Aberdeen Competitive Framework
                        customer requirements                         defines enterprises as falling into one of the
                •       Industry Average companies have               three following levels of practices and
                        applications that force the use of            performance:
                        some manual processes to meet                 Best in Class (20%) —practices that are the
                        requirements.                                 best currently being employed and
                                                                      significantly superior to the industry average
                •       Laggard organizations find that
                        their applications offer little or no         Industry Average (50%) —practices that
                        flexibility  to    meet      individual       represent the average or norm
                        customer requirements or force the            Laggards (30%) —practices that are
                        organization to limit the services it         significantly behind the industry average
                        can offer.
Best in Class organizations are more likely to be aware of SOA, due largely to the
knowledge levels of their IT organizations and the support and commitment from the
business side or executive leadership. In short, these organizations are committed to
SOA as their platforms of the future. They are also the least likely to suffer from snags
in their ERP integration projects.




                                 All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                        Aberdeen Group • 11
                                                              Aligning IT to Business Processes



Process and Organization
Commitment to and interest in SOA and BPM spell the difference between Best in Class
organizations and the rest of the survey pool. Facilitating that is that only 11% of these
companies believe they’re dealing with too much complexity for employees to handle, in
spite of the fact that close to half of them indicate they’re busy with several
technology/business process initiatives.
Further, only 24% of the Best in Class use
legacy mainframe applications to manage
                                                   Commitment to and interest in both
critical business processes, well below the
                                                   SOA and BPM spells the difference
39% of Industry Average. This highlights a
willingness and commitment by the Best in          between Best in Class organizations
Class to use more advanced applications,           and the rest of the survey pool.
such as best of breeds and Web-hosted
and On Demand tools.

Kinks in the SOA Supply Chain
For all the benefits SOA bring, companies that rely heavily on their supply chains
are least likely to use SOA, even though their benefits are more than apparent.
Here are some key survey findings on this group, which made up more than half of the
respondent pool:
   • 63% say the upfront costs for implementing SOA are higher because of a need for
     more design and architecture (56% of the entire survey pool cited this);
   • 63% say they lack the IT governance and process systems to ensure SOA success
     - full survey pool: 43% (Note: see Aberdeen’s Information Governance and Process
     Systems Benchmark Repor for additional informationt);
   • 63% say their current teams can’t adjust to the culture change that’s needed with
     reusable services (full survey pool: 45%); and
   • 58% say piloted projects were very expensive and yielded many lessons to learn.
     This was more than twice the entire survey pool (21%).
Even worse, these technological and organizational limitations may well impact
performance at many of these supply-chain-centric companies. For instance:
   • A whopping 93% cite inconsistency or outdated information in orders sent to
     manufacturers, compared with just 12% cited by the whole survey pool.
   • 69% cite data errors caused by manual updating, which can potentially affect
     purchase orders and inventory.
   • 67% say business process changes result in interim paper workarounds until
     IT catches up. In an age of tighter compliance with Sarbanes-Oxley and other
     business regulations, this finding points up the importance of SOA as a tool that
     can improve IT agility: the ability of IT to keep up with the business.




                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 12
                                                             Aligning IT to Business Processes

Large Companies Show the Way in Technology Investments
Close to three-quarters of large companies (annual revenue of more than $1 billion),
where the processes are more complex, are investing in BPM tools, as well as ESB and
SOA middleware software (Table 3). Most are also investing in EAI tools, and they are
twice as likely to spend on MDM and data quality tools than small and mid-size
organizations.
From these and other findings, it’s clear that larger organizations are showing the way
on these integration catalysts. They are also much more likely to have the right
functionality from their ERP systems and best-of-breed supply chain tools.
Most small and mid-size organizations represented in our survey say their ERP and
supply-chain tools don’t provide the functionality they want. Mid-size companies, in
particular, are unable to adjust to the rapid technology change underfoot, with 43%
citing this as a challenge and, 57% reporting that line-of-business executives’
expectations are too high for IT to meet, .

Table 3: Technology Investments by Organization Size
                                                     Small      Mid-size     Enterprise
 Business process management (BPM) tools for
                                                       55%         52%            76%
 creating business workflows
 Business intelligence or business performance
                                                       55%         48%            48%
 management/monitoring tools
 Enterprise Service Bus (ESB) and SOA
                                                       18%         35%            71%
 middleware software
 Enterprise application integration (EAI)
                                                       27%         35%            57%
 middleware software
 Master data management (MDM) tools                     9%         17%            43%
 Data quality tools                                     9%         17%            33%
 Event management tools                                14%         9%             19%
                                                    Source: Aberdeen Group, December 2006

Organizational Impediments
Many mid-market companies are in a tight spot when it comes to technical, financial, and
human resources, given their size, and that’s reflected in the survey. For instance, they
are more likely than larger or smaller organizations to cite challenges in these areas
(Figures 8 and 9). Companies with these symptoms need to look at personnel issues.




                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 13
                                                                         Aligning IT to Business Processes

Figure 8: Organizational Challenges to SOA Implementations



         60%                       57%
                                                           Small       Mid-Size      Large
         50%
                                            41%
                         38%
         40%
                                                                             31%
         30%
                                                                  19%
         20%
                                                                                     12%
         10%

          0%
                    Current IT team is unable to             Piloted projects were very
                    adjust to culture change of            expensive with lots of lessons
                     needed reusable services                          learned

                                                                Source: Aberdeen Group, December 2006

Figure 9: Application Challenges to Business Process Improvements

                                                                                               Large
Inconsistent or outdated information within orders that    5%
                                                                                               Mid-Size
                                                                       20%
              are sent to manufacturers                          12%                           Small


                                                                                    37%
                       Errors due to manual updating                                            57%
                                                                              30%


    Business process changes result in interim paper                                  41%
                                                                                             54%
            workarounds until IT catches up                                           42%


 Workflows associated with management of life-cycles                                               61%
                                                                                                      66%
  are owned by multiple organizations and systems                              33%


                                                      0%   10% 20% 30% 40% 50% 60% 70%

                                                                Source: Aberdeen Group, December 2006

Management alignment is another issue worth underlining. More than half the
companies using BPM report limited vision/support or understanding from
the business side and/or executive leadership. These companies go even further,
saying “We have realized that it requires not only buy-in but also strong commitment
from lines of business execs, not just IT.” Because BPM projects require active
participation during the development phase by the lines of business, plus ownership of
BPM changes once the system is in place, IT needs to negotiate appropriate expectation
levels with the business units before commencing initial BPM projects.




                   All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                          Aberdeen Group • 14
                                                                           Aligning IT to Business Processes

                                     Chapter Four:
                               Recommendations for Action

                 •   Best in Class companies have the most experience with SOA, and they should rely on it
                     to drive higher ROI from their investments in SOA and BPM.
Key Takeaways




                 •   Industry Average organizations must focus on modernizing their application approaches
                     to BPM, eschewing pure legacy mainframe applications in favor of composite or best-
                     of-breed tools.
                 •   Laggard companies must invest in more technology to improve BPM. Discovering the
                     potential of SOA by using external expertise would be a good start.


Best in Class Next Steps
                1) Drive more ROI from your SOA investments. Better returns come with maturity. As
                   your organization gains more experience with SOA, it will find ways to generate
                   higher returns on its investments. Look to consolidating services under SOA to
                   create a common back end to BPM-driven front-end applications.
                2) Make SOA better for the user. Improving the user experience is - or should be -
                   the top mission of any corporate IT organization. Utilize the superior SOA
                   knowledge within the IT staff to help the user - especially those in customer-
                   facing roles - become more productive. BPM and composite application
                   development tools can improve the usability and productivity of legacy
                   applications vastly.
                3) Focus on application life-cycle management costs. BPM and SOA are no longer two
                   distinct technologies that IT must integrate into custom solutions. Technology
                   suppliers are doing the integration, delivering products that start with BPM and
                   include the SOA transport and infrastructure, including composite application
                   technology to modernize legacy applications and, for the application providers,
                   SOA-enabled application versions that fit well with BPM.

Industry Average Steps to Success
                1) Get out of the old and into the new. Decrease your dependence on legacy
                   mainframe applications, desktop applications, and spreadsheets as keys to
                   business process improvement and replace them with more BPM-based,
                   composite and best-of-breed applications.
                2) Discover the potential for BPM in your organization. BPM holds the potential to
                   dramatically improve IT agility with rapidly changing line-of-business
                   requirements, and as a tool for critical process transformation.
                3) Is there interest in SOA? All but 5% of Industry Average organizations at least
                   have interest in the potential advantages of an SOA. But more than one-quarter
                   of Industry Average organizations in our survey that haven’t heard about SOA
                   want to know more (Only 36% have SOA solutions in place). The increase in
                   knowledge starts at the top; 61% of Industry Average companies cite limited
                   vision, support, or understanding of SOA from the business side or executive



                            All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                   Aberdeen Group • 15
                                                          Aligning IT to Business Processes

      leadership, compared with only 37% of Best in Class companies. There are
      numerous SOA success stories across vertical markets to use as guideposts.

Laggard Steps to Success
  1) Make sure you have the right core application software. Trying to make due with
     the wrong software (e.g. ERP)— or a home-grown equivalent — creates a
     perpetual money hole in integration costs. After looking at the real costs of
     running your systems, consider replacing it or using BPM software to deliver a
     business-friendly front end to the transaction engine.
  2) Invest in more modern technology to improve management of critical processes with
     BPM. If you have the financial resources, spend some on best-of-breed or
     composite applications and modernize old legacy mainframe apps, especially the
     user interface, by extending the legacy applications with a BPM front end that
     matches what the business units really need. Pay for the investments in
     measurable productivity improvements just on reduced keystrokes and screen
     changes alone.
  3) Discover the potential of SOA. Chances are if you haven’t embarked on or are
     planning an SOA project, there is interest in the organization. If so, ramp up the
     internal knowledge on SOA and learn what an ESB and SOA middleware
     software can do to help improve business processes.
  4) Extend your already existing investments. The investment in office tools,
     communication systems, document management and knowledge managements
     systems exists. Implement your BPM tool strategy into these already existing
     applications and leverage your employee knowledge base.




              All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                     Aberdeen Group • 16
                                                             Aligning IT to Business Processes

                         Featured Underwriters
This research report was made possible, in part, with the financial support of our under-
writers. These individuals and organizations share Aberdeen’s vision of bringing fact
based research to corporations worldwide at little or no cost. Underwriters have no
editorial or research rights and the facts and analysis of this report remain an exclusive
production and product of Aberdeen Group.




                                                Appian is a leading provider of
business process management (BPM) technology that helps organizations design,
manage, and optimize their business processes. Appian Enterprise has revolutionized
process design with a modeling environment that is simple enough for business users
yet powerful enough for IT. Appian is the first BPM vendor to combine collaboration
and content management with process to create best practice business processes.
Appian's patent-pending Active Optimization Technology, which analyzes the in-flight
process data stream, not just stored data, helps companies stay ahead of the
competition.
For additional information on Appian Corporation:
8000 Towers Crescent Drive, 16th Floor Vienna, VA 22182
703-442-8844 or info@appian.com
www.appian,com




                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 17
                                                           Aligning IT to Business Processes




                                             CTSpace is a leading software-as-a-service
                                             provider     of     enterprise    content
                                             collaboration and business process
                                             management solutions. The Company
                                             maintains its corporate headquarters in
San Francisco and has offices in the UK, Germany, France, Austria and India. CTSpace
provides corporations with SaaS applications that manage communication and
information across projects. Key customers include GE, Shell Oil, Duke Energy, London
Underground, IKEA and BNP Paribas among others.
For additional information on CTSpace:
49 Stevenson, Suite 950 San Francisco, CA 94105
415-882-1888 or hkoenig@ctspace.com
www.ctspace.com




               All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                      Aberdeen Group • 18
                                                            Aligning IT to Business Processes




                                         Ramco is a global provider of software and
                                         services that create agile global-class business
                                         applications for a variety of enterprises.
                                         Ramco’s Business Process Delivery System
                                         (BPDS) enables fast, flexible deployment and
                                         change on demand of processes and
                                         applications for maximum flexibility – so when
your business changes your system changes too. The Ramco BPDS combines best in
class BPM capabilities with an integrated services environment and a repository of over
1,200 pre-built services for true end-to-end SOA based application development.
Ramco Systems has offices in nine countries and customers in 1,000 locations
worldwide across multiple verticals.
For additional information on Ramco Systems:
3150 Brunswick Pike, Lawrenceville, NJ 08648
609-620-4800 or info@rsc.ramco.com
www.ramco.com




                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 19
                                                            Aligning IT to Business Processes

                             Appendix A:
                        Research Methodology



O
         ver the last year, Aberdeen Group examined the technology use, investment
         plans, pressures, and challenges of more than 125 enterprises in such
         middleware solutions as Business Process Management (BPM) and Service-
         Oriented Architecture (SOA) as integration catalysts that can potentially
improve their business processes.
Responding executives and managers completed an online survey that included
questions designed to determine the following:
   •   The factors pushing companies to initiate or implement an SOA-based system;
   •   The challenges companies face in initiating or implementing an SOA;
   •   The amount of organizational investment in SOA and BPM and the payback from
       investments;
   •   The degree of importance organizations place on a set of technological
       capabilities that can impact the performance of critical business processes; and
   •   The degree of satisfaction with their investments in SOA and BPM solutions.
Aberdeen supplemented this online survey effort with telephone interviews with select
survey respondents, gathering additional information on middleware strategies,
experiences, and results.
The study aimed to identify emerging best practices for the use of these middleware
tools as integration catalysts in today’s modern IT infrastructures and provide a
framework by which readers could assess their own capabilities in these areas.
Responding enterprises included the following:
   •   Job title/function: The research sample included respondents from the
       following areas of the organization: information technology (53%), business
       process management (10%); other (13%); marketing (6%); sales (5%);
       logistics/supply chain (6%); finance (3%), customer service (2%) and
       manufacturing (1%). Job titles included the following: manager (24%);
       consultant (22%); senior management, such as CEO or COO (18%); staff (11%);
       director (11%); CIO (6%); vice president (6%); other (3%) and CFO (1%).
   •   Industry: The research sample included respondents predominantly from
       manufacturing and services industries, led by the following: finance, banking, and
       accounting (18%); high technology/software (14%); insurance, real estate, legal
       services (8%); transportation/logistics (8%); public sector (4%); publishing and
       media (4%); retail (4%); aerospace/defense (3%); apparel (3%); automotive (4%);
       education (3%); health, medical, and dental services (4%); and utilities
       (3%).Other responding sectors included computer equipment and peripherals;
       construction/engineering; consumer electronics, consumer packaged goods;
       food and beverage; medical devices; metals and metal products; mining/oil/gas;
       paper, lumber, and timber; pharmaceutical manufacturing, telecommunications
       services, and wholesale. The survey was supplemented with responses to a


                All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                       Aberdeen Group • 20
                                                                          Aligning IT to Business Processes

         select group of supply-chain companies in the discrete manufacturing, process
         manufacturing, distribution, and retail industries.
    •    Geography: About 45% of all study respondents were from North America
         (US, Canada, Mexico); 28% were from Europe; 20% from Asia/Pacific; 5% from
         the Middle East and Africa; and 3% from South America and the Caribbean.
    •    Company size: About 32% of respondents were from large enterprises (annual
         revenues above US$1 billion); 31% were from mid-size enterprises (annual
         revenues between $50 million and $1 billion); and 37% from small businesses
         ($50 million or less).
Solution providers recognized as sponsors of this report were solicited after the fact
and had no substantive influence on the direction of this benchmark report. Their
sponsorship has made it possible for Aberdeen Group to make these findings available
to readers at no charge.

 Table 4: PACE Framework

PACE Key
Aberdeen applies a methodology to benchmark research that evaluates the business pressures, actions,
capabilities, and enablers (PACE) that indicate corporate behavior in specific business processes. These
terms are defined as follows:
Pressures — external forces that impact an organization’s market position, competitiveness, or business
operations (e.g., economic, political and regulatory, technology, changing customer preferences,
competitive)
Actions — the strategic approaches that an organization takes in response to industry pressures (e.g., align
the corporate business model to leverage industry opportunities, such as product/service strategy, target
markets, financial strategy, go-to-market, and sales strategy)
Capabilities — the business process competencies required to execute corporate strategy (e.g., skilled
people, brand, market positioning, viable products/services, ecosystem partners, financing)
Enablers — the key functionality of technology solutions required to support the organization’s enabling
business practices (e.g., development platform, applications, network connectivity, user interface, training
and support, partner interfaces, data cleansing, and management)
                                                                            Source: Aberdeen Group, 2007

 Table 5: Relationship between PACE and Competitive Framework

PACE and Competitive Framework How They Interact
Aberdeen research indicates that companies that identify the most impactful pressures and take the most
transformational and effective actions are most likely to achieve superior performance. The level of
competitive performance that a company achieves is strongly determined by the PACE choices that they
make and how well they execute.
                                                                            Source: Aberdeen Group, 2007




                    All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                           Aberdeen Group • 21
                                                                        Aligning IT to Business Processes

                      Appendix B:
           Related Aberdeen Research & Tools

Related Aberdeen research that forms a companion or reference to this
report include:
     •      The Composite Applications Benchmark Report, December 2006
     •   The Legacy Application Modernization Benchmark Report; September
     2006
     •      2007 Aberdeen Benchmark Report, April 2007
     •      The Business Process Management Benchmark Report; August 2006
     •   Outsourcing Application Development and Maintenance; November
     2006
     •      Enterprise Service Bus and SOA Middleware; June 2006
     •      Achieving More Value from Enterprise Applications, May 2006
     •      The SOA in IT Benchmark Report; December 2005
Information on these and any other Aberdeen publications can be found at
www.Aberdeen.com.




      Author: Ralph A. Rodriguez, Senior VP & Research Director of Technology Markets,
      Ralph.rodriguez@aberdeen.com
Founded in 1988, Aberdeen Group is the technology- driven research destination of choice for the global business
executive. Aberdeen Group has over 100,000 research members in over 36 countries around the world that both
participate in and direct the most comprehensive technology-driven value chain research in the market. Through its
continued fact-based research, benchmarking, and actionable analysis, Aberdeen Group offers global business and
technology executives a unique mix of actionable research, KPIs, tools, and services.
This document is the result of research performed by Aberdeen Group. Aberdeen Group believes its findings are
objective and represent the best analysis available at the time of publication. Unless otherwise noted, the entire
contents of this publication are copyrighted by Aberdeen Group, Inc. and may not be reproduced, stored in a retrieval
system, or transmitted in any form or by any means without prior written consent by Aberdeen Group, Inc.




22
  THIS DOCUMENT IS FOR ELECTRONIC DELIVERY ONLY
                      The following acts are strictly prohibited:
                             • Reproduction for Sale
                             • Transmittal via the Internet
                     Copyright © 2007 Aberdeen Group, Inc. Boston, Massachusetts



Terms and Conditions
Upon receipt of this electronic report, it is understood that the user will and must fully comply with the
terms of purchase as stipulated in the Purchase Agreement signed by the user or by an authorized
representative of the user’s organization. Aberdeen has granted this client permission to post this report
on its Web site.

This publication is protected by United States copyright laws and international treaties. Unless otherwise
noted in the Purchase Agreement, the entire contents of this publication are copyrighted by Aberdeen
Group, Inc., and may not be reproduced, stored in another retrieval system, or transmitted in any form or
by any means without prior written consent of the publisher. Unauthorized reproduction or distribution of
this publication, or any portion of it, may result in severe civil and criminal penalties, and will be
prosecuted to the maximum extent necessary to protect the rights of the publisher.

The trademarks and registered trademarks of the corporations mentioned in this publication are the
property of their respective holders.

All information contained in this report is current as of publication date. Information contained in this
publication has been obtained from sources Aberdeen believes to be reliable, but is not warranted by the
publisher. Opinions reflect judgment at the time of publication and are subject to change without notice.


Usage Tips
Report viewing in this PDF format offers several benefits:
        • Table of Contents: A dynamic Table of Contents (TOC) helps you navigate through the
            report. Simply select “Show Bookmarks” from the “Windows” menu, or click on the bookmark
            icon (fourth icon from the left on the standard toolbar) to access this feature. The TOC is both
            expandable and collapsible; simply click on the plus sign to the left of the chapter titles listed
            in the TOC. This feature enables you to change your view of the TOC, depending on whether
            you would rather see an overview of the report or focus on any given chapter in greater
            depth.
        • Scroll Bar: Another online navigation feature can be accessed from the scroll bar to the right
            of your document window. By dragging the scroll bar, you can easily navigate through the
            entire document page by page. If you continue to press the mouse button while dragging the
            scroll bar, Acrobat Reader will list each page number as you scroll. This feature is helpful if
            you are searching for a specific page reference.
        • Text-Based Searching: The PDF format also offers online text-based searching capabilities.
            This can be a great asset if you are searching for references to a specific type of technology
            or any other elements within the report.
        • Reader Guide: To further explore the benefits of the PDF file format, please consult the
            Reader Guide available from the Help menu.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | bpm-align-business-f76616 |
| title | Aligning IT to Business Processes: How BPM is Complementing ERP and Custom Applications |
| author | Aberdeen Group |
| date | 2007-05 |
| type | employer-record |
| subject_domain | BPM; SOA; ERP integration; application lifecycle management; supply chain |
| methodology | survey; benchmark; n=125+ enterprises; qualitative interviews; Dec 2006 |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

29-page Aberdeen Group benchmark report on BPM adoption, ROI, and ERP integration. Based on survey of 125+ enterprises. 51% of respondents say ERP systems don't provide adequate functionality. Only 15% believe applications afford desired flexibility. Over 50% turning to BPM in 2007. BPM investment leads middleware: 57% investing in BPM tools vs 45% ESB/SOA vs 25% MDM. SOA technology and web services cited by 67% as integration glue between BPM and ERP. Large companies 50% more likely to invest in BPM vs SMEs. Underwriters: Appian, CTSpace, Ramco.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 7 | Captures 2007 BPM adoption wave with quantitative survey data; documents ERP-BPM-SOA integration convergence; identifies supply chain as key laggard segment |
| **Relevance** | 8 | Rich market data on BPM/SOA adoption with cross-tabulations by company size and industry; vendor mentions (Appian, CTSpace, Ramco) provide market map |
| **Prescience** | 7 | Correctly predicted BPM-SOA convergence as key IT architecture trend; 2007 prediction that BPM would lead middleware investment proved accurate |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (4)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Aberdeen Group | firm | [DEFERRED] | [DEFERRED] |
| Appian Corporation | company | active |  |
| CTSpace | company | [DEFERRED] | [DEFERRED] |
| Ramco Systems | company | active |  |

### Technologies Referenced (6)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Business Process Management Suite (BPM) | middleware |  | growth | mature |
| Enterprise Service Bus (ESB) and SOA Middleware | middleware |  | growth | evolved |
| Enterprise Application Integration (EAI) | middleware |  | mature | legacy |
| Master Data Management (MDM) | data-management |  | emerging | mature |
| Business Activity Monitoring / Business Intelligence Tools | analytics |  | growth | mature |
| ERP Systems | enterprise-applications |  | mature | mature |

### Observation Summary

- Total observations: 27
- By type: survey-finding: 26, technical-claim: 1
