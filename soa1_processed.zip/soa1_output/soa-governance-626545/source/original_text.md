# Management and Governance: Planning for an Optimized SOA Application Lifecycle

> Archived from: source/_raw_text.txt
> Original publication date: 2007-03
> Author: Aberdeen Group

---

## Original Document Text

Management and Governance: Planning for an
    Optimized SOA Application Lifecycle
             Technology That Drives Lower
       Software Development and Lifecycle Costs




                       March 2007
                               Management and Governance: Planning for an Optimized SOA Application Lifecycle,




                               Executive Summary

This report examines the effectiveness of IT investments in three areas of a services-
oriented architecture (SOA): operations management; design and operations governance;
and underlying changes in project management, development, testing, and application
lifecycle management tools.

Key Business Value Findings
Between a third and half of the 950 companies we surveyed in 2006 are having serious
difficulties getting their SOA-enabled applications into stable deployment. The survey
for this report shows that the predominant reason for these difficulties is inexperience
exacerbated by inadequate tools for the automated management and governance of the
growing plethora and complexity of web services and applications under an SOA.
There are four characteristics of the top-performing 20% of the companies — the Best in
Class — in our survey:
        •    The Best in Class are most likely (33%) to have more than two years experi-
             ence with SOA technology;
        •    68% of the Best in Class are achieving positive ROI on their SOA investments
             and are seeing lower application development costs under SOA, while 77% of
             the overall survey has yet to see an SOA payback achieved;
        •    The Best in Class companies have implemented design-time governance and
             re-use policy to minimize lifecycle service costs compared to 26% overall.
             Close to half of the Best in Class have set minimizing application software
             lifecycle costs as a measurable management objective.
        •    More than 80% of the Best in Class have implemented an automated solution
             to SOA operations and governance, typically with third-party software.

Implications & Analysis
There is a tangible cause and effect relationship between management and governance
and overall software lifecycle costs:
    •       Operationally, SOA introduces a myriad of new design, testing and performance-
            related issues that can not readily be solved with prior technology or IT elbow
            grease;
    •       Design-time governance is where programmers can be “encouraged” to re-use
            existing services, saving the initial coding time and long-term maintenance costs
            of writing new but duplicative program code;
    •       Operational governance ensures that eligible services are given the resources
            they need, and that performance and security issues are managed. It also helps
            manage the complexity of loosely-coupled services running on multiple servers
            in a highly distributed fashion — the hallmark of a SOA.



                                 All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                          Aberdeen Group • i
Management and Governance: Planning for an Optimized SOA Application Lifecycle



         The inefficiencies caused by a lack of SOA management and governance lower IT per-
         formance, raise current operating costs, and collar IT with long-term software mainte-
         nance costs that will endure for decades. Fortunately, none of our survey participants
         will ignore investments in SOA management and governance. The Best in Class have
         it now and the Industry Average company is in the planning stage.

         Recommendations for Action
         Our extensive research in 2006 and for this report paint a clear approach to achieving
         superior results:
             •    Experience Counts. Organizations that are dawdling with web services and with
                  no firm enterprise plan for an SOA (and the technology investments that re-
                  quires) are falling behind their peers. Get the focused training necessary to bring
                  not just specialists but the whole IT organization up to snuff, using outside ser-
                  vices where appropriate. SOA is not a fad. It will be with us for decades.
             •    Design in SOA Management and Governance. Manageability of loosely-
                  coupled services, re-use policies, and security are all most economically designed
                  in rather than bolted on after the fact. Technology for automating management
                  and governance is proving its worth at Best in Class companies.
             •    Focus on Application Lifecycle Costs. A systematic focus on the costs of de-
                  veloping and maintaining SOA services, which can be assisted with automation,
                  will result in the appropriate methodologies and policies such as code re-use that
                  drive lower costs of ownership. Without design-time governance, programmers
                  will not re-use services, and lifecycle costs will balloon. The Best in Class com-
                  panies who are already using automated SOA management and governance are
                  encouraged to take the next step in operational excellence by concentrating on
                  processes to minimize costs across the application lifecycle. One area they
                  should focus on is quality, which is a major aim of the SOA application lifecycle.




All print and electronic rights are the property of Aberdeen Group © 2007.
ii • Aberdeen Group
                        Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                  Table of Contents
Executive Summary .............................................................................................. i
     Key Business Value Findings.......................................................................... i
     Implications & Analysis ................................................................................... i
     Recommendations for Action......................................................................... ii
Chapter One: Issue at Hand.................................................................................1
     The Components of an SOA Life-Cycle Management Model.........................2
     Operational Management .............................................................................. 3
     Governance ................................................................................................... 4
     Project Management, Development and
     Application Lifecycle Management Tools ....................................................... 4
     The Drivers for SOA Management and Control .............................................5
Chapter Two: Key Business Value Findings .........................................................6
     Experience Counts ........................................................................................6
     IT Drivers for SOA Management and Governance ........................................6
     SOA Operations Challenges and Responses ................................................7
Chapter Three: Implications & Analysis................................................................9
     Process and Organization ........................................................................... 10
     Technology Provides Leverage to the Best-in-Class Companies................. 10
     Pressures, Actions, Capabilities, Enablers (PACE)...................................... 11
     Governance Views by Industry .................................................................... 11
Chapter Four: Recommendations for Action ...................................................... 13
     Best in Class Next Steps ............................................................................. 13
     Industry Average Steps to Success ............................................................. 14
     Laggard Steps to Success........................................................................... 14
Appendix A: Research Methodology .................................................................. 16




                            All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                       Aberdeen Group
 Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                                           Figures

                Figure 1: SOA Application Integration Life-Cycle Stumbling Blocks .....................2

                Figure 2: Business Drivers for Investments in
                SOA Management and Governance ....................................................................5

                Figure 3: Length of Time Since First SOA Services Were Deployed ....................7

                Figure 4: IT Drivers for SOA Management and Governance................................8

                Figure 5: SOA Governance Drivers by Industry ................................................. 12


                                                            Tables

                Table 1: SOA Operations Challenges and Responses .........................................8

                Table 2: SOA Operations and Governance Competitive Framework....................9

                Table 3: Application Lifecycle Cost Changes by Maturity Framework – 2006..... 10

                Table 4: Prioritized Pressures and Enablers....................................................... 11

                Table 5: PACE Framework ................................................................................. 17

                Table 6: Relationship between PACE and Competitive Framework ................... 17




All print and electronic rights are the property of Aberdeen Group © 2007.
Aberdeen Group
                                                 Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                               Chapter One:
                                              Issue at Hand

                • A strong focus on management and governance is a key to wringing the most savings
Key Takeaways




                  out of SOA projects that use core middleware or extend from existing ERP systems.
                • The top stumbling blocks to SOA implementation and operation center around operations
                  management and governance issues.
                • The key to application lifecycle cost control is governance, especially in driving service
                  re-use at design time.




A       berdeen research in 2006 watched the 90% of Global 10,000 organizations that
        have embarked on SOA journeys. The vast majority of IT executives and other
        senior executives are convinced that a service-oriented architecture (SOA) is the
        right technology path to improve IT agility and lower the 40% of IT budget
dedicated to application integration. We can all salute that flag.
The problem is that each organization’s “SOA journey” takes a different path. We have
identified three major classifications to describe SOA strate-
gies:                                                            Competitive Framework
                                                                            Key
    • SOA Lite, for the half that are calling web services
    “SOA”;                                                     The Aberdeen Competitive
                                                               Framework defines enter-
    • Enterprise SOA, for the 30% that are building            prises as falling into one of
    around core SOA infrastructure middleware; and             the three following levels of
    • ERP SOA, for the 20% that are building their             practices and performance:
    SOAs from their ERP vendors’ SOA middleware ca-            Best in class (20%) —
    pabilities.                                                practices that are the best
Importantly, while SOA may be the solution, it’s not a currently being employed
painless cure for the pain of integration. In fact, between a and significantly superior to
third and half of the 950 companies we surveyed in 2006 are the industry norm
having serious difficulties getting their SOA-enabled appli-    Industry Average (50%) —
cations into stable deployment (Figure 1). These problems practices that represent the
can be lumped into five major categories of yellow-flags for average or norm
IT executives:
                                                               Laggards (30%) —practices
      1. Poor operational control of the loosely coupled       that are significantly behind
          applications, including security;                    the average of the industry
                2. Inadequate control over programmers: SOA application creation, re-use,
                   and modification;
                3. Unanticipated deployment issues regarding performance and scaling, and
                   testing issues caused by the new development methodologies inherent in Web
                   services and SOA, and simplifying the inherent complexity in SOA;



                                          All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                                  Aberdeen Group • 1
Management and Governance: Planning for an Optimized SOA Application Lifecycle



               4. Project management methodologies that have not kept up with SOA devel-
                  opment, testing, and deployment techniques, lowering ROI and raising costs
                  due to inadequate application life-cycle management; and
               5. Inadequate ROI or difficulty in justifying the ROI of project expenditures.
         Based on Figure 1 and the 50% of companies that are not deploying SOA infrastructure
         software (i.e., SOA Lite), a significant minority of the Global 10,000 will encounter
         ongoing SOA operational issues and vexing development problems, which, in turn,
         will reduce the potential double-digit savings in application lifecycle costs under
         SOA.
         One key to SOA-based cost reduction is a strong focus on management and governance.
         Figure 1: SOA Application Integration Life-Cycle Stumbling Blocks

            Establishment of operational security, governance,
                            and management                                                                  44%

                     Security issues are different from older IT                                      39%
             SLAs: Scaling to production volumes, reliability &
                                availability                                                         38%
                  Debugging problems with complex services,
                                 composites                                                        35%

            Data management of SOA services is problematic                                        34%
             QA: Testing and deployment stage problems spill
                           over into production                                                31%

                                                                   0% 5% 10% 15% 20% 25% 30% 35% 40% 45% 50%



                                                                                 Source: Aberdeen Group, January 2007


         The Components of an SOA Life-Cycle Management Model
         There are only bits and pieces of an IT product category called “SOA life-cycle manage-
         ment”. That means IT executives will have to develop their own models for how their
         organizations will maximize productivity and minimize total life-cycle costs over the
         decades-long lives of their SOA applications portfolios and infrastructure investments.
         And the key really is to take a decades-long view. Why? Because the Pandora’s Box that
         is intractable software integration costs has been opened, and the industry will never re-
         turn to the tightly-coupled, brittle applications and interfaces we have lived with since the
         appearance of client-server and relational databases in the early 1990s.




All print and electronic rights are the property of Aberdeen Group © 2007.
2 • AberdeenGroup
                                   Management and Governance: Planning for an Optimized SOA Application Lifecycle



Not only is there no product category of SOA life-cycle management, there is no single,
point-product solution either. That means IT
executives will be cobbling together technol- PACE Key — For more detailed descrip-
ogy over the near term until vendors catch up tion see Appendix A
with more integrated product portfolios.       Aberdeen applies a methodology to benchmark
IT executives can succeed in developing their     research that evaluates the business pressures,
                                                  actions, capabilities, and enablers (PACE) that
SOA life-cycle management plans by con-           indicate corporate behavior in specific business
centrating on three areas:                        processes. These terms are defined as follows:
     •   Operational Management —                 Pressures — external forces that impact an
         How does a loosely-coupled SOA           organization’s market position, competitiveness,
         change the way applications oper-        or business operations
         ate, forcing changes in IT opera-        Actions — the strategic approaches that an
         tions?                                   organization takes in response to industry pres-
                                                  sures
     •   SOA Governance — How does
         an SOA affect application design         Capabilities — the business process competen-
         standards, change run-time secu-         cies required to execute corporate strategy
         rity and compliance, testing, and        Enablers — the key functionality of technology
         impact the overall IT governance         solutions required to support the organization’s
         framework?                               enabling business practices

     •   Project Management, Development and Application Life-Cycle Manage-
         ment Tools — What process and technology changes are required to gain the
         maximum long-term productivity improvements from the impact of SOA on
         the application portfolio?

Operational Management
Whether or not an organization uses SOA infrastructure middleware such as an ESB, ap-
plications increasingly consist of composites of existing “legacy” applications, held to-
gether with a loosely-coupled IT infrastructure. SOA services have different workload
characteristics than their predecessors. In addition, they behave differently and require
new techniques — and likely new technology — to operate efficiently. Key areas of
change include:
     •   Integrating an SOA and its applications with existing enterprise systems man-
         agement infrastructure to create a services-aware, end-to-end view of business
         processes;
     •   Development of new procedures for application crash debugging and recov-
         ery;
     •   Testing and development of new capacity planning benchmarks, performance
         tuning, and revised response-time thresholds. SOA requires new testing meth-
         odologies and testing technology;
     •   Integration with first-tier IT help desk and vendors’ second- and third-tier sup-
         port;
     •   Incorporating SOA-specific security into the enterprise IT security plan;



                             All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                     Aberdeen Group • 3
Management and Governance: Planning for an Optimized SOA Application Lifecycle



                 •    Development of service-aware Quality of Service requirements; and
                 •    Changes to service-level agreements to reflect these operational changes.

         Governance
         Governance in an SOA world implies a decision and accountability framework with
         strong auditing, conformance, and measurement capabilities that support compliance
         management. Organizations are applying governance throughout the application lifecy-
         cle, especially during design and operations stages. Governance is meant to reduce risk
         and complexity around the common challenges associated with adopting SOA especially
         defining and reusing services, managing the lifecycle of service assets, and the measuring
         effectiveness of policies.
         At design time, governance can guide decisions on service re-use. The simple equation
         going forward is that more re-use will result in lower integration costs and the mainte-
         nance costs that follow. Our survey for this report shows that about one-quarter of
         Global 10,000 organizations are employing design-time governance.
         During service operation, governance software supports the creation and modification of
         policies that trigger events and actions. It also controls and monitors service use by em-
         ployees, customers, and business suppliers, as well as across business units. SOA opera-
         tional issues become obvious as volumes scale, and especially when multiple applica-
         tion service servers are required to support the workloads.

         Project Management, Development and
         Application Lifecycle Management Tools
         The SOA application development and maintenance lifecycle is different from prior soft-
         ware lifecycles, even though organizations use the same phases of design, coding, test-
         ing, quality assurance, and deployment. To us, SOA is a standards-based descendent of
         the object-oriented development techniques that became popular in the early 1990s. But
         object-oriented C++ applications never became widespread among the Global 10,000,
         even though the language did. Will the industry lose the opportunity for lower applica-
         tion/service lifecycle costs as it did by failing to use the full re-use capabilities of object-
         oriented C++?
         In a SOA, applications are no longer silos of program code; they’re incorporated into
         services. Nevertheless, the lifecycle revolves around the following long-used concepts
         and techniques, updated to use a services-centric view and with a keen eye to re-use:
             •       Managing module versions of services and service components, including legacy
                     applications;
             •       Assessing and managing change impact on SOA operations and services;
             •       Fostering re-use, quality, performance, and testing of services;
             •       Employing SOA debugging, performance management, and recovery techniques;
                     and
             •       Integrating legacy custom programs, third-party independent software applica-
                     tions (e.g., ERP), and new application definition technology, especially BPM and
                     related BPM models.

All print and electronic rights are the property of Aberdeen Group © 2007.
4 • AberdeenGroup
                                     Management and Governance: Planning for an Optimized SOA Application Lifecycle



Our recent survey on building better composite applications revealed that 75% of Best in
Class organizations are unhappy with their application development tools and plan to
supplement or replace this technology in the next six months.

The Drivers for SOA Management and Control
The most important driver in this survey is developing new business capabilities or prod-
ucts and services for the business (Figure 2). Best in Class companies are focusing more
on managing IT complexity, which is increasing with the growing use of web services
and SOA.

Figure 2: Business Drivers for Investments in SOA Management and Governance


                                                                          36%
                  Alignment with the business                         30%
                                                                        34%


                                                                       32%
                 Speed of IT implementations                          30%
                                                                                43%

                                                                          36%
   Re-usage of applications via Web Services                                    43%
                                                                                  47%


                                                                                   48%
  Development of new business capabilities or                                       50%
         new products and services                                           38%


                                                                                 44%
                Management of IT complexity                                   40%
                                                                               41%

      Laggard     Average     BIC
                                                0%   10%   20%     30%    40%      50%    60%


                                                              Source: Aberdeen Group, January 2007




                               All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                       Aberdeen Group • 5
Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                              Chapter Two:
                                       Key Business Value Findings

                         • Get your organization up the SOA experience curve as soon as possible.
         Key Takeaways




                         • Dealing with SOA operational issues requires rethinking existing IT operations processes
                           and updating them.
                         • Third-party IT services are seen as a first response in bringing on needed experience
                           and SOA best practices quickly.

         Experience Counts



         T       here is a high correlation in this survey between the overall maturity ranking in
                 Aberdeen’s framework and experience with SOA technology (Figure 3). More
                 than half of the Best in Class companies in our survey have at least 12 months of
         production experience with deployed applications under an SOA, while only 30% of the
         whole survey had this experience. But 20% of the Industry Average and Laggard compa-
         nies in this survey had only six months or less of experience, twice as many as the Best in
         Class.
         Readers should consider this “experience counts” finding carefully. The good news is
         that there is light at the end of the tunnel for many companies riding the SOA learning
         curve. The challenge is how to best
         use the training period to best long-
         term advantage.                             “The more experience we got, the more we real-
         Finally, we note a prescient comment                   ized what we didn’t know. That made us realize
         from a university IT manager, who                      we needed outside help from services vendors
         stated: “The more experience we got,                   and more peer-support efforts.”
         the more we realized what we didn’t
         know. That made us realize we                                                   ~ University IT manager
         needed outside help from services
         vendors and more peer-support ef-
         forts.”

         IT Drivers for SOA Manage-
         ment and Governance
         For 45% of the survey pool – and 46% of supply chain-oriented organizations -- the top
         driver for SOA management and governance is developing new business capabilities or
         new products and services (Figure 4). Management of IT complexity is second at 42%
         overall, yet a more apparent pressure for the Best in Class at 44%. This difference in pri-
         ority is caused by the greater experience levels of the Best in Class. “The first applica-
         tion-services server was a piece of operations cake”, a consumer products goods manu-
         facturer told us. “But by the fifth server, we really did not know what was going on in-
         side at any given moment, and that got scary quickly.”


All print and electronic rights are the property of Aberdeen Group © 2007.
6 • AberdeenGroup
                                     Management and Governance: Planning for an Optimized SOA Application Lifecycle



Figure 3: Length of Time Since First SOA Services Were Deployed


                                                                                        33%
    More than 24 months                            12%

                                                                        24%
    More than 12 months                                      18%

                                                               19%
             6-12 months                                                      27%

                                               10%                                    BIC
    Less than six months                                       19%
                                                                                      Overall
                                               10%
  Plan to deploy in 2007                                       19%

                            0%      5%      10%      15%     20%      25%      30%      35%


                                                              Source: Aberdeen Group, January 2007


SOA Operations Challenges and Responses
Standing in the way of optimized SOA operations is establishment of operational secu-
rity, governance, and management (Table 1). Twice as many survey respondents cite this
as a top challenge over Best in Class companies. The key reason cited is the IT complex-
ity an SOA operations environment creates. The desire to manage IT complexity raises
the challenge of establishing operational security, governance, and management.
SOA security is the second challenge, with about the same numbers of Best in Class and
all other respondents citing the differences and complexity that a loosely coupled, be-
hind-the-firewall SOA environment presents to IT operations. The third challenge: de-
bugging, caused by the different architecture of loosely-coupled SOA services compared
to most prior IT applications using con-
ventional programming techniques.
In response to these challenges, the top    ”With SOA, we were forced to rewrite whole
response, chosen by 45% of our sur-         chapters of our IT processes manual…and that’s
vey, is to revise application lifecycle     not a bad thing.”
processes and responsibilities. This
challenge is best illustrated by an auto-                      ~ Automotive parts manufacturer
motive parts manufacturer who told us,
“With SOA, we were forced to rewrite
whole chapters of our IT processes
manual…and that’s not a bad thing”.
Second, 41% of our survey have en-
gaged third-party IT services firms for consulting, evaluation, and assessment. But only
25% of the Best in Class companies are taking this route since they tend to be more ex-
perienced.




                               All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                       Aberdeen Group • 7
Management and Governance: Planning for an Optimized SOA Application Lifecycle



         Figure 4: IT Drivers for SOA Management and Governance


           Development of new business capabilities,                                            48%
                                                                                                 50%
                   products and services                                                 38%

                                                                                             44%
                          Management of IT complexity                                     40%
                                                                                           41%

                     Re-usage of applications via Web                                  36%
                                                                                             43%
                                Services                                                       47%

                                                                                      36%
                           Alignment with the business                             30%
                                                                                     34%

                                                                                    32%
                           Speed of IT implementations                             30%
                                                                                             43%
                   Laggard      Average      BIC
                                                          0%     10% 20% 30% 40% 50% 60%

                                                                           Source: Aberdeen Group, January 2007


         Table 1: SOA Operations Challenges and Responses
                 Challenges                  % Selected            Responses to Challenges             % Selected
    Establishment of operational secu-          45%            Revised our application lifecycle          45%
    rity, governance, and management                           process and responsibilities
    Security issues are different from          38%            Engaged third-party IT services            41%
    those of older IT                                          consulting, evaluation, and as-
                                                               sessments
    Debugging problems with complex             37%            Purchase or plan to purchase SOA           28%
    services, composites                                       operations management software
    SLAs: Scaling to production vol-            37%            Purchase or plan to purchase SOA           26%
    umes, reliability and availability                         security software
    Data management of SOA services             33%            Invested in additional operations          22%
    is problematic                                             and applications lifecycle training
    QA: Testing and deployment stage            31%            Bought additional computer capac-          19%
    problems spill over into production                        ity to minimize perform-
                                                               ance/capacity issues
                                                                           Source: Aberdeen Group, January 2007




All print and electronic rights are the property of Aberdeen Group © 2007.
8 • AberdeenGroup
                                                   Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                        Chapter Three:
                                   Implications & Analysis

                •   Existing processes do not apply well to new SOA operations and governance issues
Key Takeaways




                    and require changes.
                •   Best in Class companies achieve performance excellence in SOA operations and gov-
                    ernance, partly through the use of SOA-specific technology.
                •   Using operations, governance, and application lifecycle management technology, Best
                    in Class companies are focused on ─ and achieving ─lower long-term costs.




A
        s shown in Table 2, survey respondents fell into one of three categories – Lag-
        gard, Industry Average, or Best in Class — based on their characteristics in four
        key categories: (1) process (investment/payback metrics, SOA-specific processes
        and governance); (2) organization (SOA IT topology, governance philosophy);
(3) knowledge (visibility into operations, governance, and lifecycle cost data); and (4)
technology (scope of SOA management and governance automation, productivity tools).
In each of these categories, survey results show that firms exhibiting Best in Class SOA
operations and governance characteristics also enjoy Best in Class application lifecycle
performance and payback on their companies’ SOA investments (Table 2).
Table 2: SOA Operations and Governance Competitive Framework
                           Laggards                      Industry Average            Best in Class
  Process                 Using existing IT opera-     Some SOA operations         SOA-tuned operations; IT
                          tions processes not          processes have been         governance accounts for
                          adjusted for loosely-        planned or are in place;    SOA design and operations;
                          coupled SOA architec-        modest SOA governance       application lifecycle cost
                          ture and technology          activities                  awareness.
  Organization            SOA has not caused a         Changes planned or          Roles and responsibilities
                          change in organization.      newly implemented           revised for SOA operations
                                                                                   and governance.
  Knowledge               Limited SOA experience       Knowledge limited to key    Experienced veterans who
                          means no visibility of       personnel and not scal-     have widespread hands-on
                          pitfalls ahead; modest       able; challenged and        SOA production experience;
                          problems due to limited      reactive to unanticipated   management has changed
                          scale, experience.           operations and govern-      goals and metrics based on
                                                       ance crises.                experiences.
  Technology              “SOA Lite” web ser-          Increasing SOA middle-      Enterprise middleware tech-
                          vices; no special SOA        ware use; plans and         nology supplemented by
                          operations; no IT gov-       some purchases of op-       SOA operations and gov-
                          ernance or SOA gov-          erations, governance,       ernance automation; lifecy-
                          ernance automation;          and application lifecycle   cle-based application ROI
                          project-based ROI            automation
                                                                             Source: Aberdeen Group, January 2007



                                         All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                                 Aberdeen Group • 9
Management and Governance: Planning for an Optimized SOA Application Lifecycle



         Process and Organization
         In the process category, companies in the survey that employ SOA operations automation
         products and SOA-related governance consistently achieve much higher ROI on their
         SOA investments. Some 40% of the Best in Class companies earned a payback of more
         than $1 million on their SOA investments, compared to 17% of the survey overall. Lag-
         gard firms are trying to get by with both the existing processes and organization.

         Technology Provides Leverage to the Best-in-Class Companies
         Best in Class firms in our survey are employing SOA operations management software to
         automate the SOA-specific services they’re deploying, as well as SOA governance soft-
         ware, typically an upgrade from an existing automated IT governance software package’s
         processes. The Best in Class companies are focusing on the entire life of an application
         “service”, from design through programming, testing, deployment, and into maintenance.
         We asked, “How has SOA development in the past year changed the IT costs of the ap-
         plication/service lifecycle?” As Table 3 clearly shows, the automation investments by the
         Best in Class resulted in decreases in development costs in 2006 while the majority
         of Industry Average and Laggard companies are actually seeing their development
         costs increase.
         Importantly, 58% of Laggard firms are not taking action to treat SOA operations, gov-
         ernance, and the resulting lifecycle costs as anything different from past processes. These
         companies are least likely to use SOA operational management, governance, and applica-
         tion lifecycle management software.
         Table 3: Application Lifecycle Cost Changes by Maturity Framework – 2006
                                                                         Industry        Best in
                                                           Laggards
                                                                         Average         Class
                  No change                                  55%           43%              12%
                  Increased costs up to 5%                   24%           14%              4%
                  Increased costs 6-10%                      2%            12%              4%
                  Increased costs 11-20%                     4%             8%              4%
                  Increased costs 21-30%                                    2%              8%
                  Increased costs more than 30%              7%             1%
                  Decreased costs up to 5%                   5%             8%              28%
                  Decreased costs 6-10%                      2%             7%              12%
                  Decreased costs 11-20%                     2%             4%              12%
                  Decreased costs 21-30%                                                    8%
                  Decreased costs more than                                 1%              8%
                  30%
                                                                           Source: Aberdeen Group, January 2007




All print and electronic rights are the property of Aberdeen Group © 2007.
10 • AberdeenGroup
                                           Management and Governance: Planning for an Optimized SOA Application Lifecycle



Pressures, Actions, Capabilities, Enablers (PACE)
Table 4 shows how operations, governance, and application lifecycle technologies map to
the SOA-driving pressures that were listed in Chapter Two. These findings highlight is-
sues cited in previous Aberdeen research in 2006, namely:
    •    The biggest challenge in corporate IT organizations is improving real-time visi-
         bility into business operations;
    •    Business is discovering the SOA as a technological foundation that can make
         businesses more nimble and business processes more flexible with less IT inter-
         vention than prior approaches; and
    •    As organizations gain more experience with SOA technology and methodologies,
         they realize that currently used approaches and methodologies do not match well
         with the best practices in using an SOA.
Table 4: Prioritized Pressures and Enablers

Priorities   Prioritized Pressures                        Prioritized Enablers

    1        Development of new business capabili-        * Harnessing custom and third-party applica-
             ties, products, and services                 tions, such as ERP, under an SOA
                                                          * Building composite applications

    2        Management of IT complexity                  * Enterprise SOA middleware technology
                                                          * SOA operations management technology
                                                          * SOA governance technology

    3        Re-use of applications via Web Services      * Design-time governance software
             and SOA
                                                          * Application lifecycle management software

    4        Speed of IT implementations                  * Design-time governance software enables
                                                          service reuse, quicker delivery
                                                          * SOA governance and application lifecycle
                                                          management software keep projects on track

    5        Alignment with the business                  * Composite applications that span at least
                                                          some of the following: legacy applications,
                                                          ERP, best-of-breed applications, web-
                                                          hosted/On Demand applications, customers’
                                                          or suppliers’ applications
                                                          * Design-time governance software enables
                                                          service reuse, quicker delivery
                                                                    Source: Aberdeen Group, January 2007

Governance Views by Industry
Not all industries have the same view on the importance or management reason for a
formal IT governance policy (Figure 5). The findings from our survey make it clear that



                                 All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                        Aberdeen Group • 11
Management and Governance: Planning for an Optimized SOA Application Lifecycle



         governance of SOA design, operations, and policy management are critical factors in
         achieving process excellence and higher results, especially over time, to wit:
             •    None of our survey participants will ignore governance going forward, even
                  those whose companies have not implemented IT governance policies to date;
             •    The Best in Class companies are most likely to have existing IT governance poli-
                  cies in place, updated to reflect the necessities of an SOA environment; and
             •    The strong correlation between use of governance (and application lifecycle)
                  automation and higher SOA investment payback, resulting in overall lower ap-
                  plication development costs.
         The public sector is driven by regulation. But the services industry is strongly driven to
         governance as a means of lowering application lifecycle costs.

         Figure 5: SOA Governance Drivers by Industry


              Governance is mandated by government or                                                 54%
                                                                            24%
                             regulation.                                 18%

             We are striving to lower application lifecycle                         31%
                                                                                                      53%
                  costs: saving money over time.                                          40%

           Our management team demands clear policy                 8%
                                                                          19%
                      and accountability                                    22%

            SOA governance is an update to our existing                                   38%
                                                                                 24%
                     IT governance process                                        26%

            To ensure uniform and consistent application                                              54%
                                                                                                46%
                 of policy across the organization.                                             46%

                   supply chain    services   public          0%   10%   20%     30%    40%     50%    60%


                                                                           Source: Aberdeen Group, January 2007




All print and electronic rights are the property of Aberdeen Group © 2007.
12 • AberdeenGroup
                                                   Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                       Chapter Four:
                                 Recommendations for Action

                 •     The larger the company, the greater the need for management by IT governance policy,
Key Takeaways




                       preferably automated.
                 •     Focus on the long-term goal of lowering application lifecycle costs and avoid the ten-
                       dency to look to take a short-term project ROI while increasing long-term costs.
                 •     Since Best in Class companies are also the most experienced, proactively utilize train-
                       ing and IT services to speed up the learning curve.




C       ost control of the application lifecycle is a long-term benefit worthy of manage-
        ment’s attention. Best in Class companies in this survey are most likely to have
        well-defined processes for managing and governing SOA design and operations,
including the use of application lifecycle management software and IT governance soft-
ware to automate the process. And, these companies are not paying lip service to the sub-
ject. To reinforce this point, users need both SOA operations management as well as
governance. This is not an “either/or” choice, nor are the two mutually exclusive.
As an airline IT executive told us:
“There are too many moving parts in
our IT operations not to have applica-                        “There are too many moving parts in our IT op-
tions watching applications ─ and pro-                        erations not to have applications watching appli-
grammers. That’s the only way we can                          cations ─ and programmers. That’s the only way
sleep at night.”                                              we can sleep at night.”
Based on the information in Chapters
Two and Three, readers should deter-                                 ~ Airline IT executive
mine whether their organizations fall
into the “Laggard”, “Industry Average,”
or “Best in Class” categories. The key
to gaining value from this report is
moving your organization along the maturity path to Best in Class. The following actions
will help spur necessary performance improvements:

Best in Class Next Steps
                1. Build out your SOA infrastructure — methodically.
                     Plan and deploy the SOA middleware — enterprise service bus, repository, secu-
                     rity, management and governance — needed to support your organization’s long-
                     term plans. That may well require an enterprise-level capital expenditure since
                     the cost won’t fit into a project budget. Even many Best in Class firms have yet
                     to complete this task.
                2. Tighten governance, especially at design time.




                                             All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                                    Aberdeen Group • 13
Management and Governance: Planning for an Optimized SOA Application Lifecycle



                  With experienced companies reporting code re-use in the 50%-70% range under
                  SOA, there is a lot of value to shoot for. However, it will cost more to develop
                  reusable code. Employ tight project schedules and lifecycle-cost focused re-use
                  planning as governance techniques.
             3. Aim for the application lifecycle cost “brass ring”.
                  Focus programming governance efforts on a best-practices program to drive all
                  aspects of lowering costs in the lifecycle of applications.

         Industry Average Steps to Success
             1. Upgrade from Web services to an Enterprise SOA infrastructure plan.
                  The allure of improved IT agility using composite applications constructed with
                  Web services should be tempered with the reality of a plan to quickly build out
                  an Enterprise SOA infrastructure as described in Chapter 1. SOA infrastructure
                  middleware is a prerequisite to scalable, well-mannered IT operations.
             2. Anticipate increasing complexity
                  Survey participants tell us IT complexity (especially in operations) increases al-
                  most exponentially at first as more SOA services and servers are added. The in-
                  ternal costs of disruption can be high and hinder ongoing project roll-outs. Ac-
                  celerated training programs, SOA management software, and the judicious use of
                  third-party IT services are the ingredients for getting over the complexity hump
                  of the learning curve.
             3. Turn SOA governance plans into reality
                  Every company in our survey believes there is an SOA governance process in
                  their future. Many are at the planning stage. Automating SOA governance is an
                  investment the vast majority of mid-size and large companies ought to make.
             4. Start planning for the control of application lifecycle costs
                  This survey clearly demonstrates that design-time and programming extra effort
                  can lower application lifecycle costs through code reuse at 50% and above. Start
                  planning by measuring application lifecycle costs, examining whether current
                  SOA development practices encourage “one time” programming or reuse. Con-
                  sider automated lifecycle management tools as part of the development govern-
                  ance process.

         Laggard Steps to Success
             1. Establish operational security, governance, and management policies and proc-
                esses.
                  The old, but true, adage is “you can’t manage what you can’t measure.” Too
                  many Laggard organizations lack the process, let alone automation, for the proc-
                  ess. Start with SOA operations, then move to design governance, revising appli-
                  cation lifecycle processes and responsibilities along the way.
             2. Fix the lack of management support to drive SOA governance as a means to low-
                ering lifecycle costs.


All print and electronic rights are the property of Aberdeen Group © 2007.
14 • AberdeenGroup
                              Management and Governance: Planning for an Optimized SOA Application Lifecycle



   More than one-third of Laggard organizations face management that is not con-
   vinced of the long-term benefits of governance as a way to lower application
   lifecycle costs. This report is ammunition, but driving SOA governance will re-
   quire more company-specific proof points. For example, a 50% code re-use un-
   der SOA governance cuts the lines of code maintained in half permanently.
3. Plan for the long haul.
   The ROI of too many SOA projects are justified under business-as-usual rules
   favoring project-based ROI. That approach won’t unlock the long-term value to
   the entire organization of lower application lifecycle costs or solve the manage-
   ment of IT complexity issues driven by a growing use of SOA. Our 2006 surveys
   showed that companies following an “Enterprise SOA” strategy (see Chapter 1)
   can scale more easily with lower short- and long-term costs by investing in all
   aspects of SOA infrastructure software and in IT staff training.




                        All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                               Aberdeen Group • 15
Management and Governance: Planning for an Optimized SOA Application Lifecycle




                                          Appendix A:
                                     Research Methodology



         B        etween November 2006 and January 2007, Aberdeen Group examined the SOA
                  management strategies of more than 200 companies across a variety of geogra-
                  phies, industries and company revenues.
         Aberdeen supplemented this online survey effort with telephone interviews with select
         survey respondents, gathering additional information on SOA management strategies,
         experiences, and results.
         The study aimed to identify emerging best practices for SOA operations management and
         governance, and provide a framework by which readers could assess their own organiza-
         tion’s capabilities and maturity.
         Responding enterprises included the following:
             •    Job title/function: About half of the survey respondents are in their organiza-
                  tions’ IT departments. The research sample included respondents with the fol-
                  lowing job titles: senior executive (CEO, COO, CFO, VP) (13%); CIO (11%); IT
                  manager or director (32%); internal consultant (21%), and IT staff (8%).
             •    Industry: The research sample included respondents predominantly from manu-
                  facturing industries and companies with a supply-chain focus (wholesale, retail,
                  distribution, high tech). These represented 52% of the sample, of which 53%
                  were manufacturing. Services industries including banking, brokerage, insurance,
                  and health care represented 40% of the survey. Public sector (government and
                  education) represented 8% of the survey.
             •    Geography: The survey respondents were distributed: North America (U.S.,
                  Canada, Mexico) 57%; Central and South America 4%; Asia/Pacific 16%;
                  Europe, Middle East, and Africa 24%.
             •    Company size: About 46% of respondents were from large enterprises (annual
                  revenues above US$1 billion, including 27% over US$5 billion); 38% were from
                  midsize enterprises (annual revenues between $50 million and $1 billion); and
                  28% of respondents were from small businesses (annual revenues of $50 million
                  or less).
         Solution providers recognized as sponsors of this report were solicited after the fact and
         had no substantive influence on the direction of this report. Their sponsorship has made it
         possible for Aberdeen Group to make these findings available to readers at no charge.




All print and electronic rights are the property of Aberdeen Group © 2007.
16 • AberdeenGroup
                                           Management and Governance: Planning for an Optimized SOA Application Lifecycle




Table 5: PACE Framework

PACE Key

Aberdeen applies a methodology to benchmark research that evaluates the business pressures, actions,
capabilities, and enablers (PACE) that indicate corporate behavior in specific business processes. These
terms are defined as follows:
Pressures — external forces that impact an organization’s market position, competitiveness, or business
operations (e.g., economic, political and regulatory, technology, changing customer preferences, competi-
tive)
Actions — the strategic approaches that an organization takes in response to industry pressures (e.g., align
the corporate business model to leverage industry opportunities, such as product/service strategy, target
markets, financial strategy, go-to-market, and sales strategy)
Capabilities — the business process competencies required to execute corporate strategy (e.g., skilled
people, brand, market positioning, viable products/services, ecosystem partners, financing)
Enablers — the key functionality of technology solutions required to support the organization’s enabling
business practices (e.g., development platform, applications, network connectivity, user interface, training
and support, partner interfaces, data cleansing, and management)

                                                                       Source: Aberdeen Group, January 2007


Table 6: Relationship between PACE and Competitive Framework

PACE and Competitive Framework How They Interact
Aberdeen research indicates that companies that identify the most impactful pressures and take the most
transformational and effective actions are most likely to achieve superior performance. The level of com-
petitive performance that a company achieves is strongly determined by the PACE choices that they make
and how well they execute.

                                                                       Source: Aberdeen Group, January 2007




                                    All print and electronic rights are the property of Aberdeen Group © 2007.
                                                                                           Aberdeen Group • 17
                                   Appendix B:
                        Related Aberdeen Research & Tools

       Related Aberdeen research that forms a companion or reference to this report include:
           •     The Composite Applications Benchmark Report, December 2006
           •     The Legacy Application Modernization Benchmark Report; September 2006
           •     The Business Process Management Benchmark Report; August 2006
           •     Outsourcing Application Development and Maintenance; November 2006
           •     Enterprise Service Bus and SOA Middleware; June 2006
           •     The SOA in IT Benchmark Report; December 2005
       Information on these and any other Aberdeen publications can be found at
       www.Aberdeen.com.




Aberdeen Group, Inc.                             Founded in 1988, Aberdeen Group is the technology-
260 Franklin Street                              driven research destination of choice for the global
Boston, Massachusetts                            business executive. Aberdeen Group has over 150,000
02110-3112                                       research members in over 36 countries around the world
USA                                              that both participate in and direct the most comprehen-
                                                 sive technology-driven value chain research in the
Telephone: 617 723 7890                          market. Through its continued fact-based research,
Fax: 617 723 7897                                benchmarking, and actionable analysis, Aberdeen Group
www.aberdeen.com                                 offers global business and technology executives a
                                                 unique mix of actionable research, KPIs, tools,
© 2007 Aberdeen Group, Inc.                      and services.
All rights reserved
March 2007
The information contained in this publication has been obtained from sources Aberdeen believes to be reliable, but
is not guaranteed by Aberdeen. Aberdeen publications reflect the analyst’s judgment at the time and are subject to
change without notice.
The trademarks and registered trademarks of the corporations mentioned in this publication are the property of their
respective holders.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | soa-governance-626545 |
| title | Management and Governance: Planning for an Optimized SOA Application Lifecycle |
| author | Aberdeen Group |
| date | 2007-03 |
| type | employer-record |
| subject_domain | SOA governance; SOA operations management; application lifecycle management |
| methodology | survey; benchmark; n=200+ companies; qualitative interviews; Nov 2006–Jan 2007 |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

24-page Aberdeen Group benchmark report examining effectiveness of IT investments in three SOA lifecycle areas: operations management, design/operations governance, and project/development/ALM tools. Survey of 200+ companies across geographies and industries. Between one-third and half of 950 companies surveyed in 2006 had serious deployment difficulties. Best-in-Class (top 20%) distinguish themselves through experience (33% with >2 years SOA), positive ROI (68%), design-time governance implementation, and automated management/governance solutions (>80%). Three SOA strategies identified: SOA Lite (50%), Enterprise SOA (30%), ERP SOA (20%).

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 8 | Provides quantitative benchmarks for SOA governance adoption; introduces three-way SOA strategy taxonomy (SOA Lite/Enterprise/ERP SOA) that became influential framing |
| **Relevance** | 9 | Rich survey data on operational challenges, governance drivers by industry, lifecycle cost impact; spans 200+ company survey with financial and industry segmentation |
| **Prescience** | 8 | Correctly predicted decades-long importance of SOA governance; design-time governance and service reuse principles now foundational to microservices/API management |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (1)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Aberdeen Group | firm | [DEFERRED] | [DEFERRED] |

### Technologies Referenced (5)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| SOA Governance Software | governance |  | emerging | evolved |
| SOA Operations Management | operations |  | emerging | evolved |
| SOA Infrastructure Middleware / ESB | middleware |  | growth | evolved |
| Business Process Management (BPM) Tools | middleware |  | growth | mature |
| Application Lifecycle Management Tools | development-tools |  | growth | mature |

### Observation Summary

- Total observations: 26
- By type: survey-finding: 20, strategic-recommendation: 3, technical-claim: 2, competitive-analysis: 1
