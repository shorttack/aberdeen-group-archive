# Why Aberdeen Group is Focusing on Enterprise IT Integration

> Archived from: source/_raw_text.txt
> Original publication date: 2006-02-23
> Author: Peter S. Kastner

---

## Original Document Text

Enterprise Integration Research                                                      February 23, 2006


       Why Aberdeen Group is Focusing on Enterprise IT Integration
         Business Challenge
 The time has come for enterprise management, not just the CIO, to look at the “forest” as a whole,
 not be distracted by today’s tactical “trees”. There are megatrends in both information technology
 (IT) and business opportunities enabled by technology. Aberdeen’s Enterprise IT Integration
 practice seeks to identify technology types and uses, which are synergistic: over time, IT
 investments end up being worth more than the sum of the individual projects. This Perspective
 examines the megatrends we are observing in 2006 and discusses the business-value themes that
 will follow our fact-based research in IT and in conjunction with other Aberdeen research
 practices.


        Aberdeen Perspective
The Megatrends Driving Information Technology Integration Opportunity
Our perspective is based on almost two decades of watching the evolution of IT through market
research. The key forces driving opportunities in information technology are:
    1. Programmer productivity is
       stuck at the 1970s level at many        Forces Triggering a Call For Change
       shops. Legacy application               Traditional approaches to building and deploying IT
       spaghetti-code is legendary for its     systems are not scaling with elegance. Brute force
       ability to soak up enormous talent      programming and enormous investments in hardware
       for trivial gains. A change is          and software infrastructure are expensive to maintain
       needed because the world just           and difficult to change. Yet Internet applications and
       does not have the programmers           flat-world globalization challenges are driving
       coding in 3GLs needed to solve          demands for flexibility, rapid IT change, grow-with-
       the business problems at hand. It       explosive-demand volumes, higher and smarter
       is telling that Microsoft – a bastion worker productivity, and collaboration with
       of technology brainpower – halted       customers and supply partners in ways barely
       work on its Windows Vista OS            dreamed of a decade ago. Since IT budget growth
       and threw away tens of millions of cannot eat up the bottom line, and business-driven IT
       lines of code in 2004. Why? To          complexity is assured, enterprises need to take a
       institute a programming process         more holistic, longer-term view on maximizing the
       change that should enable a lower       value of IT personnel and infrastructure investments.
       life-cycle cost. Aberdeen sees
       opportunities in service-oriented architectures, composite applications, and business
       process modeling as examples of development technology that can dramatically improve
       the quality, timeliness, and productivity of application developers and analysts. Are
       programmer productivity and program quality the weakest links in the IT chain? Our
       research shows best-in-class IT organizations freeing up to 15% of the IT budget with

         Announcement             Visit the Aberdeen Group Technology Research Channel.
                                                  Why Aberdeen Group is Focusing on Enterprise IT Integration
Perspective                                                                                           Page 2



        lower software maintenance costs compared to the average IT organization. Most of the
        savings are redeployed to IT innovation that drives immediate and tangible business value.
    2. Systems-Oriented Architecture and Web Services based on industry standards are in use
       at many enterprises and will make up the majority of development by the turn of the
       decade. A lot of valuable solutions in this space from new and well-established suppliers
       will ease the transition. However, the real payback comes when existing “legacy”
       applications can be wrapped as an SOA-based service. Some ten years down the road,
       investments in SOA and reusable code will be paying back enormous dividends in lower IT
       application asset life-cycle costs and faster, more flexible application changes. Lastly, an
       SOA is a good vehicle for virtualizing the processing, storage, and network components of
       IT infrastructure (see below).
    3. Deconstructing Processing at the Core and Edge and on the Network is driven by a
       new perspective on an old model, spoke-node-ring (SNR), Aberdeen’s first framework in
       1988. SNR foreshadowed the client-server and LAN/WAN revolution. Looking forward,
       we see the core datacenter “factories” deliberately breaking out processing (i.e., blades),
       storage (i.e., SANs) and datacenter fabric connecting LANs and WANs. Enterprise
       datacenters must be replicated and support data synchronization and fast switch-over on
       failure. 24-7 was seldom needed 20 years ago. Today, it is mandatory for most
       organizations.

        The edge is where data are delivered to people and devices, and from which data are
        captured. The edge is gaining lots of intelligence, as exemplified by the growth in retail
        store and shop floor computing power. The edge is an opportunity for value generation
        with careful integration.

        Sun Microsystems' trademark is “the network is the computer”. Watch out, Sun and other
        server suppliers, because true networking vendors such as Cisco are angling to provide
        intelligent network service networks that to date have been run on conventional servers.
        Our perspective is that solutions selection will become more complex with the advent of
        network processing but also more competitive, as new approaches will prove desirable.

 Figure 1: Aberdeen Group’s Enterprise IT Integration Model


                                                                  Enterprise WAN
                                                                  & Internet
                                             Processing
                                              Factory
                         EDGE
                                                                   Processing
                                                          CORE      Factory

                 Delivery /
                 Capture
                                                  Processing
                                                   Factory




                                                                 Source: AberdeenGroup, February 2006

© 2006 AberdeenGroup, Inc.                                                          Telephone: 617 723 7890
260 Franklin Street                                                                       Fax: 617 723 7897
Boston, Massachusetts 02110-3112                                                         www.aberdeen.com
                                                  Why Aberdeen Group is Focusing on Enterprise IT Integration
Perspective                                                                                           Page 3



        Figure 1 depicts our Enterprise Integration model, which is composed of:
        ▪        Edge components consisting of fixed and mobile people and devices such as
                 laptops and RFID stations. The edge is where data are first captured, and the end
                 point for delivery. The edge will often be connected via the Internet, so secure
                 authentication, encryption, and all the Internet security concerns and solutions
                 apply.
        ▪        Networking consists of Internet and enterprise WAN components. What we see
                 changing are two factors: first, the network itself supplies more computing services
                 such as encryption, compression, queuing and messaging, quality of service, and
                 other activities that today are performed by servers attached to the network. The
                 enterprise WAN and related managed services may be an outsourcing candidate.
                 Edge-attached appliances also have a role, as there are many benefits to moving
                 certain processing and data closer to the edge user. The business value is in
                 optimizing the security, performance, and reliability of the WAN backbone and its
                 operations.
        ▪        Processing Factories are deconstructed datacenters that will gradually become
                 “JBOR” (just a bunch of racks). Traditional computers are already splitting into
                 computing servers and Storage Area Networks. Datacenter fabrics are adequate to
                 tie together the datacenter LAN segments. We anticipate further server
                 consolidation as virtualization technology eases the complexity of running and
                 isolating multiple workloads. The monolithic enterprise datacenter is, fortunately,
                 seldom employed today.

                 Chip-maker focus on instructions per watt will allow greater density, as will better
                 cooling technology, lowering HVAC demands. Operational tools to remotely
                 monitor, virtually reconfigure, and deploy servers are needed to keep labor costs
                 under control.

                 Leading companies will translate lessons from scientific massively parallel
                 computing into a grid for commercial computing. The insight is the movement
                 towards greater real-time operational analysis and decision making (see below).

                 The business goal of enterprise integration is to achieve a smart processing
                 architecture, in which “where” and “how” computing is done is continually
                 optimized for business process conditions – without throwing out today’s IT
                 investments.
    4. Mobility is the Norm, Not the Exception. There are many applications running today that
       were designed in a business world where immobile terminals and devices on land lines
       connected to computers with a very fixed view of the world. Mobility technology is
       opening up new business-generation and service opportunities while enabling new
       employee work models such as telecommuting and ad hoc meeting collaboration. Driving
       business value requires integrating a mobility infrastructure with the existing static
       infrastructure – with the added security and performance issues inherent to mobility
       technology. Our point of view is that mobility technology is technically mature enough in
       2006, but that many enterprises have only a tepid, reactive strategy for generating business
       value. We will examine the market’s maturity, best practices and solution selection.

© 2006 AberdeenGroup, Inc.                                                          Telephone: 617 723 7890
260 Franklin Street                                                                       Fax: 617 723 7897
Boston, Massachusetts 02110-3112                                                         www.aberdeen.com
                                                  Why Aberdeen Group is Focusing on Enterprise IT Integration
Perspective                                                                                           Page 4



    5. Real-Time Business Intelligence (RTBI) demands the rapid consolidation of business-
       critical data to drive key operational performance metrics. The mostly large companies
       which have RTBI experience consider the business value generation so critical to success
       that the “how” becomes a company secret – a competitive weapon. Data warehouses and
       datamarts traditionally look at older information, meaning an insight into where the
       business was not where it is or will be. Our perspective is that the gradual “replumbing” of
       IT infrastructure with a service-driven architecture creates new opportunities to instrument
       enterprise IT management (e.g., transaction response times and server outages) as well as
       new business process management instrumentation that can drive much faster, “near real
       time”, universal, and lower level decision-making. However, there are significant issues in
       data management, quality, timeliness, and processing. Enterprise information integration
       (EII) is technology that promises to augment traditional data warehouse technology.
       Nevertheless, we view RTBI as a megatrend offering the promise of significant business
       benefits.
    6. Knowledge Worker (KW) Productivity is an attractive tangential target due to the
       requirement to manage mobility and the desirability to drive better RTBI, discussed above.
       Other technology vectors contributing to KW productivity include collaboration,
       messaging, smart phones, laptops, podcasting, conferencing, enterprise portals, project
       management and compliance, and improvements in enterprise applications such as
       Microsoft Office, ERP, sales force automation, and customer relationship management.
       Integrating this technology with the trends discussed above is a rich source of value
       generation. For example, best-in-class organizations show positive ROI for laptops merely
       with a few minutes of e-mail time gained while waiting for meetings to start.


Bottom Line: Act Tactically but Build Strategically
No reader can start with a clean sheet of paper and no legacy. The reality is that there is a legacy
and new investments are limited. We posit the need for a focus on synergy: over time, IT
investments end up being worth more than the sum of the individual projects. Our experience is
that the integration of information technologies and the integration of IT with business processes
are areas ripe for improving value: efficiency, speed, productivity, useful life, and quality.

Our perspective is that the tough but best approach is to have a strategic IT architecture that
incorporates the megatrends discussed above, and to use every tactical project opportunity to get a
step closer to making the development process, edge and datacenter infrastructure, mobility, and
data management intelligence-generation capabilities the big contributors to business value
generation.
The Enterprise Integration practice continually researches the market, assisting our IT management
readers in benchmarking their organization’s maturity, examining best practices, and studying the
lessons learned from technology solution selection and implementation. We invite IT managers to
participate in our fact-based research studies and to use the CIO portal at Aberdeen.com.




© 2006 AberdeenGroup, Inc.                                                          Telephone: 617 723 7890
260 Franklin Street                                                                       Fax: 617 723 7897
Boston, Massachusetts 02110-3112                                                         www.aberdeen.com
                                                                 Why Aberdeen Group is Focusing on Enterprise IT Integration
Perspective                                                                                                                   Page 5




                                                     Related Research
The SOA in IT Benchmark Report, December                           The Service-Oriented Architecture in the Supply
2005                                                               Chain Benchmark Report, October 2005
For Mid-Size Enterprises, SOA’s Benefits                           SOA Success Starts with IT Success, November
Begin with IT, January 2006                                        2005


   Author: Peter S. Kastner, Senior Research Analyst, Enterprise Integration Research
   peter.kastner@aberdeen.com
Founded in 1988, AberdeenGroup is the technology- driven research destination of choice for the global business executive.
AberdeenGroup has over 100,000 research members in over 36 countries around the world that both participate in and direct the most
comprehensive technology-driven value chain research in the market. Through its continued fact-based research, benchmarking, and
actionable analysis, AberdeenGroup offers global business and technology executives a unique mix of actionable research, KPIs, tools,
and services.
This document is the result of research performed by AberdeenGroup, which believes its findings are objective and represent the best
analysis available at the time of publication. Unless otherwise noted, the entire contents of this publication are copyrighted by
AberdeenGroup, Inc. and may not be reproduced, stored in a retrieval system, or transmitted in any form or by any means without prior
written consent by AberdeenGroup, Inc.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | enterprise-integration-perspective-2-cb6165 |
| title | Why Aberdeen Group is Focusing on Enterprise IT Integration |
| author | Peter S. Kastner |
| date | 2006-02-23 |
| type | employer-record |
| subject_domain | Enterprise IT integration; SOA; megatrends; programmer productivity; RTBI; mobility; datacenter; knowledge worker productivity |
| methodology | Aberdeen Perspective. Analyst opinion/megatrend analysis based on approximately two decades of market research observation. No survey data cited. |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Dated/published version of the Aberdeen Enterprise IT Integration practice launch perspective. Kastner identifies six megatrends driving IT integration opportunity: (1) Programmer productivity stuck at 1970s levels — legacy spaghetti code; SOA/composite applications/BPM as solutions; best-in-class frees 15% of IT budget with lower maintenance costs. (2) SOA and Web Services will constitute majority of development by ~2010. (3) Deconstruction of processing at core and edge — datacenter as JBOR; SANs; blade servers; virtualization; grid computing. (4) Mobility is the norm — technically mature in 2006 but enterprises have tepid reactive strategy. (5) Real-Time Business Intelligence (RTBI) — gradual replumbing creates new opportunities; EII as augmentation to data warehouses. (6) Knowledge Worker productivity — collaboration, messaging, smart phones, laptops, enterprise portals, CRM/ERP improvements. Bottom line: act tactically but build strategically; focus on IT investment synergy. February 23, 2006 dateline confirms this as the formal published version of the perspective.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 5 | High importance. This is the dated/published version of a foundational Kastner perspective establishing Aberdeen's Enterprise IT Integration practice and framing the six megatrends that informed all subsequent SOA research. The February 23 2006 dateline is significant. |
| **Relevance** | 5 | Directly relevant — core document framing the Kastner SOA research agenda and six megatrends. Published version for the archive vs. the undated internal DOC in SOA1. |
| **Prescience** | 5 | Six megatrends showed strong prescience: SOA/Web Services adoption majority by ~2010 (accurate); datacenter deconstruction to commodity racks (very accurate — hyperscale); mobility as norm (accurate); RTBI (accurate — became analytics/data lake paradigm); grid to cloud (accurate). Knowledge worker productivity and collaboration tools (accurate). |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (5)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | firm | [DEFERRED] | [DEFERRED] |
| Microsoft | company | [DEFERRED] | [DEFERRED] |
| Sun Microsystems | company | [DEFERRED] | [DEFERRED] |
| Cisco Systems | company | [DEFERRED] | [DEFERRED] |

### Technologies Referenced (16)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| Service-Oriented Architecture (SOA) | architecture-framework | industry-standard | growth | evolved |
| Composite Applications | application-architecture | multi-vendor | emerging | evolved |
| Business Process Modeling / Management (BPM) | process-management | multi-vendor | emerging | mature |
| Web Services (industry standards) | integration-protocol | industry-standard | growth | mature |
| Real-Time Business Intelligence (RTBI) | analytics | multi-vendor | emerging | evolved |
| Enterprise Information Integration (EII) | data-integration | multi-vendor | emerging | legacy |
| Enterprise Mobility / Mobile Computing | mobile-infrastructure | multi-vendor | growth | mature |
| Grid Computing | infrastructure | multi-vendor | emerging | evolved |
| Server Virtualization | infrastructure | multi-vendor | emerging | mature |
| Blade Servers | hardware | multi-vendor | growth | mature |
| Storage Area Network (SAN) | infrastructure | multi-vendor | growth | evolved |
| RFID (Radio Frequency Identification) | edge-technology | multi-vendor | emerging | mature |
| Enterprise Portal | application | multi-vendor | growth | evolved |
| Podcasting | collaboration | generic | emerging | evolved |
| Edge Computing / Edge Intelligence | infrastructure | multi-vendor | emerging | evolved |
| Aberdeen Spoke-Node-Ring (SNR) Framework | architectural-framework | Aberdeen Group | legacy | legacy |

### Observation Summary

- Total observations: 18
- By type: technical-claim: 12, prediction: 2, strategic-recommendation: 2, survey-finding: 1, competitive-analysis: 1
