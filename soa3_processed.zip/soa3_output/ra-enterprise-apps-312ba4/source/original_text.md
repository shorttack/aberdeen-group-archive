# Achieving More Value from Enterprise Applications

> Archived from: source/_raw_text.txt
> Original publication date: 2006-05
> Author: Peter S. Kastner, Aberdeen Group

---

## Original Document Text

   Achieving More Value
from Enterprise Applications
  An Aberdeen Benchmark Report




             May 2006


          — Sponsored by —
                                       Achieving More Value from Enterprise Applications Benchmark Report




              About the Research Organizations




Aberdeen delivers unbiased, primary re-     Enterprise Strategies newsletters provide
search that helps enterprises derive tan-   real-world business and technology infor-
gible business value from technology-       mation for managers of large, high-volume-
enabled solutions. Through continuous       transaction, high-availability, high per-
benchmarking and analysis of value          formance computer systems and infrastruc-
chain practices, Aberdeen offers a unique   tures.
mix of research, tools, and services to
                                        We offer the latest industry news, analyst
help Global Business Executives accom-
                                        and user perspective, and commentary on the
plish the following:
                                        latest enterprise, security, and storage trends
•   IMPROVE the financial and com- and technologies. From getting the most out
    petitive position of their business of your system to preparing for security
    now;                                breaches, Enterprise Strategies newsletters
                                        provide the information and insight to cost-
•   PRIORITIZE operational improve-
                                        effectively manage your IT resources.
    ment areas to drive immediate, tan-
    gible value to their business;      For more informatin, please visit
                                        www.esj.com
•   LEVERAGE information technology
    for tangible business value.




                            All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                     AberdeenGroup • i
       Achieving More Value from Enterprise Applications Benchmark Report




                                        Executive Summary



        B       usiness process management is not optimized due to poor integration at the in-
                formation technology (IT) level. In many enterprises, business processes consist
                of silos of enterprise application software connected by the slap-dash integration
        software equivalent of duct tape, chewing gum, and string. No organization runs on a
        single enterprise application, so, by definition, the integration of enterprise applications is
        a necessary reality. But often, this reality is the cause of enormous lost business value-
        generating opportunity as well as rancor between the IT department and business units.
        If the Industry Average IT department ran at the software-maintenance cost-efficiency of
        the Best in Class IT shops in Aberdeen’s maturity model, some $143 billion in 2006 sav-
        ings would be generated. We believe $20 billion in IT savings is readily achievable.
        The enterprise application silos were never designed to communicate freely with other
        applications that make up a typical business process in today’s complex, global economy.
        IT departments are spending inordinate amounts of expensive labor in a continuing ─ and
        often losing ─ battle to re-plumb the IT infrastructure that interconnects enterprise appli-
        cations in order to catch up with the perpetually changing business process requirements
        set by the line of business (LOB) units. Meanwhile, the LOB units’ staff and manage-
        ment are missing opportunities to generate business value due to lack of IT agility; a lack
        of visibility into business processes causes inefficiencies and lower customer satisfaction.
        No wonder more than half the enterprises we surveyed are unhappy with the ROI on their
        enterprise application investment.
        The good news is that the antiquated and brittle IT that routes business processes is being
        changed for the better. Enterprises are focusing on best-of-breed functionality, advanced
        business intelligence capabilities, and especially service-oriented architectures (SOA) as
        a technological means to, once and for all, eliminate the break-fix cycle that has plagued
        IT development and maintenance for more than a decade.

        Key Business Value Findings
        Moving information between business applications such as ERP and customer relation-
        ship management (CRM) often requires custom programming, which diverts time and
        attention from high business value projects, and delays value delivery. Half of the enter-
        prises Aberdeen surveyed for this report complain they have no flexibility in integrating
        business processes, and that the associated costs lead to trade-offs that prevent other im-
        portant investments. They lack the resources to keep up with the value-driven projects
        demanded by the LOBs.
        Until recently, there were few desirable approaches and even fewer simple solutions.
        Service-Oriented Architecture (SOA) technologies such as web services, XML, and open
        middleware are now seen by at least two-thirds of survey respondents as the custom
        means of improving enterprise application integration going forward. There are two
        components to this integration:
             •    SOA-enabled versions of key third-party applications such as enterprise resource
                  planning (ERP) from independent software vendors (ISVs) that make it easier to


All print and electronic rights are the property of AberdeenGroup © 2006.
ii • AberdeenGroup
                                        Achieving More Value from Enterprise Applications Benchmark Report



        modify internal application processes and get data into and out of these mono-
        liths;
    •   A standards-based SOA toolset that uses open or proprietary software products to
        create an SOA “fabric” that is much more agile, flexible, and potentially resilient
        than today’s IT duct tape for integrating applications with changing process re-
        quirements.
Nevertheless, some of the integration pain is self-inflicted: Industry Average and Laggard
organizations are likely to have poor IT process discipline, which is correctable. A meas-
urable minority of enterprises may be poorly suited for the ISV application software they
have installed.
Importantly, Best in Class practitioners are already saving more than 11% of their IT
budgets through lower software maintenance costs and are channeling those savings back
into LOB projects that have high business-value returns for the enterprise.

Implications & Analysis
We are at a technology inflection point that offers considerable long-term benefits to
most organizations, can be implemented project-by-project without a forklift-like re-
placement of infrastructure, and enjoys wide adoption among independent software ven-
dors (ISVs). Importantly, SOA includes numerous industry standards that are now built
into software products, making the application-to-application plumbing less complex and
risky.
By SOA-enabling their enterprise application products, ISVs make it easier for IT to get
information in and out of the application. Future business processes are likely to be com-
posites of multiple ISV and home-grown applications.
Some buyers feel they can upgrade to the SOA-enabled versions of their ERP applica-
tions and use them as their organizations’ SOA toolsets. We caution against such an ap-
proach as the ISV tools are designed for the unique technology and architecture of the
ISV’s application. Look closely at the ability of the ERP-SOA to integrate with legacy
platforms and applications. It’s likely that cross-application SOA development tools and
middleware connected to ISV SOA technology will be the norm, not the exception, by
2010.
Today’s composite applications lack sufficient built-in business intelligence capabilities
and don’t provide business process owners with a timely view into all operations. Real-
time process performance management (RPPM) is a functional requirement of enterprise
applications going forward.

Recommendations for Action
    •   Use the right application software. The root cause may be using the wrong
        software. Is integration complexity caused by a poor business process fit to the
        ISV application software installed? The payback in replacing the wrong ISV ap-
        plications for your business may be shorter than you imagine due to much-
        reduced ongoing requirements for customizations and business-specific integra-
        tion. This particularly applies to specialized vertical enterprises where general-



                             All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                     AberdeenGroup • iii
       Achieving More Value from Enterprise Applications Benchmark Report


                  purpose ISV applications require more customization, more often than vertical-
                  specific ISV applications need them.
             •    Consider upgrades to SOA-enabled versions of outside applications. Virtually
                  all third-party applications (such as ERP) offer or plan to offer SOA technology.
                  IT planners should consider upgrading to the SOA-enabled versions of these
                  third-party applications since the SOA technology offers an economical and for-
                  ward-looking means of getting information into and out of the ERP application.
             •    Look outside as well. The SOA technology in these third-party applications may
                  not be well suited to connect to other third-party applications, so consider look-
                  ing elsewhere for a robust, enterprise-quality SOA toolset.
             •    Avoid ending up with an “accidental architecture”. Most enterprises are im-
                  plementing a service-oriented architecture on a project-by-project basis. That
                  strategy places considerable weight on the need to carefully select the SOA infra-
                  structure and development tools. The key considerations are cross-platform,
                  cross-process and cross-application capability.
             •    Create an architecture, an architect role and competency center, and prioritize
                  a list of process-level integration points as projects. Give the top priority to pro-
                  jects that can return the highest and most immediate business value. Budget for
                  additional SOA-based training through a competency center to disperse compe-
                  tency throughout the development organization.
             •    Since LOB users are demanding increased visibility into business processes,
                  plan to build greater RPPM into new integration and remediation projects.
                  Also, consider compliance and governance issues early in the technology lifecy-
                  cle so your industry’s regulatory issues can be addressed systematically at the
                  service and infrastructure levels.
             •    Measure, measure, measure! Change is a process, which is not gauged in a sin-
                  gle, completed project. Best in Class IT organizations measure ROI at the begin-
                  ning and end of every project. They use a Japanese kanban approach by looking
                  for continuous improvements in business processes on a systematic basis. This
                  process discipline leads to numerous key performance metric (KPM) advantages,
                  especially in the reduction in software maintenance costs as a percentage of the
                  IT budget, where Best in Class IT organizations have an 11% IT budget advan-
                  tage over Industry Average organizations.




All print and electronic rights are the property of AberdeenGroup © 2006.
iv • AberdeenGroup
                                             Achieving More Value from Enterprise Applications Benchmark Report




                                    Table of Contents

About the Research Organizations ....................................................................... i

Executive Summary ............................................................................................. ii
   Key Business Value Findings..........................................................................ii
   Implications & Analysis ..................................................................................iii
   Recommendations for Action.........................................................................iii

Chapter One: Issue at Hand.................................................................................1
   Application Integration is a Formidable Challenge to Agility........................... 2

Chapter Two: Key Business Value Findings .........................................................4
   How Can We Take Enterprise Applications to the Next Level? ...................... 5

Chapter Three: Implications & Analysis...............................................................7
   Process and Organization ............................................................................. 8
   Technical Maturity and Technology Usage..................................................... 8
   Integrating Applications with SOA Technology ............................................... 9
   Challenges and Solutions Differ by Company Size........................................ 9
       Small Companies with less than US$50 Million in Revenue ................. 10
       Medium Companies with $50M to $1B in Revenue............................... 10
       Large Companies with Revenue Exceeding $1B .................................. 11
   Business Value Findings by Industry Group ................................................ 11

Chapter Four: Recommendations for Action ...................................................... 12
   Laggard Steps to Success........................................................................... 13
   Industry Average Steps to Success ............................................................. 14
   Best in Class Next Steps ............................................................................. 14

Featured Sponsors............................................................................................. 15

Sponsor Directory .............................................................................................. 17

Author Profile ..................................................................................................... 18

Appendix A: Research Methodology .................................................................. 19

Appendix B: Related Aberdeen Research & Tools ............................................. 21




                             All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                        AberdeenGroup
Achieving More Value from Enterprise Applications Benchmark Report




                                                         Figures

                 Figure 1: Top Enterprise Application Integration Challenges ................................2

                 Figure 2: Challenges Faced in Integrating Enterprise Applications ......................4

                 Figure 3: Application Integration Stumbling Blocks...............................................5

                 Figure 4: SOA Leads List of “Must Have” Integration Technologies .....................6

                 Figure 5: Top Challenges by Vertical Sector....................................................... 13


                                                          Tables

                 Table 1: Enterprise Application Integration Competitive Framework.....................7

                 Table 2: Challenges and Value of SOA to the Enterprise .....................................9

                 Table 3: Ways of Overcoming Deployment Challenges by Size ......................... 10

                 Table 4: Top Three Business Drivers by Industry Group .................................... 11




All print and electronic rights are the property of AberdeenGroup © 2006.
AberdeenGroup
                                                     Achieving More Value from Enterprise Applications Benchmark Report




                                              Chapter One:
                                             Issue at Hand

                •   Business processes today are supported by a composite of multiple enterprise
Key Takeaways




                    applications.
                •   Existing application integration technology is too complex, resource-consuming, and
                    slow to implement in order to keep up with business process changes.
                •   SOA technology from both application ISVs and development/middleware companies is
                    the preferred technology base for solving the application integration problem.




T       he problem of enterprise application integration has been growing for years. Vir-
        tually no organization is running itself with a single, third-party software applica-
        tion such as ERP. Different third-party applications are running all or critical parts
of the key business processes such as order fulfillment or customer relationship manage-
ment (CRM). Sometimes, they were purchased to run an organization that had been ac-
quired or merged. In other cases, they were selected as best-of-breed solutions to specific
process problems. For example, our September 2005 benchmark report, SOA in the Sup-
ply Chain, reported that only 18% of companies managed
                                                                     Competitive Framework
their supply chains with commercial software with few or no                      Key
modifications.
                                                                    The Aberdeen Competitive
Enterprises are stuck with multiple third-party software ap- Framework defines enter-
plications that were not designed to communicate business prises as falling into one of
process information freely and flexibly. It’s not the respon- the three following levels of
sibility of any one application software company to deliver practices and performance:
all the unique, custom process tweaks that make up every
single organization’s workflow.                                     Laggards (30%) —practices
                                                                    that are significantly behind
As a result, the IT department is forced to create custom the average of the industry
programs to execute transactions and move data between
these application silos to meet the changing requirements of Industry norm (50%) —
the line of business. Complicating the IT job of application practices that represent the
integration is the need to prolong the investment life of leg- average or norm
acy mainframe applications and to extend business processes Best in class (20%) —
to reach out over the Internet to B2B customers, suppliers, practices that are the best
and business partners.                                              currently being employed
Meanwhile, pressures on the LOB from competitive, global, and significantly superior to
or regulatory sources create a strong demand for changes the industry norm
and improvements in business processes. Today, many of
these changes involve marrying data and functionalities from multiple enterprise applica-
tions. Publicly traded companies in the U.S. have been forced to do top-down reviews of
processes to comply with the Sarbanes-Oxley Act and SEC regulatory changes. European
firms are dealing with evolving customer data privacy regulations, while the U.S. health-
care sector is dealing with patient data privacy regulations in the Health Insurance Port-
ability and Accountability Act (HIPAA). Finally, consider the new e-business opportuni-


                                         All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                                 AberdeenGroup • 1
Achieving More Value from Enterprise Applications Benchmark Report



        ties created over the past decade by the Internet with the creation of a whole new layer of
        outward-facing web service software to add an external B2C user interface to what has
        largely been an internal process focus by ISV enterprise applications.

        Application Integration is a Formidable Challenge to Agility
        The research for this report, based on surveys of more than 400 IT and LOB executives,
        indicates that the top challenge enterprises face is in redesigning business processes along
        with the IT in order to implement the process changes (Figure 1). As a corollary, a sig-
        nificant number of enterprises indicate that the costs of integrating enterprise applications
        are too high and that customizing technology creates challenges of its own, leading to
        delays. These challenges conflict with the top enterprise business goals, which are:
             •    Achieving better, more timely visibility into business operations;
             •    Reducing operating costs;
             •    Growing revenue; and
             •    Improving customer service.
        In short, prior approaches and technology used to solve the ongoing application integra-
        tion problems are too expensive, too slow to implement, and too complicated to flexibly
        modify when the next change comes along.

        Figure 1: Top Enterprise Application Integration Challenges

                                 Redesigning business processes                             52%

                                              High integration costs                      45%

                                 Customization-related challenges                       41%

                   Need for an incremental/evolutionary approach                     35%

                 Little flexibility in adapting to business processes               32%

                                                                        0%   20%     40%      60%
                                                                         % of respondents

                                                                             Source: AberdeenGroup, April 2006

        While Industry Average organizations today are focused on streamlining order fulfill-
        ment processes and enabling easier connections with suppliers, Laggard organizations are
        caught up in compliance, inventory management, process standardization, revenue
        growth, and regulatory compliance challenges. Best in Class organizations reported no
        specific challenges in enterprise application integration.
        Some of the pain is self-inflicted: Industry Average and Laggard organizations are much
        more likely to be behind in installing the current releases of enterprise applications and in
        documenting the integrations they have made, which makes new changes more difficult.



All print and electronic rights are the property of AberdeenGroup © 2006.
2 • AberdeenGroup
                                          Achieving More Value from Enterprise Applications Benchmark Report



Moreover, Industry Average and Laggard organizations have a poor record of using ROI
metrics either before or after project completion.
Integration using SOA technology is strongly
                                                    PACE Key — For a more detailed de-
preferred by organizations at all stages of
                                                    scription, see Appendix A
PACE maturity (See PACE Key). In 2006,
                                                    Aberdeen applies a methodology to benchmark
buyers have reached a point of education
                                                    research that evaluates the business pressures,
about SOA technology at which they are              actions, capabilities, and enablers (PACE) that
ready to move beyond planning and pilots            indicate corporate behavior in specific business
and toward a multi-pronged approach to              processes. These terms are defined as follows:
renovate their organizations’ enterprise ap-
                                                    Pressures — external forces that impact an
plication integration infrastructure – albeit on
                                                    organization’s market position, competitiveness,
a project-by-project basis. The approach            or business operations
many companies are taking includes the fol-
lowing steps:                                       Actions — the strategic approaches that an
                                                    organization takes in response to industry pres-
    •   Upgrading to the SOA versions of            sures
        their key enterprise applications,          Capabilities — the business process competen-
        such as CRM and ERP;                        cies required to execute corporate strategy
    •   Building a middleware and develop-          Enablers — the key functionality of technology
        ment toolset that supports standards        solutions required to support the organization’s
        and is interoperable with the SOA-          enabling business practices
        enabled application’s tools;
    •   Incorporating business process modeling, business intelligence, rules, and man-
        agement technology;
    •   Implementing inward-facing SOA integration, creating composites of multiple
        applications, and
    •   Building outward-facing web services delivered to browser-based applets. Cus-
        tomer-centric web services are one class of outward-facing SOA applications;
        supplier B2B applications are another.




                              All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                      AberdeenGroup • 3
Achieving More Value from Enterprise Applications Benchmark Report




                                              Chapter Two:
                                       Key Business Value Findings
        Key Takeaways




                        • SOA-enabled enterprise applications are only a partial solution to integration issues.
                        • Consider how to both align the business process to the ISV application’s capabilities and
                          align the ISV software to the business process requirements.
                        • Think strategically and act tactically; build an SOA infrastructure for the long-term.




        T      he imperfections of the enterprise applications in place today are a major stum-
               bling block to delivering efficient business processes that are tuned to the enter-
               prise’s needs (Figure 2). The reasons are fairly straightforward: Each ISV’s appli-
        cations use a different architecture and technology base. These applications must be ex-
        tended across processes to connect them effectively. Over the past decade, a typical or-
        ganization has employed a variety of products to extend ISV applications to the web, to
        other partners and suppliers outside the enterprise, and to connect applications in order to
        yield a composite view of the process.

        Figure 2: Challenges Faced in Integrating Enterprise Applications
                             Integration work delayed the enterprise from
                        taking timely advantage of system enhancements                                    49%

                              Integration work diverted time and attention                             45%
                                                from other critical projects
                                      We had (or have) to install custom                            40%
                              extensions or code, relying on outside help

                                           Integration work was too costly                      34%

                                 Integration work was difficult to manage                       33%

                                                                          0% 10% 20% 30% 40% 50% 60%
                                                                                    % of respondents

                                                                                     Source: AberdeenGroup, April 2006

        All of this technology is daunting to the typical enterprise’s IT organization. The most
        common example of this is the delay penalty incurred when the IT department has to in-
        stall and pay for a new version of an application, but cannot generate value from it until
        the necessary integration software additions are made to connect the new version to all
        the enterprise’s processes that depend on the applications. This customization cycle can
        last for months.
        The most common IT complaints about enterprise applications are a lack of flexibility in
        business process integration, an inability to obtain enough business intelligence and que-


All print and electronic rights are the property of AberdeenGroup © 2006.
4 • AberdeenGroup
                                          Achieving More Value from Enterprise Applications Benchmark Report



ries, and high integration costs that soak up budget funds that could otherwise be used to
drive innovation (Figure 3).

Figure 3: Application Integration Stumbling Blocks

           No flexibility in business process
                   integration/manipulations                                      51%

        Can’t obtain deep-enough business
                                                                                 49%
          intelligence reporting and queries
              High integration costs prevent                                42%
        new investments in needed features
          Monolithic application architecture                              41%
         forces costly and complex changes
                Can’t manage or implement                               36%
               real time business processes
                                                0% 10% 20% 30% 40% 50% 60%
                                                      % of respondents

                                                                 Source: AberdeenGroup, April 2006


How Can We Take Enterprise Applications to the Next Level?
Today’s reality is that there are no viable alternatives to enterprise applications from
ISVs. The investments in homemade and purchased applications ─ plus all those difficult
modifications to get to where we are in enterprise application integration ─ are measured
in the hundreds of billions of dollars. Every organization has an application legacy that
must be moved forward with changing business requirements.
In many cases, ISVs have introduced SOA-enabled versions of their application products.
Upgrading to these versions is the first step toward obtaining more value.
All the SOA-enabled ISV applications we have reviewed come with SOA software tools
and interfaces of some kind, or they’re on the horizon for delivery. Such applications
typically provide a more extensive, flexible, and broader entrée to getting information
into and out of the application. For this reason, using the SOA technology in ISV appli-
cations is the next step toward a more workable infrastructure.
For many mid-size and large enterprises, the ISV application-focused SOA technology
will be insufficient. The ISVs do not guarantee that the particular SOA technology they
use inside their applications is suited for all of the client, web, e-commerce, B2B, and
application integration across legacy applications that forward-looking organizations are
planning.
The goal of most organizations in our survey is an SOA infrastructure capable of con-
necting all of an enterprise’s key applications, based on a question that asked about re-
spondents’ “must have” technologies (Figure 4).




                               All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                       AberdeenGroup • 5
Achieving More Value from Enterprise Applications Benchmark Report



        Figure 4: SOA Leads List of “Must Have” Integration Technologies

                                           Web services                                       76%

                Built-in, open middleware for integration                                 66%

                                        XML standards                                     66%
                       Business-process execution and
                        manipulation across processes                                  60%

         Advanced business intelligence manipulations                               55%

                    Open messaging-based architecture                               55%

                            Business process modeling                               54%

             Rule-based toolset for configuring changes                            53%

                               Event-driven architecture                          51%

             Operating in a heterogeneous environment                            49%

                             Best-of- breed functionality                        49%

        Overall compliance within an SOA infrastructure                          48%

                 Composite applications interoperability                        47%

                                                        0%       20%     40%      60%        80%
                                                             % of respondents that ranked
                                                              a technology as "must-have"

                                                                               Source: AberdeenGroup, April 2006

        There are two other improvements that are demanded in next-generation enterprise appli-
        cations: advanced business intelligence and support for business process events. The
        crux of the problem is the need for better, real-time views into business processes. LOB
        owners cannot wait hours, days, or weeks to see what today’s bottlenecks are. They want
        more business process-focused business intelligence and analytics ─ no matter how many
        application silos are touched.
        Business process event notification is a powerful tool that puts the computer in the loop
        and takes more people out of it. Computer-based rules keep the process flowing until an
        out-of-parameter metric or rule is triggered with an appropriate exception compliance
        notification up the organization’s chain of command.




All print and electronic rights are the property of AberdeenGroup © 2006.
6 • AberdeenGroup
                                                          Achieving More Value from Enterprise Applications Benchmark Report




                                          Chapter Three:
                                     Implications & Analysis

                 Best in Class IT organizations:
                 •   Have the right ISV software for functionality, at the current release, with a strong proc-
Key Takeaways




                     ess for managing customizations by ROI.
                 •   Have overcome the significant problems of integration.
                 •   Have in-house competency to perform LOB integration requests and keep the infra-
                     structure up to date.
                 •   Have the IT process maturity that leads to lower integration and maintenance costs and
                     frees up considerable capital for LOB innovation.




A        s shown in Table 1, survey respondents fell into one of three segments – Lag-
         gard, Industry Average, or Best in Class based on Aberdeen’s Competitive
         Framework model for IT organizations, which weights the cost of application
maintenance as a percentage of IT budget and the percent of IT budget spent on deliver-
ing innovations to the LOB. The three segments are analyzed further based on their char-
acteristics in four key categories:
                (1) Process (application maturity and experience, success with application integra-
                    tion, discipline in measuring business value);
                (2) Organization (corporate focus/philosophy, level of collaboration among stake-
                    holders, IT organization’s focus and the level of centralization);
                (3) Technical Maturity (competency in performing application integration, ability
                    to complete integration in-house); and
                (4) Technology (application modernity, functional adequacy, discipline in mainte-
                    nance).

Table 1: Enterprise Application Integration Competitive Framework
                                Laggards                      Industry Average             Best in Class
  Process                      Recent adopter of mod-        Considerable experience      Considerable experience
                               ern applications. Little      with too many applica-       and integration process
                               experience in integra-        tions. Process not suc-      is successful. ROI meas-
                               tion. ROI seldom meas-        cessful. ROI planned         ured before and after
                               ured.                         before project.              implementation.
  Organization                 Business focus on inven-      Focus is on order fulfill-   No single factor domi-
                               tory management, reve-        ment, CRM, real-time         nates. IT is decentral-
                               nue growth, and process       visibility.                  ized and especially LOB-
                               standardization. Highly                                    focused.
                               centralized.




                                           All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                                   AberdeenGroup • 7
Achieving More Value from Enterprise Applications Benchmark Report



                               Laggards                    Industry Average              Best in Class
         Technical            Low competency leads        Moderate competency,         No significant challenges
         Maturity             to high costs, delays,      but integration is still a   in application integration.
                              delivery inconsistency.     pain point. May need         Work done internally.
                              Needs outside help.         outside help.
         Technology           Applications antiquated     Behind at least one re-      Well-documented and
                              and inadequate. Cus-        lease. Adequate func-        managed. May need
                              tomizations are poorly      tionality. More integra-     more integration, but
                              documented.                 tion needed.                 may be doing everything
                                                                                       required.

                                                                                Source: AberdeenGroup, April 2006


        Process and Organization
        •    In the process category, BIC firms that
                                                               BIC firms have fewer problems
             have low maintenance costs as a percent-
             age of IT budget also show high                   with application integration as a
             innovation rates and considerable                 result of superior control over IT
             discipline in IT process management.              software maintenance costs re-
             They generally have relatively few                sulting from application integra-
             problems with application integration.            tion and LOB changes.
             Laggards typically have poor controls
             over IT change management and rely on
             outside services. They also are likely to
             have obsolescent versions of application software or the application software’s func-
             tionality is a poor match for the enterprise’s LOB processes.
        •    Organizationally, the BIC IT shop has no single pain point. It is disciplined and fo-
             cused on continually responding to LOB changes and optimizations. Laggards focus
             on unsophisticated business metrics such as revenue growth. They tend to be highly
             centralized, but least able to cope with change; they seldom measure business value
             before or after implementing a project.

        Technical Maturity and Technology Usage
        Best in Class and Industry Average organizations have numerous ISV applications which
        they have worked with for years. However, BIC has superior IT processes and talent,
        enabling them to show no significant challenge in managing the application integration
        process or the technologies involved. Industry Average organizations have a propensity
        to be a version or more behind the ISV’s latest release. Since SOA and other new tech-
        nologies are most likely in the latest releases, average and laggard organizations will be
        unable to leverage the flexibility of SOA technology – a widening gap between SOA-
        enabled haves and have-nots is a point of technology differentiation.
        Laggards are most likely to have self-described inadequate application functionality
        while being least likely to cope with change-driven application integration without out-
        side assistance. Yet these same organizations have the highest percentage of the IT
        budget dedicated to software maintenance. Since laggards have difficulty absorbing new


All print and electronic rights are the property of AberdeenGroup © 2006.
8 • AberdeenGroup
                                                   Achieving More Value from Enterprise Applications Benchmark Report



technology, a fling at SOA without shoring up the application functionality and technical
maturity issues is problematic on its face.

Integrating Applications with SOA Technology
Table 2 is a view of the challenges and opportunities opened up through the use of SOA
technology, the clearest course of future action indicated by research participants.

Table 2: Challenges and Value of SOA to the Enterprise
                                             The SOA Response
           Challenges                          to Challenges                      SOA Incremental Value
 1. Ability to re-use data and          Single source of data or function-    Reuse eliminates need for redun-
 functionality without duplicating      ality that can be accessed in real-   dant data sources and greatly ac-
 databases or applications              time as required                      celerates development time of new
                                                                              applications
 2. Eliminate need to create            Standard communications proto-        Greatly reduces the time and cost
 unique interfaces for individual       col and interface between appli-      incurred by current integration
 applications to integrate with         cations and data sources              methods
 data sources
 3. Increase effectiveness of           Access real-time, appropriate         Include real-time trading partner
 electronic communications with         product, forecast, production in-     information in planning, execution,
 trading partners                       formation from partners' applica-     and decision-making processes
                                        tions
 4. Process and application flexi-      Applications broken down into         Configure process workflow to
 bility to comply with trading part-    discrete business services that       quickly accommodate unique trad-
 ners' requests                         can be used to support multiple       ing partner requests using func-
                                        processes                             tionality and data from multiple
                                                                              applications
 5. Data accuracy and ease of           Master data management tools          Eliminates costly rework and errors
 replication                            and processes that ensure data        created by old, inaccurate data
                                        integrity
 6. Quickly integrate mergers and       Integrate with legacy systems         Quickly aggregate information
 acquisitions into enterprise proc-     using standard interfaces; share      required for management reporting
 esses and systems                      required functionality using busi-    and consistent operation
                                        ness services
 7. Reduce process performance          Workflow management directs           Implement tailored business proc-
 failures                               both automated and human activi-      esses to meet specific require-
                                        ties                                  ments; monitor business activity to
                                                                              identify process breakdown and
                                                                              root causes
 8. Increase information velocity       Information made available in         Manage business processes with
                                        real-time by data sources             most current information for mak-
                                                                              ing decisions
llenges The SOA Response to Challenges SOA Incremental Value
                                                                        Source: AberdeenGroup, September 2005


Challenges and Solutions Differ by Company Size
Companies are overcoming challenges with approaches that differ by company size as
measured by revenue (Table 3). Small companies are typically tied to the capabilities of
their ISV software: they lack extensive customization resources. Mid-size companies


                                       All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                               AberdeenGroup • 9
Achieving More Value from Enterprise Applications Benchmark Report



        have the highest likelihood of “junking” older integration middleware software for SOA
        because they lack the resources and skills of large companies to cope with challenges
        driven by legacy middleware complexity. Large companies are most likely to replace
        existing enterprise applications with SOA versions, but less likely to remove API-driven
        legacy middleware than mid-size counterparts.

        Table 3: Ways of Overcoming Deployment Challenges by Size


                      How did your company                            Small     Mid ($50M          Large
                    overcome these challenges?                       (<$50M)    to $999M)         (>$1B)

            Deploying newer, more modern applica-
            tions                                                     65%           61%            50%
            Aligning business processes to software
            capabilities                                              78%           47%            50%
            Aligning software capabilities to business
            processes                                                 65%           47%            40%
            Replacing legacy applications with applica-
            tions enabled by a service-oriented archi-
            tecture (SOA)                                             22%           33%            55%
            Moved from API-driven integration to stan-
            dards-based, messaging-driven integration                 17%           44%            35%

                                                                               Source: AberdeenGroup, April 2006

        Small Companies with less than US$50 Million in Revenue
        Small companies in this study are 65% more likely than larger companies to align their
        business processes with the functionality provided in their ISV applications. They are
        half as likely as larger companies to have customization challenges because they are not
        as process- and organizationally complex. But smaller companies have more difficulty in
        redesigning business processes, relying on best-of-breed functionality from ISV applica-
        tions, and noting higher integration costs when they stray outside the application soft-
        ware’s functionality. These higher costs are more likely to displace innovation invest-
        ments. Small companies show the poorest IT governance practices; project ROI is seldom
        tracked. Finally, small companies are least likely to be completely satisfied with the ISV
        application functionality.

        Medium Companies with $50M to $1B in Revenue
        Medium-size companies have few distinguishing traits. Like smaller companies, they are
        somewhat dependent on the enterprise application functionality, but less so than smaller
        companies and more than large companies. Like smaller companies, the mid-size firms
        demand built-in open middleware and advanced business intelligence capabilities in ISV-
        provided applications. Medium-size companies are most likely to replace older middle-
        ware software used in integration for SOA. Overall, medium companies are moderately
        challenged by enterprise integration.



All print and electronic rights are the property of AberdeenGroup © 2006.
10 • AberdeenGroup
                                           Achieving More Value from Enterprise Applications Benchmark Report



Large Companies with Revenue Exceeding $1B
Large companies are less institutionally challenged by business process redesign and in-
tegration issues than smaller companies, but the agility comes at a high absolute cost.
With many distributed processes across a disparate IT infrastructure silos, large compa-
nies are particularly challenged to provide a complete information picture to knowledge
workers and with inconsistent data standards. Large companies are most likely to adopt
web services as a means to integrate applications and most likely to force WS-* standards
on SOA projects. IT governance is better — but not uniformly laudable — than at small
enterprises.

Business Value Findings by Industry Group
The stand-out pressure across all industries is the need to get better visibility into busi-
ness processes in real-time, which will be the subject of a summer 2006 Aberdeen Group
study (Table 4).

Table 4: Top Three Business Drivers by Industry Group
                                                               Con-                       Public
      Business Driver           Discrete      Process         sumer        Services       Sector

Better real-time visibility
into business operations          65%           67%            65%           80%           75%
Reducing operating costs          58%           58%            41%           40%           50%
Revenue growth                    23%           33%            59%           44%            n/a-
Mandates to improve cus-
tomer service                     26%           17%            35%           44%           38%
Streamlining of order ful-
fillment processes                26%           42%             6%           24%           13%

                                                                   Source: AberdeenGroup, April 2006
•   Discrete and Process Manufacturing sectors are most focused on reducing operat-
    ing costs, a challenge of globalization. Application customization is a problem,
    which is being solved by deploying more modern application versions and by align-
    ing business processes with the application’s capabilities.
•   Consumer Goods companies are driven by revenue growth. This sector has no dis-
    tinguishing characteristics about responding to integration issues.
•   Services sector is especially challenged to redesign business processes, and has the
    highest pain level for better visibility into business processes in real-time. This sector
    is also aligning business processes with application functionality, and most likely to
    move from an API-driven middleware architecture to a message-based SOA architec-
    ture.
•   Public sector is most likely to have inflexible business processes that demand cus-
    tomization of ISV applications or in-house code requiring integration. This sector
    also suffers from lengthy and incomplete integration projects.



                              All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                     AberdeenGroup • 11
Achieving More Value from Enterprise Applications Benchmark Report




                                              Chapter Four:
                                        Recommendations for Action

                          •   If an ISV application has adequate functionality for your organization, plan to upgrade to
        Key Takeaways




                              the SOA-enabled version.
                          •   SOA is neither a panacea nor a free lunch. Look at organizational discipline improve-
                              ments and SOA competency training before leaping.
                          •   Measure twice and cut once: getting to an enterprise-wide SOA infrastructure will take
                              several years of planned but incremental growth and deployments..




        A      pplication integration is a never-ending process — it is unlikely that a thriving
               business will reach a point of business-process stasis. Unfortunately, too many
               organizations have not invested in the training and management discipline to
        make this ongoing application integration process a well-oiled machine.
        It is clear from this study that the next generation of business applications will have deep
        business intelligence views into complex LOB processes, and many organizations will
        move towards a machine-in-loop model of business process management where humans
        deal with the exceptions to the rules. Both will result in better management due to trans-
        parency and immediacy. Notably, survey respondents believe SOA technology is the
        critical technology “glue” that will make application integration less complex, more re-
        peatable, faster, and more flexible.
        The business challenges organizations face vary by vertical industry sector (Figure 6):
        •               The public sector is most challenged in customization and related costs. This ex-
                        plains the worldwide interest in e-government.
        •               Services are plagued by high integration costs.
        •               Discrete and process manufacturers are more concerned by flexibility in redesign-
                        ing business processes, and customization to fit changing business processes. Proc-
                        ess is particularly plagued with three-fifths lacking flexibility in adapting software to
                        business processes, while half of discrete manufacturers have the same problems.
        •               Consumer products companies complain most about the challenges of radical
                        changes: they want a more measured, evolutionary approach.




All print and electronic rights are the property of AberdeenGroup © 2006.
12 • AberdeenGroup
                                        Achieving More Value from Enterprise Applications Benchmark Report




Figure 5: Top Challenges by Vertical Sector

  Percent of companies in each sector that reported
  the challenge among their top three challenges

     16%
                                    13%                        Cost of
                                                 38%
               30%                                             updates/upgrades
                                    25%
     48%                   41%                   13%
                                    17%
                                                               Little flexibility in adapting
               60%         12%                   50%           to business processes
     32%                            63%
                                                               Need for an
                           59%                   25%
     35%       40%                                             incremental/evolutionary
                                                               approach
                                    42%
               30%         41%                   63%           High integration costs
     52%

               40%         24%                                 Customization-related
                                    75%
                                                 50%           challenges
     48%
               30%
               30%         35%
                                                               Redesigning business
   Discrete   Process Consumer Services         Public         processes
                                                Sector
                      Vertical Sector
                                                               Source: AberdeenGroup, April 2006


Laggard Steps to Success
   1. Evaluate the ISV application set for functional completeness.
       Do not charge off with new technology if the ISV application horse is not up to
       the task. There are numerous modern applications for use in-house or through an
       application service provider (ASP). On a five-year basis, it is likely less expen-
       sive to change application horses for a modern technology base with the right
       functionality than pay outside service providers to patch up an inadequate appli-
       cation. Consider buying the best-fit vertical-market-specific ISV application, and
       outsourcing to an ASP.
   2. Install the ISV’s SOA-enabled application versions. Train on this baseline.
       Start with a solid technology base, which includes the ISV application versions
       that incorporate SOA technology. One approach: Get the ISV’s upgrade, install
       it, and use it as a baseline for training and learning about SOA.
   3. Conduct an SOA readiness assessment.
       Many service companies now provide comprehensive SOA readiness assess-
       ments. Such an assessment becomes the planning roadmap for technology acqui-
       sition, application integration priorities for individual projects, and organiza-
       tional readiness to stage a new integration technology rollout.




                            All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                   AberdeenGroup • 13
Achieving More Value from Enterprise Applications Benchmark Report



        Industry Average Steps to Success
             1. Perform gap analysis on ISV SOA application versions.
                While every current version may be SOA-enabled, it is unlikely they will all
                mesh and merge seamlessly into a full-blown enterprise SOA infrastructure.
                First, determine how well individual applications integrate with the functionality
                of their SOA peers. Then, consider how these applications will integrate into a
                full-blown SOA infrastructure that includes an enterprise service bus (ESB),
                business process management (BPM), a metadata repository, and a cross-
                platform development environment including middleware.
             2. Build your SOA infrastructure project by project.
                Prioritize LOB requirements for application integration based on ROI or other
                metrics. Map the technology requirements of the project to the overall infrastruc-
                ture plan, and buy accordingly.
             3. Work on the organizational and technology maturity issues.
                Integration competency is a hallmark of Best in Class organizations, as is organ-
                izational discipline. Measure and drive down integration costs and timeframes
                while improving skill sets.
             4. Catch up on the integration backlog.
                A hallmark of Best in Class organizations is the lack of significant application in-
                tegration issues. That means the IT organization is scaled and competent at keep-
                ing the backlog manageable and completion rates timely for the LOB. The impli-
                cation is that a new SOA technology toolset must be completely mastered.

        Best in Class Next Steps
             1. Build it and they will come.
                Best in Class organizations are already mature in IT organization, technology se-
                lection and technology integration areas. Their opportunity is to build out an
                SOA infrastructure that integrates the enterprise’s applications while providing
                an outward facing posture to customers, partners, and suppliers.
             2. The next stage is real-time BPM with machine-in-the-loop.
                Several Aberdeen studies point to the need for deeper visibility into active busi-
                ness processes with RPPM. First, look to BPM software with knowledge man-
                agement, analytics, and rules-based exception handling. Next, use exception-
                based application integration reporting to work with LOB process owners and
                drive out human bottlenecks to efficient process flow. Use rules-based technol-
                ogy to make decisions and ensure compliance, removing unnecessary human in-
                tervention.
             3. Plan for the heterogeneous SOA integration environment.
                SOA is no one trick pony. Its architecture in many larger organizations will be
                heterogeneous, with the need to plan for complex, phased implementation across
                operating system platforms, applications, geographies, and lines of business.
                Succeeding at that will require enterprise-level planning and governance.




All print and electronic rights are the property of AberdeenGroup © 2006.
14 • AberdeenGroup
                                        Achieving More Value from Enterprise Applications Benchmark Report




                            Featured Sponsors




FlexiInternational® provides a suite of financial accounting solutions that provide a
higher level of financial intelligence. For over a decade, Flexi has been providing ac-
counting solutions to the mid and enterprise markets offering financial services, banking,
and other service organizations a flexible and scalable solution.
Flexi’s SOA provides the most flexible integration options available including web ser-
vices and COM+. FlexiSmartClient™ Suite offers a series of accounting components that
are customizable and can be integrated into any organizations business processes. Flex-
iSmartClient was developed using the latest technologies of .Net and architected as a
SmartClient providing the rich GUI experience users expect. For more information, visit
www.Flexi.com.




With more than 2,150 customers worldwide, Made2Manage Systems has a 20-year track
record of delivering enterprise resource planning software and a broad range of services
that meet the unique market specifications of more than 30 manufacturing sectors, in-
cluding industrial and commercial machinery, fabricated metals, rubber and plastics,
electronics, analytical and measuring equipment, furniture and fixtures, durable goods,
and metals, wire and cable. Made2Manage Systems’ sustained leadership position in the
ERP marketplace is built on a commitment to fostering productive, long-lasting customer
relationships, developing a quality product line based on unique industry specifications,
and providing excellence in customer support and professional services. For further in-
formation, visit www.made2manage.com.




                             All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                    AberdeenGroup • 15
Achieving More Value from Enterprise Applications Benchmark Report




        SoftBrands, Inc. is a global leader in providing solutions for small to medium-sized busi-
        nesses in the manufacturing and hospitality industries worldwide. With more than 4,000
        customers in over 60 countries now actively using its manufacturing and hospitality
        products, SoftBrands has established a global infrastructure for distribution, development
        and support of enterprise software. The company, headquartered in Minneapolis, Minne-
        sota, has more than 550 employees with branch offices in Europe, India, Asia, Australia
        and Africa. Additional information can be found at www.softbrands.com.




All print and electronic rights are the property of AberdeenGroup © 2006.
16 • AberdeenGroup
                                      Achieving More Value from Enterprise Applications Benchmark Report




                           Sponsor Directory

FlexiInternational Software, Inc.
856 Third Avenue South
Naples, FL 34102
(239) 298-5700
www.Flexi.com
Sales@Flexi.com



Made2Manage Systems, Inc.
450 E 96th St, Suite 300
Indianapolis IN 46240
317-249-1200
800-626-0220 toll-free
www.made2manage.com
info@made2manage.com




SoftBrands
Two Meridian Crossings
Suite 800
Minneapolis, MN 55423
1-800-586-7858
www.softbrands.com
info@softbrands.com




                           All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                  AberdeenGroup • 17
Achieving More Value from Enterprise Applications Benchmark Report




                                              Author Profile

        Peter S. Kastner
        Research Vice President and Co-Founder
        Enterprise Integration Research
        AberdeenGroup, Inc.
        Peter S. Kastner conducts research in the integration of information technology across
        and among enterprises and their customers and employees. He focuses on the near-term
        business value-generation tradeoffs faced by technology and business managers who
        must deliver repeated, short-term value gains while refreshing the enterprise infrastruc-
        ture to take advantage of evolving technology, standards, practices, and regulations. His
        practice covers technology integration, including application development; software ar-
        chitectures and middleware; core architecture, processing and networking; edge devices,
        data and business intelligence and integration; security integration; managed services and
        integration of third-party services; and enterprise business process and technology man-
        agement.




All print and electronic rights are the property of AberdeenGroup © 2006.
18 • AberdeenGroup
                                             Achieving More Value from Enterprise Applications Benchmark Report




                                   Appendix A:
                              Research Methodology



B       etween January and March 2006, AberdeenGroup examined the application inte-
        gration competency, experiences, and intentions of enterprises in discrete manu-
        facturing, process manufacturing, consumer product, service, and government
industries. Responding IT and line-of-business (LOB) technology executives completed
an online survey that included questions designed to determine the following:
    •      The degree to which application integration issues impact corporate and IT strate-
           gies, operations, and financial results;
    •      The structure and effectiveness of existing application integration management
           procedures;
    •      Current and planned use of technology to improve application integration and the
           ROI of ISV application investments;
    •      How enterprises are extracting more value from their enterprise applications (es-
           pecially ERPs and legacy customized applications); and
    •      Whether application integration will enable flexible business process integration,
           manipulation, and orchestration based on more flexible workflows.
Aberdeen supplemented this online survey effort with telephone interviews with select
survey respondents, gathering additional information on enterprise applications manage-
ment strategies, experiences, and results.
The study aimed to identify emerging best practices for application integration and pro-
vide a framework by which readers could assess their own enterprise application integra-
tion capabilities.
Responding enterprises covered the following:
•   Job title/function: The research sample included respondents with the following job
    titles:
        Title                                                     Percent of Respondents
        Senior Management (CEO, CFO, COO)                                    11%
        CIO/IT Leader                                                        15%
        (Senior) Vice President                                              6%
        Director                                                             19%
        Manager                                                              25%
        Staff                                                                6%
        Internal Consultant                                                  11%
        Other                                                                6%


                                  All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                         AberdeenGroup • 19
Achieving More Value from Enterprise Applications Benchmark Report



        •    Industry: The research sample included respondents from 27 industrial categories.
             Discrete manufacturing represents 35% of the sample, including 17% from high tech
             hardware and software. Process manufacturing represents 12% of the survey popula-
             tion and consumer 14%. Services represent 30%, including 8% in financial services
             and banking. Government and education in the public sector represent 9% of the
             survey population.

        •    Geography:
                                                                       Percent of Respondents
              North America (Includes USA, Canada, Mexico)                      55%
              Europe                                                            23%
              Asia/Pacific                                                      8%
              Middle East, Africa                                               7%
              South/Central America and Caribbean                               6%

        •     Company size:
                                                                        Percent of Respondents
              Less than $50 million in annual revenue                            31%
              $50M to $249M                                                      20%
              $250M to 499M                                                      17%
              $500M to $999M                                                     10%
              $1 billion to $5 billion                                           17%
              More than $5 billion                                               4%

        Solution providers recognized as sponsors of this report were solicited after the fact and
        had no substantive influence on the direction of the Achieving More Value from
        Enterprise Applications benchmark report. Their sponsorship has made it possible for
        AberdeenGroup to make these findings available to readers at no charge.




All print and electronic rights are the property of AberdeenGroup © 2006.
20 • AberdeenGroup
                                        Achieving More Value from Enterprise Applications Benchmark Report




                        Appendix B:
             Related Aberdeen Research & Tools

Related Aberdeen research that forms a companion or reference to this report includes:
    •   The Service-Oriented Architecture (SOA) in IT Benchmark Report (December
        2005)
    •   The Service-Oriented Architecture in the Supply Chain Benchmark Report (Sep-
        tember 2005)
    •   The 2005 CIO Agenda — CIO Disruptors (July 2005)
    •   SOA Success Starts with IT Success (November 2005)
    •   The ESB in the Land of SOA (November 2005)
Information on these and any other Aberdeen publications can be found at
www.Aberdeen.com.




                             All print and electronic rights are the property of AberdeenGroup © 2006.
                                                                                    AberdeenGroup • 21
                                                        Achieving More Value from Enterprise Applications Benchmark Report




AberdeenGroup, Inc.                              Founded in 1988, AberdeenGroup is the technology-
260 Franklin Street, Suite 200                   driven research destination of choice for the global
Boston, Massachusetts                            business executive. AberdeenGroup has over 100,000
02110-3112                                       research members in over 36 countries around the world
                                                 that both participate in and direct the most comprehen-
USA
                                                 sive technology-driven value chain research in the
Telephone: 617 723 7890                          market. Through its continued fact-based research,
Fax: 617 723 7897                                benchmarking, and actionable analysis, AberdeenGroup
www.aberdeen.com                                 offers global business and technology executives a
                                                 unique mix of actionable research, KPIs, tools,
© 2006 AberdeenGroup, Inc.                       and services.
All rights reserved
April 2006
The information contained in this publication has been obtained from sources Aberdeen believes to be reliable, but
is not guaranteed by Aberdeen. Aberdeen publications reflect the analyst’s judgment at the time and are subject to
change without notice.
The trademarks and registered trademarks of the corporations mentioned in this publication are the property of their
respective holders.
  THIS DOCUMENT IS FOR ELECTRONIC DELIVERY ONLY
                      The following acts are strictly prohibited:
                             • Reproduction for Sale
                             • Transmittal via the Internet
                     Copyright © 2006 AberdeenGroup, Inc. Boston, Massachusetts



Terms and Conditions
Upon receipt of this electronic report, it is understood that the user will and must fully comply with the
terms of purchase as stipulated in the Purchase Agreement signed by the user or by an authorized
representative of the user’s organization. Aberdeen has granted this client permission to post this report
on its Web site.

This publication is protected by United States copyright laws and international treaties. Unless otherwise
noted in the Purchase Agreement, the entire contents of this publication are copyrighted by Aberdeen
Group, Inc., and may not be reproduced, stored in another retrieval system, or transmitted in any form or
by any means without prior written consent of the publisher. Unauthorized reproduction or distribution of
this publication, or any portion of it, may result in severe civil and criminal penalties, and will be
prosecuted to the maximum extent necessary to protect the rights of the publisher.

The trademarks and registered trademarks of the corporations mentioned in this publication are the
property of their respective holders.

All information contained in this report is current as of publication date. Information contained in this
publication has been obtained from sources Aberdeen believes to be reliable, but is not warranted by the
publisher. Opinions reflect judgment at the time of publication and are subject to change without notice.


Usage Tips
Report viewing in this PDF format offers several benefits:
        • Table of Contents: A dynamic Table of Contents (TOC) helps you navigate through the
            report. Simply select “Show Bookmarks” from the “Windows” menu, or click on the bookmark
            icon (fourth icon from the left on the standard toolbar) to access this feature. The TOC is both
            expandable and collapsible; simply click on the plus sign to the left of the chapter titles listed
            in the TOC. This feature enables you to change your view of the TOC, depending on whether
            you would rather see an overview of the report or focus on any given chapter in greater
            depth.
        • Scroll Bar: Another online navigation feature can be accessed from the scroll bar to the right
            of your document window. By dragging the scroll bar, you can easily navigate through the
            entire document page by page. If you continue to press the mouse button while dragging the
            scroll bar, Acrobat Reader will list each page number as you scroll. This feature is helpful if
            you are searching for a specific page reference.
        • Text-Based Searching: The PDF format also offers online text-based searching capabilities.
            This can be a great asset if you are searching for references to a specific type of technology
            or any other elements within the report.
        • Reader Guide: To further explore the benefits of the PDF file format, please consult the
            Reader Guide available from the Help menu.


---

## Frictionless Data Package Metadata

> Auto-generated by Archival Ingest Skill v16

### Study Record

| Field | Value |
|-------|-------|
| study_id | ra-enterprise-apps-312ba4 |
| title | Achieving More Value from Enterprise Applications |
| author | Peter S. Kastner, Aberdeen Group |
| date | 2006-05 |
| type | employer-record |
| subject_domain | Enterprise Application Integration/SOA |
| methodology | Survey benchmark (online survey + telephone interviews; Jan-Mar 2006; Aberdeen PACE methodology; Aberdeen Competitive Framework) |
| source_file | source/_raw_text.txt |
| license | CC-BY-4.0 |

### Abstract

Enterprise application silos connected by inadequate integration software ('duct tape, chewing gum, and string'). If Industry Average IT ran at Best in Class cost-efficiency, $143 billion in 2006 savings would be generated; $20 billion readily achievable. SOA technologies (web services, XML, open middleware) seen by at least two-thirds of respondents as means to improve enterprise application integration. Survey covers discrete/process manufacturing, consumer, services, and government sectors. Aberdeen Competitive Framework used.

### Document Assessment

| Dimension | Rating | Rationale |
|-----------|--------|-----------|
| **Importance** | 4 | Key 2006 benchmark establishing SOA-for-enterprise-integration value proposition; $143B savings claim is striking; authored by Kastner (Aberdeen co-founder). Covers ERP/CRM/SCM integration challenges. |
| **Relevance** | 4 | Rich data on enterprise application integration stumbling blocks, SOA technology adoption patterns, ROI metrics, industry-vertical breakdowns, and company-size-based differences in integration strategy. |
| **Prescience** | 4 | Correctly identified SOA-enabled ISV applications (SAP, Oracle, etc.) as necessary but insufficient; BPM with machine-in-loop as next stage; ESB/BPM as core infrastructure needs. Prescient on master data management importance. |

### Prescience Detail

This study did not make forward-looking claims.

### Entities Referenced (6)

| Entity | Type | Status | Successor |
|--------|------|--------|-----------|
| Peter S. Kastner | person | active |  |
| Aberdeen Group | organization | acquired |  |
| FlexiInternational Software Inc. | organization | acquired |  |
| Made2Manage Systems Inc. | organization | acquired |  |
| SoftBrands Inc. | organization | acquired |  |
| Enterprise Strategies Newsletters | organization | inactive |  |

### Technologies Referenced (21)

| Technology | Category | Vendor | Lifecycle (at study) | Lifecycle (current) |
|------------|----------|--------|---------------------|---------------------|
| SOA-Enabled ERP Applications | enterprise-application | vendor-neutral | emerging | mature |
| Enterprise Application Integration (EAI) | middleware | vendor-neutral | mature | legacy |
| Web Services | standards | vendor-neutral | growth | mature |
| Built-in Open Middleware for Integration | middleware | vendor-neutral | growth | mature |
| XML Standards | standards | vendor-neutral | growth | mature |
| Business Process Execution and Manipulation Across Processes | bpm | vendor-neutral | growth | mature |
| Advanced Business Intelligence Manipulations | analytics | vendor-neutral | growth | mature |
| Open Messaging-Based Architecture | middleware | vendor-neutral | growth | mature |
| Business Process Modeling | bpm | vendor-neutral | growth | mature |
| Rule-Based Toolset for Configuring Changes | bpm | vendor-neutral | growth | mature |
| Event-Driven Architecture | architecture | vendor-neutral | emerging | mature |
| Operating in Heterogeneous Environment | architecture | vendor-neutral | growth | mature |
| Best-of-Breed Functionality | application-strategy | vendor-neutral | growth | mature |
| Overall Compliance within an SOA Infrastructure | standards | vendor-neutral | emerging | mature |
| Composite Applications Interoperability | architecture | vendor-neutral | emerging | mature |
| Master Data Management Tools | data-management | vendor-neutral | emerging | mature |
| Business Activity Monitoring (BAM) | analytics | vendor-neutral | emerging | mature |
| Enterprise Service Bus (ESB) | middleware | vendor-neutral | growth | mature |
| FlexiSmartClient Suite | application | FlexiInternational | niche | legacy |
| Made2Manage ERP | application | Made2Manage Systems | niche | legacy |
| SoftBrands Manufacturing ERP | application | SoftBrands | niche | legacy |

### Observation Summary

- Total observations: 82
- By type: survey-finding: 65, adoption-rate: 13, analyst-finding: 4
